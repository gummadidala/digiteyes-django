#!/bin/bash

echo "Updating services.."
for i in `cat image-versions.txt`
do
	echo $i
	image=`echo $i | cut -f1 -d"="`
	version=`echo $i | cut -f2 -d"="`
	echo "Updating ..." $image
	imageTag=""
	tag=$image
	if [ $tag == 'app' ] 
	then
        	imageTag="digiteyes91/adiotserver"
	elif [ $tag == 'beat' ]
	then
       		 imageTag="digiteyes91/adiotbeat"
	elif [ $tag == 'celery' ]
	then
       	 	imageTag="digiteyes91/adiotcelery"
	elif [ $tag == 'web' ]
	then 
        	imageTag="digiteyes91/adiotloadbalancer"
	elif [ $tag == 'mysqldb' ]
	then 
        	imageTag="digiteyes91/db"
	elif [ $tag == 'front' ]
	then 
        	imageTag="digiteyes91/front"
	fi 
	fullTag=$imageTag":"$version
	sudo docker service update --image=$fullTag $tag
done
