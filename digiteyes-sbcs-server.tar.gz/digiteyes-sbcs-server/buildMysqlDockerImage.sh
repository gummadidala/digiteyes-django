#!/bin/bash
sudo docker build --file=MySQLDockerFile  . -t digiteyes91/db:2.0
