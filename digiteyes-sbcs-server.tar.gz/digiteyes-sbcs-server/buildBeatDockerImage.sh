#!/bin/bash
sudo docker build --file=BeatDockerfile  . -t digiteyes91/adiotbeat:2.0
