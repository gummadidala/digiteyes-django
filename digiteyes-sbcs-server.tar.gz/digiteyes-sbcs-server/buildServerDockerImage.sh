#!/bin/bash
if [ $# -gt 0 ] 
then
  version="$1"
else
  version="2.0.6"
fi
tag=digiteyes91/adiotserver:$version
echo "Building Image :" $tag
sudo docker build . -t $tag
echo "Done."
