#!/bin/bash
python manage.py showmigrations -p | grep '\[X\]' > /tmp/migrations-list-completed
migrationsDone=`cat /tmp/migrations-list-completed | wc -l `
rm /tmp/migrations-list-completed
fake_initial=""
echo "No of Migrations already applied = "$migrationsDone > /var/log/startup.log
if [ $migrationsDone -eq 0 ] 
then
	fake_initial="--fake-initial"
fi
python manage.py showmigrations -p | grep '\[ \]' >> /tmp/migrations-list
migrations=`cat /tmp/migrations-list | wc -l`
echo "No of Migrations to be applied = "$migrations >> /var/log/startup.log
if [ $migrations -ne 0 ]
then  
	if [ ! -f /var/log/migrations.pid ]
	then 
		touch /var/log/migrations.pid
		echo "-----------------------------" >> /var/log/startup.log
		echo "Running Migrations" >> /var/log/startup.log
		echo "------------------------------" >> /var/log/startup.log
		sed -e 's/ //g' /tmp/migrations-list | sed -e 's/\[\]//g' > /var/log/cleaned-list
		for migration in `cat /var/log/cleaned-list`
		do
			app=`echo $migration | cut -f1 -d"."`
			actual_migration=`echo $migration | cut -f2 -d"."`
			echo $app:$actual_migration $fake_initial >> /var/log/startup.log
			python manage.py migrate --verbosity 3 --traceback $app $actual_migration >> /var/log/startup.log 
			fake_initial=""
		done
		rm /var/log/migrations.pid
		rm /tmp/migrations-list
		echo "-----------------------------" >> /var/log/startup.log
		echo " Migrations done"
		echo "------------------------------" >> /var/log/startup.log
	else 
		# Migrations going on.. Wait...
		echo "-----------------------------" >> /var/log/startup.log
		echo " Waiting for Migrations to complete..." >> /var/log/startup.log
		echo "-----------------------------" >> /var/log/startup.log
		while [ -f /var/log/migrations.pid ]
		do
			sleep 10s
		done
	fi	
fi
echo "---------------------------" >> /var/log/startup.log
echo " Starting Gunicorn" >> /var/log/startup.log
echo "---------------------------" >> /var/log/startup.log
gunicorn bbplatform.wsgi:application -w 2 --bind :$BIND_PORT --log-file /var/log/gunicorn-log.log \
	 --error-log /var/log/gunicorn-error.log --log-level "debug" \
	 --capture-output  --enable-stdio-inheritance 
