#!/bin/bash
sudo docker build --file=CeleryDockerFileMod . -t digiteyes91/adiotcelery:2.3
