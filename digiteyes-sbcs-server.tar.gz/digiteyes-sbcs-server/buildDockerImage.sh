#!/bin/bash
if [ $# -eq 0 ]
then
  echo " Usage : buildDockerImage.sh tagName [fileName]"
  exit
fi
tag=$1
versionTag=`grep $tag image-versions.txt`
#echo $versionTag
currentVersion=`echo $versionTag | cut -f2 -d"="`
echo "Current Version :" $currentVersion
lastDigit=`echo $currentVersion | cut -f3 -d"."`
#echo $lastDigit
newVersion=`expr $lastDigit + 1`
#echo $newVersion
major=`echo $currentVersion | cut -f1 -d"."`
minor=`echo $currentVersion | cut -f2 -d"."`
newFullVersion=$major"."$minor"."$newVersion
echo "New Version to be built :" $newFullVersion
imageTag=""
dockerFile=""
if [ $tag == 'app' ] 
then
	imageTag="digiteyes91/adiotserver"
	dockerFile="Dockerfile"
elif [ $tag == 'beat' ]
then 
	imageTag="digiteyes91/adiotbeat"
	dockerFile="BeatDockerfile"
elif [ $tag == 'celery' ]
then 
	imageTag="digiteyes91/adiotcelery"
	dockerFile="CeleryDockerFileMod"
elif [ $tag == 'loadbalancer' ]
then 
	imageTag="digiteyes91/adiotloadbalancer"
	dockerFile="LoadBalancerDockerFile"
elif [ $tag == 'mysqldb' ]
then 
	imageTag="digiteyes91/db"
	dockerFile="MySQLDockerFile"
elif [ $tag == 'front' ]
then 
	imageTag="digiteyes91/front"
	dockerFile="FrontLoadBalancerDockerFile"
fi
#echo $imageTag
fullTag=$imageTag":"$newFullVersion
echo "New Image :" $fullTag
./buildAndPushDockerImage.sh $fullTag $dockerFile 
newVersionTag=$tag"="$newFullVersion
echo $newVersionTag
echo $versionTag
#Now update the versions file
echo "Updating versions file..."
sed -i -- "s/$versionTag/$newVersionTag/g" image-versions.txt
echo "Done"

