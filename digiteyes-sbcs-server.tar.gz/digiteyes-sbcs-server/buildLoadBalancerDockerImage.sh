#!/bin/bash
sudo docker build --file=LoadBalancerDockerFile . -t digiteyes91/adiotloadbalancer:2.0
