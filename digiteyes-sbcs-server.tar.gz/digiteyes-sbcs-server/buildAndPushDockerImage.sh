#!/bin/bash
if [ $# -eq 0 ]
then
  echo " Usage : buildAndPushDockerImage.sh tagName [fileName]"
  exit
fi
tag=$1
echo "Building Image :" $tag
if [ $# -eq 2 ]
then
  fileName=$2
  echo "Using DockerFile : " $fileName
fi
if [ $# -eq 2 ]
then 
  sudo docker build --file=$fileName .  -t $tag
else
  sudo docker build . -t $tag
fi
echo "Done."
echo "Pushing Image :" $tag
sudo docker push $tag
echo "Done."

