#!/bin/sh
python manage.py showmigrations -p | grep '\[X\]' > /tmp/migrations-list-completed
migrationsDone=`cat /tmp/migrations-list-completed | wc -l `
rm /tmp/migrations-list-completed
fake_initial=""
echo "No of Migrations already applied = "$migrationsDone
if [ $migrationsDone -eq 0 ] 
then
	fake_initial="--fake-initial"
fi
python manage.py showmigrations -p | grep '\[ \]' > /tmp/migrations-list
migrations=`cat /tmp/migrations-list | wc -l`
echo "No of Migrations to be applied = "$migrations
if [ $migrations -ne 0 ]
then  
	if [ ! -f /var/log/migrations.pid ]
	then 
		touch /var/log/migrations.pid
		echo "-----------------------------"
		echo "Running Migrations"
		echo "------------------------------"
		sed -e 's/ //g' /tmp/migrations-list | sed -e 's/\[\]//g' > /var/log/cleaned-list
		for migration in `cat /var/log/cleaned-list`
		do
			app=`echo $migration | cut -f1 -d"."`
			actual_migration=`echo $migration | cut -f2 -d"."`
			echo $app:$actual_migration $fake_initial
			python manage.py migrate $app $actual_migration 
			fake_initial=""
		done
		rm /var/log/migrations.pid
		rm /tmp/migrations-list
		echo "-----------------------------"
		echo " Migrations done"
		echo "------------------------------"
	else 
		# Migrations going on.. Wait...
		echo "-----------------------------"
		echo " Waiting for Migrations to complete..."
		echo "-----------------------------"
		while [ -f /var/log/migrations.pid ]
		do
			sleep 10s
		done
	fi	
fi
