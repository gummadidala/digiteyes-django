from __future__ import absolute_import
from datetime import timedelta,datetime
from celery.schedules import crontab
import logging.config
import json
#: Only add pickle to this list if your broker is secured
#: from unwanted access (see userguide/security.html)
################################################################################
LOGGING_CONFIG = None
LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    'filters': {
        'require_debug_false': {
            '()': 'django.utils.log.RequireDebugFalse',
        },
        'require_debug_true': {
            '()': 'django.utils.log.RequireDebugTrue',
        },
    },
    'formatters': {
        'simple': {
            'format': '[%(asctime)s] %(levelname)s %(message)s',
        'datefmt': '%Y-%m-%d %H:%M:%S'
        },
        'verbose': {
            'format': '[%(asctime)s] %(levelname)s [%(name)s.%(funcName)s:%(lineno)d] %(message)s',
        'datefmt': '%Y-%m-%d %H:%M:%S'
        },
    },
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'filters': ['require_debug_true'],
            'class': 'logging.StreamHandler',
            'formatter': 'simple'
        },
        'development_logfile': {
            'level': 'DEBUG',
            'class': 'cloghandler.ConcurrentRotatingFileHandler',
            'maxBytes': 1024*1024*10, # 5 MB
            'backupCount': 5,
            'filename': '/var/log/adiot_server.log',
            'formatter': 'verbose'
        },
        'production_logfile': {
            'level': 'INFO',
            'filters': ['require_debug_false',],
            'class': 'cloghandler.ConcurrentRotatingFileHandler',
            'maxBytes': 1024*1024*10, # 5 MB
            'backupCount': 5,
            'filename': '/var/log/adiot_server.log',
            'formatter': 'simple'
        },
         'development_task_logfile': {
            'level': 'DEBUG',
            'class': 'cloghandler.ConcurrentRotatingFileHandler',
            'maxBytes': 1024*1024*10, # 5 MB
            'backupCount': 5,
            'filename': '/var/log/adiot_tasks.log',
            'formatter': 'verbose'
        },
        'production_task_logfile': {
            'level': 'INFO',
            'filters': ['require_debug_false',],
            'class': 'cloghandler.ConcurrentRotatingFileHandler',
            'maxBytes': 1024*1024*10, # 5 MB
            'backupCount': 5,
            'filename': '/var/log/adiot_tasks.log',
            'formatter': 'simple'
        },
        'dba_logfile': {
            'level': 'DEBUG',
	    'class': 'cloghandler.ConcurrentRotatingFileHandler',
            'maxBytes': 1024*1024*10, # 5 MB
            'backupCount': 5,
            'filename': '/var/log/django_dba.log',
            'formatter': 'simple'
        },
    },
    'loggers': {
        'django.request': {
            'handlers': ['development_logfile','production_logfile'],
            'level' : 'DEBUG',
            'propagate': False,
        },
        'django.db': {
            'handlers': ['dba_logfile',],
            'level' : 'DEBUG',
            'propagate': False,
        },
        'django': {
            'handlers': ['development_logfile','production_logfile'],
            'level' : 'DEBUG',
            'propagate': False,
        },      
        'boardcontentmgmt': {
            'handlers': ['development_logfile','production_logfile'],
            'level' : 'DEBUG',
            'propagate': False,
         },
        'testdata': {
            'handlers': ['development_logfile','production_logfile'],
            'level' : 'DEBUG',
            'propagate': False,
         },
        'affiliateads': {
            'handlers': ['development_logfile','production_logfile'],
            'level' : 'DEBUG',
            'propagate': False,
         },
        'affiliateads.tasks': {
            'handlers': ['development_task_logfile','production_task_logfile'],
            'level' : 'DEBUG',
            'propagate': False,
         },
        'boardcontentmgmt.tasks': {
            'handlers': ['development_task_logfile','production_task_logfile'],
            'level' : 'DEBUG',
            'propagate': False,
         },
        'boardcontentmgmt.taskprocessors': {
            'handlers': ['development_task_logfile','production_task_logfile'],
            'level' : 'DEBUG',
            'propagate': False,
         },
        'py.warnings': {
            'handlers': ['development_logfile'],
        },
    },  
}
################################################################################
# Celery Configuration.
BROKER_URL = 'redis://localhost:6379/0'
CELERY_ACCEPT_CONTENT = ['json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
################################################################################
CELERYBEAT_SCHEDULER = "djcelery.schedulers.DatabaseScheduler"
CELERYBEAT_SCHEDULE = {
    #calling allocation algorithm, CampaignReport daily at midnight 12:00 A.M
    'Call_AllocationAlgorithm': {
        'task': 'boardcontentmgmt.tasks.Call_AllocationAlgorithm',
        #'schedule': timedelta(seconds=60),
        #'schedule': crontab(hour=0, minute=0),
        'schedule': crontab(minute=30,hour='5,7,9,11,13,15,17,19'),
        #'schedule': crontab(minute=30,hour=[5,9,11,13,15,19]),
    },
    'CampaignReport': {
        'task': 'boardcontentmgmt.tasks.CampaignReport',
        #'schedule': timedelta(seconds=60)
        'schedule': crontab(hour=3, minute=0),
    },
    'PullAffiliateContents': {
        'task': 'affiliateads.tasks.load_all_affiliate_contents_automatic',
        'schedule': crontab(hour=20, minute=0),
    },
    'ServiceNotification': {
        'task': 'boardcontentmgmt.tasks.ServiceNotification',
        'schedule': crontab(minute='*/5')
    },
    'GetLatestNews': {
        'task': 'affiliateads.tasks.pull_news_latest',
        'schedule': crontab(minute=0,hour='8,14'),
    },
    'ScreenAvailabilityStatistics': {
        'task': 'boardcontentmgmt.tasks.ScreenAvailabilityStatistics',
        'schedule': crontab(hour=2, minute=0),
    },
    'NoPlayCredit': {
        'task': 'boardcontentmgmt.tasks.NoPlayCredit',
        'schedule': crontab(hour=2, minute=0),
    },
    'UnblockBookedAdPacks': {
        'task': 'boardcontentmgmt.tasks.UnblockBookedAdPacks',
        'schedule': crontab(minute='*/5')
    },
    'CreateCampaignWifiCount': {
        'task': 'boardcontentmgmt.tasks.create_campaign_wificount',
        'schedule': crontab(hour=0, minute=0),
    },
    'ATVPowerOff' : {
        'task' : 'boardcontentmgmt.tasks.power_off_ATV',
        'schedule' : crontab(hour=0, minute=0),
    },
    'ATVPowerOn' : {
        'task' : 'boardcontentmgmt.tasks.power_on_ATV',
        'schedule' : crontab(hour=5, minute=0),
    }
}
################################################################################
CELERY_RESULT_BACKEND = "amqp"
CELERY_IMPORTS = ("boardcontentmgmt.tasks", 
                  "affiliateads.tasks")
################################################################################
"""
Django settings for bbplatform project.

Generated by 'django-admin startproject' using Django 1.8.2.

For more information on this file, see
https://docs.djangoproject.com/en/1.8/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/1.8/ref/settings/
"""

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)

import os


BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))




# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.8/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'm8ko=2aw57j5#*vi=-t%w1@z*gqhd1wekku-1rb^tz@@z=(x-#'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = ["www.adiot.in","djangoapps","localhost"]

#AWS Settings
AWS_ACCESS_KEY_ID = 'AKIAIU5QBFMYBBQ4DM4Q'
AWS_SECRET_ACCESS_KEY = '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'
AWS_STORAGE_BUCKET_NAME = 'ruga-boardcontentmgmt-uploaded-media-content'
AWS_QUERYSTRING_AUTH = False
AWS_HEADERS = {
  'Cache-Control': 'max-age=86400',
}
DEFAULT_FILE_STORAGE = 'storages.backends.s3boto.S3BotoStorage'
################################################################################
# Application definition
INSTALLED_APPS = (
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework_swagger',
    'rest_framework',
    'rest_framework.authtoken',
    'storages',
    'djcelery',
    'boardcontentmgmt',
    'testdata',
    'affiliateads',
)
################################################################################
#PAYU_MERCHANT_KEY = "gtKFFx",
#PAYU_MERCHANT_SALT = "eCwWELxi",
# And add the PAYU_MODE to 'TEST' for testing and 'LIVE' for production.
#PAYU_MODE = "TEST"
################################################################################
MIDDLEWARE_CLASSES = (
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'request_logging.middleware.LoggingMiddleware',
    'boardcontentmgmt.TokenLoggingMiddleware.AuthMiddleware',
    'audit_log.middleware.UserLoggingMiddleware',

)
################################################################################
REST_FRAMEWORK = {
    'DEFAULT_FILTER_BACKENDS': ('rest_framework.filters.DjangoFilterBackend',),
    'DEFAULT_PAGINATION_CLASS' : 'rest_framework.pagination.PageNumberPagination',
    'PAGE_SIZE': 10,
    
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework.authentication.SessionAuthentication',
        #'rest_framework.authentication.TokenAuthentication',
        'boardcontentmgmt.permissionsmgmt.expirytokenauthentication.ExpiringTokenAuthentication',
    ),
   
}
################################################################################
ROOT_URLCONF = 'bbplatform.urls'
################################################################################
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]
################################################################################
WSGI_APPLICATION = 'bbplatform.wsgi.application'
################################################################################
# Database
# https://docs.djangoproject.com/en/1.8/ref/settings/#databases
DATABASES = {
    'backup': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    },
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME' : 'version_2_5_0',
        'USER' : 'de-dbuser',
        'PASSWORD' : 'db1234',
        'HOST': 'mysqldb',
        'PORT': '3306',
        #'OPTIONS': {
         #   'read_default_file': 'bbplatform/mysql.cnf',
        #},
    }
}
################################################################################
# Internationalization
# https://docs.djangoproject.com/en/1.8/topics/i18n/
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Kolkata'
USE_I18N = True
USE_L10N = True
USE_TZ = False
################################################################################

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.8/howto/static-files/

STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR,'static')

ANONYMOUS_USER_ID = -1

AUTHENTICATION_BACKENDS = (
    'django.contrib.auth.backends.ModelBackend', # this is default
    #'guardian.backends.ObjectPermissionBackend',
)

ENTITLEMENTS = -1

#STATICFILES_DIRS = (
#    os.path.join(BASE_DIR, "static"),
#)
################################################################################
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.zoho.com'
EMAIL_PORT = 465
EMAIL_HOST_USER = 'info@digiteyes91.com'
EMAIL_HOST_PASSWORD = 'info1234'
EMAIL_USE_SSL = True
DEFAULT_FROM_EMAIL = EMAIL_HOST_USER
################################################################################
HOSTING_SERVER = 'https://www.adiot.in/'
################################################################################
DE_logo_url = "https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/DE91_full.jpg"
Adiot_logo_url = "https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/Adiot-logo.jpg"
DE_logo_white="https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/DE91_full_white.jpg"
flipkart_logo_url = "https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/flipkart_logo_detail.jpg"
amazon_logo_url = "https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/Amazon_Logo.png"
jabong_logo_url = "https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/Jabong_logo.png"
limeroad_logo_url = "https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/limeroad-logo.png"
nnnow_logo_url = "https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/NNNOW_Logo.jpg"
ie_logo_url="https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/Indian_express.png"
fb_events="https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/events%2B2.jpg"
################################################################################
AWS = True
AZURE = False
