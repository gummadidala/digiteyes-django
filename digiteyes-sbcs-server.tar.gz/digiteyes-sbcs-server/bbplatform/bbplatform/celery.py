from __future__ import absolute_import

import os

from celery import Celery
from celery.schedules import crontab
from datetime import timedelta

# set the default Django settings module for the 'celery' program.
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'bbplatform.settings')

from django.conf import settings  # noqa

app = Celery('bbplatform')

# Using a string here means the worker will not have to
# pickle the object when using Windows.
app.config_from_object('django.conf:settings')
app.autodiscover_tasks(lambda: settings.INSTALLED_APPS)

# CELERYBEAT_SCHEDULE = {
#     # Executes every Monday morning at 7:30 A.M
#     'add-every-monday-morning': {
#         'task': 'boardcontentmgmt.tasks.allocate_bookings',
#         'schedule': timedelta(seconds=60),
#     },
# }

CELERYBEAT_SCHEDULE = {
    #calling allocation algorithm daily at midnight
    'Call_AllocationAlgorithm': {
        'task': 'boardcontentmgmt.tasks.Call_AllocationAlgorithm',
        'schedule': timedelta(seconds=90),
         #'schedule': crontab(minute=2),
    },
  }

@app.task(bind=True)
def debug_task(self):
    print('Request: {0!r}'.format(self.request))