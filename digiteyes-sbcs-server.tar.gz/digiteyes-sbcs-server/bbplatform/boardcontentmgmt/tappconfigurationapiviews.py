from rest_framework import generics

from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters
import django_filters
from boardcontentmgmt.models import TappConfiguration,AccountUser
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from rest_framework import serializers

class TappConfigurationSerializer(serializers.ModelSerializer):
    class Meta:
        model = TappConfiguration
        fields = ('app_version','key','parameter','value')

class TappConfigurationFilter(django_filters.FilterSet):
    app_version = django_filters.CharFilter(name='app_version',lookup_type='exact')
    class Meta:
        model = TappConfiguration
	fields = ('app_version',)
#################################################################################
# DeviceAppConfigurationListView
#################################################################################
class TappConfigurationListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = TappConfigurationSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('app_version', )
    filter_class = TappConfigurationFilter
    search_fields = ('app_version',)
    lookup_field = 'key'
    def get_queryset(self):
        return TappConfiguration.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return TappConfigurationSerializer
        return TappConfigurationSerializer
#################################################################################
# DeviceAppConfigurationUpdateView
#################################################################################
class TappConfigurationUpdateView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = TappConfigurationSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('app_version', )
    filter_class = TappConfigurationFilter
    search_fields = ('app_version',)
    lookup_field = 'key'
    def get_queryset(self):
        return TappConfiguration.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return TappConfigurationSerializer
        return TappConfigurationSerializer
