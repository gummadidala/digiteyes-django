from __future__ import division
from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework import filters
from boardcontentmgmt.models import DiscountCoupon,AccountUser,Account,MyOrder,BookedAdPack,BookedDayPack,PromoParam
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from datetime import datetime,timedelta
import time,calendar
import sys,traceback
from .discountcouponserializers import DiscountCouponSerializer
from pyparsing import infixNotation, opAssoc, Keyword, Word, alphas,alphanums
import logging
logger = logging.getLogger(__name__)

class BoolOperand(object):
    def __init__(self,t):
        self.label = t[0]
        self.value = eval(t[0])
    def __bool__(self):
        return self.value
    def __str__(self):
        return self.label
    __repr__ = __str__
    __nonzero__ = __bool__

class BoolBinOp(object):
    def __init__(self,t):
        self.args = t[0][0::2]
    def __str__(self):
        sep = " %s " % self.reprsymbol
        return "(" + sep.join(map(str,self.args)) + ")"
    def __bool__(self):
        return self.evalop(bool(a) for a in self.args)
    __nonzero__ = __bool__
    __repr__ = __str__

class BoolAnd(BoolBinOp):
    reprsymbol = '&'
    evalop = all

class BoolOr(BoolBinOp):
    reprsymbol = '|'
    evalop = any

class BoolNot(object):
    def __init__(self,t):
        self.arg = t[0][1]
    def __bool__(self):
        v = bool(self.arg)
        return not v
    def __str__(self):
        return "~" + str(self.arg)
    __repr__ = __str__
    __nonzero__ = __bool__

TRUE = Keyword("True")
FALSE = Keyword("False")
boolOperand = TRUE | FALSE | Word(alphanums,max=20)
boolOperand.setParseAction(BoolOperand)

boolExpr = infixNotation( boolOperand,
    [
    ("not", 1, opAssoc.RIGHT, BoolNot),
    ("and", 2, opAssoc.LEFT,  BoolAnd),
    ("or",  2, opAssoc.LEFT,  BoolOr),
    ])

def validate_condition_expression(cpn):
    try:
        logger.info("VALIDATE_COUPON_STATS : Validation_String : "+str(cpn.condition_expression))
        if cpn.condition_expression != "":
            res = boolExpr.parseString(cpn.condition_expression)[0]
            logger.info("VALIDATE_COUPON_STATS : Final_Validation_Result : "+str(bool(res)))
            return bool(res)
        else:
            logger.info("VALIDATE_COUPON_STATS : Final_Validation_Result : "+str(True))
            return True
    except:
        logger.error ("VALIDATE_COUPON_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("VALIDATE_COUPON_ERROR "+str(tb))
        return False

def single_value_condition(value1,value2,op):
    logger.info("value1 : "+str(value1)+" value2 : "+str(value2)+" op : "+str(op))
    check = True
    if op == 'LTE':
        if value1 <= value2:
            pass
        else:
            check = False
    elif op == 'GTE':
        if value1 >= value2:
            pass
        else:
            check = False
    elif op == 'E':
        if value1 == value2:
            pass
        else:
            check = False
    elif op == 'NE':
        if value1 != value2:
            pass
        else:
            check = False
    logger.info("RETURNING : "+str(check))
    return check

def multi_value_condition(val,values):
    check = True
    if val not in values:
        check = False
    return check


'''
class ConditionEvaluator:
    print 'In class ConditionEvaluator'
    def __init__(self, name):
        self.name = name
    def evaluate_condition(self,odr,cndtn):
        pass
'''
class PackNameEvaluator():  
    def evaluate_condition(self,odr,cndtn,cpn):
        #print cndtn.parameter.name, cndtn.operator
        values = cndtn.value.split(',')
        pack_name = ""
        if odr.item_type.name == 'DayPack':
            pck = BookedDayPack.objects.filter(key = odr.items.split(',')[0])[0]
            pack_name = pck.day_pack.name
        return multi_value_condition(pack_name,values)
class ChannelNameEvaluator(): 
    def evaluate_condition(self,odr,cndtn,cpn):
        #print cndtn.parameter.name, cndtn.operator
        values = cndtn.value.split(',')
        channel_name = ""
        if odr.item_type.name == 'MasterAdPack':
            pck = BookedAdPack.objects.filter(key = odr.items.split(',')[0])[0]
            channel_name = pck.booked_screen.show_spot.attached_attribute_tag.name
        elif odr.item_type.name == 'DayPack':
            pck = BookedDayPack.objects.filter(key = odr.items.split(',')[0])[0]
            channel_name = pck.booked_screen_groups.all()[0].name
        return multi_value_condition(channel_name,values)
class CurrentMonthEvaluator(): 
    def evaluate_condition(self,odr,cndtn,cpn):
        values = cndtn.value.split(',')
        #print cndtn.parameter.name, cndtn.operator
        curr_month_name = calendar.month_name[datetime.today().month]
        return multi_value_condition(curr_month_name,values)
class MonthBookedForEvaluator(): 
    def evaluate_condition(self,odr,cndtn,cpn):
        values = cndtn.value.split(',')
        #print cndtn.parameter.name, cndtn.operator
        month_name_booked_for = calendar.month_name[datetime.today().month]
        if odr.item_type.name == 'MasterAdPack':
            pck = BookedAdPack.objects.filter(key = odr.items.split(',')[0])[0]
            month_name_booked_for = calendar.month_name[pck.date_booked_for.month]
        elif odr.item_type.name == 'DayPack':
            pck = BookedDayPack.objects.filter(key = odr.items.split(',')[0])[0]
            month_name_booked_for = calendar.month_name[pck.date_booked_for.month]
        return multi_value_condition(month_name_booked_for,values)
class CurrentDayOfWeekEvaluator(): 
    def evaluate_condition(self,odr,cndtn,cpn):
        values = cndtn.value.split(',')
        #print cndtn.parameter.name, cndtn.operator
        day_name = calendar.day_name[datetime.today().weekday()]
        return multi_value_condition(day_name,values)
class DayOfWeekBookedForEvaluator(): 
    def evaluate_condition(self,odr,cndtn,cpn):
        values = cndtn.value.split(',')
        #print cndtn.parameter.name, cndtn.operator
        day_name_booked_for = calendar.day_name[datetime.today().weekday()]
        if odr.item_type.name == 'MasterAdPack':
            pck = BookedAdPack.objects.filter(key = odr.items.split(',')[0])[0]
            day_name_booked_for = calendar.day_name[pck.date_booked_for.weekday()]
        elif odr.item_type.name == 'DayPack':
            pck = BookedDayPack.objects.filter(key = odr.items.split(',')[0])[0]
            day_name_booked_for = calendar.day_name[pck.date_booked_for.weekday()]
        return multi_value_condition(day_name_booked_for,values)
class ExpiryDateEvaluator(): 
    def evaluate_condition(self,odr,cndtn,cpn):
        #print cndtn.parameter.name, cndtn.operator
        cndtn_date = datetime.strptime(cndtn.value,"%Y-%m-%d")
        return single_value_condition(datetime.now().date(),cndtn_date,cndtn.operator.value)
class DateBookedForEvaluator(): 
    def evaluate_condition(self,odr,cndtn,cpn):
        #print cndtn.parameter.name, cndtn.operator
        cndtn_date = datetime.strptime(cndtn.value,"%Y-%m-%d")
        date_booked_for = datetime.now().date()
        if odr.item_type.name == 'MasterAdPack':
            pck = BookedAdPack.objects.filter(key = odr.items.split(',')[0])[0]
            date_booked_for = pck.date_booked_for
        elif odr.item_type.name == 'DayPack':
            pck = BookedDayPack.objects.filter(key = odr.items.split(',')[0])[0]
            date_booked_for = pck.date_booked_for
        return single_value_condition(date_booked_for,cndtn_date,cndtn.operator.value)
class TotalPriceEvaluator(): 
    def evaluate_condition(self,odr,cndtn,cpn):
        #print cndtn.parameter.name
        return single_value_condition(odr.actual_amount,int(cndtn.value),cndtn.operator.value)
class NumUnitsEvaluator(): 
    def evaluate_condition(self,odr,cndtn,cpn):
        #print cndtn.parameter.name, cndtn.operator
        num_units = 0
        if odr.item_type.name == 'MasterAdPack':
            pck = BookedAdPack.objects.filter(key = odr.items.split(',')[0])[0]
            num_units = pck.units_per_play  
        elif odr.item_type.name == 'DayPack':
            pck = BookedDayPack.objects.filter(key = odr.items.split(',')[0])[0]
            num_units = pck.units_per_play      
        return single_value_condition(num_units,int(cndtn.value),cndtn.operator.value)
class NumItemsEvaluator(): 
    def evaluate_condition(self,odr,cndtn,cpn):
        #print cndtn.parameter.name, cndtn.operator
        num_items = len(odr.items.split(','))
        return single_value_condition(num_items,int(cndtn.value),cndtn.operator.value)
class UsagePerAccountEvaluator():
    def evaluate_condition(self,odr,cndtn,cpn):
        usage = len(MyOrder.objects.filter(applied_coupon__key=cpn.key,account__key = odr.account.key,
                                            status__name__in=['INITIATED','BLOCKED','SUCCESS']))
        logger.info("UsagePerAccountEvaluator : Num_times_used : "+str(usage+1))
        return single_value_condition(usage+1,int(cndtn.value),cndtn.operator.value)
    
    
class BookedSlotsPerDayEvaluator():
    def evaluate_condition(self,odr,cndtn,cpn):
        try:
            if odr.item_type.name == 'MasterAdPack':
                pck = BookedAdPack.objects.filter(key = odr.items.split(',')[0])[0]
                dates_booked_for = pck.applied_to.planned_dates.all()
            elif odr.item_type.name == 'DayPack':
                pck = BookedDayPack.objects.filter(key = odr.items.split(',')[0])[0]
                dates_booked_for = pck.applied_to.planned_dates.all()
            planned_dates = []
            for obj in dates_booked_for:
                planned_dates.append(obj.date)
            for pd in planned_dates:
                slots_booked_for_day = 0
                bookedadpacks = BookedAdPack.objects.filter(account__key=odr.account.key,
                                                            date_booked_for=pd,
                                                            booking_state__name__in=['INITIATED','BLOCKED','SUCCESS'])
                if bookedadpacks is not None and len(bookedadpacks)>0:
                    for bap in bookedadpacks:
                        slots_booked_for_day = slots_booked_for_day + (bap.num_plays*bap.units_per_play*bap.unit_size/30)            
                        logger.info('slots_booked_for_day : '+str(slots_booked_for_day))
                res = single_value_condition(slots_booked_for_day,int(cndtn.value),cndtn.operator.value)
                if not res:
                    logger.error("slots_booked_for_day : "+str(pd) +"are : "+str(slots_booked_for_day)+
                                 "exceeding the limit of : "+str(int(cndtn.value)))
                    return False
            return True
        except:
            return False
class NumWeekDaysEvaluator():
    def evaluate_condition(self,odr,cndtn,cpn):
        if odr.item_type.name == 'MasterAdPack':
            pck = BookedAdPack.objects.filter(key = odr.items.split(',')[0])[0]
            dates_booked_for = pck.applied_to.planned_dates.all()
        elif odr.item_type.name == 'DayPack':
            pck = BookedDayPack.objects.filter(key = odr.items.split(',')[0])[0]
            dates_booked_for = pck.applied_to.planned_dates.all()
        planned_dates = []
        for obj in dates_booked_for:
            planned_dates.append(obj.date)
        week_day_count = 0
        for dt in planned_dates:
            if dt.weekday() ==0 or dt.weekday() == 1 or  dt.weekday() ==2 or dt.weekday() == 3:
                week_day_count = week_day_count + 1
        return single_value_condition(week_day_count,int(cndtn.value),cndtn.operator.value)
class NumWeekEndDaysEvaluator():
    def evaluate_condition(self,odr,cndtn,cpn):
        if odr.item_type.name == 'MasterAdPack':
            pck = BookedAdPack.objects.filter(key = odr.items.split(',')[0])[0]
            dates_booked_for = pck.applied_to.planned_dates.all()
        elif odr.item_type.name == 'DayPack':
            pck = BookedDayPack.objects.filter(key = odr.items.split(',')[0])[0]
            dates_booked_for = pck.applied_to.planned_dates.all()
        planned_dates = []
        for obj in dates_booked_for:
            planned_dates.append(obj.date)
        weekend_day_count = 0
        for dt in planned_dates:
            if dt.weekday() ==4 or dt.weekday() == 5 or  dt.weekday() ==6:
                weekend_day_count = weekend_day_count + 1
        return single_value_condition(weekend_day_count,int(cndtn.value),cndtn.operator.value)
class BookingWindowEvaluator():
    def evaluate_condition(self,odr,cndtn,cpn):
        if odr.item_type.name == 'MasterAdPack':
            pck = BookedAdPack.objects.filter(key = odr.items.split(',')[0])[0]
            dates_booked_for = pck.applied_to.planned_dates.all()
        elif odr.item_type.name == 'DayPack':
            pck = BookedDayPack.objects.filter(key = odr.items.split(',')[0])[0]
            dates_booked_for = pck.applied_to.planned_dates.all()
        planned_dates = []
        for obj in dates_booked_for:
            planned_dates.append(obj.date)
        min_date = min(planned_dates)
        logger.info('min_date : '+str(min_date))
        max_date = max(planned_dates)
        logger.info('max_date : '+str(max_date))
        diff = min_date-max_date
        logger.info('Window : '+str(abs(diff.days)))
        return single_value_condition(abs(diff.days)+1,int(cndtn.value),cndtn.operator.value)
class ConsecutiveWeekendDaysEvaluator():
    def evaluate_condition(self,odr,cndtn,cpn):
        try:
            if odr.item_type.name == 'MasterAdPack':
                pck = BookedAdPack.objects.filter(key = odr.items.split(',')[0])[0]
                dates_booked_for = pck.applied_to.planned_dates.all()
            elif odr.item_type.name == 'DayPack':
                pck = BookedDayPack.objects.filter(key = odr.items.split(',')[0])[0]
                dates_booked_for = pck.applied_to.planned_dates.all()
            planned_dates = []
            for obj in dates_booked_for:
                planned_dates.append(obj.date)
            weekend_dates = []
            for dt in planned_dates:
                if dt.weekday() ==4 or dt.weekday() == 5 or  dt.weekday() ==6:
                    weekend_dates.append(dt)
            weekend_dates = sorted(weekend_dates)
            #logger.info("Weekend days : "+str(weekend_dates))
            result = [weekend_dates[i:i+3] for i in xrange(0, len(weekend_dates), 3)]
            #check = 'True'
            #logger.info('result : '+str(result))
            for res_set in result:
                date_ints = set([d.toordinal() for d in res_set])
                #logger.info('date_ints : '+str(date_ints))
                #logger.info('max : '+str(max(date_ints))+' min : '+str(min(date_ints))+ 'diff : '+str() )
                if max(date_ints) - min(date_ints) != len(date_ints) - 1:
                    #logger.error("Dates are not consecutive : "+str(res_set))
                    #check = 'False'
                    #return single_value_condition(check,str(cndtn.value),cndtn.operator.value)
                    return False
            return True
        except:
            return False

def create_condition_evaluator(condition_name):
    try:
        if condition_name == 'PACKNAME':
            return PackNameEvaluator()
        elif condition_name == 'CHANNELNAME':
            return ChannelNameEvaluator()
        elif condition_name == 'CURRENTMONTH':
            return CurrentMonthEvaluator()
        elif condition_name == 'CURRENTDAYOFWEEK':
            return CurrentDayOfWeekEvaluator()
        elif condition_name == 'EXPIRYDATE':
            return ExpiryDateEvaluator()
        elif condition_name == 'MONTHBOOKEDFOR':
            return MonthBookedForEvaluator()
        elif condition_name == 'DAYOFWEEKBOOKEDFOR':
            return DayOfWeekBookedForEvaluator()
        elif condition_name == 'DATEBOOKEDFOR':
            return DateBookedForEvaluator()
        elif condition_name == 'TOTALPRICE':
            return TotalPriceEvaluator()
        elif condition_name == 'NUMUNITS':
            return NumUnitsEvaluator()
        elif condition_name == 'TOTALITEMS':
            return TotalItemsEvaluator()
        elif condition_name == 'USAGEPERACCOUNT':
            return UsagePerAccountEvaluator()
        
        elif condition_name == 'BOOKEDSLOTSPERDAY':
            return BookedSlotsPerDayEvaluator()
        elif condition_name == 'NUMWEEKDAYS':
            return NumWeekDaysEvaluator()
        elif condition_name == 'NUMWEEKENDDAYS':
            return NumWeekEndDaysEvaluator()
        elif condition_name == 'CONSECUTIVEWEEKENDDAYS':
            return ConsecutiveWeekendDaysEvaluator()
        elif condition_name == 'BOOKINGWINDOW':
            return BookingWindowEvaluator()
        
    except:
        logger.error ("VALIDATE_COUPON_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("VALIDATE_COUPON_ERROR "+str(tb))
        return None
    
def validate_promo_conditions(cpn, odr):
    try:
        coupon_conditions = cpn.coupon_conditions.all()
        error_msgs = []
        condition_map = {}
        for cndtn in coupon_conditions:
            logger.info("EVALUATING FOR : "+str(cndtn.parameter.name))
            evaluator=create_condition_evaluator(cndtn.parameter.name)
            status=evaluator.evaluate_condition(odr,cndtn,cpn)
            condition_map[cndtn.parameter.name]=status
            #globals()[cndtn.parameter.name]=status
            globals()[str(cndtn.name)]=status
        logger.info("VALIDATE_COUPON_STATS : Condition_Map : "+str(condition_map))
        return condition_map
    except:
        logger.error ("VALIDATE_COUPON_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("VALIDATE_COUPON_ERROR "+str(tb))
        return None

def apply_coupon_values(odr,cpn,parsed_data):
    try:
        amount_to_pay = odr.paid_amount
        discount_amount = 0.00
        if cpn.discount_percentage != 0.00:
            discount_amount = float(cpn.discount_percentage)*float(amount_to_pay)/100
            if discount_amount > float(cpn.max_amount_discounted) and float(cpn.max_amount_discounted) != 0.00:
                discount_amount = float(cpn.max_amount_discounted)
        else:
            discount_amount = float(cpn.max_amount_discounted)
        amount_to_pay = amount_to_pay - discount_amount
        if amount_to_pay < 0:
            amount_to_pay = 0
        res_obj = {#'actual_amount':float(parsed_data['actual_amount']),
                    'amount_to_pay':amount_to_pay,
                    'discount_amount':discount_amount}
        odr.discounted_amount = discount_amount
        odr.paid_amount = amount_to_pay
        odr.save()
        return res_obj
    except:
        logger.error ("VALIDATE_COUPON_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("VALIDATE_COUPON_ERROR "+str(tb))
        return None

#################################################################################
#Validate Discount Coupon API List View - Supports Listing and Create
#################################################################################
class ValidateDiscountCouponView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,DjangoModelPermissions,DjangoObjectPermissions,)
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('coupon_code',)
    filter_fields = ('coupon_code','expiry_date','discount_percentage','max_amount_discounted','valid_across_all_users')
    lookup_field = 'key'
    def get_queryset(self):
        return DiscountCoupon.objects.all()
    def post(self,request,format=None):
        logger.info ("VALIDATE_COUPON_START")
        try:
            username = request.user.username
            accounts = AccountUser.objects.filter(account_user__username=username)
            acct = accounts[0].account
            parsed_data = request.data
            if 'coupon_code' not in parsed_data and 'txnid' not in parsed_data:
                error = {'error':'Both coupon code and txnid are mandatory!'}
                logger.info ("VALIDATE_COUPON_END")
                return Response([error],status = HTTP_400_BAD_REQUEST)
            logger.info ("VALIDATE_COUPON_STATS : Coupon_Code : "+str(parsed_data['coupon_code'])+
                                                            " TXNID : "+str(parsed_data['txnid']) )
            cpn = DiscountCoupon.objects.filter(coupon_code = parsed_data['coupon_code'])
            order_obj = MyOrder.objects.filter(txnid = parsed_data['txnid'],
                                               account__key = acct.key)
            if len(order_obj) <=0 or order_obj is None:
                error = {'error':'Order with given txnid is not found.'}
                logger.info ("VALIDATE_COUPON_END")
                return Response([error],status = HTTP_400_BAD_REQUEST)
            if cpn is not None and len(cpn) > 0:
                if cpn[0].valid_across_all_users == False:
                    valid_users = cpn[0].valid_users.all()
                    if acct not in valid_users:
                        error = {'error':'This coupon is not applicable for you!'}
                        logger.info ("VALIDATE_COUPON_END")
                        return Response([error],status = HTTP_400_BAD_REQUEST)
                if cpn[0].expiry_date < datetime.now().date():
                    error = {'error':'This coupon is already expired!'}
                    logger.info ("VALIDATE_COUPON_END")
                    return Response(error,status = HTTP_400_BAD_REQUEST)
                msgs = validate_promo_conditions(cpn[0],order_obj[0])
                res = validate_condition_expression(cpn[0])
                if res:
                    order_obj[0].applied_coupon = cpn[0]
                    order_obj[0].save()
                    logger.info ("VALIDATE_COUPON_END")
                    return Response(apply_coupon_values(order_obj[0],cpn[0],parsed_data),
                                    status=HTTP_201_CREATED)    
                else:
                    error_msg = []
                    for cndtn in cpn[0].coupon_conditions.all(): 
                        if cndtn.parameter.name in msgs:
                            if not msgs[cndtn.parameter.name]:
                                error_msg.append({'error': cndtn.description})
                    logger.info ("VALIDATE_COUPON_END")
                    return Response(error_msg,status=HTTP_400_BAD_REQUEST)
            else:
                error = {'error':'Sorry! Incorrect coupon code!'}
                return Response([error],status = HTTP_400_BAD_REQUEST) 
        except:
            logger.error ("VALIDATE_COUPON_ERROR "+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("VALIDATE_COUPON_ERROR "+str(tb))
            error = {'error':'Error while applying coupon!'}
            return Response([error],status = HTTP_400_BAD_REQUEST)
