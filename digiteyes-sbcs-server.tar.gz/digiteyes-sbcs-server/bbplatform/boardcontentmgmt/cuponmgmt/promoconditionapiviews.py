from rest_framework import generics

from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters
import django_filters
from boardcontentmgmt.models import PromoCondition,AccountUser,PromoParam,ConditionOperator
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from rest_framework import serializers
import datetime
from boardcontentmgmt.utilities.masterdataserializers import PromoParamSerializer,ConditionOperatorSerializer


class PromoConditionSerializer(serializers.ModelSerializer):
    parameter = PromoParamSerializer()
    operator = ConditionOperatorSerializer()
    class Meta:
        model = PromoCondition
        fields = ['key','parameter','value','last_modified_date','description','operator','name']

class PromoConditionWriteSerializer(serializers.ModelSerializer):
    parameter = serializers.SlugRelatedField(
        queryset=PromoParam.objects.all(),
        slug_field='name')
    operator = serializers.SlugRelatedField(
        queryset=ConditionOperator.objects.all(),
        slug_field='value')
    class Meta:
        model = PromoCondition
        fields = ['parameter','key','value','last_modified_date','description','operator','name']
        
class PromoConditionFilter(django_filters.FilterSet):
    parameter = django_filters.CharFilter(name='parameter__name',lookup_type='exact')
    class Meta:
        model = PromoCondition
	fields = ('parameter',)
#################################################################################
# PromoConditionListView
#################################################################################
class PromoConditionListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = PromoConditionSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('parameter', )
    filter_class = PromoConditionFilter
    search_fields = ('parameter',)
    lookup_field = 'key'
    def get_queryset(self):
        return PromoCondition.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return PromoConditionWriteSerializer
        return PromoConditionSerializer
#################################################################################
# PromoConditionUpdateView
#################################################################################
class PromoConditionUpdateView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)# DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = PromoConditionSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('parameter', )
    filter_class = PromoConditionFilter
    search_fields = ('parameter',)
    lookup_field = 'key'
    def get_queryset(self):
        return PromoCondition.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return PromoConditionWriteSerializer
        return PromoConditionSerializer
