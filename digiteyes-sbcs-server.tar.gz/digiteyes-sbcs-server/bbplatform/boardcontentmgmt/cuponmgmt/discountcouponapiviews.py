from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from django.db.models import Q
from rest_framework import filters
from boardcontentmgmt.models import DiscountCoupon,AccountUser,Account,MyOrder
from .discountcouponserializers import DiscountCouponSerializer,DiscountCouponWriteSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from datetime import datetime,timedelta
import time

import django_filters

class DiscountCouponFilter(django_filters.FilterSet):
	account=django_filters.Filter(name="valid_users__key",lookup_type="exact")
	coupon_code=django_filters.Filter(name="coupon_code",lookup_type="exact")
	valid_across_all_users = django_filters.BooleanFilter(name="valid_across_all_users",lookup_type="exact")
	class Meta:
		model = DiscountCoupon
		fields = ('account','coupon_code','valid_across_all_users',)
#################################################################################
#Discount Coupon API List View - Supports Listing and Create
#################################################################################
class DiscountCouponListView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,DjangoModelPermissions,DjangoObjectPermissions,)
    serializer_class  = DiscountCouponSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('coupon_code',)
    #filter_fields = ('coupon_code','valid_across_all_users')
    filter_class = DiscountCouponFilter
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'discountcoupon') == True):
            return DiscountCoupon.objects.all()
        else:
            return DiscountCoupon.objects.filter(Q(expiry_date__gte =  datetime.now().date()) &
                Q (Q (valid_users__in=[acct]) | Q (valid_across_all_users='True') ))
    def post(self,request,format=None):
        parsed_data = request.data
        if not parsed_data['valid_across_all_users']:
            if parsed_data['valid_users'] is None or len(parsed_data['valid_users']) == 0:
                error = {'error':'Please mention the list of users for whom this coupon code is valid'}
                return Response(error,status = HTTP_400_BAD_REQUEST)
        serializer = DiscountCouponWriteSerializer(data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)
#################################################################################
# Discount Coupon  API Detail View - Supports Update/Patch and Deletion
#################################################################################
class DiscountCouponUpdateView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions)#,DjangoObjectPermissions)
    serializer_class  = DiscountCouponSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('coupon_code',)
    filter_fields = ('coupon_code','valid_across_all_users')
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'discountcoupon') == True):
            return DiscountCoupon.objects.all()
        else:
            return DiscountCoupon.objects.filter(Q(expiry_date__gte =  datetime.now().date()) &
                Q (Q (acct__in=valid_users) | Q (valid_across_all_users='True') ))
    '''
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return DiscountCouponWriteSerializer
        return DiscountCouponSerializer
    '''
    def patch(self,request,key,format=None):
        parsed_data = request.data
        if not parsed_data['valid_across_all_users']:
            if parsed_data['valid_users'] is None or len(parsed_data['valid_users']) == 0:
                error = {'error':'Please mention the list of users for whom this coupon code is valid'}
                return Response(error,status = HTTP_400_BAD_REQUEST)
        cpn = DiscountCoupon.objects.get(key = key)
        serializer = DiscountCouponWriteSerializer(cpn,data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)
    
    def put(self,request,key,format=None):
        parsed_data = request.data
        if not parsed_data['valid_across_all_users']:
            if parsed_data['valid_users'] is None or len(parsed_data['valid_users']) == 0:
                error = {'error':'Please mention the list of users for whom this coupon code is valid'}
                return Response(error,status = HTTP_400_BAD_REQUEST)
        cpn = DiscountCoupon.objects.get(key = key)
        serializer = DiscountCouponWriteSerializer(cpn,data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)
            

        
        
        
        
        
        
        
