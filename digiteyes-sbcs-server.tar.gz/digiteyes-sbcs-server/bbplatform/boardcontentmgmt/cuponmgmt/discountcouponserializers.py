from rest_framework import serializers
from boardcontentmgmt.models import Account,AccountUser,DiscountCoupon,PromoCondition
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from .promoconditionapiviews import PromoConditionWriteSerializer,PromoConditionSerializer

##################################################################################
#Serializer for DiscountCoupon
#################################################################################
class DiscountCouponSerializer(serializers.ModelSerializer):
    valid_users = AccountSerializer(many = True)
    coupon_conditions = PromoConditionSerializer(many = True)
    class Meta:
        model = DiscountCoupon
        fields = ['key','coupon_code','valid_across_all_users','valid_users','condition_expression',
                  'last_modified_date','coupon_conditions','expiry_date','discount_percentage','max_amount_discounted']

##################################################################################
#Write Serializer for DiscountCoupon
#################################################################################
class DiscountCouponWriteSerializer(serializers.ModelSerializer):
    valid_users = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        many = True,slug_field='key',required = False)
    coupon_conditions = PromoConditionWriteSerializer(many=True,required=False)
    class Meta:
        model = DiscountCoupon
        fields = ['key','coupon_code','valid_across_all_users','valid_users','condition_expression',
                  'last_modified_date','coupon_conditions','expiry_date','discount_percentage','max_amount_discounted']
    def create(self, validated_data):
        dCoupon = DiscountCoupon()
        dCoupon.coupon_code=validated_data['coupon_code']
        dCoupon.valid_across_all_users=validated_data['valid_across_all_users']
        print unicode(validated_data['valid_across_all_users'])
        if 'condition_expression' in validated_data:
            dCoupon.condition_expression = validated_data['condition_expression']
        if 'expiry_date' in validated_data:
            dCoupon.expiry_date = validated_data['expiry_date']
        dCoupon.save()
        if 'valid_users' in validated_data:
            dCoupon.valid_users = validated_data['valid_users']
        dCoupon.discount_percentage = validated_data['discount_percentage']
        if 'max_amount_discounted' in validated_data:
            dCoupon.max_amount_discounted = validated_data['max_amount_discounted']
        condition_list=[]
        if 'coupon_conditions' in validated_data:
            for condition in validated_data['coupon_conditions']:
                c_condition=PromoConditionWriteSerializer().create(condition)
                c_condition.save()
                condition_list.append(c_condition)
        dCoupon.save()
        dCoupon.coupon_conditions = condition_list
        dCoupon.save()
        return dCoupon
    def update(self, instance, validated_data):
        dCoupon = instance
        dCoupon.coupon_code=validated_data['coupon_code']
        dCoupon.valid_across_all_users=validated_data['valid_across_all_users']
        print unicode(validated_data['valid_across_all_users'])
        if 'condition_expression' in validated_data:
            dCoupon.condition_expression = validated_data['condition_expression']
        if 'expiry_date' in validated_data:
            dCoupon.expiry_date = validated_data['expiry_date']
        dCoupon.save()
        if 'valid_users' in validated_data:
            dCoupon.valid_users = validated_data['valid_users']
        dCoupon.discount_percentage = validated_data['discount_percentage']
        if 'max_amount_discounted' in validated_data:
            dCoupon.max_amount_discounted = validated_data['max_amount_discounted']
        condition_list=[]
        if 'coupon_conditions' in validated_data:
            for condition in validated_data['coupon_conditions']:
                c_condition=PromoConditionWriteSerializer().create(condition)
                c_condition.save()
                condition_list.append(c_condition)
        dCoupon.save()
        dCoupon.coupon_conditions = condition_list
        dCoupon.save()
        return dCoupon
        
                
                
        