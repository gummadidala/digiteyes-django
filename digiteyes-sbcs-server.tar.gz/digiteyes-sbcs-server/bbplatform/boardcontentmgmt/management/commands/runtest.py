'''
Created on 17-Feb-2017

@author: saba
'''
from django.core.management.base import BaseCommand, CommandError
from boardcontentmgmt.tests import test_report_data



class Command(BaseCommand):
    help = 'Runs Test'

    def add_arguments(self, parser):
        #parser.add_argument('poll_id', nargs='+', type=int)
        pass

    def handle(self, *args, **options):
        test_report_data()
        