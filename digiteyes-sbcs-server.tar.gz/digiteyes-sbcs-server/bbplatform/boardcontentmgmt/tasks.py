from __future__ import absolute_import, division
from collections import defaultdict
from celery import shared_task
from celery.task.base import periodic_task
from boardcontentmgmt.models import BookedAdPack,BookedSlot,DayPart,BookingState,Board,\
    ConsumerTracking, BoardPlayHistory, ShowSpotAsset, ConsumerContentTargets , MyOrder, BookingState,\
    Account , AdvtCampaign,AccountUser, CampaignState , ContentQueue, DeviceController,RequestState , SystemConfiguration
from boardcontentmgmt.models import Content,ContentType, TrackBookingAlgo,ContentState,ItemType,\
    BookedDayPack,DeviceLastContact,ResidentialComplex,ContentApprovals,ScreenAvailabilityStats,\
    DeviceAppVersion,CampaignWifiCount,WifiConsumerTracking,ContentSchedule,TransactionReason,\
    StorageAccount,SystemConfiguration, ContentTarget
from datetime import datetime,date,time,timedelta
from boardcontentmgmt.taskprocessors.algov7 import allocation_algorithm
from boardcontentmgmt.taskprocessors.vuforiatargetuploader import upload_cloud_target_from_file
from boardcontentmgmt.taskprocessors.reportgen import generate_campaign_play_report
from boardcontentmgmt.utilities.algo_utilities import ValidateAlgorithm,get_daypart,find_diff_in_secs
import celery
from django.db.models import Q
from bbplatform.celery import app 
import subprocess
import json
import boto
from boto.s3.connection import S3Connection
from boto.s3.key import Key
import boto.ses
import os
from os import listdir
from os.path import isfile, join
import sys, zipfile
import traceback
import urllib,urllib2
import hashlib,random,string
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from django.template import Context
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from reportlab.lib.pagesizes import letter
#from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.colors import pink, black, red, blue, green
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Image 
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (Flowable, Paragraph, SimpleDocTemplate, Spacer)
from bbplatform.settings import Adiot_logo_url
import logging
from .taskprocessors.activelocationmgr import process_user_event, \
    create_consumer_targets_for_play_history
from time import sleep
from bbplatform.settings import HOSTING_SERVER,Adiot_logo_url,AWS,AZURE   
from django.db.models import Max,Min 
from celery import chord
from boardcontentmgmt.taskprocessors.playreport import find_campaign_stats_for_day
from boardcontentmgmt.taskprocessors.reportgen import generate_campaign_invoice
#from gi.overrides.keysyms import currency
import plivo
logger = logging.getLogger(__name__)
from boardcontentmgmt.utilities.credittransactionutilities import create_credit_transaction_from_system
from boardcontentmgmt.contentmgmt.azureuploadcredentialsapiview import create_blob
from boardcontentmgmt.models import RpiController,RpiControlCommand,RequestState,RpiVersion,RpiLastContact
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from boardcontentmgmt.contentmgmt.adcontentserializers import ContentSerializer
from boardcontentmgmt.servicesmgmt.screenstatusapiviews import get_device_last_contact
from boardcontentmgmt.models import RpiController,RpiControlCommand,RequestState,RpiVersion
from boardcontentmgmt.contentmgmt.adcontentserializers import ContentTargetSerializer, ContentSerializer
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from uuid import UUID
from .taskprocessors.targetimagescaler import scale_target_image
@shared_task
def send_sms_plivo(user_name,txt_msg,phone_numbers=[]):
    logger.info("SEND_SMS_PLIVO_START")
    auth_id = "MAODK5M2Y5MJGZYWYXMD"
    auth_token = "ZTU1NzZhYTY4ODRhYzA2MzY4YjViM2I3NDBmNGQ5"
    txt_msg = 'Hi '+ user_name +','+ txt_msg+'.'
    try:
        if len(phone_numbers) < 0:
            phone_numbers = ['9945079955','7259945267']
        p = plivo.RestAPI(auth_id, auth_token)
        for num in phone_numbers:
            params = {
                'src': '+919973140609', 
                'dst' : '+91'+str(num), 
                'text' : unicode(txt_msg)
            }
            response = p.send_message(params)
            print 'ResPONSE :',response
            logger.info("SEND_SMS_PLIVO_STATS : SMS sent to : "+str(num))
    except:
        logger.error ("SEND_SMS_PLIVO_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("SEND_SMS_PLIVO_ERROR "+str(tb))
    logger.info("SEND_SMS_PLIVO_END")
    

@shared_task
def get_facebook_user_profile(fb_token):
    return 0

def send_contentstatechange_notification(cntnt):
    logger.info("CONTENTS_STATE_CHANGE_EMAIL_NOTIFICATION_START")
    print 'In send_contentstatechange_notification!'
    try:
        user_name = cntnt.content_owner.account_user.first_name+" "+cntnt.content_owner.account_user.last_name
        user_email = cntnt.content_owner.account_user.email
        state = cntnt.content_state.state_name
        #print user_name, user_email
        link=""
        if state == 'APPROVED':
            text = "for start creating playlist."
            link = HOSTING_SERVER+'contentmgmt/queues'
        else:
            text = "for knowing the reason for rejection."
            link = HOSTING_SERVER+'contentmgmt/contents'
        logger.debug("attempting to send email to " +str(user_email))
        htmly  = get_template('approved_contents_notification.html')
        d = Context({ 'link': link,'username':user_name,'logo_url':Adiot_logo_url,
                    'content':cntnt.content_name,'state':state,'text':text})
        subject = 'Media content is '+ state
        html_content = htmly.render(d)
        #send_email.delay(user_email,subject,html_content,link,"")
        send_email_ses.delay(user_email,subject,html_content,link,"")
        if cntnt.content_owner.verified_mobile:
            txt_msg = ' Your media content: '+unicode(cntnt.content_name)+ ' is '+state
            send_sms_plivo(user_name, txt_msg, [cntnt.content_owner.account_user_phone_no])
        logger.info("CONTENTS_STATE_CHANGE_EMAIL_NOTIFICATION_STATS: EMAIL : "+str(user_email)+
                    " CONTENT : "+unicode(cntnt.content_name)+" STATE : "+unicode(state))
        logger.info('content state change notification mail sent successfully to: '+str(user_email))
    except:
        logger.error ("CONTENTS_STATE_CHANGE_EMAIL_NOTIFICATION_START "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("CONTENTS_STATE_CHANGE_EMAIL_NOTIFICATION_START "+str(tb))

def prepare_mail_format(subject,to_user,attachment_file,html_content):
    attachment_file = str(attachment_file)
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From'] = 'info@digiteyes91.com'
    msg['To'] = to_user
    msg.preamble = 'Multipart message.\n'
    
    part2 = MIMEText(html_content.encode('utf-8').strip(), 'html')
    msg.attach(part2)
    if attachment_file !="":
        part = MIMEApplication(open(attachment_file, 'rb').read())
        part.add_header('Content-Disposition', 'attachment', filename=attachment_file)
        msg.attach(part)
    return msg

#################################################################################
# Returns the Video play time of the URL.
#################################################################################
def getLength(url):
    try:
        curl_out = subprocess.Popen(('curl','-s',url),stdout=subprocess.PIPE)
        result = subprocess.check_output(("ffprobe" ,"pipe:0","-show_streams", 
            "-loglevel", "quiet", "-print_format", "json"),stdin=curl_out.stdout)
        probe_result = json.loads(result)
        duration=probe_result['streams'][0]['duration']
        delta = timedelta(seconds=float(duration))
        delta = delta - timedelta(microseconds=delta.microseconds)
        logger.info("Video Length of "+ url + ":  " +str(delta))
        return delta
    except:
        logger.error ("Error while calculating Video Length of "+url+ " "+sys.exc_info()[0])
        tb = traceback.format_exc()
        logger.error ("Stack Trace: "+str(tb))
    return timedelta(seconds=0)
#################################################################################
# Creates a random temp file
#################################################################################
def create_random_temp_file(keyword,extn):
    temppath = '/tmp/'
    fileName = keyword
    random_name = ''.join(random.choice(string.ascii_lowercase + 
        string.ascii_uppercase + string.digits) for i in range(10))
    fileName += random_name+'.'+extn  
    if os.path.exists(temppath+fileName) :
        os.remove(temppath+fileName)
    return temppath+fileName
#################################################################################
# Uploades given file to S3
#################################################################################
def upload_file_to_s3(filePath,name_of_key):
    conn = S3Connection('AKIAIU5QBFMYBBQ4DM4Q','jl9Ac+LTgkRQfJTS6b9HJeByHwt6JjfrPTHtaPaz')
    bucket_name = 'ruga-boardcontentmgmt-uploaded-media-content'
    bucket=conn.get_bucket(bucket_name)
    k = Key(bucket)
    k.key = name_of_key
    k.set_contents_from_filename(filePath)
    k.make_public()
    thumb_url = k.generate_url(expires_in=0,query_auth=False)
    thumb_url = thumb_url.split('?', 1)[0]
    return thumb_url
#################################################################################
# Uploades given file to S3
#################################################################################
def upload_file_to_azure(filePath,name_of_key,container_name,file_type,type):
    blob_name = name_of_key
    return create_blob(filePath,blob_name,container_name,file_type,type)

def upload_file_to_remote_storage(filePath,name_of_key,container_name,file_type,type):
    if AWS:
        return upload_file_to_s3(filePath,name_of_key)
    elif AZURE:
        return upload_file_to_azure(filePath,name_of_key,container_name,file_type,type)
#################################################################################
# Creates a thumbnail image for the given video and uploads to cloud.
#################################################################################
def get_thumbnail(url,content_name,account_name):
    try:  
        '''
        temp_file=create_random_temp_file('grab', '.jpeg')
        curl_out = subprocess.Popen(('curl','-s',url),stdout=subprocess.PIPE)
        subprocess.check_output(("ffmpeg","-i","pipe:0","-vframes","1","-ss","03",temp_file),
            stdin=curl_out.stdout)
            '''
        temp_file_img=create_random_temp_file('grab', '.jpeg')
        temp_file_vid=create_random_temp_file('content_name', '.mp4')
        testfile = urllib.URLopener()
        testfile.retrieve(url, temp_file_vid)
        subprocess.check_output(("ffmpeg","-i",temp_file_vid,"-vframes","1","-ss","03",temp_file_img),)
        os.remove(temp_file_vid)
        # Now upload to S3
        if os.path.exists(temp_file_img):
            #thumb_url=upload_file_to_s3(temp_file_img,
            #    content_name +"_thumbnail"+".jpeg")
            thumb_url = upload_file_to_remote_storage(temp_file_img,content_name +"_thumbnail"+".jpeg",account_name,
                                             "image/jpeg",'MEDIA')
            os.remove(temp_file_img)
            return thumb_url
    except:
        logger.error ("Error while creating thumbnail "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("Stack Trace: "+str(tb))
        if os.path.exists(temp_file_img) :
            os.remove(temp_file_img)
        if os.path.exists(temp_file_vid) :
            os.remove(temp_file_vid)
    return ""
#################################################################################
# Extracts thumbnail url for Image Bunch
#################################################################################
def get_thumbnail_for_bunch(url,content_name,account_name):
    try:
        temp_file=create_random_temp_file('image_bunch', '.zip')
        testfile = urllib.URLopener()
        testfile.retrieve(url, temp_file)
        with zipfile.ZipFile(temp_file, 'r') as bunch_zip:
            arch_files = bunch_zip.infolist()
            bunch_zip.extract(arch_files[0],'/tmp/')
            extracted_file='/tmp/'+arch_files[0].filename
            if os.path.exists(extracted_file):
                #thumb_url=upload_file_to_s3(extracted_file,
                #    content_name +"_"+arch_files[0].filename)
                thumb_url = upload_file_to_remote_storage(extracted_file,content_name +"_"+arch_files[0].filename,
                                             account_name,"image/jpeg",'MEDIA')
                os.remove(extracted_file)
                os.remove(temp_file)
                return thumb_url
    except:
        logger.error ("Error while creating thumbnail for bunch"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("Stack Trace: "+str(tb))
        if os.path.exists(temp_file) :
            os.remove(temp_file)
        
    return ""


def zip_pdf_pages(folder,name):
    onlyfiles = [f for f in listdir(folder) if isfile(join(folder, f))]
    temp_file=create_random_temp_file(name+'_image_bunch', '.zip')
    with zipfile.ZipFile(temp_file, 'w') as bunch_zip:
        for iFile in onlyfiles:
            bunch_zip.write(join(folder, iFile),iFile)
        bunch_zip.close()
    return temp_file
    
    
def convert_PDF_to_image_bunch(primary_source,content_name,account_name):
    try:
        temp_file=create_random_temp_file('pdfcontent', '.pdf')
        testfile = urllib.URLopener()
        testfile.retrieve(primary_source, temp_file)
        dirname = temp_file+"_converted_images/"
        os.mkdir(dirname)
        subprocess.check_output(("convert","-density","400",temp_file,""+dirname+"ouput.png"))
        zip_file = zip_pdf_pages(dirname,content_name)
        #url = upload_file_to_s3(zip_file, content_name+"_image_bunch")
        url = upload_file_to_remote_storage(zip_file,content_name+"_image_bunch",account_name,
                                             "application/zip",'MEDIA')
        onlyfiles = [f for f in listdir(dirname) if isfile(join(dirname, f))]
        for iFile in onlyfiles:
            if os.path.exists(join(dirname,iFile)):
                os.remove(join(dirname,iFile))
        if os.path.exists(dirname):
            os.rmdir(dirname)
        if os.path.exists(temp_file):
            os.remove(temp_file)
        return url
    except:
        logger.error ("Error while converting PDF to image bunch"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("Stack Trace: "+str(tb))

    
#################################################################################
# Celery Task for Filling the video play time for newly created content.
#################################################################################
@shared_task
def fill_content_length(content_key):
    logger.info("Fill Content Length Task START :"+ str(content_key))
    content_created = Content.objects.get(key=content_key)
    draft_state=ContentState.objects.filter(state_name='DRAFT')[0]
    if content_created.content_type.type_name == 'VIDEO' :
        logger.info("CONTENT_VIDEO_PROCESSING_START :"+str(content_created.content_name))
        try:
            #logger.info("Fill Content Length & Create Thumbnail for Video")
            length = getLength(content_created.content_source)
            logger.info("CONTENT_VIDEO_PROCESSING_STATS : VIDEO_LENGTH:"+str(length))
            content_created.content_play_time = length
            content_created.save()
            thumb_url = get_thumbnail(content_created.content_source,content_created.content_name,
                                      content_created.account.account_name)
            content_created.thumbnail_source = thumb_url
            content_created.content_state=draft_state
            content_created.save()
        except:
            logger.error ("CONTENT_VIDEO_PROCESSING_ERROR"+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("CONTENT_VIDEO_PROCESSING_ERROR"+str(tb))
        logger.info("CONTENT_VIDEO_PROCESSING_END:"+str(content_created.content_name))
    if content_created.content_type.type_name == 'IMAGE_BUNCH' :
        logger.info("CONTENT_IMAGE_BUNCH_PROCESSING_START:"+str(content_created.content_name))
        try:
            logger.info("Create Thumbnail for Image Bunch")
            thumb_url = get_thumbnail_for_bunch(content_created.content_source,
                content_created.content_name,content_created.account.account_name)
            content_created.thumbnail_source = thumb_url
            content_created.content_state=draft_state
            content_created.save()
        except:
            logger.error ("CONTENT_IMAGE_BUNCH_PROCESSING_ERROR"+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("CONTENT_IMAGE_BUNCH_PROCESSING_ERROR"+str(tb))
        logger.info("CONTENT_IMAGE_BUNCH_PROCESSING_END:"+str(content_created.content_name))
    if content_created.content_type.type_name == 'PDF' :
        logger.info("CONTENT_PDF_PROCESSING_START:"+str(content_created.content_name))
        try:
            url = convert_PDF_to_image_bunch(content_created.content_primary_source,
                content_created.content_name,content_created.account.account_name)
            content_created.content_source = url
            thumb_url = get_thumbnail_for_bunch(url, content_created.content_name,
                                                content_created.account.account_name)
            typeObj = ContentType.objects.get(type_name='IMAGE_BUNCH')
            content_created.content_type =typeObj 
            content_created.content_state=draft_state
            content_created.thumbnail_source = thumb_url
            content_created.save()
        except:
            logger.error ("CONTENT_PDF_PROCESSING_ERROR"+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("CONTENT_PDF_PROCESSING_ERROR"+str(tb))
        logger.info("CONTENT_PDF_PROCESSING_END:"+str(content_created.content_name))
################################################################################
#Celery Task for making the bookedadpacks from blocked state to normal state
#Trigger time : when payment initiated
################################################################################
def change_item_status(pack,status):
    initiate = BookingState.objects.filter(name = 'INITIATED')[0]
    block = BookingState.objects.filter(name = 'BLOCKED')[0]
    rejected=CampaignState.objects.filter(state_name='REJECTED')[0]
    planned=CampaignState.objects.filter(state_name='PLANNED')[0]
    if pack.booking_state == block or pack.booking_state == initiate:
        pack.booking_state = status
        if status.name == 'CANCELLED' or status.name == 'FAILED' :
            pack.applied_to.state = rejected
            pack.applied_to.save()
            pack.save()
        elif status.name == 'SUCCESS':
            pack.applied_to.state = planned
            pack.applied_to.save()
            pack.save()
        pack.save()
        logger.debug("campaign state:"+str(pack.applied_to.state.state_name)+" Campaign name:"+str(pack.applied_to.name))
@shared_task
def check_booking_status(txnid,state_name):
    logger.info("ORDER_STATUS_TIMEOUT_PROCESSING_START :"+ str(txnid))
    try:
        state = BookingState.objects.filter(name = state_name)[0]
        order = MyOrder.objects.filter(txnid = txnid)
        order = order[0]
        items = order.items
        initiate = BookingState.objects.filter(name = 'INITIATED')[0]
        cancel = BookingState.objects.filter(name = 'CANCELLED')[0]
        block = BookingState.objects.filter(name = 'BLOCKED')[0]
        success= BookingState.objects.filter(name = 'SUCCESS')[0]
        masteradpack = ItemType.objects.filter(name = 'MasterAdPack')[0]
        daypack = ItemType.objects.filter(name = 'DayPack')[0]
        arpack = ItemType.objects.filter(name = 'ArAdPack')[0]
        
        item_keys = items.split(',')
        if order.item_type == masteradpack:
            for pck_key in item_keys:
                bap = BookedAdPack.objects.filter(key = pck_key)[0]
                if bap.booking_state == state:
                    change_item_status(bap,cancel)
                
        elif order.item_type == daypack:
            for pck_key in item_keys:
                bdp = BookedDayPack.objects.filter(key = pck_key)
                if order.status != success:
                    change_item_status(bdp[0],cancel)
                    baps = bdp[0].booked_ad_pack.all()
                    for each_bap in baps:
                        if each_bap.booking_state == state:
                            change_item_status(each_bap,cancel)
        elif order.item_type == arpack:
            if order.status != success:
                order.campaign.state=CampaignState.objects.filter(state_name='REJECTED')[0]
                order.campaign.save()
        if order.status == state:
            order.status = cancel
            if order.applied_credit_trasaction is not None and len(order.applied_credit_trasaction.all()) > 0:
                order.applied_credit_trasaction.all()[0].transaction_status = cancel
                order.applied_credit_trasaction.all()[0].save()
            order.save()
        logger.error ("ORDER_STATUS_TIMEOUT_PROCESSING_STATS ORDER_ID "+str(txnid)+
                        "STATUS:"+ str(order.status.name))
    except:
        logger.error ("ORDER_STATUS_TIMEOUT_PROCESSING_ERROR"+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("ORDER_STATUS_TIMEOUT_PROCESSING_ERROR"+str(tb))
    logger.info("ORDER_STATUS_TIMEOUT_PROCESSING_START :"+ str(txnid))
            
################################################################################
#Celery Task for calling the slots allocation algorithm 
#Trigger Time : every day at :00:00:00
################################################################################  
#@periodic_task(run_every=crontab(hour=0, minute=0))   
@shared_task
def Call_AllocationAlgorithmValidation(date,dp,brd):
    logger.info("ALLOCATION_ALGO_VALIDATION_START")
    try :
        ValidateAlgorithm(date,dp,brd)
    except:
        logger.error ("ALLOCATION_ALGO_VALIDATION_ERROR"+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("ALLOCATION_ALGO_VALIDATION_ERROR"+str(tb))
    logger.info("ALLOCATION_ALGO_VALIDATION_END")
    
def validator(date,dp,brd):
     Call_AllocationAlgorithmValidation.delay(date,dp,brd)
     
@shared_task
def Call_AllocationAlgorithm_for_selected_screens(boards,tracking_key,daypart_list,camp_types):
    logger.info("Call_AllocationAlgorithm_for_selected_screens Task START :")
    try:
        return allocation_algorithm(boards,datetime.now().date(),tracking_key,validator,daypart_list,camp_types)
    except:
        logger.error ("Error while Running Call_AllocationAlgorithm_for_selected_screens: "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("Stack Trace: "+str(tb))
    logger.info("Call_AllocationAlgorithm_for_selected_screens Task END :")
def divide_screens_for_tasks(screen_list,tracking_key,daypart_list,camp_types):
    logger.info("divide_screens_for_tasks_START")
    task_res= []
    boards = []
    if len(screen_list) > 0:
        for scrn in screen_list:
            scrn_obj = Board.objects.filter(key=scrn)
            if scrn_obj is not None and len(scrn_obj)>0: 
                boards.append(scrn)
    else:
        all_boards = Board.objects.all()
        for each_brd in all_boards:
            boards.append(str(each_brd.key))
    logger.info("Total screens present are : "+str(len(boards)))
    for brd in boards:
        task_res.append(Call_AllocationAlgorithm_for_selected_screens.s([brd],tracking_key,daypart_list,camp_types))
    logger.info("divide_screens_for_tasks_END")
    return task_res

@shared_task
def PrePlayReport(dump,daypart_list):
    logger.info("PrePlayReport Task START")
    try:
        day_parts = []
        if len(daypart_list) >0:
            for d in daypart_list:
                dp_obj = DayPart.objects.filter(name=d)
                if dp_obj is not None and len(dp_obj)>0:
                    day_parts.append(dp_obj[0])
        else:
            day_parts = get_daypart()
        for dp in day_parts:
            campaigns = AdvtCampaign.objects.filter(planned_dates__date__in = [datetime.now().date()])
            if campaigns is not None and len(campaigns)>0:
                for camp in campaigns:
                    acnt_type = str(camp.account.account_type.type_name)
                    bkadpacks = BookedAdPack.objects.filter(applied_to__key = camp.key,
                                                            date_booked_for = datetime.now().date(),
                                                            day_part_booked_for = dp)
                    if bkadpacks is not None and len(bkadpacks) > 0 and acnt_type in ['ADVERTISER'] \
                        and camp.type.name=='NORMAL':
                        CampaignReport.delay(str(camp.key),True,str(dp.key))
        ############################################################################
            curr_state = CampaignState.objects.filter(state_name = 'COMPLETED')[0]
            campaigns = AdvtCampaign.objects.annotate(end_date = Max('planned_dates__date')).filter(
                                                      end_date = datetime.now().date()+timedelta(days=-1))
            for camp in campaigns:
                if camp.state.state_name=='RUNNING':
                    camp.state = curr_state
                    logger.info("ALLOCATION_ALGO_COMPLETED_CAMPAIGN: "+str(camp.name))
                    camp.save()
    except:
        logger.error ("PrePlayReport Task ERROR: "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("PrePlayReport Task ERROR: "+str(tb))
    logger.info("PrePlayReport Task END")
@shared_task
def Call_AllocationAlgorithm(screen_list=[],daypart_list=[],camp_types=[]):
    logger.info("MAIN_ALLOCATION_ALGO_START DATE : "+str(datetime.now().date()))
    try :
        obj = TrackBookingAlgo()
        obj.trigger_time = datetime.now()
        obj.save()
        
        allocation = divide_screens_for_tasks(screen_list,str(obj.key),daypart_list,camp_types)
        pre_play_report =  PrePlayReport.s(daypart_list)
        result = chord(allocation)(pre_play_report)
        
    except:
        logger.error ("ALLOCATION_ALGO_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("ALLOCATION_ALGO_ERROR "+str(tb))
    ############################################################################
    logger.info("MAIN_ALLOCATION_ALGO_END DATE : "+str(datetime.now().date()))
###################################################################################
# Task which fills the Consumer Target objects when a new consumer tracking event 
# is received.
###################################################################################
@shared_task
def fill_consumer_content_targets_for_userevent(consumer_tracking_key):
    #logger.info("Fill Consumer Content Targets for User Event Task START :"+ str(consumer_tracking_key))
    try:
        event = ConsumerTracking.objects.get(key=consumer_tracking_key)
        logger.info("CONSUMER_TRACKING_EVENT_START TYPE : "+str(event.event_type))
        process_user_event(event)
        logger.info( "CONSUMER_TRACKING_EVENT_STATS  BEACON: "+str(event.event_location.name) + 
                     "Event Time : "+str(event.event_time_stamp) + "Event_type :"+str(event.event_type))
        #logger.info("CONSUMER_TRACKING_EVENT_STATS SHOW_SPOT"+str(event.event_type))
        if event.event_type == 'EXIT' :
            # Find the corresponding entry event
            entry_events = ConsumerTracking.objects.filter(event_location__key = event.event_location.key,
                event_type = 'ENTER', consumer_account__key = event.consumer_account.key,
                event_time_stamp__lt=event.event_time_stamp).order_by(
                    '-event_time_stamp')
            if entry_events and entry_events is not None:
                logger.debug('Found entry events')
                matched_entry = entry_events[0]
                logger.debug('Entry Event Time stamp:'+ str(entry_events[0].event_time_stamp))
                diff = event.event_time_stamp - matched_entry.event_time_stamp
                if diff.total_seconds() > 1800 : 
                    logger.warn("Event Entry more than 30 mins in the past.. Capping to 30 mins")
                    matched_entry.event_time_stamp = event.event_time_stamp - timedelta(minutes=30)
                beacons = [event.event_location]
                show_spot = ShowSpotAsset.objects.filter(attached_beacons__in=beacons)
                if show_spot is not None and show_spot:
                    #logger.info( "Event Show Spot:"+show_spot[0].name)
                    logger.info( "CONSUMER_TRACKING_EVENT_STATS SHOw_SPOT: "+str(show_spot[0].name))
                    boards = Board.objects.filter(show_spot__key=show_spot[0].key)
                    board = boards[0]
                    logger.info(board.board_name)
                    board_play_histories = BoardPlayHistory.objects.filter(Q(board__key = board.key) &
                        Q(
                          Q(
                            Q(content_from_time__lte=event.event_time_stamp) & 
                            Q(content_from_time__gte = matched_entry.event_time_stamp)
                            )
                          |
                  
                        Q(
                          Q(content_to_time__lte=event.event_time_stamp) & 
                          Q(content_to_time__gte = matched_entry.event_time_stamp) 
                          )
                        )
                    )
                    for history in board_play_histories:
                        logger.info("History: from-time:"+ str(history.content_from_time)+" To time :"+str(history.content_to_time))
                        existing_targets = ConsumerContentTargets.objects.filter(show_spot_location_key=show_spot[0].key,
                            time=history.content_to_time,account__key=event.consumer_account.key)
                        if not existing_targets or existing_targets is None:
                            logger.info("No Existing Target Saving New One")
                            consumer_target = ConsumerContentTargets()
                            consumer_target.show_spot_location_lat = show_spot[0].spot_location_lat
                            consumer_target.show_spot_location_long = show_spot[0].spot_location_long
                            consumer_target.show_spot_location_key = show_spot[0].key
                            consumer_target.show_spot_location_image_url = show_spot[0].spot_location_image_url
                            consumer_target.show_spot_beacon_touched = event.event_location.mac_address
                            consumer_target.content_target = history.content_played.content_target
                            consumer_target.content = history.content_played
                            consumer_target.time = history.content_to_time
                            consumer_target.campaign = history.campaign.key
                            consumer_target.account = event.consumer_account
                            consumer_target.save()
    except:
        logger.error ("CONSUMER_TRACKING_EVENT_ERROR"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("CONSUMER_TRACKING_EVENT_ERROR "+str(tb))    
    logger.info("CONSUMER_TRACKING_EVENT_END :")
    
def create_campaign_wificount_entry(play_history):
    logger.info("create_campaign_wificount_entry_START")
    try:
        play_start_time = play_history.content_from_time
        play_end_time = play_history.content_to_time
        played_campaign = play_history.campaign
        existing_entries = CampaignWifiCount.objects.filter(campaign__key=played_campaign.key,
                                                            showspot__key=play_history.board.show_spot.key,
                                                            start_time__gte = play_start_time,
                                                            end_time__lte=play_end_time)
        wificounters=play_history.board.show_spot.attached_wificounters.all()
        wifi_keys = []
        for wifi in wificounters:
            wifi_keys.append(wifi.key)
        if  existing_entries is None or len(existing_entries) == 0:
            obj = CampaignWifiCount()
            obj.campaign = played_campaign
            obj.showspot = play_history.board.show_spot
            obj.start_time = play_start_time
            obj.end_time = play_end_time
            logger.info("play_start_time : "+str(play_start_time))
            logger.info("play_end_time : "+str(play_end_time))
            track_objs = WifiConsumerTracking.objects.filter(
                                            Q( Q(
                                                Q(start_time__lte = play_start_time)&
                                                Q(end_time__gte=play_start_time)
                                                )   |
                                              Q(
                                                Q(start_time__lte = play_end_time)&
                                                Q(end_time__gte=play_end_time)
                                                ) 
                                            )&
                                            Q(event_location__key__in = wifi_keys))
            logger.info("create_campaign_wificount_entry_STATS Campaign : "+str(played_campaign.name)+" Count : "+str(len(track_objs)))
            count = 0
            for track in track_objs:
               count = count + track.devices_count
            obj.count = count
            obj.save()
    except:
        logger.error ("create_campaign_wificount_entry_ERROR"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("create_campaign_wificount_entry_ERROR "+str(tb))    
    logger.info("create_campaign_wificount_entry_END")
    
@shared_task
def fill_consumer_content_targets_for_playhistory(play_history_key):
    logger.info("Fill Consumer Targets for Play History Task START: "+ str(play_history_key))
    try :
        play_history = BoardPlayHistory.objects.get(key=play_history_key)
        create_consumer_targets_for_play_history(play_history)
        logger.info("History From Time:"+str(play_history.content_from_time) + "To Time:"+str(play_history.content_to_time))
        board = play_history.board
        show_spot = board.show_spot
        logger.info( "Board :"+board.board_name+ " Show Spot:"+show_spot.name)
        beacons = show_spot.attached_beacons.all()
        beacon_keys = []
        logger.info( board.board_name)
        logger.info( show_spot.name)
        for beacon in beacons:
            logger.info( "Beacon :"+beacon.mac_address)
            beacon_keys.append(beacon.key)
        consumer_events = ConsumerTracking.objects.filter(Q (event_location__key__in= beacon_keys) &
            Q(
                Q(event_time_stamp__gte = play_history.content_from_time) & 
                Q(event_time_stamp__lte = play_history.content_to_time)
                ))
        for event in consumer_events:
            logger.info(event.event_location)
            existing_targets = ConsumerContentTargets.objects.filter(show_spot_location_key=show_spot.key,
                    time=play_history.content_to_time,account__key=event.consumer_account.key)
            if not existing_targets or existing_targets is None:
                logger.info("No Existing Target Saving New One")
                consumer_target = ConsumerContentTargets()
                consumer_target.show_spot_location_lat = show_spot.spot_location_lat
                consumer_target.show_spot_location_long = show_spot.spot_location_long
                consumer_target.show_spot_location_key = show_spot.key
                consumer_target.show_spot_beacon_touched = event.event_location.mac_address
                consumer_target.show_spot_location_image_url = show_spot.spot_location_image_url
                consumer_target.content_target = play_history.content_played.content_target
                consumer_target.content = play_history.content_played
                consumer_target.time = play_history.content_to_time
                consumer_target.campaign = play_history.campaign.key
                consumer_target.account = event.consumer_account
                consumer_target.save()
        #create_campaign_wificount_entry(play_history)
    except:
        logger.error ("Error while Fill Consumer Targets for Play History: "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("Stack Trace: "+str(tb))    
    logger.info("Fill Consumer Targets for Play History Task END: "+ str(play_history_key))

#################################################################################
# Stringifies any UUID present in the object hierarchy
#################################################################################
def stringify_uuid(obj):
    if obj is None:
        return obj
    if isinstance(obj, dict):
	print "dict"
        for key in obj.keys():
		print key
		obj[key]=stringify_uuid(obj[key])
	print str(obj)
	return obj
    elif isinstance(obj, list):
	print "list"
	stringified_obj = []
	for item in obj:
		stringified_obj.append(stringify_uuid(item))
	print str(stringified_obj)
	return stringified_obj 
    print str(obj)
    return str(obj)
#################################################################################
# Uploads the image as Vuforia target along with meta data.
#################################################################################
@shared_task
def do_vuforia_upload_for_AR(content_key):
    cntnt = Content.objects.filter(key = content_key)[0]
    logger.info("VuFORIA UPLOAD FOR AR START")
    configs = SystemConfiguration.objects.filter(name='AR_ENABLE')
    if len(configs) > 0 and configs[0].value == 'NO':
        logger.info("VuFORIA UPLOAD FOR AR END : AR Not Enabled at System Level")
        return
    if not cntnt.enable_ar :
        logger.info("VuFORIA UPLOAD FOR AR END : AR Not Enabled for the Content"
            +str(content_key))
        return
    for_tv_size=40
    tv_size_config = SystemConfiguration.objects.filter(name='AR_TV_SIZE')
    if len(tv_size_config) > 0 :
        for_tv_size=int(tv_size_config[0].value)
        logger.info("VuFORIA UPLOAD FOR AR : AR TV Size "+str(for_tv_size))
    if cntnt.content_type.type_name == 'IMAGE':
        meta_data= {}
        url = cntnt.content_source
        filePath=create_random_temp_file(cntnt.content_name, '.jpg')
        try:
            testfile = urllib.URLopener()
            testfile.retrieve(url, filePath)
        except:
            logger.debug("Exception happened with urllib")
            hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
                    'Accept-Encoding': 'none',
                    'Accept-Language': 'en-US,en;q=0.8',
                    'Connection': 'keep-alive'}
            req = urllib2.Request(url, headers=hdr)
            page = urllib2.urlopen(req)
            with open(filePath,'wb') as output:
                output.write(page.read())
        serializer = ContentSerializer(cntnt)
        print str(serializer.data)
        meta_data = stringify_uuid(serializer.data)
        print str(meta_data)
        upload_cloud_target_from_file(filePath,cntnt.content_name,meta_data,for_tv_size)
        os.remove(filePath)
    else :
        logger.info("VuFORIA UPLOAD FOR AR : NON IMAGE TYPE")
    logger.info("VuFORIA UPLOAD FOR AR : END")
#################################################################################
@shared_task
def calculate_hash(content_key,user):
    cntnt = Content.objects.filter(key = content_key)
    logger.info("CONTENT_HASH_PROCESSING_START : "+unicode(cntnt[0].content_name))
    filePath = ''
    try:
        url = ''
        if len(cntnt) > 0 and cntnt is not None:
            if cntnt[0].content_type.type_name == 'TEXT' :
                hasher = hashlib.sha512()
                msg = cntnt[0].content_source
                hasher.update(msg.encode('utf-8').strip())
                cntnt[0].hash = hasher.hexdigest()
                cntnt[0].save()
            else:
                url = cntnt[0].content_source
                filePath=create_random_temp_file('tempcontent', '.mp4')
                try:
                    testfile = urllib.URLopener()
                    testfile.retrieve(url, filePath)
                except:
                    logger.debug("Exception happened with urllib")
                    hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
                           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                           'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
                           'Accept-Encoding': 'none',
                           'Accept-Language': 'en-US,en;q=0.8',
                           'Connection': 'keep-alive'}
                    req = urllib2.Request(url, headers=hdr)
                    page = urllib2.urlopen(req)
                    with open(filePath,'wb') as output:
                        output.write(page.read())
                hasher = hashlib.sha512()
                with open(filePath, 'rb') as afile:
                    buf = afile.read()
                    hasher.update(buf)
                logger.info("CONTENT_HASH_PROCESSING_STATS : HASH_GENERATED : "+ hasher.hexdigest())
                os.remove(filePath)
                cntnt[0].hash = hasher.hexdigest()
                cntnt[0].save()
        else:
            logger.info("Invalid content key")
            cntnt[0].content_state = ContentState.objects.filter(state_name='SUBMITTED')[0]
            cntnt[0].save()
    except:
        logger.error ("CONTENT_HASH_PROCESSING_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("CONTENT_HASH_PROCESSING_ERROR "+str(tb))
        if os.path.exists(filePath) :
            os.remove(filePath)
        cntnt[0].content_state = ContentState.objects.filter(state_name='REJECTED')[0]
        cntnt[0].save()
        send_contentstatechange_notification(cntnt[0])
        obj=ContentApprovals()
        obj.content = Content.objects.filter(key=content_key)[0]
        obj.action_state = ContentState.objects.filter(state_name='REJECTED')[0]
        obj.action_takenby = AccountUser.objects.filter(account_user__username=user)[0]
        obj.action_time = datetime.now()
        obj.action_comment = "Invalid content / HASH FAILURE"
        obj.save()
    logger.info("CONTENT_HASH_PROCESSING_END : "+unicode(cntnt[0].content_name))
    
@shared_task
def send_email(user_email,subject,html_content,link,attachment_file):
    logger.info("EMAIL_START")
    try:
        msg = EmailMultiAlternatives(subject, html_content,'',[user_email])
        msg.attach_alternative(html_content, "text/html")
        if attachment_file !="":
            msg.attach_file(attachment_file)
        msg.send()
        logger.error ("EMAIL_STATS LINK : "+str(link)+" SENT_TO : "+str(msg['To']))
    except:
        logger.error ("EMAIL_EEROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("EMAIL_EEROR "+str(tb))
    logger.info("EMAIL_END:")
    
@shared_task
def send_email_ses(user_email,subject,html_content,link,attachment_file):
    logger.debug('In send_email_ses')
    msg = prepare_mail_format(subject,user_email,attachment_file,html_content)
    logger.info("EMAIL_START")
    try:
        conn = boto.ses.connect_to_region(
        'us-west-2',
        aws_access_key_id='AKIAIFDAWOJJI7ITUMLQ',
        aws_secret_access_key='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')
        result = conn.send_raw_email(msg.as_string(), 
                                 source=msg['From'], 
                                 destinations=msg['To'])
        #logger.info('link: '+str(link)+'sent to: '+str(msg['To']))
        #logger.info('Email sent successfully!')
        logger.error ("EMAIL_STATS LINK : "+str(link)+" SENT_TO : "+str(msg['To']))
    except:
        logger.error ("EMAIL_EEROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("EMAIL_EEROR "+str(tb))
    logger.info("EMAIL_END:")

@shared_task
def check_devicecontrol_status(devicecontroller_key):
    logger.info("check_devicecontrol_status Task START :"+ str(devicecontroller_key))
    try:
        submitted = RequestState.objects.filter(name = 'SUBMITTED')[0]
        expired = RequestState.objects.filter(name = 'EXPIRED')[0]
        obj = DeviceController.objects.filter(key = devicecontroller_key)
        if len(obj) > 0 and obj is not None:
            if obj[0].request_state == submitted:
                obj[0].request_state = expired
                obj[0].save()
                logger.info('changing the request_state from SUBMITTED to EXPIRED of:'+str(devicecontroller_key)) 
        else:
            logger.info('entry not found in DeviceController table with key:'+str(devicecontroller_key))
    except:
        logger.info('something went wrong!')
    logger.info("check_devicecontrol_status Task END :"+ str(rpicontroller_key))
@shared_task
def check_rpicontrol_status(rpicontroller_key):
    logger.info("check_rpicontrol_status Task START :"+ str(rpicontroller_key))
    try:
        submitted = RequestState.objects.filter(name = 'SUBMITTED')[0]
        expired = RequestState.objects.filter(name = 'EXPIRED')[0]
        print unicode(submitted)
        print unicode(expired)
        obj = RpiController.objects.filter(key = rpicontroller_key)
        if len(obj) > 0 and obj is not None:
            
            if obj[0].request_state == submitted:
                obj[0].request_state = expired
                obj[0].save()
                logger.info('changing the request_state from SUBMITTED to EXPIRED of:'+str(rpicontroller_key)) 
        else:
            logger.info('entry not found in DeviceController table with key:'+str(rpicontroller_key))
    except:
        logger.info('something went wrong!')
    logger.info("check_rpicontrol_status Task END :"+ str(rpicontroller_key))

#################################################################################
# Creates Campaignreport
#################################################################################
@shared_task
def CampaignReport(camp_key=None,pre_play=False,daypart_key=""):
    logger.info("CAMPAIGN_REPORT_PROCESSING_START")
    try:
        today = datetime.now().date()
        prev_date = datetime.now().date()+timedelta(days=-1)
        campignList=[]
        if camp_key is not None:
            campignList = AdvtCampaign.objects.filter(key = camp_key)
        else:
            campignList = AdvtCampaign.objects.annotate(end_date = Max('planned_dates__date')).filter(
                                                  end_date = prev_date)
        logger.info("total campaigns: "+str(len(campignList)))
        if campignList is not None and len(campignList) > 0:
            for campaign in campignList:
                logger.info("CAMPAIGN_REPORT_PROCESSING_FOR : "+str(campaign.name))
                user_email = campaign.owner.account_user.email
                temppath = '/tmp/'
                fileName = str(today)+'_'+campaign.owner.account_user.username+"report.pdf"
                if os.path.exists(temppath+fileName) :
                    os.remove(temppath+fileName)
                generate_campaign_play_report(campaign,temppath+fileName,pre_play,daypart_key)
    ############################################################################
                user_name = str(campaign.owner.account_user.first_name) +" "+ str(campaign.owner.account_user.last_name)
                htmly  = get_template('campaign_report.html')
                link = ""
                d = Context({ 'link': link,'username':user_name,"logo_url":Adiot_logo_url})
                subject = 'Campaign report!'
                html_content = htmly.render(d)
                send_email_ses.delay(user_email,subject,html_content,link,temppath+fileName)
    ############################################################################
                    
    ############################################################################
                #thumb_url = upload_file_to_s3(temppath+fileName,unicode(campaign.name)+'_'+str(today)+"_Report")
                container_name = campaign.account.account_name
                '''
                thumb_url = upload_file_to_remote_storage(temppath+fileName,unicode(campaign.name)+'_'+str(today)+"_Report",container_name,
                                             "file/pdf",'PDFREPORT')
                user_camp = AdvtCampaign.objects.filter(key = camp_key)
                campaign  = user_camp[0]
                campaign.latest_report= thumb_url
                campaign.save()
                '''
                campaign.latest_report= thumb_url
                campaign.save()
                logger.info("CAMPAIGN_REPORT_PROCESSING_STATS:  Generated Report path :"+
                                unicode(thumb_url))
                #if campaign.owner.verified_mobile:
                    #txt_msg  = ' Please get the campaign report by clicking here: '+unicode(thumb_url) 
                    #phone_numbers = [campaign.owner.account_user_phone_no]
                    #send_sms_plivo(user_name, txt_msg, phone_numbers)
    ############################################################################
    except:
        logger.error ("CAMPAIGN_REPORT_PROCESSING_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("CAMPAIGN_REPORT_PROCESSING_ERROR "+str(tb))
    logger.info("CAMPAIGN_REPORT_PROCESSING_END")
#################################################################################
# Service Notification
#################################################################################
def get_service_people(info_list):
    logger.info("In get_service_people")
    try:
        service_notifications = []
        groups = defaultdict(list)
        for inf in info_list:
            groups[inf['location']].append(inf)
        for vals in groups.values():
            obj = {}
            obj['email_contents'] = []
            obj['service_people_emails'] = []
            obj['service_people_numbers']=[]
            for val in vals:
                obj['email_contents'].append(val)
                complex_obj=ResidentialComplex.objects.filter(name=val['location'])[0]
                logger.debug("Length: "+str(len(complex_obj.service_people.all())))
                if len(complex_obj.service_people.all())>0:
                    for sp in complex_obj.service_people.all():
                        if sp.account_user.email not in obj['service_people_emails']:
                            obj['service_people_emails'].append(sp.account_user.email)
                        if sp.account_user.email not in obj['service_people_numbers']:
                            obj['service_people_numbers'].append(sp.account_user_phone_no) 
                else:
                    obj['service_people_emails'] = ['gkrkoti3@gmail.com',
                                            'daksha.rekha@digiteyes91.com',
                                            'prodadmin@digiteyes91.com','sumanth472@gmail.com']
                    obj['service_people_numbers'] = ['8977650865','9945079955','7259945267','8892196239']
            service_notifications.append(obj)
        return service_notifications
    except:
        tb = traceback.format_exc()
        logger.error ("Stack Trace: "+str(tb))
@shared_task
def ServiceNotification():
    logger.info("SERVICE_REPORT_PROCESSING_START")
    try:
        curr_time = datetime.now()+timedelta(minutes=-5)
        all_objs = DeviceLastContact.objects.filter(last_contact_time__gte = curr_time)
        all_live_brds = Board.objects.filter(board_state__name='LIVE')
        logger.debug("total number of live devices:"+str(len(all_live_brds)))
        active_brds = []
        dead_brds = []
        if all_objs is not None and len(all_objs)>0:
            for obj in all_objs:
                if str(obj.board.key) not in active_brds:
                    active_brds.append(str(obj.board.key))
            if len(all_live_brds) != len(active_brds):
                for live_brd in all_live_brds:
                    if str(live_brd.key) not in active_brds:
                        obj = {}
                        obj['brd'] = live_brd
                        rpi_last_contact_obj = RpiLastContact.objects.filter(board = live_brd)[0]
                        obj['RPIStatus'] = rpi_last_contact_obj.status
                        obj['Last_contact_time'] = str(rpi_last_contact_obj.last_contact_time)
                        screen_status_list = get_device_last_contact(live_brd.key)
                        obj['SCREEN_POWER_STATUS'] = screen_status_list[1];
                        obj['status'] = 'NOT CONTACTING'
                        dead_brds.append(obj)
        else:
            arr = []
            for b in all_live_brds:
                obj = {}
                obj['brd'] = b
                rpi_last_contact_obj = RpiLastContact.objects.filter(board = b)[0]
                obj['RPIStatus'] = rpi_last_contact_obj.status
                obj['Last_contact_time'] = str(rpi_last_contact_obj.last_contact_time)
                screen_status_list = get_device_last_contact(b.key)
                obj['SCREEN_POWER_STATUS'] = screen_status_list[1];
                obj['status'] = 'NOT CONTACTING'
                arr.append(obj)
            dead_brds = arr
        logger.debug('total number of devices failed to contact in last 5 minutes: '+str(len(dead_brds)))
        logger.debug('Rpi status: '+str(obj['RPIStatus']))
        logger.debug('Last_contact_time: '+str(obj['Last_contact_time']))
        logger.debug('Screen_power_status: '+str(obj['SCREEN_POWER_STATUS']))
        
        # check for boards which are not reporting play history.
        dayparts =DayPart.objects.all().order_by('from_time')
        day_start_time = dayparts[0].from_time
        day_end_time = dayparts[len(dayparts)-1].to_time
        '''
        for i in range(1,len(dayparts)):
            if day_start_time>dayparts[i].from_time:
                day_start_time=dayparts[i].from_time
            if day_end_time<dayparts[i].to_time:
                day_end_time=dayparts[i].to_time
                '''
        start_time=datetime.combine(datetime.now().date(),day_start_time)
        end_time=datetime.combine(datetime.now().date(),day_end_time)
        
        curr_time = datetime.now()+timedelta(minutes=-15)
        #print start_time, end_time, curr_time
        
        if len(dead_brds) < all_live_brds and curr_time>=start_time and curr_time<=end_time:
            play_dead_brds = []
            db_brds = []
            for dbrd in dead_brds:
                db_brds.append(dbrd['brd'])
            for brd in all_live_brds:
                if brd not in db_brds:
                    history_objs = BoardPlayHistory.objects.filter(board__key=brd.key,
                                                                   content_from_time__gte=curr_time,
                                                                   campaign__type__name='NORMAL')
                    if history_objs is None or len(history_objs)<=0:
                        obj = {}
                        obj['brd'] = brd
                        rpi_last_contact_obj = RpiLastContact.objects.filter(board = brd)[0]
                        obj['RPIStatus'] = rpi_last_contact_obj.status
                        obj['Last_contact_time'] = str(rpi_last_contact_obj.last_contact_time)
                        screen_status_list = get_device_last_contact(brd.key)
                        obj['SCREEN_POWER_STATUS'] = screen_status_list[1];
                        obj['status'] = 'NOT REPORTING PLAY HISTORY'
                        play_dead_brds.append(obj)
            logger.debug("total number of devices failed to post playhistory in last 15 mins:"+ str(len(play_dead_brds)))
            logger.debug('Rpi status: '+str(obj['RPIStatus']))
            logger.debug('Last_contact_time: '+str(obj['Last_contact_time']))
            logger.debug('Screen_power_status: '+str(obj['SCREEN_POWER_STATUS']))
            
            if len(play_dead_brds)>0:
                for pdb in play_dead_brds:
                    dead_brds.append(pdb)
        logger.debug("SERVICE_REPORT_PROCESSING_STATS SCREENS_DOWN :"+str(len(dead_brds)))
        if len(dead_brds)>0:
            info_list = []
            for db in dead_brds:
                d_brd = db['brd']
                info_obj = {}
                info_obj['serial_number'] = d_brd.board_serial_number
                residential_complex = ResidentialComplex.objects.filter(account__key=d_brd.show_spot.account.key)
                if residential_complex is not None and len(residential_complex)>0:
                    res_complex = residential_complex[0]
                    info_obj['location'] = res_complex.name
                    last_contact_obj = DeviceLastContact.objects.filter(board__key=d_brd.key).order_by('-last_contact_time')
                    if last_contact_obj is not None and len(last_contact_obj)>0:
                        contacted_time = last_contact_obj[0].last_contact_time
                        info_obj['last_contact_time'] = contacted_time.strftime('%m-%d-%Y %H:%M:%S')
                    else:
                        info_obj['last_contact_time'] = "Unknown"
                    screen_location= ""
                    if d_brd.show_spot is not None:
                        if res_complex.name is not None:
                            screen_location += res_complex.name
                        if res_complex.address is not None:
                            screen_location += ', '+res_complex.address
                        if res_complex.city_sub_area is not None:
                            screen_location += ', '+res_complex.city_sub_area
                        if res_complex.city is not None:
                            screen_location += ', '+res_complex.city.city_name
                    info_obj['screen_location'] = screen_location
                    info_obj['status'] = db['status']
                    info_obj['RpiStatus'] =db['RPIStatus'] 
                    info_obj['RpiLastContactTime'] = db['Last_contact_time']
                    info_obj['ScreenPowerStatus'] =  db['SCREEN_POWER_STATUS']
                    info_list.append(info_obj)
            logger.debug(str(info_list))
            
            serivce_notifications = get_service_people(info_list)
            logger.debug('service_notifications:'+str(serivce_notifications))
            users = [] 
            if serivce_notifications is not None and len(serivce_notifications)>0:
                for notify in serivce_notifications:
                    if len(notify['service_people_emails'])>0:
                       users = notify['service_people_emails']
                    #else:
                       # users= ['gkrkoti3@gmail.com','daksha.rekha@digiteyes91.com']
                       # users= ['sumanth472@gmail.com']
                    for user_email in users:
                        try:
                            link = 'service notification'
                            htmly  = get_template('service_notifications.html')
                            d = Context({ 'info_list': notify['email_contents'],'username':user_email,'logo_url':Adiot_logo_url})
                            #d = Context({ 'info_list': 'screen_status_content','username':user_email,'logo_url':Adiot_logo_url})
                            subject = 'Devices are down or may not reporting play history!'
                            html_content = htmly.render(d)
                            send_email_ses.delay(user_email,subject,html_content,link,"")
                            #send_email.delay(user_email,subject,html_content,link,"")
                            logger.info('service notification sent successfully to: '+str(user_email))
                        except:
                            logger.error ("Error while sending service notification: "+ str(sys.exc_info()[0]))
                            tb = traceback.format_exc()
                            logger.error ("Stack Trace: "+str(tb))
                            return Response('Something went wrong!',status=HTTP_400_BAD_REQUEST)
                    user_name = "service engineer"
                    txt_msg = "It seems some of the devices are not working. Your action is required."
                    phone_numbers = notify['service_people_numbers']
                    # Send service SMS based on System Configuration
                    configs = SystemConfiguration.objects.filter(name='SEND_SERVICE_SMS')
                    if len(configs) > 0 and configs[0].value == 'YES':
                        send_sms_plivo(user_name, txt_msg, phone_numbers)
            else:
                logger.info("total number of service people:"+str(len(users)))
    except:
        logger.error ("SERVICE_REPORT_PROCESSING_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("SERVICE_REPORT_PROCESSING_ERROR "+str(tb))
    logger.info("SERVICE_REPORT_PROCESSING_END")
    
@shared_task
def ScreenAvailabilityStatistics():
    logger.info("ScreenAvailabilityStats_START")
    try:
        live_brds = Board.objects.filter(board_state__name='LIVE')
        production_cntnt = ContentQueue.objects.filter(content_queue_name = 'nearby_android_playlist')
        for brd in live_brds:
            obj = ScreenAvailabilityStats()
            obj.board = brd
            prev_date = datetime.now().date()+timedelta(days=-1)
            #prev_date = datetime.now().date()
            obj.date = prev_date
            baps = BookedAdPack.objects.filter(booked_screen__key=brd.key,
                                               date_booked_for = prev_date,
                                               booking_state__name='SUCCESS') 
            auto_bs_count = 0
            normal_bs_count = 0
            for bap in baps:
                if bap.booking_type == 'auto_booking' or bap.booking_type == 'empty_booking':
                    auto_bs_count = auto_bs_count + len(bap.slots_booked.all())
                else:
                    normal_bs_count = normal_bs_count + len(bap.slots_booked.all()) 
            obj.production_planned_slots = auto_bs_count
            obj.normal_planned_slots = normal_bs_count
            
            dayparts =DayPart.objects.all().order_by('from_time')
            start_time = dayparts[0].from_time
            end_time = dayparts[len(dayparts)-1].to_time
            '''
            for i in range(1,len(dayparts)):
                if start_time>dayparts[i].from_time:
                    start_time=dayparts[i].from_time
                if end_time<dayparts[i].to_time:
                    end_time=dayparts[i].to_time
                        '''
            start_date_time = datetime.combine(prev_date,start_time)
            end_date_time = datetime.combine(prev_date,end_time)
            normal_bph_count = 0
            auto_empty_bph_count = 0
            bphs = BoardPlayHistory.objects.filter(board__key=brd.key,
                                                   content_from_time__gte=start_date_time,
                                                   content_from_time__lte=end_date_time)
            for bph in bphs:
                if bph.campaign.play_list.key == production_cntnt[0].key:
                    auto_empty_bph_count = auto_empty_bph_count+1
                else:
                    normal_bph_count = normal_bph_count +1
            obj.normal_played_slots = normal_bph_count
            obj.production_played_slots = auto_empty_bph_count
            dl = DeviceLastContact.objects.filter(board__key=brd.key,
                                                  last_contact_time__gte=start_date_time,
                                                  last_contact_time__lte=end_date_time)
            obj.device_play_last_contacts = len(dl)
            if normal_bs_count >0:
                obj.availability = (normal_bph_count/normal_bs_count)*100
            else:
                obj.availability = 0
            if brd.show_spot is not None:
                obj.showspot = brd.show_spot
            #obj.save()
            down_time = timedelta(seconds=0)
            device_last_contacts = DeviceLastContact.objects.filter(board__key=brd.key,
                                                                    last_contact_time__gte=start_date_time,
                                                                    last_contact_time__lte=end_date_time)
            if device_last_contacts is not None and len(device_last_contacts)>0:
                for i in range(1,len(device_last_contacts)):
                    diff_time = find_diff_in_secs(device_last_contacts[i].last_contact_time,
                                                  device_last_contacts[i-1].last_contact_time)
                    if  diff_time>60:
                        down_time = down_time+timedelta(seconds=diff_time)
            
            obj.screen_down_time = down_time
            obj.save()
            logger.info("ScreenAvailabilityStats_END")
    except:
        logger.error ("ScreenAvailabilityStats_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("ScreenAvailabilityStats_ERROR "+str(tb))
        logger.info("ScreenAvailabilityStats_END")
        
@shared_task        
def calculate_hash_apk(obj_key,dev_type):
    logger.info("CALCULATE_HASH_APK_START")
    if dev_type == "RPI":
        obj = RpiVersion.objects.filter(key=obj_key)[0]
        file_type = ".zip"
        url = obj.code_location
    else:
        obj = DeviceAppVersion.objects.filter(key=obj_key)[0]
        file_type = ".apk"
        url = obj.apk_location
    try:
        #url = obj.apk_location
        filePath=create_random_temp_file('tempcontent', file_type)
        try:
            testfile = urllib.URLopener()
            testfile.retrieve(url, filePath)
        except:
            logger.debug("Exception happened with urllib")
            hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                   'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
                   'Accept-Encoding': 'none',
                   'Accept-Language': 'en-US,en;q=0.8',
                   'Connection': 'keep-alive'}
            req = urllib2.Request(url, headers=hdr)
            page = urllib2.urlopen(req)
            with open(filePath,'wb') as output:
                output.write(page.read())
        hasher = hashlib.sha512()
        with open(filePath, 'rb') as afile:
            buf = afile.read()
            hasher.update(buf)
        logger.info("APK_HASH_PROCESSING_STATS : HASH_GENERATED : "+ hasher.hexdigest())
        os.remove(filePath)
        obj.hash = hasher.hexdigest()
        obj.save()
        logger.info("CALCULATE_HASH_APK_END")
    except:
        logger.error ("CALCULATE_HASH_APK_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("CALCULATE_HASH_APK_ERROR "+str(tb))
        logger.info("CALCULATE_HASH_APK_END")

@shared_task        
def NoPlayCredit(camp_key=None):
    logger.info("NOPLAY_CREDIT_START")
    try:
        success = BookingState.objects.filter(name='SUCCESS')[0]
        prev_date = datetime.now().date()+timedelta(days=-1)
        curr_date = datetime.now().date()
        campaigns = []
        if camp_key is not None:
            campaigns = AdvtCampaign.objects.filter(key=camp_key)
        else:
            campaigns = AdvtCampaign.objects.filter(planned_dates__date__in=[prev_date])
        for camp in campaigns:
            logger.info("NOPLAY_CREDIT_STATS : Campaign : "+str(camp.name))
            orders=MyOrder.objects.filter(campaign__key=camp.key,status=success)
            if len(orders) > 0:
                odr=orders[0]
            else:
                continue
            total_amount_paid = odr.paid_amount + odr.credit_amount
            campaign_stats = find_campaign_stats_for_day(prev_date,camp)
            missed_time_secs = campaign_stats['missed_time']
            bps = BookedAdPack.objects.filter(applied_to__key = camp.key,booking_state=success)
            total_units=0
            for bp in bps:    
                total_units = total_units+bp.num_plays*bp.units_per_play*bp.unit_size/30
            price_per_unit = 0
            if total_units != 0:
                price_per_unit = total_amount_paid/total_units
            if price_per_unit == 0 :
                logger.info("NOPLAY_CREDIT_STATS : Price / Unit is Zero - NO CREDIT to be given")
                continue
            missed_units=missed_time_secs/30
            refund_amount = missed_units * price_per_unit
            logger.info("NOPLAY_CREDIT_STATS : CAMPAIGN : "+str(camp.name)+" TOTAL_NO_PLAY_UNITS : "+str(missed_units) +
                    " TOTAL_UNITS_PLANNED : "+str(total_units)+ " TOTAL_AMOUNT_PAID_TO_CAMP : "+
                    str(total_amount_paid)+ "PRICE_PER_UNIT : "+str(price_per_unit)+ 
                    " REFUND_AMOUNT : "+str(refund_amount)+ " FOR DATE:"+str(prev_date))
            transaction_reason = TransactionReason.objects.filter(reason_text='No Play Credit')[0]
            desc = "Credited by system for no play contents in camapign : "+str(camp.name)
            transaction = create_credit_transaction_from_system(camp.account,refund_amount,
                 transaction_reason,desc)
            # add to the order
            if len(orders[0].applied_credit_trasaction.all()) > 0:
                orders[0].applied_credit_trasaction.add(transaction)
            else:
                orders[0].applied_credit_trasaction = [transaction]
            orders[0].save()
            ####################################################################
            user_email = camp.owner.account_user.email
            user_name  = str(camp.owner.account_user.first_name) + str(camp.owner.account_user.last_name)
            htmly  = get_template('noplaycredit.html')
            link = ""
            d = Context({'username':user_name,"logo_url":Adiot_logo_url,"CampaignName":camp.name,
                        "PlayedDate":str(prev_date),"MissedSlots":str(missed_units),
                        "UnitPricePerSlot":str(price_per_unit),"TotalRefundAmount":str(refund_amount)})
            subject = 'No play credit'
            html_content = htmly.render(d)
            send_email_ses.delay(user_email,subject,html_content,link,"")
            txt_msg  = ' Rs.'+str(refund_amount) +'/- has been credited to your account'
            phone_numbers = [camp.owner.account_user_phone_no]
            send_sms_plivo(user_name, txt_msg, phone_numbers)
            ####################################################################    
    except:
        logger.error ("NOPLAY_CREDIT_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("NOPLAY_CREDIT_ERROR "+str(tb))
    logger.info("NOPLAY_CREDIT_END")

@shared_task    
def UnblockBookedAdPacks():
    logger.info("UnblockBookedAdPacks_START")
    try:
        curr_time = datetime.now()+timedelta(minutes=-30) 
        status = BookingState.objects.filter(name = 'CANCELLED')[0]
        all_baps = BookedAdPack.objects.filter(when_booked__lte = curr_time,
                                               booking_state__name__in=['BLOCKED','INITIATED'])
        logger.info('UnblockBookedAdPacks_STATS : total blocked packs : '+str(len(all_baps)))
        for pack in all_baps:
            change_item_status(pack,status)
    except:
        logger.error ("UnblockBookedAdPacks_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("UnblockBookedAdPacks_ERROR "+str(tb))
    logger.info("UnblockBookedAdPacks_END")

@shared_task    
def InvoiceGeneration(tid):
    logger.info("InvoiceGeneration_START")
    try:
        today = datetime.now().date()
        order = MyOrder.objects.filter(txnid = tid)
        if order is not None and len(order)>0:
            odr = order[0]
            logger.info('InvoiceGeneration_STATS : Campaign : '+str(odr.campaign.name))
            temppath = '/tmp/'
            fileName = str(today)+'_'+odr.campaign.owner.account_user.username+"invoice.pdf"
            if os.path.exists(temppath+fileName) :
                os.remove(temppath+fileName)
            generate_campaign_invoice(odr.campaign,temppath+fileName)
    ############################################################################
            user_email = str(odr.campaign.owner.account_user.email)
            user_name = str(odr.campaign.owner.account_user.first_name) + str(odr.campaign.owner.account_user.last_name)
            htmly  = get_template('invoice.html')
            link = ""
            d = Context({ 'link': link,'username':user_name,"logo_url":Adiot_logo_url})
            subject = 'Invoice for your order - '+str(tid)
            html_content = htmly.render(d)
            send_email_ses.delay(user_email,subject,html_content,link,temppath+fileName)
    ############################################################################
                    
    ############################################################################
            #thumb_url = upload_file_to_s3(temppath+fileName,unicode(odr.campaign.name)+'_'+str(today)+"_Invoice")
            container_name = odr.account.account_name
            thumb_url = upload_file_to_remote_storage(temppath+fileName,unicode(odr.campaign.name)+'_'+str(today)+"_Invoice",container_name,
                                             "file/pdf",'INVOICE')
            odr.invoice= thumb_url
            odr.save()
            logger.info("InvoiceGeneration_STATS:  Generated invoice path :"+
                                unicode(thumb_url))
            #if odr.campaign.owner.verified_mobile:
                #txt_msg  = ' Please get the invoice by clicking here: '+unicode(thumb_url) 
                #phone_numbers = [odr.buyer.account_user_phone_no]
                #send_sms_plivo(user_name, txt_msg, phone_numbers)
        
    except:
        logger.error ("InvoiceGeneration_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("InvoiceGeneration_ERROR "+str(tb))
    logger.info("InvoiceGeneration_END")

@shared_task
def create_campaign_wificount():
    logger.info("create_campaign_wificount_entry_START")
    try:
        dayparts =DayPart.objects.all().order_by('from_time')
        start_time = dayparts[0].from_time
        end_time = dayparts[len(dayparts)-1].to_time
        '''
        for i in range(1,len(dayparts)):
            if start_time>dayparts[i].from_time:
                start_time=dayparts[i].from_time
            if end_time<dayparts[i].to_time:
                end_time=dayparts[i].to_time
                '''
        prev_date = datetime.now().date()+timedelta(days=-1)                
        start_date_time = datetime.combine(prev_date,start_time)
        end_date_time = datetime.combine(prev_date,end_time)
        all_objs = WifiConsumerTracking.objects.filter(start_time__gte=start_date_time,
                                                       end_time__lte=end_date_time)
        if all_objs is not None and len(all_objs)>0:
            for obj in all_objs:
        #tracking_obj = WifiConsumerTracking.objects.filter(key=obj_key)
        #if tracking_obj is not None and len(tracking_obj)>0:
            #obj = tracking_obj[0]
                count_start_time = obj.start_time
                count_end_time = obj.end_time   
                spot = ShowSpotAsset.objects.filter(attached_wificounters__in = [obj.event_location])[0]
                brd = Board.objects.filter(attached_wificounters__in = [obj.event_location])[0]
                '''
                existing_entries = CampaignWifiCount.objects.filter(showspot__key=spot.key,
                                                                start_time__gte = count_start_time,
                                                                end_time__lte=count_end_time)
                if  existing_entries is None or len(existing_entries) == 0:
                '''
                play_hist_objs = BoardPlayHistory.objects.filter(
                                                        Q( Q(
                                                            Q(content_from_time__gte = count_start_time)&
                                                            Q(content_from_time__lte=count_end_time)
                                                            )   |
                                                          Q(
                                                            Q(content_to_time__gte = count_start_time)&
                                                            Q(content_to_time__lte=count_end_time)
                                                            ) 
                                                        )&
                                                        Q(board__key = brd.key))
                for hist in play_hist_objs:
                    ob = CampaignWifiCount()
                    ob.campaign = hist.campaign
                    ob.showspot = spot
                    ob.start_time = count_start_time
                    ob.end_time = count_end_time
                    ob.count = obj.devices_count
                    ob.save()
                    logger.info("create_campaign_wificount_entry_STATS : Campaign : "+str(hist.campaign.name)+
                                    " Count : "+str(obj.devices_count))
        else:
            logger.error("create_campaign_wificount_entry_ERROR: WifiConsumerTracking is not found")
    except:
        logger.error ("create_campaign_wificount_entry_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("create_campaign_wificount_entry_ERROR "+str(tb))
    logger.info("create_campaign_wificount_entry_END")

@shared_task
def screen_down_time(obj_key):
    logger.info("screen_down_time_START")
    try:
        print ""
    except:
        logger.error ("screen_down_time_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("screen_down_time_ERROR "+str(tb))
    logger.info("screen_down_time_END")

@shared_task
def power_off_ATV():
    logger.info("Power_off_ATV_COMMAND_SEND")
    try:
        Boardobjects = Board.objects.all()
        for object in Boardobjects:
            rpi_object = RpiController()
            rpi_object.board = object
            rpi_object.command = RpiControlCommand.objects.filter(name='ATV_POWEROFF')[0]
            rpi_object.request_start_time = datetime.now()
            rpi_object.request_state = RequestState.objects.filter(name='SUBMITTED')[0]
            rpi_object.save()
            logger.info("Rpi Controller query : Board : "+str(rpi_object.board)+" Command : "+str(rpi_object.command)+
                        " Start_time : "+str(rpi_object.request_start_time))
    except:
        logger.error("Power_off_ATV_ERROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error("Power_off_ATV_ERROR "+str(tb))
    logger.info("Power_off_ATV_COMMAND_SENT")

@shared_task
def power_on_ATV():
    logger.info("Power_on_ATV_COMMAND_SEND")
    try:
        Boardobjects = Board.objects.all()
        for object in Boardobjects:
            rpi_object = RpiController()
            rpi_object.board = object
            rpi_object.command = RpiControlCommand.objects.filter(name='ATV_POWERON')[0]
            rpi_object.request_start_time = datetime.now()
            rpi_object.request_state = RequestState.objects.filter(name='SUBMITTED')[0]
            rpi_object.save()
            logger.info("Rpi Controller query : Board : "+str(rpi_object.board)+" Command : "+str(rpi_object.command)+
                    " Start_time : "+str(rpi_object.request_start_time))
    except:
        logger.error("Power_on_ATV_ERROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error("Power_on_ATV_ERROR "+str(tb))
    logger.info("Power_on_ATV_COMMAND_SENT")

@shared_task
def scale_target_image_task(instance_key):
    logger.info("Scale Target Image Task START :"+ str(instance_key))
    content_target = ContentTarget.objects.filter(key=instance_key)[0]
    url = content_target.target_image_url
    filePath=create_random_temp_file('tempcontent', '.jpg')
    try:
        testfile = urllib.URLopener()
        testfile.retrieve(url, filePath)
    except:
        logger.debug("Exception happened with urllib")
        hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
                'Accept-Encoding': 'none',
                'Accept-Language': 'en-US,en;q=0.8',
                'Connection': 'keep-alive'}
        req = urllib2.Request(url, headers=hdr)
        page = urllib2.urlopen(req)
        with open(filePath,'wb') as output:
            output.write(page.read())
    
    scaled_file = scale_target_image(filePath)
    key = str(url).split('/')[-1]+"_target_img"
    scaled_url = upload_file_to_remote_storage(scaled_file, key, content_target.account.account_name, "image/jpeg",'MEDIA')
    content_target.target_image_url = scaled_url
    content_target.save()
    os.remove(filePath)
    os.remove(scaled_file)
    logger.info("Scale Target Image Task END :")
    
    
    
