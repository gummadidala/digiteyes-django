'''
Created on 24-Sep-2016

@author: saba
'''
from rest_framework import generics, filters
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from rest_framework.authentication import TokenAuthentication
from boardcontentmgmt.tracking.consumertrackingserializers import ActiveConsumerSerializer
from boardcontentmgmt.models import ActiveConsumerLocation, ShowSpotAsset
from boardcontentmgmt.showspotmgmt.showspotassetserializers import ShowSpotShortSerializer
from rest_framework.response import Response
class ConsumerTrackingListView(generics.ListAPIView):
    """
    Accounts List
    ========
    ##GET:
    List of Active Consumer location objects. 
    ###Search Fileds:
    
        1. show_spot_name
        
    
    """
    authentication_classes = (TokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = ActiveConsumerSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('account_type__type_name','account_name',)
    search_fields = ('account_name',)
    def get(self, request, *args, **kwargs):
        (size,results) = self.get_active_consumers(request)
        req_response = {"count":size,"results":results}
        return Response(req_response)
    def get_active_consumers(self,request):
        page = request.query_params.get('page',None)
        pageNo = 1
        if page is not None:
            pageNo = int(page)
        show_spots = []
        show_spot = request.query_params.get('show_spot', None)
        if show_spot is not  None:
            spot = ShowSpotAsset.objects.filter(key=show_spot)
            if len(spot) == 0:
                error = {'error':'Given Spot is not found'}
                return Response (error,status = HTTP_400_BAD_REQUEST)
            show_spots.append(spot[0])
        else:
            show_spots = ShowSpotAsset.objects.all()
        response_obj = []
        final_list = []
        for show_spot in show_spots:
            obj = {}
            obj["show_spot"] = ShowSpotShortSerializer(show_spot).data
            obj["active_count"] = 0
            response_obj.append(obj)
        if show_spots and len(show_spots) > 0:
            if ((pageNo-1) * 10) < len(show_spots):
                i=(pageNo-1) * 10
                size = i+10
                while i < size and i < len(show_spots):
                    active_consumers = ActiveConsumerLocation.objects.filter(
                        event_location__key=show_spots[i].key,is_active=True).count()
                    response_obj[i]["active_count"]=active_consumers
                    final_list.append(response_obj[i])
                    i=i+1
        return (len(response_obj),final_list)
    