from rest_framework.views import APIView
from rest_framework import generics
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from django.http.response import Http404
from boardcontentmgmt.models import WifiConsumerTracking,WifiCounter,ShowSpotAsset,\
        BoardPlayHistory,Board,CampaignWifiCount
from wificonsumertrackingserializer import WifiConsumerTrackingSerializer,WifiConsumerTrackingWriteSerializer,WifiCountingSerializer,WifiCountingWriteSerializer
from django.contrib.auth.models import Group
import django_filters
from rest_framework import filters
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from django.db.models import Q
from boardcontentmgmt.tasks import create_campaign_wificount
import logging
from boardcontentmgmt.utilities.wifireachutility import generate_wifi_count_stats
from dateutil.parser import parse 
logger = logging.getLogger(__name__)

class WifiConsumerTrackingFilter(django_filters.FilterSet):
    start_time = django_filters.CharFilter(name='event_time_stamp', lookup_type="gte")
    end_time = django_filters.CharFilter(name='event_time_stamp',lookup_type="lte")
    class Meta:
        model = WifiConsumerTracking
        fields = []
#################################################################################
# Wificounter List API List View
#################################################################################
class WificounterListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = WifiCountingSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_fields = ('name',)
    search_fields = ('name','mac_address',)
    lookup_field = 'key'
    def get_queryset(self):
        return WifiCounter.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return WifiCountingWriteSerializer
        return WifiCountingSerializer

#################################################################################
# Wificounter  API Detail View - Supports Update/Patch and Deletion
#################################################################################
class WificounterDetailView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = WifiCountingSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name','mac_address',)
    lookup_field = 'key'
    queryset = WifiCounter.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return WifiCountingWriteSerializer
        return WifiCountingSerializer
#################################################################################
# WificonsumerTracking List API List View
#################################################################################
class WificonsumerTrackingListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = WifiConsumerTrackingSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_class = WifiConsumerTrackingFilter
    search_fields = ('start_time','end_time','devices_count',)
    lookup_field = 'key'
    def get_queryset(self):
        return WifiConsumerTracking.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return WifiConsumerTrackingWriteSerializer
        return WifiConsumerTrackingSerializer
    '''
    def perform_create(self, serializer):
        logger.debug( "perform create WifiConsumerTracking")
        generics.ListCreateAPIView.perform_create(self, serializer)
        logger.debug( serializer.instance)
        create_campaign_wificount.delay(str(serializer.instance.key))
        '''
        
class WifiTrafficView(generics.ListCreateAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    def get(self,request):
        showspot_key = request.query_params.get('show_spot', None)
        start_date = parse(request.query_params.get('start_date', None)).date()
        end_date = parse(request.query_params.get('end_date', None)).date()
        return Response(generate_wifi_count_stats(start_date,end_date,showspot_key))
        

