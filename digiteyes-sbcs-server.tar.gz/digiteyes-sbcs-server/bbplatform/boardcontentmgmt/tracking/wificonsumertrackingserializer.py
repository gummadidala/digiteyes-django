from rest_framework import serializers
from boardcontentmgmt.models import WifiConsumerTracking,WifiCounter
import random, string

import logging
logger = logging.getLogger(__name__)


def generate_wifibeacon_name():
    b_name = ''.join(random.choice(string.ascii_lowercase + string.ascii_uppercase + string.digits) for i in range(5))
    bcns = WifiCounter.objects.filter(name = b_name)
    if len(bcns) > 0:
        generate_wifibeacon_name()
    else:
        return b_name
#################################################################################
# wifi counting Serializer
#################################################################################
class WifiCountingSerializer(serializers.ModelSerializer):
    class Meta:
        model = WifiCounter
        fields = ['key','mac_address','name']
    
#################################################################################
# wifi counting WriteSerializer
#################################################################################
class WifiCountingWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model = WifiCounter
        fields = ['key','mac_address','name']
    def create(self, validated_data):
        validated_data['name'] = generate_wifibeacon_name()
        return serializers.ModelSerializer.create(self, validated_data)

#################################################################################
# wifi consumer tracking Serializer
#################################################################################
class WifiConsumerTrackingSerializer(serializers.ModelSerializer):
    event_location = serializers.SlugRelatedField(
        queryset=WifiCounter.objects.all(),
        slug_field='mac_address')
    class Meta:
        model = WifiConsumerTracking
        fields = ['key','start_time','end_time','devices_count','event_location']
    
#################################################################################
# wifi consumer tracking WriteSerializer
#################################################################################
class WifiConsumerTrackingWriteSerializer(serializers.ModelSerializer):
    event_location = serializers.SlugRelatedField(
        queryset=WifiCounter.objects.all(),
        slug_field='mac_address')
    class Meta:
        model = WifiConsumerTracking
        fields = ['key','start_time','end_time','devices_count','event_location']
