'''
Created on 24-Sep-2016

@author: saba
'''
from rest_framework import serializers
from boardcontentmgmt.models import ActiveConsumerLocation
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from boardcontentmgmt.showspotmgmt.showspotassetserializers import ShowSpotShortSerializer
#################################################################################
# Serializer for Active Consumer Location Object
#################################################################################
class ActiveConsumerSerializer(serializers.ModelSerializer):
    consumer_account = AccountSerializer()
    event_location = ShowSpotShortSerializer()
    class Meta:
        model = ActiveConsumerLocation
        fields = ('key','consumer_account','exit_time_stamp','entry_time_stamp',
            'event_location', 'is_active')
    