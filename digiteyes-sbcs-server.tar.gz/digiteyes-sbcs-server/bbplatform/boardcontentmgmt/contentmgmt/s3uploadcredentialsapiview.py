from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework.response import Response
from boardcontentmgmt.models import AccountUser,StorageAccount
from rest_framework.status import HTTP_201_CREATED, HTTP_500_INTERNAL_SERVER_ERROR
import boto3
from rest_framework.authentication import TokenAuthentication
import boto.s3.connection
import traceback
from boto.s3.connection import S3Connection
from boto.iam.connection import IAMConnection
from boto.s3.cors import CORSConfiguration
from boto.exception import S3ResponseError, S3CreateError
import math,random,string,json
from boto.s3.key import Key
from rest_framework.authentication import TokenAuthentication

AWS_ACCESS_KEY_ID = 'AKIAIFDAWOJJI7ITUMLQ'#'AKIAIU5QBFMYBBQ4DM4Q'
AWS_SECRET_ACCESS_KEY = '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'#'jl9Ac+LTgkRQfJTS6b9HJeByHwt6JjfrPTHtaPaz'
AWS_STORAGE_BUCKET_NAME = 'ruga-boardcontentmgmt-uploaded-media-content'
SERVER_NAME="https://s3.amazonaws.com"
import logging
import sys
logger = logging.getLogger("boardcontentmgmt.s3uploadcredentialsapiview")


def percent_cb(complete, total):
    sys.stdout.write('.')
    sys.stdout.flush()

def upload_file(conn,bucket_name):
    bucket = conn.get_bucket(bucket_name)
    k = Key(bucket)
    bucket_size = 0.0
    for key in bucket.list():
        bucket_size += key.size
        print bucket_size
        print key.name,key.size   
    
    k.key = 'my test file1'
    file_path = '/home/koti/Videos/VID-20130425-WA0000.mp4'
    k.set_contents_from_filename(file_path,
    cb=percent_cb, num_cb=10)

def assign_policy(conn,bucket_name):
    resource = "arn:aws:s3:::"+bucket_name+"/*"
    try:
        policy ={
                    "Version":"2012-10-17",
                    "Id":"Policy1472621232968",
                    "Statement":[
                                    {
                                        "Sid":"Stmt1472621216559",
                                        "Effect":"Allow",
                                        "Principal":{"AWS":"arn:aws:iam::372888330298:role/upload-access"},
                                        "Action":["s3:AbortMultipartUpload","s3:GetObject","s3:ListMultipartUploadParts","s3:PutObject","s3:PutObjectAcl"],
                                        "Resource":resource
                                    }
                                ]
                }
        policy1 ={
                    "Version":"2012-10-17",
                    "Id":"Policy1472621232968",
                    "Statement":[
                                    {
                                        "Sid":"Stmt1472621216559",
                                        "Effect":"Allow",
                                        "Action":["s3:AbortMultipartUpload","s3:GetObject","s3:ListMultipartUploadParts","s3:PutObject","s3:PutObjectAcl"],
                                        "Resource":resource
                                    }
                                ]
                }
        iam_conn = IAMConnection(aws_access_key_id=AWS_ACCESS_KEY_ID, 
                                 aws_secret_access_key=AWS_SECRET_ACCESS_KEY, 
                                 is_secure=True, 
                                 port=None, 
                                 proxy=None, 
                                 proxy_port=None, 
                                 proxy_user=None, 
                                 proxy_pass=None, 
                                 host='iam.amazonaws.com', 
                                 debug=0, 
                                 https_connection_factory=None, 
                                 path='/', 
                                 security_token=None, 
                                 validate_certs=True, 
                                 profile_name=None)
        
        try:
            cors_config = CORSConfiguration()
            cors_config.add_rule(['PUT', 'POST', 'DELETE','GET'], 
                              '*', 
                              allowed_header='*', 
                              max_age_seconds=3000,
                              expose_header='ETag')
            bckt = conn.get_bucket(bucket_name)
            bckt.set_policy(json.dumps(policy))
            bckt.set_cors(cors_config)
            iam_conn.put_role_policy('upload-access','policy_'+bucket_name,json.dumps(policy1))
        except:
            print str(sys.exc_info()[0])
            tb = traceback.format_exc()
            print str(tb)
        #iam_conn.put_role_policy('upload-access','policy_'+bucket_name,json.dumps(policy1))
    except:
        logger.error("Error occured while AWS set_policy"+str(sys.exc_info()[0]))
        response_obj={"error":"Could not able to set policy to bucket"}
        return Response(response_obj,status=HTTP_500_INTERNAL_SERVER_ERROR)
    
def get_bucket_name(account_name):
    conn = S3Connection(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
    sa_name = account_name  
    try:
        bucket = conn.create_bucket(sa_name)
        #conn.create_bucket(sa_name)
        assign_policy(conn,sa_name)
        return sa_name         
    except S3CreateError:
        print "This bucket exist:",sa_name
        rand_name = '-'.join(random.choice(string.ascii_lowercase) for i in range(5))
        sa_name += rand_name
        get_bucket_name(sa_name)
def create_storageaccount(acct):
    sa = StorageAccount()
    sa.name = get_bucket_name(acct.account_name)
    sa.account = acct
    sa.save()
    
class S3UploadCredentials(APIView):
    #authentication_classes = (ExpiringTokenAuthentication,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated, )
    
    def get(self,request,format = None):
        usr = request.user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        account = aUsr[0].account.account_name
        storage_account = StorageAccount.objects.filter(account__account_name = account)
        bucket_name = ""
        if storage_account is not None and len(storage_account) > 0:
            bucket_name = storage_account[0].name
        try:
            sts = boto3.client('sts',
                aws_access_key_id=AWS_ACCESS_KEY_ID,
                aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
                region_name='us-west-2')
            role_response = sts.assume_role(
                RoleArn='arn:aws:iam::372888330298:role/upload-access',
                RoleSessionName=account.replace(" ","_"),
                DurationSeconds=900,)
            #print role_response
            response_obj={"Credentials":role_response["Credentials"],
                          "bucket_name":bucket_name}
            return Response(response_obj,status=HTTP_201_CREATED)
        except:
            logger.error("Error occured while AWS Assume Role"+str(sys.exc_info()[0]))
            response_obj={"error":"Could not fetch credentials from AWS"}
            return Response(response_obj,status=HTTP_500_INTERNAL_SERVER_ERROR)

class AwsBucketDetailsListAPIView(generics.ListCreateAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, )
    def get(self,request,format = None):
        usr = request.user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        account = aUsr[0].account.account_name
        response_obj = []
        try:
            conn = S3Connection(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
            for bucket in conn.get_all_buckets():
                if bucket.name =='ruga-boardcontentmgmt-uploaded-media-content':
                    try:
                        print bucket.get_cors_xml()
                    except:
                        print str(sys.exc_info()[0])
                        tb = traceback.format_exc()
                        print str(tb)
                bucket_size = 0.0
                for key in bucket.list():
                    bucket_size += key.size 
                obj = {'bucket_name':bucket.name,
                       'total_size_occupied':math.floor(bucket_size/(1024*1024))}
                response_obj.append(obj)
        except:
            logger.error("Error occured while AWS Assume Role"+str(sys.exc_info()[0]))
            response_obj={"error":"Could not fetch credentials from AWS"}
            return Response(response_obj,status=HTTP_500_INTERNAL_SERVER_ERROR)
        #response_obj= {'Hello':'hello'}
        return Response(response_obj,status=HTTP_201_CREATED)
    
    
    
    
    
    
    
    
    
    