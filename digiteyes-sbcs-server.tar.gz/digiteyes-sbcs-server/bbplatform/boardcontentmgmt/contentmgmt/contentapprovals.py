from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST,HTTP_200_OK
import django_filters
from rest_framework import filters
from boardcontentmgmt.models import ContentApprovals,AccountUser,Content,ContentState
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
import datetime
from rest_framework import serializers
from boardcontentmgmt.accountmgmt.accountuserserializers import AccountUserShortSerializer
from .adcontentserializers import ContentShortSerializerForTaPP
##################################################################################
#Serializer for ContentApprovals
#################################################################################
class ContentApprovalsSerializer(serializers.ModelSerializer):
    content = ContentShortSerializerForTaPP()
    action_takenby = AccountUserShortSerializer()
    action_state = serializers.SlugRelatedField(
        queryset=ContentState.objects.all(),
        slug_field='state_name')
    
    class Meta:
        model = ContentApprovals
        fields = ['key','action_time','action_takenby','action_comment','action_state','content']
#################################################################################
#ContentApprovals API List View - Supports Listing and Create
#################################################################################
class ContentApprovalsFilter(django_filters.FilterSet):
    content = django_filters.CharFilter(name='content__key',lookup_type='exact')
    action_state  = django_filters.CharFilter(name='action_state__state_name',lookup_type='exact')
    class Meta:
        model = ContentApprovals
	fields = ('content', 'action_state',)
class ContentApprovalsAPIView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,DjangoModelPermissions,DjangoObjectPermissions,)
    serializer_class  = ContentApprovalsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('action_time','content__key','action_takenby__account_user__username','action_state__state_name')
    filter_class = ContentApprovalsFilter
    lookup_field = 'key'
    def get_queryset(self):
        return ContentApprovals.objects.all()
                
    

    
    
    
    
