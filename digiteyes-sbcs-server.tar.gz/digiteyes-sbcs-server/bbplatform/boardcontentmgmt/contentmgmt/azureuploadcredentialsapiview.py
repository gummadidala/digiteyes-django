from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework.response import Response
from boardcontentmgmt.models import AccountUser,StorageAccount,Account
from rest_framework.status import HTTP_201_CREATED, HTTP_500_INTERNAL_SERVER_ERROR,\
HTTP_302_FOUND,HTTP_400_BAD_REQUEST
from rest_framework.authentication import TokenAuthentication
import traceback,sys
import math,random,string,json
from rest_framework.authentication import TokenAuthentication

from azure.storage.blob import BlockBlobService,ContainerPermissions
from azure.storage.blob import PublicAccess
from azure.storage.blob import ContentSettings
from datetime import datetime, timedelta
from azure.storage.models import CorsRule


import logging
logger = logging.getLogger(__name__)

def set_cors(block_blob_service):
    print 'In Setting_cors!!'
    url = ['*']
    method =['GET','POST','PUT','OPTIONS']
    corslist = []
    corslist.append(CorsRule(url,method,allowed_headers=['*'],max_age_in_seconds=20,exposed_headers=['*']))
    block_blob_service.set_blob_service_properties(None,None,None,corslist,"2015-02-21",None)

def get_media_creds():
    print "In get_media_creds"
    acct_name='demediatest'
    access_key="RhMG+X6knV4IKZIkXARRP53lN5+lQTM/r389RCdgoEb1hkBwObL2L7e8chqTVwTLmRofcnfm6O3Xgr78iMSxsA=="
    block_blob_service = BlockBlobService(account_name=acct_name, account_key=access_key)
    #set_cors(block_blob_service)
    host_path = 'https://demediatest.blob.core.windows.net/'
    print block_blob_service,host_path
    return block_blob_service,host_path

def get_invoice_creds():
    print "In get_invoice_creds"
    acct_name='deinvoicetest'
    access_key="FXwz53SB9tZaqlinlOOIx2LeFjp2oDtNXa1WSd8R0iewQQf3FRtbUNmMBD/gsSMS+4UnwOwau5jGFNhLy1ga0Q=="
    block_blob_service = BlockBlobService(account_name=acct_name, account_key=access_key)
    #set_cors(block_blob_service)
    host_path = 'https://deinvoicetest.blob.core.windows.net/'
    return block_blob_service,host_path

def get_pdfreport_creds():
    print "In get_pdfreport_creds"
    acct_name='depdfreporttest'
    access_key="UloQsxP545HlOUBHvnPF2aK7VJaBQh88PIwJ6QAfvQsaB/6arJMnlUzlRLlX0HI7tJf5swy3gT7OUcB4xnGLww=="
    block_blob_service = BlockBlobService(account_name=acct_name, account_key=access_key)
    #set_cors(block_blob_service)
    host_path = 'https://depdfreporttest.blob.core.windows.net/'
    return block_blob_service,host_path

def get_common_creds():
    print "In get_common_creds"
    acct_name='decommontest'
    access_key="VqfzkcIcUgLrwzhNJTjTgYELC2CJ+aZlvzArJww/p5jDEEzhDFqy/GKJqAx4t+OxFKlhz5BGPb1oVbc9kx5iBQ=="
    block_blob_service = BlockBlobService(account_name=acct_name, account_key=access_key)
    #set_cors(block_blob_service)
    host_path = 'https://decommontest.blob.core.windows.net/'
    return block_blob_service,host_path 

def get_creds_type_based(type):
    if type == 'MEDIA':
        return get_media_creds()
    elif type == 'INVOICE':
        return get_invoice_creds()
    elif type == 'PDFREPORT':
        return get_pdfreport_creds()
    else:
        return get_common_creds()
    
def get_sas(container_name,type="MEDIA"):
    if container_name == "":
        container_name = 'defaultcontainer'
    print 'type :',type
    service = get_creds_type_based(type)
    sas_url = service[0].generate_container_shared_access_signature(
            container_name,
            ContainerPermissions.WRITE,
            datetime.utcnow() + timedelta(hours=1),
        )
    return sas_url,service[1]
    
def create_storage_container(container_name):
    corrected_name = container_name.decode('utf-8').lower().replace(" ", "")
    sa = StorageAccount()
    sa.name = corrected_name
    logger.info("container_name :"+str(container_name))
    sa.account = Account.objects.filter(account_name=container_name)[0]
    sa.save()
    storage_container_name=corrected_name
    storage_types = ['MEDIA','INVOICE','PDFREPORT']
    for type in storage_types:
        service = get_creds_type_based(type)
        containers = service[0].list_containers()
        exists = False
        for c in containers:
            if c.name == storage_container_name:
                exists = True
        if not exists:
            logger.info('Service_instance:'+unicode(service[0]))       
            service[0].create_container(storage_container_name,public_access=PublicAccess.Container)  

def create_blob(filePath,blob_name,container_name,file_type,type="MEDIA"):
    logger.info("container_name :"+str(container_name))
    container_name = container_name.decode('utf-8').lower().replace(" ", "")
    service = get_creds_type_based(type)
    if container_name == "":
        container_name = 'defaultcontainer'
    containers = service[0].list_containers()
    print 'BLOB_Service_instance : ',unicode(service[0])
    exists = False
    for c in containers:
        if c.name == container_name:
            exists = True
    if not exists:
        create_storage_container(container_name)
    service[0].create_blob_from_path(
        container_name,
        blob_name,
        filePath,
        content_settings=ContentSettings(content_type=file_type)
    )
    return service[1]+container_name+'/'+blob_name
           
class AzureUploadCredentials(APIView):
    #authentication_classes = (ExpiringTokenAuthentication,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated, )
    
    def get(self,request,format = None):
        response_obj = {}
        usr = request.user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        account = aUsr[0].account.account_name
        storage_account = StorageAccount.objects.filter(account__account_name = account)
        container_name = ""
        storage_type = self.request.query_params.get('storage_type',None)
        if storage_type is None:
            storage_type = "MEDIA"
        if storage_account is not None and len(storage_account) > 0:
            container_name = storage_account[0].name
            container_name=container_name.decode('utf-8').lower().replace(" ","")
        else:
            create_storage_container(account)
            container_name = account.decode('utf-8').lower().replace(" ","")
        try:
            sas_url = get_sas(container_name,storage_type)
            response_obj={"sas_url":sas_url[0],
                          "container":container_name,
                          "host_path":sas_url[1]}
                            
            return Response(response_obj,status=HTTP_201_CREATED)
        except:
            logger.error ("AZURE_CREDS_ERROR "+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("AZURE_CREDS_ERROR "+str(tb))
            error = {'error':'Error while getting Azure Upload Credentials'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        
            

    
    
    
    
    
    
