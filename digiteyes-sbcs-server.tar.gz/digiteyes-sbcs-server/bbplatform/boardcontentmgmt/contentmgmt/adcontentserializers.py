from rest_framework import serializers
from boardcontentmgmt.models import Content, ContentQueue, ContentState, ContentType, ContentSchedule,ContentTarget,ContentQueueType
from boardcontentmgmt.models import AccountUser, Account , CTA, CTAType,SubordinateContent,ContentLabel,\
Layout,LayoutMapping,CTAParameters,CTAParametersActed,VoucherCta,VoucherCtaType, ConsumerContentTargets
from boardcontentmgmt.accountmgmt.accountuserserializers import AccountUserShortSerializer
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from boardcontentmgmt.layoutmgmt.layoutserializers import LayoutSerializer,LayoutShortSerializer
import hashlib
import urllib
import os,sys,traceback
from datetime import datetime
#import tasks

import logging
logger = logging.getLogger(__name__)
#################################################################################
# Serializers for Master data
#################################################################################

class ContentTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContentType
        fields = ['type_name',]
class ContentStateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContentState
        fields = ['state_name',]
class CTATypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = CTAType
        fields = ['name',]


class VoucherCtaSerializer(serializers.ModelSerializer):
    type = serializers.SlugRelatedField(
        queryset=VoucherCtaType.objects.all(),
        slug_field='name')
    account =  serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key')
    class Meta:
        model = VoucherCta
        fields = ['name','key','account','type','description','isSuprise','percentage_minimum',
                  'percentage_maximum','flat_amount_minimum','flat_amount_maximum','percentage',
                  'flat_amount','validity','creative_url','term_conditions']
#################################################################################
# CTA Serializers
#################################################################################
class CTAParameterSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    class Meta:
        model = CTAParameters
        fields = ['key','name','value','account']
    def create(self,validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        return serializers.ModelSerializer.create(self,validated_data)
class CTAParameterActedSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    class Meta:
        model = CTAParametersActed
        fields = ['key','name','value','account']
    def create(self,validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        return serializers.ModelSerializer.create(self,validated_data)
        
class CTASerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key')
    type = serializers.SlugRelatedField(
        queryset=CTAType.objects.all(),
        slug_field='name')
    voucher = VoucherCtaSerializer() 
    cta_parameters= CTAParameterSerializer(many=True,required=False)
    class Meta:
        model = CTA
        fields = ['type','cta_parameters','account','key','voucher']
class CTAWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key', required=False)
    type = serializers.SlugRelatedField(
        queryset=CTAType.objects.all(),
        slug_field='name')
    cta_parameters= serializers.SlugRelatedField(
        queryset=CTAParameters.objects.all(),
        slug_field='key',many=True,required=False)
    voucher = serializers.SlugRelatedField(
        queryset=VoucherCta.objects.all(),
        slug_field='key', required=False)
    class Meta:
        model = CTA
        fields = ['type','cta_parameters','account','key','voucher']
    def create(self,validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        if 'cta_parameters' not in validated_data:
            validated_data['cta_parameters']=[]
        if 'voucher' not in validated_data:
            validated_data['voucher']=None
        return serializers.ModelSerializer.create(self,validated_data)

class ContentTargetWriteSerializer(serializers.ModelSerializer):
    target_cta = serializers.SlugRelatedField(
        queryset=CTA.objects.all(),
        slug_field='key',many=True, required=False)
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    service_location_lat = serializers.CharField(default="",allow_blank=True)
    service_location_long = serializers.CharField(default="",allow_blank=True)
    class Meta:
        model = ContentTarget
        fields = ['target_image_url','target_title','target_description',
                  'target_cta','account','service_location_lat',
                  'service_location_long','key']
    def create(self,validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        return serializers.ModelSerializer.create(self,validated_data)
    
##################################################################################
#Serializer for SubordinateContent
#################################################################################
class SubordinateContentShortSerializer(serializers.ModelSerializer):
    type = serializers.SlugRelatedField(
        queryset=ContentType.objects.all(),
        slug_field='type_name')
    content_label=serializers.SlugRelatedField(
        queryset=ContentLabel.objects.all(),
        slug_field='name')
    class Meta:
        model = SubordinateContent
        fields = ['key','type','url','text','content_label','name']
class SubordinateContentSerializer(serializers.ModelSerializer):
    account = AccountSerializer()
    content_label=serializers.SlugRelatedField(
        queryset=ContentLabel.objects.all(),
        slug_field='name')
    type = serializers.SlugRelatedField(
        queryset=ContentType.objects.all(),
        slug_field='type_name')
    class Meta:
        model = SubordinateContent
        fields = ['key','account','content_label','name','type','url','text']
##################################################################################
#Write Serializer for SubordinateContent
#################################################################################
class SubordinateContentWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required = False)
    content_label=serializers.SlugRelatedField(
        queryset=ContentLabel.objects.all(),
        slug_field='name',required = False)
    type = serializers.SlugRelatedField(
        queryset=ContentType.objects.all(),
        slug_field='type_name')
    class Meta:
        model = SubordinateContent
        fields = ['key','account','content_label','name','type','url','text']
    def create(self,validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        return serializers.ModelSerializer.create(self,validated_data)
#################################################################################
# Content Serializers
#################################################################################
class ContentSubordinateTextShortSerializer(serializers.ModelSerializer):
    subordinate_content = SubordinateContentShortSerializer(many=True,required=False)
    class Meta:
        model = Content
        fields = ('content_name','subordinate_content','key')

class ContentShortSerializer(serializers.ModelSerializer):
    content_type = serializers.SlugRelatedField(
        queryset=ContentType.objects.all(),
        slug_field='type_name')
    subordinate_content = SubordinateContentShortSerializer(many=True,required=False)
    class Meta:
        model = Content
        fields = ('content_name', 'content_type','content_play_time', 'key','content_source','thumbnail_source','portrait_content_source','hash','subordinate_content')

class ContentShortSerializerForTaPP(serializers.ModelSerializer):
    content_type = serializers.SlugRelatedField(
        queryset=ContentType.objects.all(),
        slug_field='type_name')
    subordinate_content = SubordinateContentShortSerializer(many=True,required=False)
    class Meta:
        model = Content
        fields = ('content_type','content_name','key','content_source','portrait_content_source','content_primary_source','subordinate_content')

#################################################################################
# Content Target Serializers
#################################################################################
class ContentTargetSerializer(serializers.ModelSerializer):
    target_cta = CTASerializer(many=True)
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key')
    class Meta:
        model = ContentTarget
        fields = ['target_image_url','target_title','target_description',
                  'target_cta','account','service_location_lat',
                  'service_location_long','key']

class ContentSerializer(serializers.ModelSerializer):
    content_type = serializers.SlugRelatedField(
        queryset=ContentType.objects.all(),
        slug_field='type_name')
    content_state = serializers.SlugRelatedField(
        queryset=ContentState.objects.all(),
        slug_field='state_name')
    content_owner = AccountUserShortSerializer()
    account = AccountSerializer()
    content_target = ContentTargetSerializer(required=False)
    subordinate_content = SubordinateContentSerializer(many=True,required=False)
    class Meta:
        model = Content
        fields = ('content_name','content_type','content_owner','content_source',
                  'content_state', 'account','last_updated_date','content_target',
                  'portrait_content_source', 'content_play_time',
                  'thumbnail_source','key','hash','content_primary_source','subordinate_content')

class ContentWriteSerializer(serializers.ModelSerializer):
    content_type = serializers.SlugRelatedField(
        queryset=ContentType.objects.all(),
        slug_field='type_name')
    content_state = serializers.SlugRelatedField(
        queryset=ContentState.objects.all(),
        slug_field='state_name',required=False)
    content_owner = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key',required=False)
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    content_target = serializers.SlugRelatedField(
        queryset = ContentTarget.objects.all(),
        slug_field='key',
        required=False,allow_null=True)
    content_play_time = serializers.DurationField(required=False)
    portrait_content_source = serializers.CharField(default="")
    subordinate_content = serializers.SlugRelatedField(
        queryset = SubordinateContent.objects.all(),
        slug_field='key',required=False,allow_null=True,many=True)
    class Meta:
        model = Content
        fields = ('content_name','content_type','content_owner','content_source',
                  'content_state', 'account','last_updated_date','content_target',
                  'content_play_time','content_primary_source',
                  'portrait_content_source', 'key','hash','subordinate_content')
    def create(self,validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        validated_data['content_owner'] = aUsr[0]
        draft_state = ContentState.objects.filter(state_name = 'DRAFT')
        inprogress_state = ContentState.objects.filter(state_name = 'INPROGRESS')
        if validated_data['content_type'].type_name=='IMAGE'or validated_data['content_type'].type_name=='TEXT':# or validated_data['content_type'].type_name=='IMAGE_BUNCH' :
            validated_data['content_state'] = draft_state[0]
        else:
            validated_data['content_state'] = inprogress_state[0]
        if not 'content_target' in validated_data :
            validated_data['content_target'] = None
        print 'validated data', validated_data
        msg = validated_data['content_source']
        validated_data['content_source'] = msg.encode('utf-8').strip()
        return serializers.ModelSerializer.create(self,validated_data)
    
    def update(self, instance, validated_data,format = None):
        if 'content_state' in validated_data:
            instance.content_state = validated_data['content_state']
        if 'content_target' in validated_data:
            instance.content_target = validated_data['content_target']
        if 'content_name' in validated_data:
            instance.content_name = validated_data['content_name']
        if 'content_source' in validated_data:
            instance.content_source = validated_data['content_source']
        if 'content_type' in validated_data:
            instance.content_type = validated_data['content_type']
        if 'subordinate_content' in validated_data:
            instance.subordinate_content = validated_data['subordinate_content']
        instance.save()
        return instance
#################################################################################
# ContentQueue Serializers
#################################################################################
class ContentScheduleSerializer(serializers.ModelSerializer):
    content = ContentShortSerializer(read_only=True)
    class Meta:
        model = ContentSchedule
        fields = ['content','filler_time','repeat']
class ContentScheduleWriteSerializer(serializers.ModelSerializer):
    content = serializers.SlugRelatedField(
        queryset=Content.objects.all(),
        slug_field='key')
    class Meta:
        model = ContentSchedule
        fields = ['content','filler_time','repeat']
class ContentQueueWriteSerializer(serializers.ModelSerializer):
    content_list = ContentScheduleWriteSerializer(many=True)
    content_queue_owner = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key',required=False)
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)  
    queue_state = serializers.CharField(required=False)
    unit_size = serializers.IntegerField(default=30)
    layout = serializers.SlugRelatedField(
        queryset=Layout.objects.all(),
        slug_field='key',required=False)
    type = serializers.SlugRelatedField(
        queryset=ContentQueueType.objects.all(),
        slug_field='name')
    class Meta:
        model = ContentQueue
        fields = ['content_queue_name','content_queue_owner','account',
                  'last_updated_date','queue_state','content_list',
                  'num_units','unit_size','key','layout','type']
    def create(self, validated_data):
        try:
            contentq=ContentQueue()
            usr = self.context['request'].user
            aUsr = AccountUser.objects.filter(account_user__username = usr.username)
            contentq.content_queue_name=validated_data['content_queue_name']
            contentq.queue_state = 'UNSEALED'
            contentq.num_units = validated_data['num_units']
            contentq.unit_size = validated_data['unit_size']
            contentq.type = validated_data['type']
            contentq.content_queue_owner=aUsr[0]
            contentlist = validated_data['content_list']
            if 'layout' in validated_data:
                contentq.layout = validated_data['layout']
            else:
                contentq.layout=None
            logger.debug(contentlist)
            scheduleList = []
            for contentschedule in contentlist:
                schedule = ContentScheduleWriteSerializer().create(contentschedule)
                schedule.save()
                scheduleList.append(schedule)
            contentq.account = aUsr[0].account
            contentq.save()
            contentq.content_list = scheduleList
            contentq.save()
            logger.info("PLAY_LIST_CREATED : Name : "+str(contentq.content_queue_name) + 
                        "Units : "+str(contentq.num_units))
            return contentq 
        except:
            logger.error ("PLAY_LIST_CREATION_ERROR "+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("PLAY_LIST_CREATION_ERROR "+str(tb))
            return None
    def update(self, instance, validated_data):
        if instance.queue_state == 'SEALED' :
            raise ValueError("Sealed play list cannot be edited")
        else :
            instance.content_queue_name=validated_data['content_queue_name']
            instance.queue_state = validated_data['queue_state']
            contentlist = validated_data['content_list']
            instance.num_units = validated_data['num_units']
            instance.unit_size = validated_data['unit_size']
            if 'layout' in validated_data:
                instance.layout = validated_data['layout']
            scheduleList = []
            for contentschedule in contentlist:
                schedule = ContentScheduleWriteSerializer().create(contentschedule)
                schedule.save()
                scheduleList.append(schedule)
            instance.content_list = scheduleList
            instance.save()
            return instance    
class ContentQueueSerializer(serializers.ModelSerializer):
    content_list = ContentScheduleSerializer(many=True)
    content_queue_owner = AccountUserShortSerializer()
    account = AccountSerializer()  
    layout = LayoutSerializer()
    type = serializers.SlugRelatedField(
        queryset=ContentQueueType.objects.all(),
        slug_field='name')
    class Meta:
        model = ContentQueue
        fields = ['content_queue_name','content_queue_owner','account',
                  'last_updated_date','content_list','queue_state','num_units',
                  'unit_size','key','layout','type']          
class ContentQueueShortSerializer(serializers.ModelSerializer):
    content_list = ContentScheduleSerializer(many=True)
    layout = LayoutShortSerializer()
    class Meta:
        model = ContentQueue
        fields = ['content_queue_name',
                  'content_list','key','unit_size','layout'] 
        

class VoucherCtaWriteSerializer(serializers.ModelSerializer):
    type = serializers.SlugRelatedField(
        queryset=VoucherCtaType.objects.all(),
        slug_field='name')
    account =  serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    class Meta:
        model = VoucherCta
        fields = ['name','key','account','type','description','isSuprise','percentage_minimum',
                  'percentage_maximum','flat_amount_minimum','flat_amount_maximum','percentage',
                  'flat_amount','validity','creative_url','term_conditions']
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        validated_data['validity'] = validated_data['validity'].replace(minute=59,hour=23,second=59)
        return serializers.ModelSerializer.create(self,validated_data)

class ConsumerContentTargetWriteSerializer(serializers.ModelSerializer):
    show_spot_location_lat = serializers.CharField(allow_blank=True)
    show_spot_location_long = serializers.CharField(allow_blank=True)
    show_spot_location_key = serializers.UUIDField(required=False)
    show_spot_beacon_touched = serializers.CharField(required=False)
    content_target = serializers.SlugRelatedField(
        queryset=ContentTarget.objects.all(),
        slug_field='key')
    content = serializers.SlugRelatedField(
        queryset=Content.objects.all(),
        slug_field='key',required=False)
    time = serializers.DateTimeField()
    campaign = serializers.UUIDField(required=False)
    account = serializers.SlugRelatedField(
        queryset=Content.objects.all(),
        slug_field='key',required=False)
    class Meta:
		model = ConsumerContentTargets
		fields = ['show_spot_location_lat','show_spot_location_long','show_spot_location_key',
		          'show_spot_beacon_touched','content_target','content','time','campaign','account']
        
    def create(self, validated_data):
        if 'account' not in validated_data:
            usr = self.context['request'].user
            aUsr = AccountUser.objects.filter(account_user__username = usr.username)
            validated_data['account'] = aUsr[0].account
        if 'content' not in validated_data:
            validated_data['content'] = None
        if 'campaign' not in validated_data:
            if validated_data['content'] is not None:
                campaigns = AdvtCampaign.objects.filter(type__name='AR',
                    ar_content__key=validated_data['content'].key,state__state_name='RUNNING')
                if len(campaigns) > 0 :
                    validated_data['campaign'] = campaigns[0].key
                else:
                    validated_data['campaign'] = None
            else:
                validated_data['campaign'] = None
        if 'show_spot_location_key' not in validated_data:
            validated_data['show_spot_location_key'] = None
        return serializers.ModelSerializer.create(self, validated_data)    
        
              
