from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework import filters
from boardcontentmgmt.models import AffiliateContent,AccountUser
from .affiliatecontentserializers import AffiliateContentSerializer,AffiliateContentWriteSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
import datetime
#################################################################################
#AffiliateContent API List View - Supports Listing and Create
#################################################################################
class AffiliateContentFilter(django_filters.FilterSet):
    play_list = django_filters.CharFilter(name='play_list__content_queue_name',lookup_type='exact')
    screen_group = django_filters.CharFilter(name='screen_group__name',lookup_type='exact')
    planned_date = django_filters.DateFilter(name='planned_date',lookup_type='exact')
    account_name= django_filters.DateFilter(name='submitted_account__account_name',lookup_type='exact')
    class Meta:
        model = AffiliateContent
        fields = []
class AffiliateContentListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,DjangoModelPermissions)#,DjangoObjectPermissions,)
    serializer_class  = AffiliateContentSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_class = AffiliateContentFilter
    search_fields = ('play_list','screen_group','planned_date')
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'affiliatecontent') == True):
            return AffiliateContent.objects.all()
        else:
            return AffiliateContent.objects.filter(submitted_account__key = acct.key)
        #return AffiliateContent.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return AffiliateContentWriteSerializer
        return AffiliateContentSerializer
#################################################################################
# AffiliateContent  API Detail View - Supports Update/Patch and Deletion
#################################################################################
class AffiliateContentUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions)#,DjangoObjectPermissions)
    serializer_class  = AffiliateContentSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('play_list','screen_group','planned_date')
    filter_class = AffiliateContentFilter
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'affiliatecontent') == True):
            return AffiliateContent.objects.all()
        else:
            return AffiliateContent.objects.filter(submitted_account__key = acct.key)
        #return AffiliateContent.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return AffiliateContentWriteSerializer
        return AffiliateContentSerializer
    
    
    
    