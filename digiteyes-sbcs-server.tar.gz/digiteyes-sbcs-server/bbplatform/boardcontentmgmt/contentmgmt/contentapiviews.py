from rest_framework import generics, serializers
from boardcontentmgmt.models import Content , AccountUser , ContentQueue, CTA, \
ContentTarget,CTAParameters,CTAParametersActed
from boardcontentmgmt.models import ShowSpotAsset , Board, BoardPlayHistory, ContentState,SubordinateContent
from boardcontentmgmt.models import BookingState,ContentSchedule,BookedAdPack,\
AdvtCampaign,CampaignState,ContentApprovals,Account,VoucherCta
from .adcontentserializers import ContentSerializer,ContentQueueSerializer
from .adcontentserializers import CTASerializer, CTAWriteSerializer
from .adcontentserializers import ContentTargetSerializer, ContentTargetWriteSerializer
from .adcontentserializers import ContentWriteSerializer, ContentQueueWriteSerializer
from .adcontentserializers import SubordinateContentSerializer,SubordinateContentWriteSerializer,\
    CTAParameterSerializer,CTAParameterActedSerializer,VoucherCtaSerializer,VoucherCtaWriteSerializer
from rest_framework import filters
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
import django_filters
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from rest_framework.pagination import PageNumberPagination
from boardcontentmgmt.tasks import fill_content_length, calculate_hash,do_vuforia_upload_for_AR,scale_target_image_task
from boardcontentmgmt.showspotmgmt.showspotassetserializers import ShowSpotLocationSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from rest_framework.response import Response
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from affiliateads.tasks import approve_contents_email_notification
from datetime import datetime
import sys,traceback
from django.db.models import Count
import logging
from boardcontentmgmt.tasks import send_email,send_email_ses,send_contentstatechange_notification
from celery.bin.celery import result
from reportlab.lib.randomtext import objects
from babel.util import distinct
from boardcontentmgmt.accountmgmt.accountserializers import AccountShortSerializer
logger = logging.getLogger(__name__)

#################################################################################
# CTAParametersListView - Supports Listing and Creation
#################################################################################
class CTAParameterActedListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)# DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = CTAParameterActedSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('type__name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        '''
        if(ProfileCheck().get_filter(self.request.user,'cta') == True):
            return CTA.objects.all()
        else:
            return CTA.objects.filter(account__key = acct.key)
            '''
        return CTAParametersActed.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return CTAParameterActedSerializer
        return CTAParameterActedSerializer

#################################################################################
# CTAParametersListView - Supports Listing and Creation
#################################################################################
class CTAParametersListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)# DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = CTAParameterSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('type__name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        '''
        if(ProfileCheck().get_filter(self.request.user,'cta') == True):
            return CTA.objects.all()
        else:
            return CTA.objects.filter(account__key = acct.key)
            '''
        return CTAParameters.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return CTAParameterSerializer
        return CTAParameterSerializer

#################################################################################
# CTA API List View - Supports Listing and Creation
#################################################################################
class CTAListView(generics.ListCreateAPIView):
    """
    CTA List
    ========
    ##GET:
    List of CTAs already defined.
    
    ###Search Fileds:   
        1. type
    ##POST:
    Create a CTA
    ###Required fields are
        1. type (name) 
        2. call_number (based on the CTA Type)
        3. url (based on the CTA Type)
        4. app name (based on the CTA Type)
        5. app link (based on the CTA Type)
        
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = CTASerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('type__name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'cta') == True):
            return CTA.objects.all()
        else:
            return CTA.objects.filter(account__key = acct.key)
        #return CTA.objects.filter(account__key = accuser.account.key)
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return CTAWriteSerializer
        return CTASerializer
#################################################################################
# CTA API Update View - Supports Update/Patch and Deletion
#################################################################################
class CTAUpdateView(generics.RetrieveUpdateDestroyAPIView):
    """
    CTA
    ========
    ##GET:
    Retrieves the CTA object specified by the key.
           
    ##PUT:
    
    Updates a CTA Object
    ###Required fields are
        1. type (name) 
        2. call_number (based on the CTA Type)
        3. url (based on the CTA Type)
        4. app name (based on the CTA Type)
        5. app link (based on the CTA Type)
        
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = CTASerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name','desc',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'cta') == True):
            return CTA.objects.all()
        else:
            return CTA.objects.filter(account__key = acct.key)
        #return CTA.objects.filter(account__key = accuser.account.key)
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return CTAWriteSerializer
        return CTASerializer
#################################################################################
# Content Target List View - Supports Listing and Creation
#################################################################################
class ContentTargetListView(generics.ListCreateAPIView):
    """
    Content Target List
    ========
    ##GET:
    List of Content Targets. Content Target is a product/service/promotion behind
    the content that is displayed.
    
    ###Search Fileds:
    
        1. target_title
        2. target_description 
        
                
    ##POST:
    
    Creates a Content Target.
    ###Required fields are
        1. target_title
        2. target_description
        3. cta (key)
        4. target_image_url (An Image which represents the target product/service)
        
    """
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = ContentTargetSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('target_title','target_description',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'contenttarget') == True):
            return ContentTarget.objects.all()
        else:
            return ContentTarget.objects.filter(account__key = acct.key)
        #return ContentTarget.objects.all()
        #return ContentTarget.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ContentTargetWriteSerializer
        return ContentTargetSerializer
    def perform_create(self, serializer):
        try:
            generics.ListCreateAPIView.perform_create(self, serializer)
            logger.info("CONTENT_TARGET_CREATED "+str(serializer.instance))
            scale_target_image_task.delay(str(serializer.instance.key))
        except:
            logger.error ("CONTENT_TARGET_CREATION_ERROR "+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("CONTENT_TARGET_CREATION_ERROR "+str(tb))
#################################################################################
# Beacon Content Serializer and Consumer content 
#################################################################################
#class ConsumerContentTargetSerializer(serializers.Serializer):
    
class BeaconContentSerializer(serializers.Serializer):
    spot = ShowSpotLocationSerializer()
    time = serializers.DateTimeField()
    target = ContentTargetSerializer()
    
class ConsumerContentTargetListView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = BeaconContentSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_class = 
    def get_queryset(self):
        from_time = self.request.query_params.get('start_time', None)
        to_time = self.request.query_params.get('end_time', None)
        beacon = self.request.query_params.get('beacon', None)
        logger.info("From Time: "+from_time + "To Time :"+ to_time + "beacon : "+beacon)
        touchedbeacons = []       
        beacon_contents = []
        touchedbeacons.append(beacon)
        spotassets = ShowSpotAsset.objects.filter(
            attached_beacons__mac_address__in=touchedbeacons)
        if spotassets and spotassets is not None :
            for spot in spotassets:
                beacon_content = {}
                contentTargets = []
                logger.info( str(spot.key))
                boards = Board.objects.filter(show_spot__key = spot.key)
                if boards and boards is not None :
                    bord = boards[0]
                    logger.info( bord.board_name)
                    playhistories = BoardPlayHistory.objects.filter(
                        board__key=bord.key).exclude(
                        content_from_time__gte=to_time).exclude(
                        content_to_time__lte=from_time)
                    
                    if playhistories is not None and playhistories:
                        content_ids = []
                        for history in playhistories:
                            if history.content_played.key not in content_ids:
                                content_ids.append(history.content_played.key)
                                logger.info( history.content_played.content_name)
                                contentTargets.append({'target':
                                    history.content_played.content_target,
                                    'time':history.content_to_time,'spot':spot})
                #beacon_content['content_targets'] = contentTargets
                #beacon_contents.append(beacon_content)
        return contentTargets
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ConsumerContentTargetWriteSerializer
        return BeaconContentSerializer
    
        
#################################################################################
# ContentTarget API Update View - Supports Update/Patch and Deletion
#################################################################################
class ContentTargetUpdateView(generics.RetrieveUpdateDestroyAPIView):
    """
    Content Target
    ========
    ##GET:
    Retrieves the Content Target object specified by the key.
           
    ##PUT:
    Updated a Content Target.
    ###Required fields are
        1. target_title
        2. target_description
        3. cta (key)
        4. target_image_url (An Image which represents the target product/service)
        
    """
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = ContentTargetSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name','desc',)
    lookup_field = 'key'
    def get_queryset(self):
        '''
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'contenttarget') == True):
            return ContentTarget.objects.all()
        else:
            return ContentTarget.objects.filter(account__key = acct.key)
            '''
        return ContentTarget.objects.all()
    def get_serializer_class(self):
        print 'requested data:', self.request.data
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return ContentTargetWriteSerializer
        return ContentTargetSerializer
#################################################################################
# Content API List View - Pagination + Filter Classes.
#################################################################################
class CustomPagination(PageNumberPagination):
    page_size_query_param = 'page_size'
class ContentFilter(django_filters.FilterSet):
    content_state = django_filters.CharFilter(name='content_state__state_name')
    content_type = django_filters.CharFilter(name='content_type__type_name')
    account = django_filters.CharFilter(name='account__account_name')
    class Meta:
        model = Content
        fields = []
#################################################################################
# Content API List View
#################################################################################
class ContentList(generics.ListCreateAPIView):
    """
    Content List
    ========
    ##GET:
    List of Contents available in the Account. Contents are things like videos, images etc.,
    ###Filter Fields:
        1. Content State (content_state)
        2. Content Type (content_type)
    ###Search Fileds:
    
        1. Content Name
        
    ##POST:
    
    Create a Content Entry with the Account.
    ###Required fields are
        1. Content Name (content_name)
        2. Content Type (content_type)
        3. Content Source (content_source) - The URL where the content is uploaded.
    
    Contents are automatically put into the logged user's Account, with which this create call is made. The logged
    in user automatically becomes the content owner.
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    serializer_class = ContentSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_fields = ('content_type__type_name', 'content_state__state_name')
    filter_class = ContentFilter
    search_fields = ('content_name',)
    pagination_class = CustomPagination
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'content') == True):
            return Content.objects.all().order_by('-last_updated_date')
        else:
            return Content.objects.filter(account__key = acct.key).order_by('-last_updated_date')
        #return Content.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ContentWriteSerializer
        return ContentSerializer
    ##
    # Override create method to trigger the task to update play time
    ##
    def perform_create(self, serializer):
        try:
            generics.ListCreateAPIView.perform_create(self, serializer)
            logger.info("CONTENT_CREATED "+str(serializer.instance))
            fill_content_length.delay(str(serializer.instance.key))
        except:
            logger.error ("CONTENT_CREATION_ERROR "+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("CONTENT_CREATION_ERROR "+str(tb))
#################################################################################
# Content API Update View
#################################################################################
def change_status(content_key,state): #changing the booking status of apartment advertisements
    try:
        failed = BookingState.objects.filter(name='FAILED')[0]
        success = BookingState.objects.filter(name='SUCCESS')[0]
        content_schedule = ContentSchedule.objects.filter(content__key = content_key)
        if content_schedule is not None and len(content_schedule) > 0:
            play_list = ContentQueue.objects.filter(content_list__in =content_schedule).distinct()
            if play_list is not None and len(play_list)>0:
                for pl in play_list:
                    campaign = AdvtCampaign.objects.filter(play_list__key = pl.key)    
                    if campaign is not None and len(campaign)>0:
                        for camp in campaign:
                            bookedadpack = BookedAdPack.objects.filter(applied_to__key = camp.key)
                            if bookedadpack is not None and len(bookedadpack)>0:
                                for bap in bookedadpack:
                                    if state == 'APPROVED' and bap.booking_state.name == 'BLOCKED':
                                        bap.booking_state = success
                                        bap.save() 
                                        camp.state = CampaignState.objects.filter(state_name='PLANNED')[0]
                                        camp.save() 
                                    elif state == 'REJECTED':
                                        bap.booking_state = failed
                                        bap.save()
                                        camp.state = CampaignState.objects.filter(state_name='REJECTED')[0]
                                        camp.save()
    except:
        logger.error ("CONTENT_STATECHANGE_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("CONTENT_STATECHANGE_ERROR "+str(tb))
def create_contentapprovals_entry(cntnt_key,state,user,comment_info):
    print "In create_contentapprovals_entry"
    logger.debug("In create_contentapprovals_entry")
    obj=ContentApprovals()
    obj.content = Content.objects.filter(key=cntnt_key)[0]
    obj.action_state = ContentState.objects.filter(state_name=state)[0]
    obj.action_takenby = AccountUser.objects.filter(account_user__username=user)[0]
    obj.action_time = datetime.now()
    obj.action_comment = comment_info
    obj.save()
def clear_hash(cntnt_key):
    logger.debug("In clear_hash")
    obj=Content.objects.filter(key=cntnt_key)
    if obj is not None and len(obj)>0:
        obj[0].hash = ""
        obj[0].save()

class ContentUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    permission_classes = (IsAuthenticated, PermissionCheck)
    lookup_field = 'key'
    serializer_class = ContentSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('content_type__type_name', 'content_state__state_name')
    #filter_class = ContentFilter
    search_fields = ('content_name',)
    pagination_class = PageNumberPagination
    page_size = 10
    def special(self):
        approve = ContentState.objects.filter(state_name = 'APPROVED')[0]
        reject = ContentState.objects.filter(state_name = 'REJECTED')[0]    
        field_permissions = [{'field_name' : 'content_state', 'permission':['can_approve_content', 'can_reject_content'],
                             'state':[approve.state_name,reject.state_name],'model_name' : 'content'}]
        return field_permissions
    def get_queryset(self):
        '''
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'content') == True):
            return Content.objects.all()
        else:
            return Content.objects.filter(account__key = acct.key)
            '''
        return Content.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return ContentWriteSerializer
        return ContentSerializer
    
    def patch(self,request,format=None,*args,**kwargs):
        parsed_data = request.data
        rejected = ContentState.objects.filter(state_name = 'REJECTED')[0]
        if 'content_state' in parsed_data and parsed_data['content_state'] == rejected:
            if parsed_data['comment_info'] !="":
                error = {'error':'Please mention the reason for rejection!'}
                return Response(error,status = HTTP_400_BAD_REQUEST) 
        return generics.RetrieveUpdateDestroyAPIView.patch(self,request,*args,**kwargs) 
    
    def put(self,request,format=None,*args,**kwargs):
        parsed_data = request.data
        rejected = ContentState.objects.filter(state_name = 'REJECTED')[0]
        if 'content_state' in parsed_data and parsed_data['content_state'] == rejected:
            if parsed_data['comment_info'] !="":
                error = {'error':'Please mention the reason for rejection!'}
                return Response(error,status = HTTP_400_BAD_REQUEST) 
        return generics.RetrieveUpdateDestroyAPIView.patch(self,request,*args,**kwargs)
    
    def perform_update(self, serializer):
        username = self.request.user.username
        comment_info =self.request.data['comment_info']
        generics.RetrieveUpdateDestroyAPIView.perform_update(self, serializer)
        approved = ContentState.objects.filter(state_name = 'APPROVED')
        #print serializer.instance.content_state.state_name
        if serializer.instance.content_state.state_name == approved[0].state_name :
            calculate_hash.delay(str(serializer.instance.key),username)
            do_vuforia_upload_for_AR.delay(str(serializer.instance.key))
            change_status(str(serializer.instance.key),'APPROVED')
            create_contentapprovals_entry(str(serializer.instance.key),'APPROVED',username,comment_info)
            send_contentstatechange_notification(serializer.instance)
            logger.info("CONTENT_APPROVED: Type : "+str(serializer.instance.content_type.type_name)+
                        " NAME : "+str(serializer.instance.content_name))
        elif serializer.instance.content_state.state_name == 'REJECTED':
            if 'revoke' in self.request.data:
                if self.request.data['revoke'] :
                    logger.debug('Revoking approval')
                    clear_hash(str(serializer.instance.key))
                    change_status(str(serializer.instance.key),'REJECTED')
                    send_contentstatechange_notification(serializer.instance)
                    create_contentapprovals_entry(str(serializer.instance.key),'REJECTED',username,comment_info)
                    logger.info("CONTENT_REVOKED: Type : "+str(serializer.instance.content_type.type_name)+
                        " NAME : "+str(serializer.instance.content_name))
                else:
                    change_status(str(serializer.instance.key),'REJECTED')
                    send_contentstatechange_notification(serializer.instance)
                    create_contentapprovals_entry(str(serializer.instance.key),'REJECTED',username,comment_info)
                    logger.info("CONTENT_REJECTED: Type : "+str(serializer.instance.content_type.type_name)+
                            " NAME : "+str(serializer.instance.content_name))
            else:
                change_status(str(serializer.instance.key),'REJECTED')
                send_contentstatechange_notification(serializer.instance)
                create_contentapprovals_entry(str(serializer.instance.key),'REJECTED',username,comment_info)
                logger.info("CONTENT_REJECTED: Type : "+str(serializer.instance.content_type.type_name)+
                        " NAME : "+str(serializer.instance.content_name))
        elif serializer.instance.content_state.state_name == 'SUBMITTED':
            try:
                create_contentapprovals_entry(str(serializer.instance.key),'SUBMITTED',username,comment_info)
                approve_contents_email_notification()
                logger.info("CONTENT_SUBMITTED: Type : "+str(serializer.instance.content_type.type_name)+
                        " NAME : "+str(serializer.instance.content_name))
            except:
                logger.error ("CONTENT_SUBMISSION_ERROR "+ str(sys.exc_info()[0]))
                tb = traceback.format_exc()
                logger.error ("CONTENT_SUBMISSION_ERROR "+str(tb))
                   
#################################################################################
# ContentQueue API List View
#################################################################################
class ContentQueueFilter(django_filters.FilterSet):
    type = django_filters.CharFilter(name='type__name')
    account = django_filters.CharFilter(name='account__account_name')
    units  = django_filters.CharFilter(name='num_units')
    unit_size = django_filters.CharFilter(name='unit_size')
    queue_state = django_filters.CharFilter(name='queue_state')
    class Meta:
        model = ContentQueue
        fields = []
class ContentQueueList(generics.ListCreateAPIView):
    """
    Content Queue List (Play Lists)
    ========
    ##GET:
    List of Content Queues (Play Lists) available in the Account. Content Queues contain videos, 
    images etc.,
    in the order of play.
    
    ###Search Fileds:
    
        1. Content Queue Name
        
    ##POST:
    
    Create a Content Entry with the Account.
    ###Required fields are
        1. Content Queue Name (content_queue_name)
        2. Content List (content_type)
        3. Content Source (content_source) - The URL where the content is uploaded.
    
    Contents are automatically put into the logged user's Account, with which this create call is made. The logged
    in user automatically becomes the content owner.
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    serializer_class = ContentQueueSerializer
    filter_class = ContentQueueFilter
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('queue_state','account__account_name',)
    search_fields = ('content_queue_name',)
    
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'contentqueue') == True):
            return ContentQueue.objects.all().order_by('-last_updated_date')
        else:
            return ContentQueue.objects.filter(account__key = acct.key).order_by('-last_updated_date')
        #return ContentQueue.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ContentQueueWriteSerializer
        return ContentQueueSerializer
#################################################################################
# ContentQueue API Update View
#################################################################################
class ContentQueueUpdateView(generics.RetrieveUpdateDestroyAPIView):
    """
    Content Queue
    ========
    ##GET:
    Gets the Specific Content with the given key. Contents are things like 
    videos, images etc.,
    
        
    ##PUT:
    
    Update a Content Entry with the Account.
    ###Required fields are
        1. Content Queue Name (content_queue_name)
        2. Content List (content_type)
        3. Content Source (content_source) - The URL where the content is uploaded.
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    serializer_class = ContentQueueSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    serializer_class = ContentQueueSerializer
    #filter_class = ContentQueueFilter
    search_fields = ('content_queue_name',)
   
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'contentqueue') == True):
            return ContentQueue.objects.all()
        else:
            return ContentQueue.objects.filter(account__key = acct.key)
        #return ContentQueue.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return ContentQueueWriteSerializer
        return ContentQueueSerializer  
    
class SubmittedContentsListAPIView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)# DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    serializer_class = AccountShortSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('account_name',)
    search_fields = ('account_name',)
    def get_queryset(self):
        submitted_contents = Content.objects.filter(content_state__state_name='SUBMITTED').values('account__key').distinct()
        acct_keys = []
        for sc in submitted_contents:
            acct_keys.append(str(sc['account__key']))
        return Account.objects.filter(key__in=acct_keys)
    def get_serializer_class(self):
        return AccountShortSerializer
#################################################################################
# SubordinateContent API List View
#################################################################################
class SubContentFilter(django_filters.FilterSet):
    content = django_filters.CharFilter(name='content__key',lookup_type='exact')
    class Meta:
        model = SubordinateContent
        fields = []
class SubordinateContentListAPIView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    serializer_class = SubordinateContentSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('type__type_name',)
    filter_class = SubContentFilter
    search_fields = ('name',)
    pagination_class = CustomPagination
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'subordinatecontent') == True):
            return SubordinateContent.objects.all()
        else:
            return SubordinateContent.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return SubordinateContentWriteSerializer
        return SubordinateContentSerializer
#################################################################################
# SubordinateContent API List View
#################################################################################
class SubordinateContentUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    serializer_class = SubordinateContentSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('type__type_name',)
    #filter_class = ContentFilter
    search_fields = ('name',)
    pagination_class = CustomPagination
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'subordinatecontent') == True):
            return SubordinateContent.objects.all()
        else:
            return SubordinateContent.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return SubordinateContentWriteSerializer
        return SubordinateContentSerializer

#################################################################################
# CTAParametersListView - Supports Listing and Creation
#################################################################################
class VoucherCtaListView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)# DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = VoucherCtaSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name',)
    filter_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'Vouchercta') == True):
            return VoucherCta.objects.all()
        else:
            return VoucherCta.objects.filter(account__key = acct.key)
        #return VoucherCta.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return VoucherCtaWriteSerializer
        return VoucherCtaSerializer
    
            
        
        
        