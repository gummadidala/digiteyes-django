from rest_framework import serializers
from boardcontentmgmt.models import AffiliateContent,ContentQueue,AttributeTagGroup,Account,AccountUser
from .adcontentserializers import ContentQueueShortSerializer
from boardcontentmgmt.tagmgmt.tagserializers import AttributeTagGroupSerializer
from boardcontentmgmt.accountmgmt.accountserializers import AccountShortSerializer
##################################################################################
#Serializer for AffiliateContent
#################################################################################
class AffiliateContentSerializer(serializers.ModelSerializer):
    play_list = ContentQueueShortSerializer()
    screen_group = AttributeTagGroupSerializer(many = True)
    submitted_account=AccountShortSerializer()
    class Meta:
        model = AffiliateContent
        fields = ['key','planned_date','play_list','screen_group','num_plays','play_order','submitted_date','submitted_account']
        
#################################################################################
##Serializer for AffiliateContent
#################################################################################
class AffiliateContentWriteSerializer(serializers.ModelSerializer):
    play_list = serializers.SlugRelatedField(
        queryset=ContentQueue.objects.all(),
        slug_field='content_queue_name')
    screen_group = serializers.SlugRelatedField(
        queryset=AttributeTagGroup.objects.all(),
        many = True,slug_field='key')
    submitted_account=serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='account_name')
    class Meta:
        model = AffiliateContent
        fields = ['key','planned_date','play_list','screen_group','num_plays','play_order','submitted_date','submitted_account']
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['submitted_account'] = aUsr[0].account
        return serializers.ModelSerializer.create(self, validated_data)

    