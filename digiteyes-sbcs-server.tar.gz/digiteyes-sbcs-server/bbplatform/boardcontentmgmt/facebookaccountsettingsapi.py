'''
Created on 09-Dec-2016

@author: saba
'''
from rest_framework import serializers, generics
from boardcontentmgmt.accountmgmt.accountserializers import AccountShortSerializer
from boardcontentmgmt.models import FacebookSettings, AccountUser, Account
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework.permissions import IsAuthenticated, DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck

class FacebookSettingsSerializer(serializers.ModelSerializer):
    account = AccountShortSerializer()
    class Meta:
        model = FacebookSettings
        fields =  ['account','fb_page_id','key','page_owner_id','posts_from_days_in_past',
            'channels_to_promote','enable']
class FacebookSettingsWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required = False)
    class Meta:
        model = FacebookSettings
        fields =  ['account','fb_page_id','key','page_owner_id','posts_from_days_in_past',
            'channels_to_promote','enable']
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        return serializers.ModelSerializer.create(self, validated_data)

class FacebookSettingsListView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions)
    #filter_class = 
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        print username
        print accounts[0].key
        settings = FacebookSettings.objects.filter(account__key=accounts[0].account.key)
        print "Num Settings..",len(settings.all())
        return settings
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return FacebookSettingsWriteSerializer
        return FacebookSettingsSerializer

class FacebookSettingsUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        settings = FacebookSettings.objects.filter(account__key=accounts[0].account.key)
        return settings
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return FacebookSettingsWriteSerializer
        return FacebookSettingsSerializer  
    

