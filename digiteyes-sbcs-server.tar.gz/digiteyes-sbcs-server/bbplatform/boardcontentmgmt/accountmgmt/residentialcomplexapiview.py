from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework import filters
import csv,os,urllib
from boardcontentmgmt.models  import ResidentialComplex,AccountUser,ResidentConsumer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions 
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from .residentialcomplexserializers import ResidentialComplexSerializer,ResidentialComplexWriteSerializer
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from boardcontentmgmt.tasks import create_random_temp_file
from rest_framework import serializers
import logging
logger = logging.getLogger(__name__)
#################################################################################
# Residential Complex  API List View - Supports Listing and Create
#################################################################################
class ResidentialComplexListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = ResidentialComplexSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name','city__city_name','city_sub_area')
    filter_fields = ('account__account_name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(usr,'residentialcomplex') == True or
            acct.account_type.type_name=="CONSUMER"):
            return ResidentialComplex.objects.all()
        else:
            return ResidentialComplex.objects.filter(account__key = acct.key)

    #queryset = ResidentialComplex.objects.all()
        #return ResidentialComplex.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ResidentialComplexWriteSerializer
        return ResidentialComplexSerializer
#################################################################################
# Residential Complex  API Detail View - Supports Update/Patch and Deletion
#################################################################################
class ResidentialComplexDetailView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    #permission_classes = (IsAuthenticated, PermissionCheck)
    serializer_class  = ResidentialComplexSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name','city__city_name','city_sub_area')
    lookup_field = 'key'
    def modify(self):
        field_permissions = [{'permission':'modify_all_residentialcomplex',
                              'model_name' : 'residentialcomplex'}]
        return field_permissions
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(usr,'residentialcomplex') == True):
            return ResidentialComplex.objects.all()
        else:
            return ResidentialComplex.objects.filter(account__key = acct.key)
    #queryset = ResidentialComplex.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return ResidentialComplexWriteSerializer
        return ResidentialComplexSerializer
    
class LoadCsvFile(generics.ListCreateAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    def get_queryset(self):
        print 'Nothing to do with get call!'
    def post(self,request):
        if 'csv_file' not in request.data:
            error = {'error':'please send the csv file location'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        if 'apartment' not in request.data:
            error = {'error':'please send the apartment complex key'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        
        csv_file = request.data['csv_file']
        res_complex = request.data['apartment']
        temp_file_csv=create_random_temp_file('content_name', '.csv')
        testfile = urllib.URLopener()
        testfile.retrieve(csv_file, temp_file_csv)
        complex_obj = ResidentialComplex.objects.filter(key=res_complex)
        '''
        all_residentConsumers = ResidentConsumer.objects.all()
        all_contacts = []
        for i in all_residentConsumers:
            all_contacts.append(i.phone_number)
            '''
        if complex_obj is not None and len(complex_obj)>0:
            with open(temp_file_csv, 'rb') as csvfile:
                spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
                for row in spamreader:
                    #if row[2] not in all_contacts:
                    try:
                        rc = ResidentConsumer()
                        rc.name = row[0]
                        rc.flat_number = row[1]
                        rc.phone_number = row[2]
                        rc.save()
                        complex_obj[0].residents.add(rc)
                        complex_obj[0].save()
                    except:
                        logger.error("Error while creating ResidentConsumer")
            if os.path.exists(temp_file_csv):
                os.remove(temp_file_csv)
        else:
            if os.path.exists(temp_file_csv):
                os.remove(temp_file_csv)
            error = {'error':'apartment complex not found'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        return Response('Created Successfully!',status=HTTP_201_CREATED)
        
        

class ResidentConsumerSerializer(serializers.ModelSerializer):
    class Meta:
        model = ResidentConsumer
        fields = ('name','key','flat_number','phone_number')
#################################################################################
# DeviceAppConfigurationListView
#################################################################################
class ResidentConsumerListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = ResidentConsumerSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    lookup_field = 'key'
    def get_queryset(self):
        return ResidentConsumer.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ResidentConsumerSerializer
        return ResidentConsumerSerializer
#################################################################################
# DeviceAppConfigurationUpdateView
#################################################################################
class ResidentConsumerUpdateView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = ResidentConsumerSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    lookup_field = 'key'
    def get_queryset(self):
        return ResidentConsumer.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return ResidentConsumerSerializer
        return ResidentConsumerSerializer        
        
        
        
        
        
        
        
        
        
        
        
        
        
    
    
   
