from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework import filters
from boardcontentmgmt.models import Advertiser,AccountUser,Account
from .advertiserserializers import AdvertiserWriteSerializer,AdvertiserSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
#################################################################################
# Advertiser  API List View - Supports Listing and Create
#################################################################################
class AdvertiserListView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = AdvertiserSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name','firm_name','city','type_of_business','image_url')
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(usr,'advertiser') == True):
            return Advertiser.objects.all()
        else:
            return Advertiser.objects.filter(account__key = acct.key)
    #queryset = Advertiser.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return AdvertiserWriteSerializer
        return AdvertiserSerializer
#################################################################################
# Advertiser  API Detail View - Supports Update/Patch and Deletion
#################################################################################
class AdvertiserDetailView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = AdvertiserSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name','firm_name','city','type_of_business','image_url')
    lookup_field = 'key'
    queryset = Advertiser.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return AdvertiserWriteSerializer
        return AdvertiserSerializer

