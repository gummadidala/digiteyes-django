from rest_framework import serializers
from boardcontentmgmt.models import UserProfile, Account, AccountUser
from django.contrib.auth.models import Group, Permission, User
from .accountserializers import AccountShortSerializer
import logging
logger = logging.getLogger(__name__)


class GroupSerializer(serializers.ModelSerializer):
    permissions = serializers.SlugRelatedField(queryset=Permission.objects.all(),slug_field='codename', many=True)
    class Meta:
        model = Group
        fields = ['name','permissions']
    def create(self, validated_data):
        grp = Group()
        grp.name = validated_data['name']
        grp.save()
        grp.permissions = validated_data['permissions']
        return grp
    
class UserProfileSerializer(serializers.ModelSerializer):
    account = AccountShortSerializer()
    user_groups = serializers.SlugRelatedField(
        queryset = Group.objects.all(),
        many=True,
        slug_field='name',
        required=False,allow_null=True
     ) 
    class Meta:
        model = UserProfile
        fields = ['profile_name','user_groups','account','key']

class UserProfileWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(queryset=Account.objects.all(),slug_field='key',required=False)
    user_groups = serializers.SlugRelatedField(
        queryset = Group.objects.all(),
        many=True,
        slug_field='name',
        required=False,allow_null=True
     ) 
    class Meta:
        model = UserProfile
        fields = ['profile_name','user_groups','account','key']
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        return serializers.ModelSerializer.create(self, validated_data)
   
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'last_name', 'first_name','email', 'password','is_active',
                  'is_superuser','is_staff']
    def create(self, validated_data):
        usr = User.objects.create_user(validated_data['username'].lower(),
                                       validated_data['email'].lower(),
                                       validated_data['password'])
        usr.last_name = validated_data['last_name']
        usr.first_name = validated_data['first_name']
        #usr.is_active=False
        if 'is_superuser' in validated_data:
            usr.is_superuser = validated_data['is_superuser']
        if 'is_staff' in validated_data:
            usr.is_staff = validated_data['is_staff']
        return usr
    def update(self, instance, validated_data):
        if 'username' in validated_data:
            del validated_data['username']
	logger.info("User Update : "+str(validated_data))
        return serializers.ModelSerializer.update(self, instance, validated_data)
class UserUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'last_name', 'first_name','email', 'password','is_active']
    def update(self, instance, validated_data):
        if 'username' in validated_data:
            del validated_data['username']
	logger.info("User Update : "+str(validated_data))
        return serializers.ModelSerializer.update(self, instance, validated_data)
class UserShortSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['last_name', 'first_name','username']
   
    
    
   
