
from rest_framework.views import APIView
from rest_framework import generics
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from django.http.response import Http404
from django.http import HttpResponseRedirect
from boardcontentmgmt.models import Account, AccountUser, UserProfile
from .userprofileserializers import UserProfileSerializer, UserProfileWriteSerializer ,GroupSerializer 
from django.contrib.auth.models import Group
import django_filters
from rest_framework import filters
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
# Create your views here.

# API Views


class UserProfileFilter(filters.FilterSet):
    account = django_filters.CharFilter(name="account__account_name",lookup_type='exact')
    
    class Meta:
        model = UserProfile
        fields = ['account', ]
#################################################################################
# User Profile List API View calls
# Has methods for get the list of User Profiles & create a new User Profiles
#################################################################################
class UserProfileListView(generics.ListCreateAPIView):
    """
    User Profiles List
    ========
    ##GET:
    List of User profiles available in the Account. User Profiles are grouping certain permissions.  
    
    
        
    ###Search Fileds:
    
        1. profile_name
        
    ##POST:
    
    Create a user profile with the Account.
    ###Required fields are
        1. profile_name 
        2. user_groups - list of permissions associated with this user profile.
        
    
    User Profiles are automatically put into the logged user's Account (admin user), with which this create call is made. 
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    #permission_classes = (IsAuthenticated,)
    lookup_field = 'key'
    serializer_class = UserProfileSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_class = UserProfileFilter
    search_fields = ('profile_name',)
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(usr,'userprofile') == True):
            return UserProfile.objects.all()
        else:
            return UserProfile.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return UserProfileWriteSerializer
        return UserProfileSerializer
#################################################################################
# User Group  List API View calls
# Has methods for get the list of User Groups 
# User groups are predefined group of object level permissions.
# User groups cannot be added. User Profile can be created with list of user groups.
#################################################################################
class UserGroupsListView(APIView):
    """
    List of User Profiles available in the System. 
    
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    permission_classes = (IsAuthenticated,)
    def get(self,request,format = None):
        
        #groups=Group.objects.all()
        username = request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        user_profiles = accounts[0].user_profiles
        groups = []
        for usr_prof in  user_profiles.all():
            groups.extend(usr_prof.user_groups.all())
        serializer = GroupSerializer(groups, many=True)
        return Response(serializer.data)

#################################################################################
#user profile update/ delete API View
#################################################################################
class UserProfileDetailView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    serializer_class = UserProfileSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_class = UserProfileFilter
    search_fields = ('profile_name',)
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(usr,'userprofile') == True):
            return UserProfile.objects.all()
        else:
            return UserProfile.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return UserProfileWriteSerializer
        return UserProfileSerializer



