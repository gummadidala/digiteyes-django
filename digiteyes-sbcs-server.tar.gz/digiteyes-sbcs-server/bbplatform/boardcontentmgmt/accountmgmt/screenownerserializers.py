from rest_framework import serializers
from .accountserializers import AccountSerializer
from boardcontentmgmt.models import ScreenOwner,Account,City


#################################################################################
# Serializer for ScreenOwnerSerializer
#################################################################################
class ScreenOwnerSerializer(serializers.ModelSerializer):
    account = AccountSerializer()
    city = serializers.SlugRelatedField(
        queryset=City.objects.all(),
        slug_field='city_name')
    class Meta:
        model= ScreenOwner
        fields = ['firm_name','address','city','account','key']
   
#################################################################################
# Serializer for ScreenOwnerSerializer
#################################################################################    
   
class ScreenOwnerWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key')
    city = serializers.SlugRelatedField(
        queryset=City.objects.all(),
        slug_field='city_name')
    class Meta:
        model= ScreenOwner
        fields = ['firm_name','address','city','account','key']
    
