from rest_framework import serializers
from boardcontentmgmt.models import Account, AccountType
import logging

logger = logging.getLogger(__name__)

#####################################################################################
#  Account and Account Type Serializers
#####################################################################################                             
class AccountTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccountType
        fields = ['type_name','type_of_customer','key']       

class AccountSerializer(serializers.ModelSerializer):
    account_type = AccountTypeSerializer()
    class Meta:
        model = Account
        fields = ['account_name','account_type','key','consumer_accounts']
class AccountShortSerializer(serializers.ModelSerializer):
    class Meta:
        model = Account
        fields = ['account_name','key']      
class AccountWriteSerializer(serializers.ModelSerializer):
    account_type = serializers.SlugRelatedField(
        queryset=AccountType.objects.all(),
        slug_field='key')
    consumer_accounts = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',many=True,required=False)
    class Meta:
        model = Account
        fields = ['account_name','account_type','key','consumer_accounts']   
