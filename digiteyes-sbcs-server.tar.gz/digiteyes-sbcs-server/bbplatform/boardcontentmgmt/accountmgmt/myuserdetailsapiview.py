from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework import filters
from boardcontentmgmt.models import AccountUser,ResidentialComplex
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from .accountuserserializers import AccountUserSerializer,AccountUserWriteSerializer
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
import datetime
from .userprofileserializers import UserSerializer
from boardcontentmgmt.campaignmgmt.apartmentadvertisingapiviews import check_consumer_inall_apartments

import logging
logger = logging.getLogger(__name__)

def populateResidentialComplex(actusr):
    print 'In populateResidentialComplex'
    ph = actusr.account_user_phone_no
    user_acct = actusr.account
    res = check_consumer_inall_apartments(user_acct)
    if res['check']:
        complex = ResidentialComplex.objects.filter(name=res['complex'])
        complex_contacts = []
        for i in complex[0].residents.all():
            complex_contacts.append(i.phone_number)
        if ph not in complex_contacts:
            assosc_acct= complex[0].account
            assosc_acct.consumer_accounts.remove(user_acct)
            assosc_acct.save()
    else:
        all_complexes = ResidentialComplex.objects.all()
        if all_complexes is not None and len(all_complexes)>0:
            for each_complex in all_complexes:
                contacts = []
                for i in each_complex.residents.all():
                    contacts.append(i.phone_number)
                if len(contacts)>0:
                    if ph in contacts:
                        assosc_acct= each_complex.account
                        assosc_acct.consumer_accounts.add(user_acct)
                        assosc_acct.save()
                        break
        
    
class MyUserDetailsListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    serializer_class = AccountUserSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    def get_queryset(self):
        user_name = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=user_name)
        acct = accounts[0].account
        populateResidentialComplex(accounts[0])
        #return AccountUser.objects.filter(account__key = acct.key)
        return AccountUser.objects.filter(account_user__username=user_name)
    
class MyUserDetailsUpdateView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    serializer_class = AccountUserSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    
    def get_queryset(self):
        user_name = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=user_name)
        #acct = accounts[0].account
        return AccountUser.objects.filter(account_user__username=user_name)
    def put(self,request,key,format=None):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        actusr =  AccountUser.objects.filter(account__key = acct.key)[0]
        if 'account_user_phone_no' in request.data:
            populateResidentialComplex(actusr)
            actusr.account_user_phone_no = request.data['account_user_phone_no']
        if 'gender' in request.data:
            actusr.gender = request.data['gender']
        if 'birth_date' in request.data:
            actusr.birth_date = request.data['birth_date']
        if 'profile_picture' in request.data:
            actusr.profile_picture = request.data['profile_picture']
        if 'is_activeuser' in request.data:
            actusr.is_activeuser = request.data['is_activeuser']
        actusr.save()
        usr = UserSerializer().update(usr,request.data['account_user'])
        usr.save()
        return Response('Updated successfully',status = HTTP_201_CREATED)