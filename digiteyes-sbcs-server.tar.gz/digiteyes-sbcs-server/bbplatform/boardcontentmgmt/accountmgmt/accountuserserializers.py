from rest_framework import serializers
from boardcontentmgmt.models import UserProfile, Account, AccountUser, AccountType,User
from .userprofileserializers import UserSerializer, UserProfileSerializer, UserShortSerializer, UserUpdateSerializer
from django.contrib.auth.models import Group
import logging

logger = logging.getLogger(__name__)

class AccountUserSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(queryset=Account.objects.all(),slug_field='account_name')
    account_user = UserSerializer()
    user_profiles = UserProfileSerializer(many=True)
    class Meta:
        model = AccountUser
        fields = ['account_user','account_user_phone_no','account','user_profiles','key',
                  'profile_picture','gender','birth_date','is_activeuser','verified_mobile']
    def create(self, validated_data):
        usr = UserSerializer().create(validated_data['account_user'])
        usr.save()
        acct_user = AccountUser()
        acct_user.account_user_phone_no = validated_data['account_user_phone_no']
        acct_user.account = validated_data['account']
        # Save Should not be required here... need to investivate....
        acct_user.account_user = usr
        acct_user.save()
        profile_keys = []
        for profile in validated_data['user_profiles']:
            profile_keys.append(profile.key)  
        profile_list = UserProfile.objects.filter(key__in=profile_keys)
        acct_user.user_profiles = profile_list
        acct_user.save()
        return acct_user
class AccountUserShortSerializer(serializers.ModelSerializer):
    account_user = UserShortSerializer()
    class Meta:
        model = AccountUser
        fields = ['account_user','key','is_activeuser']
class AccountUserWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key')
    account_user = UserSerializer()
    is_activeuser = serializers.BooleanField(required=False)
    user_profiles = serializers.SlugRelatedField(
        queryset=UserProfile.objects.all(), many=True,
        slug_field='key',
        required=False,allow_null=True)
    class Meta:
        model = AccountUser
        fields = ['account_user','account_user_phone_no','account','user_profiles','key',
                  'profile_picture','gender','birth_date','is_activeuser','verified_mobile']
    def create(self, validated_data):
        print validated_data['account_user']
        print str(validated_data)
        '''
        if(validated_data['account_user']['test_account']==True):
            print "Test Account Creation"
            validated_data['account_user']['is_active']=True
            validated_data['is_activeuser']=True
        else:
            pass
        '''        
        usr = UserSerializer().create(validated_data['account_user'])
        usr.save()
        acct_user = AccountUser()
        acct_user.account_user_phone_no = validated_data['account_user_phone_no']
        acct_user.account = validated_data['account']
        if 'is_active' in validated_data['account_user']:
            acct_user.is_activeuser = validated_data['account_user']['is_active']  
        # Save Should not be required here... need to investigate....
        acct_user.account_user = usr
        acct_user.save()
        if 'user_profiles' in validated_data:
            acct_user.user_profiles = validated_data['user_profiles']
            #adding user groups
            for each_profile in validated_data['user_profiles']:
                for each_group in each_profile.user_groups.all():
                    acct_user.account_user.groups.add(Group.objects.get(name=each_group))
                    acct_user.save()     
            acct_user.save()
        return acct_user
    
    def update(self, instance, validated_data):
	logger.debug('Account user update : '+ str(validated_data))
        if 'account_user_phone_no' in validated_data:
            instance.account_user_phone_no = validated_data['account_user_phone_no']
        if 'account' in validated_data:
            instance.account = validated_data['account']
        usr = UserUpdateSerializer().update(instance.account_user,validated_data['account_user'])
        #usr.save()
        instance.save()
        if 'user_profiles' in validated_data:
            logger.debug('inside the loop - user profiles in validated_data')
            instance.user_profiles = validated_data['user_profiles']
            #removing user previously assigned groups
            prev_groups = instance.account_user.groups.all()
            if(len(prev_groups) > 0):
                for grp in prev_groups:
                    instance.account_user.groups.remove(Group.objects.get(name=grp))
                    instance.save()
            #adding user groups   
            for each_profile in validated_data['user_profiles']:
                for each_group in each_profile.user_groups.all(): 
                    instance.account_user.groups.add(Group.objects.get(name=each_group))
                    instance.save()     
            instance.save()
        return instance
class AccountUserUpdateSerializer(AccountUserWriteSerializer):
	account_user = UserUpdateSerializer()
