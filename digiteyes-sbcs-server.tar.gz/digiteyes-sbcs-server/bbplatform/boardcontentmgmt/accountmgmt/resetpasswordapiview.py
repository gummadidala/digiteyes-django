from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.response import Response
from django.core.mail import EmailMessage
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from django.contrib.auth.models import User
from .userprofileserializers import UserSerializer
import hashlib
import logging
from bbplatform.settings import HOSTING_SERVER,Adiot_logo_url
from boardcontentmgmt.tasks import send_email,send_email_ses
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from django.template import Context
from .accountapiviews import email_activateaccount
from boardcontentmgmt.models import AccountUser
import boto.ses
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
import sys
import traceback

logger = logging.getLogger(__name__)

################################################################################
#List API View for  EMIAL
################################################################################
'''
def prepare_mail_format(subject,to_user,attachment_file,html_content):
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From'] = 'info@digiteyes91.com'
    msg['To'] = to_user
    msg.preamble = 'Multipart message.\n'
    
    part2 = MIMEText(html_content.encode('utf-8').strip(), 'html')
    msg.attach(part2)
    if attachment_file !="":
        part = MIMEApplication(open(attachment_file, 'rb').read())
        part.add_header('Content-Disposition', 'attachment', filename=attachment_file)
        msg.attach(part)
    return msg
'''
class ResetPasswordRequestAPIView(generics.ListCreateAPIView):
    
    def post(self,request):
        user_email =''
        if 'user_email' in request.data and 'user_name' in request.data:
            user_email = request.data['user_email']
            user_name = request.data['user_name']
        else:
            return Response('user_name and user_email are mandatory!',status=HTTP_400_BAD_REQUEST)
        try:
            '''
            usr = User.objects.get(email=user_email)
            logger.info(str(usr)+' asked to reset password')
            '''
            usr = User.objects.filter(email = user_email,username=user_name,is_active=True)
            if len(usr) > 1:
                error = 'Duplicate entries are found, please try contacting admin to solve your problem.'
                return Response(error,status=HTTP_400_BAD_REQUEST)
            elif len(usr) <= 0:
                error = 'User not found or not activated, please try contacting admin to solve your problem.'
                return Response(error,status=HTTP_400_BAD_REQUEST)
            user = usr[0].first_name+" "+usr[0].last_name
            hash = hashlib.sha512(user_email.lower()+'All@thebest.,of_luck').hexdigest().lower()
            link = HOSTING_SERVER+'resetpassword/?user_email='+user_email+'&hash='+hash+'&user_name='+usr[0].username
            htmly  = get_template('email_resetpassword.html')
            d = Context({ 'link': link,'username':user,'logo_url':Adiot_logo_url})
            subject = 'Reset password for your Adiot account!'
            html_content = htmly.render(d)
            send_email_ses.delay(user_email,subject,html_content,link,"")
            
            #send_email.delay(user_email,subject,html_content,link,"")
            return Response('Email sent successfully!', status = HTTP_201_CREATED)
        except:
            logger.error ("Error while sending email "+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("Stack Trace: "+str(tb))
            print sys.exc_info()[0]
            return Response('Something went wrong!',status=HTTP_400_BAD_REQUEST)
        
        
def send_alert(user_name,user_email,subject,link,text1,text2,text3):
    try:
        htmly  = get_template('email_resetpasswordalert.html')
        d = Context({ 'link': link,'username':user_name,'logo_url':Adiot_logo_url,
                     'text1':text1,'text2':text2,'text3':text3})
        html_content = htmly.render(d)
        send_email_ses.delay(user_email,subject,html_content,link,"")
        #send_email.delay(user_email,subject,html_content,link,"")
        return Response('Email sent successfully!', status = HTTP_201_CREATED)
    except:
        return Response('Something went wrong!',status=HTTP_400_BAD_REQUEST)
    
class ResetPasswordAPIView(generics.ListCreateAPIView):
    
    def post(self,request):
        user_email = ''
        user_password = ''
        if 'user_email' in request.data and 'password' in request.data and 'hash' in request.data:
            user_email = request.data['user_email']
            user_password = request.data['password']
            user_name = request.data['user_name']
            try:
                usr = User.objects.filter(email = user_email,username=user_name,is_active=True)
                if len(usr) > 1:
                    error = 'Duplicate entries are found, please try contacting admin to solve your problem.'
                    return Response(error,status=HTTP_400_BAD_REQUEST)
                elif len(usr) <= 0:
                    error = 'User not found or already activated, please try contacting admin to solve your problem.'
                    return Response(error,status=HTTP_400_BAD_REQUEST)
                if user_password == '':
                    logger.info('Password filed is empty!')
                    return Response('Please enter the password to reset!',status=HTTP_400_BAD_REQUEST)
                hash = hashlib.sha512(user_email+'All@thebest.,of_luck').hexdigest().lower()
                logger.info('Re-calculated hash at server: '+str(hash))
                logger.info('Hash from client: '+str(request.data['hash']))
                if hash == request.data['hash']:
                    usr[0].set_password(user_password)
                    usr[0].save()
                    logger.info('password reset done for: '+str(user_email))
                    subject = 'Password changed for your Adiot account recently!'
                    link = HOSTING_SERVER+'resetpassword/?user_email='+user_email+'&hash='+hash+'&user_name='+usr[0].username
                    text1 = 'Password for your Adiot account was recently changed.'
                    text2 = "Don't recognize this activity?"
                    text3 = 'for more information on how to recover your account.'
                    _user_name = usr[0].first_name+" "+usr[0].last_name
                    send_alert(_user_name,user_email,subject,link,text1,text2,text3)
                    return Response('Password reset done successfully!',status = HTTP_201_CREATED)
                else:
                    logger.info('Invalid Hash for resetting the password')
                    return Response('Some thing went wrong!',status=HTTP_400_BAD_REQUEST)
            except:
                logger.error ("EMAIL_RESETPASWORD_ERROR"+ str(sys.exc_info()[0]))
                tb = traceback.format_exc()
                logger.error ("EMAIL_RESETPASWORD_ERROR"+str(tb))
                return Response('Error!',status=HTTP_400_BAD_REQUEST)
        else:
            logger.info('fields user_name,user_email, password and hash are mandatory')
            return Response('Fields user_email, password and hash are mandatory!',status=HTTP_400_BAD_REQUEST)

class CreatePasswordAPIView(generics.ListCreateAPIView):
    
    def post(self,request):
        user_email = ''
        user_password = ''
        if 'user_email' in request.data and 'password' in request.data and 'hash' in request.data and 'user_name' in request.data:
            user_email = request.data['user_email']
            user_password = request.data['password']
            user_name = request.data['user_name']
            try:
                usr = User.objects.filter(email = user_email,username=user_name,is_active=False)
                if len(usr) > 1:
                    error = 'Duplicate entries are found, please try contacting admin to solve your problem.'
                    return Response(error,status=HTTP_400_BAD_REQUEST)
                elif len(usr) <= 0:
                    error = 'User not found or already activated, please try contacting admin to solve your problem.'
                    return Response(error,status=HTTP_400_BAD_REQUEST)
                if user_password == '':
                    logger.info('Password filed is empty!')
                    return Response('Please enter the password!',status=HTTP_400_BAD_REQUEST)
                hash = hashlib.sha512(user_email.lower()+'All@thebest.,of_luck').hexdigest().lower()
                logger.info('Re-calculated hash at server: '+str(hash))
                logger.info('Hash from client: '+str(request.data['hash']))
                print hash
                if hash == request.data['hash']:
                    usr[0].set_password(user_password)
                    usr[0].is_active = True
                    usr[0].save()
                    logger.info('password creation done for: '+str(user_email))
                    subject = 'Adiot account is activated!'
                    link = HOSTING_SERVER+'login.html'
                    text1 = 'Thank you for activating your account.'
                    text2 = "Your username is : "+unicode(usr[0].username)
                    text3 = 'to login to your account!'
                    _user_name = usr[0].first_name+" "+usr[0].last_name
                    send_alert(_user_name,user_email,subject,link,text1,text2,text3)
                    return Response('Password creation done successfully!',status = HTTP_201_CREATED)
                else:
                    logger.info('Invalid Hash for creation the password')
                    return Response('Invalid Hash for creation the password',status=HTTP_400_BAD_REQUEST)
            except:
                logger.error ("EMAIL_ACTIVATE_ERROR"+ str(sys.exc_info()[0]))
                tb = traceback.format_exc()
                logger.error ("EMAIL_ACTIVATE_ERROR"+str(tb))
                return Response('Error!',status=HTTP_400_BAD_REQUEST)
        else:
            logger.info('fields user_name, user_email, password and hash are mandatory')
            return Response('Fields user_email, password and hash are mandatory!',status=HTTP_400_BAD_REQUEST)

def send_consumer_resetpassword_alert(user_name,user_email):
    try:
        hash = hashlib.sha512(user_email+'All@thebest.,of_luck').hexdigest().lower()
        link = HOSTING_SERVER+'consumerresetpassword/?user_email='+user_email+'&hash='+hash
        htmly  = get_template('email_resetpasswordalert.html')
        d = Context({ 'link': link,'username':user_name,'logo_url':Adiot_logo_url})
        subject = 'Password changed for your Adiot account!'
        html_content = htmly.render(d)
        send_email_ses.delay(user_email,subject,html_content,link,"")
        #send_email.delay(user_email,subject,html_content,link,"")
        return Response('Email sent successfully!', status = HTTP_201_CREATED)
    except:
        return Response('Something went wrong!',status=HTTP_400_BAD_REQUEST)

class ConsumerResetPasswordAPIView(generics.ListCreateAPIView):
    def post(self,request):
        user_email = ''
        user_password = ''
        if 'user_email' in request.data and 'password' in request.data and 'hash' in request.data:
            user_email = request.data['user_email']
            user_password = request.data['password']
            if user_password == '':
                logger.info('Password filed is empty!')
                return Response('Please enter the password to reset!',status=HTTP_400_BAD_REQUEST)
            usr = User.objects.filter(email = user_email)
            if len(usr) > 1:
                error = 'Duplicate entries are found, please try contacting admin to solve your problem.'
                return Response(error,status=HTTP_400_BAD_REQUEST)
            elif len(usr) <=0 :
                error = 'User with email address not found.'
            hash = hashlib.sha512(user_email+'All@thebest.,of_luck').hexdigest().lower()
            logger.info('Re-calculated hash at server: '+str(hash))
            logger.info('Hash from client: '+str(request.data['hash']))
            if hash == request.data['hash']:
                usr[0].set_password(user_password)
                usr[0].save()
                user_name = usr[0].first_name+" "+usr[0].last_name
                logger.info('password reset done for: '+str(user_email))
                subject = 'Your has been password changed recently!'
                link = HOSTING_SERVER+'consumerresetpassword/?user_email='+user_email+'&hash='+hash
                text1 = 'Password for your Tapp account was recently changed.'
                text2 = "Don't recognize this activity?"
                text3 = 'for more information on how to recover your account.'
                _user_name = usr[0].first_name+" "+usr[0].last_name
                send_alert(_user_name,user_email,subject,link,text1,text2,text3)
                #send_consumer_resetpassword_alert(user_name,user_email)
                return Response('Password reset done successfully!',status = HTTP_201_CREATED)
            else:
                logger.info('Invalid Hash for resetting the password')
                return Response('Some thing went wrong!',status=HTTP_400_BAD_REQUEST)
        else:
            logger.info('fields user_email, password and hash are mandatory')
            return Response('Fields user_email, password and hash are mandatory!',status=HTTP_400_BAD_REQUEST)
        
            
    
