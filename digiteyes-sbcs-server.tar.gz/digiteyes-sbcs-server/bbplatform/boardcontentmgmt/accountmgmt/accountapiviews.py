from rest_framework.views import APIView
from rest_framework import generics
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST,\
    HTTP_200_OK
from django.http.response import Http404
from django.http import HttpResponseRedirect
from boardcontentmgmt.models import Account, AccountUser, UserProfile, AccountType,Advertiser ,ResidentialComplex
from .accountuserserializers import AccountUserSerializer,AccountUserWriteSerializer, AccountUserUpdateSerializer
from .accountserializers import AccountSerializer, AccountWriteSerializer
from django.contrib.auth.models import Group
import django_filters
from rest_framework import filters
from .accountserializers import AccountTypeSerializer
from boardcontentmgmt.permissionsmgmt.Create_UserProfiles_for_users import Create_Profile
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
import hashlib
from boardcontentmgmt.tasks import send_email,send_email_ses,prepare_mail_format
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from django.template import Context
from bbplatform.settings import HOSTING_SERVER,Adiot_logo_url
import random
import string
from boardcontentmgmt.contentmgmt.s3uploadcredentialsapiview import create_storageaccount
from django.db import IntegrityError, transaction
from rest_framework.authtoken.models import Token
from django.contrib.auth.models import User
from boardcontentmgmt.contentmgmt.azureuploadcredentialsapiview import create_storage_container

import logging
logger = logging.getLogger(__name__)
#################################################################################
# Board List API List View
#################################################################################
class AccountListView(generics.ListCreateAPIView):
    """
    Accounts List
    ========
    ##GET:
    List of Client Accounts available in the Account. 
    
        
    ###Search Fileds:
    
        1. account_name
        2. account_firm_name
        3. account_firm_address
        
        
    ##POST:
    
    Create a Client account with the Account.
    ###Required fields are
        1. account_name 
        2. account_firm_name
        3. account_firm_address
    """
    authentication_classes = (TokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = AccountSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('account_type__type_name','account_name',)
    search_fields = ('account_name',)
    lookup_field = 'key'
    def get_queryset(self):
        accounts = Account.objects.all()
        return accounts
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return AccountWriteSerializer
        return AccountSerializer
    def perform_create(self, serializer):
        try:
            generics.ListCreateAPIView.perform_create(self, serializer)
            logger.info("ACCCOUNT_CREATED "+str(serializer.instance))
            create_storage_container(serializer.instance.account_name)
        except:
            logger.error ("ACCOUNT_CREATION_ERROR "+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("ACCOUNT_CREATION_ERROR "+str(tb))
#################################################################################
# Content Advice Detail API View
#################################################################################
class AccountDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    Account Details
    ===============
    ##GET:
    Returns the specific account object as queried by the key. 
    
    ##PUT:
    
    Updates the given account object as indicated by the key.
    
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions)#,DjangoObjectPermissions)
    lookup_field = 'key'
    def get_queryset(self):
        accounts = Account.objects.all()
        return accounts
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return AccountWriteSerializer
        return AccountSerializer
    
class AccountTypeListView(generics.ListAPIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    queryset = AccountType.objects.all()
    serializer_class = AccountTypeSerializer
#################################################################################
# User Profile List API View calls
# Has methods for get the list of User Profiles & create a new User Profiles
#################################################################################
def email_activateaccount(user_email,user_name,username):
    try:
        hash = hashlib.sha512(user_email.lower()+'All@thebest.,of_luck').hexdigest().lower()
        logger.info('Hash generated: '+str(hash))
        print 'Hash generated:',hash
        link = HOSTING_SERVER+'createpassword/?user_email='+user_email+'&hash='+hash+'&username='+username.lower()
        htmly  = get_template('email_createpassword.html')
        d = Context({ 'link': link,'username':user_name,'logo_url':Adiot_logo_url})
        subject = 'Activate your Adiot account!'
        html_content = htmly.render(d)
        send_email_ses.delay(user_email,subject,html_content,link,"")
        #send_email.delay(user_email,subject,html_content,link,"")
        logger.info('activation mail sent successfully to: '+str(user_email))
    except:
        return Response('Something went wrong!',status=HTTP_400_BAD_REQUEST)

class AccountUserFilter(django_filters.FilterSet):
    username = django_filters.CharFilter(name='account_user__username',lookup_type='exact')
    account = django_filters.CharFilter(name='account__account_name',lookup_type='exact')
    account_type = django_filters.CharFilter(name='account__account_type__type_name',lookup_type='exact')
    class Meta:
        model = AccountUser
        fields = ('username','account','account_type',)
        
class AccountUserListView(generics.ListCreateAPIView):
    """
    User List
    ========
    ##GET:
    List of User accounts available in the Account. 
    
    ###Filter Fields:
        1. User Profile (user_profile)
        
    ###Search Fileds:
    
        1. username
        2. User last name
        3. User first name
        4. User email
        5. User phone no
        
    ##POST:
    
    Create a user account with the Account.
    ###Required fields are
        1. username 
        2. User last name
        3. User first name
        4. User email
        5. User phone no
        6. User Profile
        7. password
    
    Users are automatically put into the logged user's Account (admin user), with which this create call is made. 
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    serializer_class = AccountUserSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_class  = AccountUserFilter
    filter_fields = ('account_user__username', 'account_user__last_name', 'account_user__first_name','account_user__email',)
    search_fields = ('account_user__username','account_user__last_name','account_user__first_name','account_user__email','account__account_name','account_user_phone_no',)
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        if(ProfileCheck().get_filter(usr,'accountuser') == True):
            return AccountUser.objects.all()
        else:
            accounts = AccountUser.objects.filter(account_user__username=username)
            acct = accounts[0].account
            return AccountUser.objects.filter(account__key = acct.key)
        
    def post(self,request, format=None):
        username = request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        parsed_data = request.data
        print str(parsed_data)
        parsed_data['account_user'] ['is_active'] = False
        if(parsed_data['account_user']['test_account']==False):
               
               parsed_data['account_user']['password'] = ''.join(random.choice(string.ascii_lowercase + string.ascii_uppercase + string.digits) for i in range(15))       
        else:
            print "Test account.."
            parsed_data['account_user']['is_active'] = True
        user_email=parsed_data['account_user']['email']
        usr = User.objects.filter(email = user_email,is_active=True)
        if len(usr) > 0 and usr is not None:
            return Response("User with email-address already exists!",status=HTTP_400_BAD_REQUEST)
        if not 'account' in parsed_data and accounts is not None: 
            acct = accounts[0].account
            parsed_data['account']=acct.key
        else:
            acct_key = parsed_data['account']
            act = Account.objects.filter( key= acct_key)
            print unicode(act)
            act_type = act[0].account_type
            if(act_type.type_name == 'ADVERTISER'):
                Create_Profile().AdvertiserProfile(act[0])
                profiles = UserProfile.objects.filter(profile_name='Advertiser Profile', account = act[0])
                parsed_data['user_profiles']= [profiles[0].key]
                
            elif(act_type.type_name == 'ASSOCIATION'):
                Create_Profile().AssociationProfile(act[0])
                profiles = UserProfile.objects.filter(profile_name='Association Profile', account = act[0])
                parsed_data['user_profiles']= [profiles[0].key]
            
            elif(act_type.type_name == 'SCREEN OWNER'):
                Create_Profile().ScreenOwnerProfile(act[0])
                parsed_data['user_profiles']= [profiles[0].key]
            
            elif(act_type.type_name == 'AFFILIATE ADVERTISER'):
                profiles = UserProfile.objects.filter(profile_name='ScreenOwner Profile', account = act[0])
                Create_Profile().AffiliateAdvertiserProfile(act[0])
                profiles = UserProfile.objects.filter(profile_name='Affiliate Advertiser Profile', account = act[0])
                parsed_data['user_profiles']= [profiles[0].key]
        serializer = AccountUserWriteSerializer(data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            user_name = parsed_data['account_user']['first_name']+" "+parsed_data['account_user']['last_name']
            if(parsed_data['account_user']['test_account']==False):
                email_activateaccount(parsed_data['account_user']['email'],user_name,parsed_data['account_user']['username'])
            else:
                pass    
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)

####################################################################################
# AccountUserDetailView
####################################################################################
class AccountUserDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    Account User Details
    ===============
    ##GET:
    Returns the specific user account object as queried by the key. 
    
    ##PUT:
    
    Updates the given account user object as indicated by the key.
    
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = AccountUserSerializer        
    lookup_field = 'key'

    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        if(ProfileCheck().get_filter(usr,'accountuser') == True):
            return AccountUser.objects.all()
        else:
            accounts = AccountUser.objects.filter(account_user__username=username)
            acct = accounts[0].account
            return AccountUser.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return AccountUserUpdateSerializer
        return AccountUserSerializer
    
    '''
    def patch(self, request, *args, **kwargs):
        username = request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        parsed_data = request.data
        if not 'account' in parsed_data and accounts is not None: 
            acct = accounts[0].account
            parsed_data['account']=acct.key
	#if 'username' in request.data['account_user'] :
		#del request.data['account_user']['username']
        return generics.RetrieveUpdateDestroyAPIView.patch(self, request, *args, **kwargs)
        '''
                
####################################################################################
# MyUserDetailView
####################################################################################
class MyUserDetailView(APIView):
    """
    My Account Details
    ===============
    ##GET:
    Returns the current logged in user details.
    
    ##PUT:
    
    Updates the curent logged in user details.
    
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = AccountUserSerializer
    def get_object(self,key):
        try :
            return AccountUser.objects.get(key=key)
        except AccountUser.DoesNotExist :
            raise Http404
    
    def get(self,request, format=None):
        username = request.user.username
        account_users = AccountUser.objects.filter(account_user__username=username)
        if len(account_users) > 0:
            serializer = AccountUserSerializer(account_users[0])
            return Response(serializer.data)
        raise Http404
    
    def put(self,request,key,format=None):
        board = self.get_object(key)
        serializer = AccountUserWriteSerializer(board, data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)

def create_account(account_name):
    acct = Account()
    acct_types = AccountType.objects.filter(type_name = 'ADVERTISER')
    acct.account_name = account_name
    acct.account_type = acct_types[0]
    acct.save()
    return acct

class SignUpAPIView(generics.ListAPIView):
    def post(self,request):
        with transaction.atomic():
            username = request.data['username']
            user_email = request.data['user_email']
            account=create_account(username)
            #password = request.data['password']
            try:
                _usr = User.objects.get(email = user_email)
                return Response("Email-address already exists!",status=HTTP_400_BAD_REQUEST)
            except:
                logger.info('Nothing to worry, test passed!')
            password = ''.join(random.choice(string.ascii_lowercase + string.ascii_uppercase + string.digits) for i in range(15))
            try:
                usr=User.objects.create_user(username,user_email,password)
                usr.first_name = ''
                usr.last_name = ''
                usr.save()
                print 'user:',usr
                act_user = AccountUser()
                act_user.account_user = usr
                act_user.account = account
                act_user.account_user_phone_no = ''
                act_user.save()
                #assigning user profile
                Create_Profile().AdvertiserProfile(account)
                act_user.user_profiles = UserProfile.objects.filter(profile_name='Advertiser Profile', account = act_user.account)
                act_user.save()
                for each_profile in act_user.user_profiles.all():
                    for each_group in each_profile.user_groups.all():
                        act_user.account_user.groups.add(Group.objects.get(name=each_group))
                        act_user.save()
                email_activateaccount(user_email)
                tkn = Token.objects.get(user__username=username)
                data = {'token':tkn.key}
                return Response(data,status=HTTP_201_CREATED)
            except:
                return Response("Error while sign up!",status=HTTP_400_BAD_REQUEST)
            
class GetLogoUrlAPIView(generics.ListAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    def get(self, request, *args, **kwargs):
        username = request.user.username
        account_users = AccountUser.objects.filter(account_user__username=username)
        accnt_key=account_users[0].account.key
        accnt = Account.objects.filter(key=accnt_key)
        logo_url=""
        if accnt is not None and len(accnt)>0:
            acct_type=accnt[0].account_type.type_name
            if acct_type=='ADVERTISER' or acct_type=='AFFILIATE ADVERTISER':
                advt = Advertiser.objects.filter(account__key=accnt_key)
                if advt is not None and len(advt)>0:
                    logo_url = advt[0].image_url
            elif acct_type=='ASSOCIATION':
                print 'hello aff advt'
                res_complex = ResidentialComplex.objects.filter(account__key=accnt_key)
                if res_complex is not None and len(res_complex)>0:
                    logo_url = res_complex[0].logo_url
                    
        return Response({'logo_url':logo_url},status=HTTP_200_OK)
    
 
 
