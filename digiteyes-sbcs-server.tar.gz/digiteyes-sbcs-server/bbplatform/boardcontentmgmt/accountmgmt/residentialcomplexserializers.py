from rest_framework import serializers
from .accountserializers import AccountSerializer
from .accountuserserializers import AccountUserSerializer
from boardcontentmgmt.models import AccountUser,ResidentialComplex,Account,City,TravelDestinationLocations,ResidentConsumer
from boardcontentmgmt.traveldestinationlocationsapiviews import TravelDestinationLocationsSerializer

#################################################################################
# Serializer for ResidentialComplexSerializer
#################################################################################
class ResidentsSerializer(serializers.ModelSerializer):
    class Meta:
        model= ResidentConsumer
        fields = ['name','flat_number','key','phone_number']
class ResidentialComplexSerializer(serializers.ModelSerializer):
    account = AccountSerializer()
    city = serializers.SlugRelatedField(
        queryset=City.objects.all(),
        slug_field='city_name')
    traveldestinationlocations = TravelDestinationLocationsSerializer(many=True)
    residents = ResidentsSerializer(many=True)
    service_people = AccountUserSerializer(many=True)
    class Meta:
        model= ResidentialComplex
        fields = ['name','address','city_sub_area','city','project_area',
                  'project_occupancy','num_of_flats','amenities',
                  'num_of_parking_lots','account','key','traveldestinationlocations',
                  'image_url','residents','service_people','logo_url','service_phone_number']
   
#################################################################################
# Serializer for ResidentialComplexSerializer
#################################################################################    
class ResidentialComplexWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key')
    city = serializers.SlugRelatedField(
        queryset=City.objects.all(),
        slug_field='city_name')
    traveldestinationlocations = serializers.SlugRelatedField(
        queryset=TravelDestinationLocations.objects.all(),
        many=True ,slug_field='key',required=False)
    residents = serializers.SlugRelatedField(
        queryset=ResidentConsumer.objects.all(),
        many=True ,slug_field='key',required=False)
    image_url = serializers.CharField(required=False)
    service_people = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        many=True ,slug_field='key',required=False)
    class Meta:
        model= ResidentialComplex
        fields = ['name','address','city_sub_area','city','project_area',
                  'project_occupancy','num_of_flats','amenities',
                  'num_of_parking_lots','account','key','traveldestinationlocations',
                  'image_url','residents','service_people','logo_url','service_phone_number']
        
    
    
    