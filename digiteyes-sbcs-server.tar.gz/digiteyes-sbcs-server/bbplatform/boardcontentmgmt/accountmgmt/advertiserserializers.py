from rest_framework import serializers
from .accountserializers import AccountSerializer
from boardcontentmgmt.models import Account,City,Advertiser


#################################################################################
# Serializer for AdvertiserSerializer
#################################################################################
class AdvertiserSerializer(serializers.ModelSerializer):
    account = AccountSerializer()
    city = serializers.SlugRelatedField(
        queryset=City.objects.all(),
        slug_field='city_name')
    class Meta:
        model= Advertiser
        fields = ['firm_name','account','key','address','city','type_of_business','image_url']
   
#################################################################################
# Serializer for AdvertiserSerializer
#################################################################################    
   
class AdvertiserWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key')
    city = serializers.SlugRelatedField(
        queryset=City.objects.all(),
        slug_field='city_name')
    class Meta:
        model= Advertiser
        fields = ['firm_name','account','key','address','city','type_of_business','image_url']
    

