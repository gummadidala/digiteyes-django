from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import sys,traceback
from boardcontentmgmt.models import MobileOTPCode,AccountUser,Account
import random,string
from boardcontentmgmt.tasks import send_sms_plivo
from rest_framework.views import APIView
import logging
from datetime import datetime,timedelta
logger = logging.getLogger(__name__)

#################################################################################
# API View
#################################################################################
class SendOTPAPIView(APIView):
    def post(self,request):
        username = self.request.user.username
        acct_user = AccountUser.objects.filter(account_user__username=username)[0]
        acct = acct_user.account
        otp_code = ''.join(random.choice(string.digits) for i in range(6))
        
        existing_codes = MobileOTPCode.objects.filter(code_validity__gte = datetime.now())
        if existing_codes is not None and len(existing_codes)>0:
            for code in existing_codes:
                code.code_validity = datetime.now() + timedelta(minutes=-30)
                code.save()
        
        obj = MobileOTPCode()
        obj.otp_code = otp_code
        obj.account_user = acct_user
        obj.account = acct
        obj.code_validity = datetime.now() + timedelta(minutes=30)
        obj.save()
        user_name = acct_user.account_user.first_name + acct_user.account_user.last_name
        #txt_msg = ' Please enter '+str(otp_code)+' to verify your mobile number. This code expires on'+ str(obj.code_validity)
        txt_msg = str(otp_code)+' is your verification code to verify your mobile number. This code expires on :'+ str(obj.code_validity)  
        send_sms_plivo.delay("", txt_msg, [acct_user.account_user_phone_no])
        
        return Response("OTP sent successfully!")

class VerifyOTPAPIView(APIView):
    def post(self,request):
        username = self.request.user.username
        acct_user = AccountUser.objects.filter(account_user__username=username)[0]
        acct = acct_user.account
        
        parsed_data = request.data
        if 'otp_code' not in parsed_data:
            error = {'error':'otp_code is required to verify mobile number'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        
        user_otp_code = parsed_data['otp_code']
        all_otps = MobileOTPCode.objects.filter(account_user__key=acct_user.key,
                                                otp_code = user_otp_code,
                                                code_validity__gte = datetime.now())
        if all_otps is not None and len(all_otps)>0:
            all_otps[0].account_user.verified_mobile = True
            all_otps[0].account_user.save()
        else:
            error = {'error':'Invalid OTP! please try again.'}
            return Response(error,status=HTTP_400_BAD_REQUEST) 
        
        return Response("Mobile number verified successfully")

