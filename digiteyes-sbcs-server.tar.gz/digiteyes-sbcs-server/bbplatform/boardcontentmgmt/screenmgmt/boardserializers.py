from rest_framework import serializers

import random

from boardcontentmgmt.models import Board, BoardPlayHistory, Content, Account, AccountUser, BoardRegistration,WifiCounter
from boardcontentmgmt.models import ScreenSize , ShowSpotAsset , ScreenStatus, AdvtCampaign , BoardRegistrationCode
from boardcontentmgmt.models import ScreenDiagnostics,Beacon
from boardcontentmgmt.accountmgmt.accountuserserializers import AccountUserShortSerializer
from boardcontentmgmt.accountmgmt.accountserializers import  AccountSerializer
from boardcontentmgmt.showspotmgmt.showspotassetserializers import ShowSpotShortSerializer
from boardcontentmgmt.contentmgmt.adcontentserializers import ContentShortSerializer
from boardcontentmgmt.tracking.wificonsumertrackingserializer import WifiCountingSerializer
from boardcontentmgmt.beaconmgmt.beaconserializers import BeaconShortSerializer
from django.utils import timezone
from rest_framework.authtoken.models import Token
from datetime import timedelta, date, datetime
import random,string
from django.contrib.auth.models import User

import logging
logger = logging.getLogger(__name__)

def generate_beacon_key():
    b_key = ''.join(random.choice(string.ascii_lowercase + string.ascii_uppercase + string.digits) 
        for i in range(4))
    spots = Board.objects.filter(beacon_key = b_key)
    if len(spots) > 0:
        generate_beacon_key()
    else:
        return b_key

#################################################################################
# Board Serializers
#################################################################################
class BoardSerializer(serializers.ModelSerializer):
    account = AccountSerializer()
    board_owner = AccountUserShortSerializer()
#     show_spot = serializers.SlugRelatedField(
#         queryset=ShowSpotAsset.objects.all(),
#         slug_field='name',
#         required=False,
#         allow_null=True)
    show_spot = ShowSpotShortSerializer()
    board_state = serializers.SlugRelatedField(
        queryset=ScreenStatus.objects.all(),
        slug_field='name',
        required=False)
    board_size = serializers.SlugRelatedField(
        queryset=ScreenSize.objects.all(),
        slug_field='name',required=False)
    attached_wificounters = WifiCountingSerializer(many=True)
    attached_beacons = BeaconShortSerializer(many=True)
    class Meta:
        model = Board
        fields = ('board_name','board_address','board_owner','board_location_lat',
                  'board_location_long','board_size', 'working_start_time',
                  'working_end_time','account','board_serial_number','show_spot',
                  'board_state','key','beacon_key','attached_wificounters','attached_beacons')

class BoardWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',
        required=False,
        allow_null=True)
    board_owner = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key',
        required=False,allow_null=True)
    board_size = serializers.SlugRelatedField(
        queryset=ScreenSize.objects.all(),
        slug_field='name', required=False,allow_null=True)
    board_address = serializers.CharField(default="",allow_blank=True)
    board_location_lat = serializers.CharField(allow_blank=True,default="")
    board_location_long = serializers.CharField(allow_blank=True,default="")
    show_spot = serializers.SlugRelatedField(
        queryset=ShowSpotAsset.objects.all(),
        slug_field='key',
        required=False,
        allow_null=True)
    board_state = serializers.SlugRelatedField(
        queryset=ScreenStatus.objects.all(),
        slug_field='name',
        required=False)
    attached_wificounters= serializers.SlugRelatedField(
        queryset=WifiCounter.objects.all(),
        many=True ,slug_field='key',required=False)
    attached_beacons= serializers.SlugRelatedField(
        queryset=Beacon.objects.all(),
        many=True ,slug_field='key',required=False)
    class Meta:
        model = Board
        fields = ('board_name','board_address','board_owner','board_location_lat',
                  'board_location_long','board_size', 'working_start_time',
                  'working_end_time','account','board_serial_number','show_spot',
                  'board_state','key','beacon_key','attached_wificounters','attached_beacons')
    def create(self, validated_data):
        scrStatus = ScreenStatus.objects.filter(name = 'CREATED')
        validated_data['board_state'] = scrStatus[0]
        if not 'board_size' in validated_data :
            validated_data['board_size'] = None
        if not 'show_spot' in validated_data :
            validated_data['show_spot'] = None
        if not 'board_owner' in validated_data :
            validated_data['board_owner'] = None
        if not 'account' in validated_data :
            validated_data['account'] = None
        beacon_key = generate_beacon_key()
        validated_data['beacon_key'] = beacon_key
        return serializers.ModelSerializer.create(self, validated_data)

class BoardBasicSerializer(serializers.ModelSerializer):
     class Meta:
        model = Board
        fields = ('board_name','board_serial_number','key')
class BoardShortSerialiser(serializers.ModelSerializer):
    class Meta:
        model = Board
        fields = ('board_name','key')

#################################################################################
# Board Play History Serializers
#################################################################################
class BoardPlayHistorySerializer(serializers.ModelSerializer):
    board = BoardBasicSerializer()
    content_played = ContentShortSerializer()
    campaign = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key',required=False)
    class Meta:
        model = BoardPlayHistory
        fields =  ('board', 'content_from_time','content_to_time',
                   'content_played', 'campaign','schedule_key','key')

class BoardPlayHistoryWriteSerializer(serializers.ModelSerializer):
    board = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='key')
    content_played = serializers.SlugRelatedField(
        queryset=Content.objects.all(),
        slug_field='key')
    campaign = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key',required=False)
    schedule_key = serializers.UUIDField(required=False)
    class Meta:
        model = BoardPlayHistory
        fields =  ('board', 'content_from_time','content_to_time',
                   'content_played','campaign','schedule_key','key')
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        return serializers.ModelSerializer.create(self,validated_data)

#################################################################################
# Board Registration Serializers
#################################################################################
class BoardRegistrationSerializer(serializers.ModelSerializer):
    board = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='board_serial_number')
    class Meta:
        model = BoardRegistration
        fields =  ('board', 'registered_date','registration_status','key')
        
class BoardRegistrationWriteSerializer(serializers.ModelSerializer):
    tokenkey = ""
    board = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='board_serial_number')
    token = serializers.CharField(required=False,allow_null=True)
    def get_tokenxyz(self,obj):
        return self.tokenkey
    registration_status = serializers.CharField(default="FAILED")
    class Meta:
        model = BoardRegistration
        fields =  ('board', 'registered_date','registration_status','token',
                   'auth_code','key')
    def create(self, validated_data):
        logger.debug( validated_data)
        if 'auth_code' in validated_data :
            authcode = validated_data['auth_code']
            serialNum = self.data['board']
            logger.debug( serialNum)
            codes = BoardRegistrationCode.objects.filter(board__board_serial_number
                 = serialNum).filter(registration_code = authcode)
            logger.debug( codes)
            if codes and codes is not None :
                if timezone.now() < codes[0].code_validity :
		    user = User.objects.get(username='board-internal-user-0001')
                    tkn = Token.objects.get_or_create(user=user)[0]
                    br = BoardRegistration()
                    br.board = validated_data['board']
                    br.registration_status = 'SUCCESS'
                    br.auth_code = validated_data['auth_code']
                    self.tokenkey = tkn.key
                    logger.debug( self.tokenkey)
                    br.save()
                    return br
        return serializers.ModelSerializer.create(self, validated_data)
#################################################################################
# Board Registration Code Serializers
#################################################################################
class BoardRegistrationCodeSerializer(serializers.ModelSerializer):
    board = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='board_serial_number')
    class Meta:
        model = BoardRegistrationCode
        fields = ('board','registration_code','code_validity')
class BoardRegistrationCodeWriteSerializer(serializers.ModelSerializer):
    board = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='board_serial_number')
    class Meta:
        model = BoardRegistrationCode
        fields = ('board',)
    def create(self, validated_data):
        brd = validated_data['board']
        brc = BoardRegistrationCode()
        brc.board = brd
        brc.registration_code = "" + str(random.randint(100000,999999))
        tstamp = datetime.now() + timedelta(seconds=45)
        brc.code_validity = tstamp
        brc.save()
        return brc
#################################################################################
# Screen Diagnostics Serializers
#################################################################################
class BoardDiagnosticsSerializer(serializers.ModelSerializer):
    board = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='key')
    class Meta:
        model = ScreenDiagnostics
        fields = ('board','diagnostics_data_date','number_of_resets_for_day',
                  'wifi_num_failed_connections','free_space','wifi_average_speed',
                  'schedule_lag_seconds','average_memory_usage',
                  'application_version','key','data_usage','device_settings')
        
        
