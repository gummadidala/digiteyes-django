from rest_framework import generics
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from boardcontentmgmt.models import Board , BoardPlayHistory, AccountUser,  BoardRegistration,AttributeTagGroup,RpiDiagnostics
from boardcontentmgmt.models import BoardRegistrationCode, ScreenDiagnostics, ScreenStatus,ShowSpotAsset,WifiCounter
from .boardserializers import BoardSerializer , BoardPlayHistorySerializer,Beacon
from .boardserializers import BoardBasicSerializer, BoardRegistrationSerializer


from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from rest_framework import filters
import django_filters
from .boardserializers import BoardWriteSerializer, BoardPlayHistoryWriteSerializer
from .boardserializers import BoardRegistrationWriteSerializer
from .boardserializers import BoardRegistrationCodeWriteSerializer, BoardRegistrationCodeSerializer
from .boardserializers import BoardDiagnosticsSerializer
from boardcontentmgmt.tasks import fill_consumer_content_targets_for_playhistory 
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework.pagination import PageNumberPagination
from rest_framework.authtoken.models import Token
from django.contrib.auth.models import User

import logging
logger = logging.getLogger(__name__)


def filter_account(queryset, value):
    if value is not None:
        logger.debug( "filter account")
        queryset = queryset.filter(account__isnull=value)
        logger.debug( queryset)
    return queryset
def filter_showspot(queryset,value):
    if value is not None:
        logger.debug( "filter showspot")
        queryset = queryset.filter(show_spot__isnull=value)
        logger.debug( queryset)
    return queryset
def filter_location(queryset,value):
    if value is not None and value != '':
        logger.debug( "filter location")
        logger.debug( value)
        queryset = queryset.filter(show_spot__attached_primary_location_tag__name=value)
        logger.debug( queryset)
    return queryset
def filter_attribute_group(queryset,value):
    if value is not None and value != '':
        logger.debug( "attrib group")
        queryset = queryset.filter(show_spot__attached_attribute_tag__name__in=[value])
        logger.debug( queryset)
    return queryset
class BoardFilter(django_filters.FilterSet):
    account = django_filters.CharFilter(name='account__account_name')
    unaccounted = django_filters.BooleanFilter(action=filter_account)
    board_state = django_filters.CharFilter(name='board_state__name')
    unleveraged = django_filters.BooleanFilter(action=filter_showspot)
    primary_location = django_filters.CharFilter(name='primary_location',action=filter_location)
    group = django_filters.CharFilter(name='group',action=filter_attribute_group)
    spot_account = django_filters.CharFilter(name='show_spot__account__key')
    class Meta:
        model = Board
        fields = ()
class BoardDiagnosticsFilter(django_filters.FilterSet):
    board = django_filters.CharFilter(name='board__key',lookup_type='exact')
    class Meta:
        model = ScreenDiagnostics
	fields = ('board',)
class BoardReigstrationFilter(django_filters.FilterSet):
    board = django_filters.CharFilter(name='board__key',lookup_type='exact')
    class Meta:
        model = BoardRegistration
	fields = ('board',)
#################################################################################
# Board List API List View
#################################################################################
class BoardListAPIView(generics.ListCreateAPIView):
    """
    Screen List
    ==========
    ##GET:
    List of Screens. If no filters passed, then it returns the list of screens in the account.
    ### Filter Fields:
        1. unaccounted (For Un accounted )
        2. board_state (For UnRegisterd or any other states)
        3. account__account_name (Filter based on account)
        4. board_name (for board name filtering)
                         
    ###Search Fileds:
        1. screen name (board_name) 
    ##POST:
    
    Create a Screen Instance. 
    ###Required fields are
        1. board Name (board_name)
        2. board serial number (board_serial_number)
    
    Screen Instance creation happens from Production account. So they are not put into any account. Screens
    are assigned to an account during Assign screen workflow, which happens after the screen is registered.
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = BoardSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_class = BoardFilter
    search_fields = ('board_name','board_serial_number','account__account_name')
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'board') == True):
            return Board.objects.all()
        else:
            return Board.objects.filter(account__key = acct.key)
        #return Board.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return BoardWriteSerializer
        return BoardSerializer

#################################################################################
# Board Update API View
#################################################################################
def get_board_forwificounter(wificounters):
    wificounter_list=[]
    for wifi_cntr in wificounters:
        obj = WifiCounter.objects.filter(key=wifi_cntr)
        if obj is not None and len(obj)>0:
            wificounter_list.append(obj[0])
    brd = Board.objects.filter(attached_wificounters__in=wificounter_list)
    if brd is not None and len(brd)>0:
        return brd
    return None
def get_board_forbeacon(beacons):
    beacon_list=[]
    for bcn in beacons:
        obj = Beacon.objects.filter(key=bcn)
        if obj is not None and len(obj)>0:
            beacon_list.append(obj[0])
    brd = Board.objects.filter(attached_beacons__in=beacon_list)
    if brd is not None and len(brd)>0:
        return brd
    return None
class BoardUpdateView(generics.RetrieveUpdateDestroyAPIView):
    """
    Board
    ========
    ##GET:
    Retrieves the Board object specified by the key.
           
    ##PUT:
    
    Updates a Board Object
    ###Required fields are
        1. board Name (board_name)
        2. board serial number (board_serial_number)
        
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = BoardSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('board_state__name', 'account__account_name')
    search_fields = ('board_name','board_serial_number')
    lookup_field = 'key'
    def modify(self):
        field_permissions = [{'permission':'modify_all_board',
                              'model_name' : 'board'}]
        return field_permissions
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'board') == True):
            return Board.objects.all()
        else:
            return Board.objects.filter(account__key = acct.key)
        #return Board.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return BoardWriteSerializer
        return BoardSerializer
    
    def patch(self,request,format=None,*args,**kwargs):
        validated_data = request.data
        #print validated_data
        if 'attached_wificounters' in validated_data:
            wifi_counters = validated_data['attached_wificounters']
            wifi_counters_list = []
            for wifi_cntr in wifi_counters:
                obj = WifiCounter.objects.filter(key=wifi_cntr)
                if obj is not None and len(obj)>0:
                    wifi_counters_list.append(obj[0])
                else:
                    error = {'error':wifi_cntr+' WifiCounter not found'}
                    return Response(error,status = HTTP_400_BAD_REQUEST)
        elif 'attached_beacons' in validated_data:
            beacons = validated_data['attached_beacons']
            beacons_list = []
            for bcn in beacons:
                obj = Beacon.objects.filter(key=bcn)
                if obj is not None and len(obj)>0:
                    beacons_list.append(obj[0])
                else:
                    error = {'error':bcn+' Beacon not found'}
                    return Response(error,status = HTTP_400_BAD_REQUEST) 
        if 'attached_wificounters' in validated_data and 'confirm' in validated_data:
            if validated_data['confirm'] != True:
                res=get_board_forwificounter(wifi_counters)
                if res is not None and len(res)>0:
                    for brd_obj in res:  
                        if brd_obj.board_name != validated_data['board_name']:
                            error = {'error':'This wificounter is already assigned to board : '+str(brd_obj.board_name)+
                             '. If you continue, this wificounter is no more attached to ' +str(brd_obj.board_name) +
                            '. Do you really want to continue??'}
                            return Response(error,status = HTTP_400_BAD_REQUEST)
            elif validated_data['confirm']:
                prev_boards_with_given_wificounters = Board.objects.filter(attached_wificounters__in = wifi_counters_list)
                if prev_boards_with_given_wificounters is not None:
                    for each_board in prev_boards_with_given_wificounters:
                        each_board.attached_wificounters = []
                        each_board.save()
        elif 'attached_beacons' in validated_data and 'confirm' in validated_data:
            if validated_data['confirm'] != True:
                res=get_board_forbeacon(beacons)
                if res is not None and len(res)>0:
                    for brd_obj in res:  
                        if brd_obj.board_name != validated_data['board_name']:
                            error = {'error':'This beacon is already assigned to board : '+str(brd_obj.board_name)+
                             '. If you continue, this beacon is no more attached to ' +str(brd_obj.board_name) +
                            '. Do you really want to continue??'}
                            return Response(error,status = HTTP_400_BAD_REQUEST)
            elif validated_data['confirm']:
                prev_boards_with_given_beacons = Board.objects.filter(attached_beacons__in = beacons_list)
                if prev_boards_with_given_beacons is not None:
                    for each_board in prev_boards_with_given_beacons:
                        each_board.attached_beacons = []
                        each_board.save()
                        
        if 'show_spot' in validated_data:
            spot_obj = ShowSpotAsset.objects.filter(key=validated_data['show_spot'])
            if spot_obj is not None and len(spot_obj)>0:
                brd_obj = Board.objects.filter(key = validated_data['key'])[0]
                if len(brd_obj.attached_beacons.all()) > 0:
                   spot_obj[0].attached_beacons = brd_obj.attached_beacons.all()
                if len(brd_obj.attached_wificounters.all()) > 0:
                   spot_obj[0].attached_wificounters = brd_obj.attached_wificounters.all()
                spot_obj[0].save()
        return generics.RetrieveUpdateDestroyAPIView.patch(self,request,*args,**kwargs)
#################################################################################
# Board List API List View -- This is not used...
#################################################################################
class BoardListView(APIView):
    """
    Screen List
    ==========
    ##GET:
    List of Screens. If no filters passed, then it returns the list of screens in the account.
    ### Filter Fields:
        1. unaccounted - All the screens in the System which are not yet assinged to any account but 
                         installed and registered.
        2. unregiestered - All the screeens in the System, which are not yet registered.
        3. tags  - Screens which have the given tags assigned.
                         
    ###Search Fileds:
    
        1. screen name (board_name) 
        
        
    ##POST:
    
    Create a Screen Instance. 
    ###Required fields are
        1. board Name (board_name)
        2. board serial number (board_serial_number)
    
    Screen Instance creation happens from Production account. So they are not put into any account. Screens
    are assigned to an account during Assign screen workflow, which happens after the screen is registered.
    """
    
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    def get(self,request,format = None):
        unaccounted = request.query_params.get('unaccounted', None)
        unregistered = request.query_params.get('unregistered', None)
        assigned_tags = request.query_params.getlist('tags',None)
        boards = []
        if unaccounted :
            registered_boards = BoardRegistration.objects.values_list('board_serial_number',flat=True)
            boards = Board.objects.filter(board_serial_number__in = registered_boards, account__isnull = True )
        else :
            if unregistered :
                registered_boards = BoardRegistration.objects.values_list('board_serial_number',flat=True)
                boards = Board.objects.exclude(board_serial_number__in = registered_boards) 
            else :
                if assigned_tags :
                    username = request.user.username
                    accounts = AccountUser.objects.filter(account_user__username=username)
                    acct = accounts[0].account
                    boards = Board.objects.filter(attached_tags__tag_name__in = assigned_tags).filter(board_owner__account__key = acct.key)
                else :
                    username = request.user.username
                    accounts = AccountUser.objects.filter(account_user__username=username)
                    acct = accounts[0].account
                    boards = Board.objects.filter(account__key = acct.key)
        serializer = BoardSerializer(boards, many=True)
        return Response(serializer.data)
    def post(self,request, format=None):
        #username = request.user.username
        #accounts = AccountUser.objects.filter(account_user__username=username)
        #acct = accounts[0].account
        #parsed_data = request.data
        #parsed_data['account'] = acct.key
        #parsed_data['board_owner'] = accounts[0].key
        serializer = BoardBasicSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)

#################################################################################
# Board List API List View
#################################################################################
class BoardRegistrationListView(generics.ListCreateAPIView):
    """
    Screen Registrations
    ===================
    ##GET:
    List of Screen Registrations happened so far. 
        
    ##POST:
    
    Creates a Screen Registration Entry.
    ###Required fields are
        1. board serial Number (board_serial_number)
        
    """
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    filter_class = BoardReigstrationFilter
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'boardregistration') == True):
            return BoardRegistration.objects.all()
        else:
            return BoardRegistration.objects.filter(account__key = acct.key)
        #return BoardRegistration.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return BoardRegistrationWriteSerializer
        return BoardRegistrationSerializer
    def post(self,request, format=None):
        serializer = BoardRegistrationWriteSerializer(data=request.data)
        if serializer.is_valid():
            br = serializer.save()
            ser = BoardRegistrationSerializer(serializer.instance)
            tkn = serializer.get_tokenxyz(None)
            resp_data = {}
            resp_data.update(ser.data)
            resp_data['token'] = tkn    
            resp_data['board_key'] = br.board.key
            resp_data['beacon_key'] = br.board.beacon_key
            status = ScreenStatus.objects.filter(name='REGISTERED')
            br.board.board_state = status[0]
            br.board.save()
            return Response(resp_data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)

#################################################################################
# Board List API List View
#################################################################################
class BoardRegistrationCodeListView(generics.ListCreateAPIView):
    """
    Screen Registrations
    ===================
    ##GET:
    List of Screen Registrations happened so far. 
        
    ##POST:
    
    Creates a Screen Registration Entry.
    ###Required fields are
        1. board serial Number (board_serial_number)
        
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'boardregistrationcode') == True):
            return BoardRegistrationCode.objects.all()
        else:
            return BoardRegistrationCode.objects.filter(account__key = acct.key)
        #return BoardRegistrationCode.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return BoardRegistrationCodeWriteSerializer
        return BoardRegistrationCodeSerializer
    def post(self,request, format=None):
        serializer = BoardRegistrationCodeWriteSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            ser = BoardRegistrationCodeSerializer(serializer.instance)
            return Response(ser.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)   
#################################################################################
# Board List API List View
#################################################################################
class BoardPlayHistoryFilter(django_filters.FilterSet):
    board = django_filters.CharFilter(name='board__key',lookup_type='exact')
    from_datetime = django_filters.DateTimeFilter(name='content_from_time',lookup_type='gte')
    to_datetime = django_filters.DateTimeFilter(name='content_to_time',lookup_type='lte')
    class Meta:
        model = BoardPlayHistory
	fields = ('board','from_datetime','to_datetime',)
class CustomPagination(PageNumberPagination):
    page_size_query_param = 'page_size'
class BoardPlayHistoryListView(generics.ListCreateAPIView):
    """
    Board Play History List
    ==========
    ##GET:
    List of History records.
    ##POST:
    Create a new History Record
    ### Required Fields
        1. Board (key)
        2. Content played (key)
        3. Content start time
        4. content_end_time
        5. campaign (key)
    """
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = BoardPlayHistorySerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_fields = ('content_played__content_name', 'account__account_name','account')
    filter_class = BoardPlayHistoryFilter
    pagination_class = CustomPagination
    search_fields = ('content_played__content_name','board__name', )
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'boardplayhistory') == True):
            return BoardPlayHistory.objects.all()
        else:
            return BoardPlayHistory.objects.filter(account__key = acct.key)
        #return BoardPlayHistory.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return BoardPlayHistoryWriteSerializer
        return BoardPlayHistorySerializer
    '''
    def perform_create(self, serializer):
        logger.debug( "perform create BoardPlayHistory")
        generics.ListCreateAPIView.perform_create(self, serializer)
        logger.debug( serializer.instance)
        fill_consumer_content_targets_for_playhistory.delay(str(serializer.instance.key))
        '''
        
class BoardPlayHistoryUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = BoardPlayHistorySerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_fields = ('content_played__content_name', 'account__account_name','account')
    filter_class = BoardPlayHistoryFilter
    pagination_class = CustomPagination
    search_fields = ('content_played__content_name','board__name', )
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'boardplayhistory') == True):
            return BoardPlayHistory.objects.all()
        else:
            return BoardPlayHistory.objects.filter(account__key = acct.key)
        #return BoardPlayHistory.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return BoardPlayHistoryWriteSerializer
        return BoardPlayHistorySerializer
    def perform_update(self, serializer):
        logger.debug( "perform update BoardPlayHistory")
        generics.RetrieveUpdateDestroyAPIView.perform_update(self, serializer)
        logger.debug( serializer.instance)
        fill_consumer_content_targets_for_playhistory.delay(str(serializer.instance.key))
#################################################################################
# Board List API List View
#################################################################################
class BoardDiagnosticsListView(generics.ListCreateAPIView):
    """
    Board Diagnostics
    ==========
    ##GET:
    List of Diagnostics records.
    ##POST:
    Create a new History Record
    ### Required Fields
        1. diagnostics_data_date
        2. number_of_resets_for_day
        3. wifi_num_failed_connections
        4. free_space
        5. wifi_average_speed
        6. schedule_lag_seconds
    """
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = BoardDiagnosticsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_fields = ('content_played__content_name', 'account__account_name','account')
    search_fields = ('board__name', 'board__board_serial_number')
    lookup_field = 'key'
    filter_class = BoardDiagnosticsFilter
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        '''
        if(ProfileCheck().get_filter(self.request.user,'screendiagnostics') == True):
            return ScreenDiagnostics.objects.all().order_by('-diagnostics_data_date')
        else:
            return ScreenDiagnostics.objects.filter(account__key = acct.key).order_by('-diagnostics_data_date')
        '''
        return ScreenDiagnostics.objects.all().order_by('-diagnostics_data_date')
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return BoardDiagnosticsSerializer
        return BoardDiagnosticsSerializer

#################################################################################
# Board List API List View
#################################################################################
class PiRegistrationListView(generics.ListCreateAPIView):
    def post(self, request, *args, **kwargs):
        resp_data={}
        mac_address=request.data['mac_address']
        if mac_address is not None:
            wificounter=WifiCounter.objects.filter(mac_address=mac_address)
            if wificounter is not None and len(wificounter)>0:
                brd = Board.objects.filter(attached_wificounters__in=wificounter)
                if brd is not None and len(brd)>0:
                    resp_data["board_beacon_id"]=brd[0].beacon_key
                    resp_data["serial_number"]=brd[0].board_serial_number
                    resp_data["board_key"]=str(brd[0].key)
                    pi_diag_obj = RpiDiagnostics.objets.filter(board__key=brd[0].key)
                    if pi_diag_obj is not None and len(pi_diag_obj)>0:
                        resp_data["application_version"]=str(pi_diag_obj[0].application_version)
                    else:
                        resp_data["application_version"]="0.0"
                else:
                    error = {'error':'No board is found with the given mac_address'}
                    return Response(error,status=HTTP_400_BAD_REQUEST)
            else:
                error = {'error':'wificounter not found with given macaddress'}
                return Response(error,status=HTTP_400_BAD_REQUEST)
        else:
            error = {'error':'mac_address can not be empty!'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        usr = User.objects.filter(username='board-internal-user-0001')[0]
        token=Token.objects.get_or_create(user=usr)[0]
        resp_data['token']=token.key
        return Response(resp_data,status=HTTP_201_CREATED)

class GetScreensByGroupAPIListView(APIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    def get(self,request):
        channel_key = request.query_params.get('group', None)
        attrib_grp = AttributeTagGroup.objects.filter(key=channel_key)
        grp_list = []
        if attrib_grp is not None and len(attrib_grp) >0:
            children = attrib_grp[0].get_children()
            if len(children) > 0:
                for child in children:
                    child_grp = child.get_children()
                    if len(child_grp)>0:
                        for ch in child_grp:
                            grp_list.append(ch.key)
                    else:
                        grp_list.append(child.key)
            else:
                grp_list.append(attrib_grp[0].key)
        spot_list = []
        for grp in grp_list:
            show_spot = ShowSpotAsset.objects.filter(attached_attribute_tag__key = grp)
            if show_spot is not None and len(show_spot)>0:
                spot_list.extend(show_spot)
        logger.info("Length of showspots for selected group:"+str(len(spot_list)))
        screen_list = []
        for spot in spot_list:
            screen= Board.objects.filter(show_spot__key=spot.key)
            if screen is not None and len(screen)>0:
                screen_list.append(BoardSerializer(screen[0]).data)
        logger.info("Length of screens for selected group:"+str(len(screen_list)))
        return Response(screen_list)

