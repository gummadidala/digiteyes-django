from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST, HTTP_200_OK
import django_filters
from rest_framework import filters
from boardcontentmgmt.models  import PrimaryLocationTag,PrimaryAttributeTag,AttributeTagGroup
from .tagserializers import PrimaryLocationTagSerializer,PrimaryLocationTagWriteSerializer
from .tagserializers import PrimaryAttributeTagSerializer,PrimaryAttributeTagWriteSerializer
from .tagserializers import AttributeTagGroupSerializer,AttributeTagGroupWriteSerializer
from boardcontentmgmt.models import AccountUser
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
#################################################################################
# PrimaryLocationTag  API List View - Supports Listing and Create
#################################################################################
class PrimaryLocationTagListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = PrimaryLocationTagSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name','name','desc')
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(usr,'primarylocationtag') == True):
            return PrimaryLocationTag.objects.all()
        else:
            return PrimaryLocationTag.objects.filter(account__key = acct.key)
    #queryset = PrimaryLocationTag.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return PrimaryLocationTagWriteSerializer
        return PrimaryLocationTagSerializer
#################################################################################
# PrimaryLocationTag  API Detail View - Supports Update/Patch and Deletion
#################################################################################
class PrimaryLocationTagDetailView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = PrimaryLocationTagSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name','name','desc')
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(usr,'primarylocationtag') == True):
            return PrimaryLocationTag.objects.all()
        else:
            return PrimaryLocationTag.objects.filter(account__key = acct.key)
    #queryset = PrimaryLocationTag.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return PrimaryLocationTagWriteSerializer
        return PrimaryLocationTagSerializer



#################################################################################
# PrimaryAttributeTag  API List View - Supports Listing and Create
#################################################################################
class PrimaryAttributeTagListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = PrimaryAttributeTagSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name','name','desc')
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(usr,'primaryattributetag') == True):
            return PrimaryAttributeTag.objects.all()
        else:
            return PrimaryAttributeTag.objects.filter(account__key = acct.key)
    #queryset = PrimaryAttributeTag.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return PrimaryAttributeTagWriteSerializer
        return PrimaryAttributeTagSerializer
#################################################################################
# PrimaryAttributeTag  API Detail View - Supports Update/Patch and Deletion
#################################################################################
class PrimaryAttributeTagDetailView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = PrimaryAttributeTagSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name','name','desc')
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(usr,'primaryattributetag') == True):
            return PrimaryAttributeTag.objects.all()
        else:
            return PrimaryAttributeTag.objects.filter(account__key = acct.key)
    #queryset = PrimaryAttributeTag.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return PrimaryAttributeTagWriteSerializer
        return PrimaryAttributeTagSerializer




#################################################################################
# AttributeTagGroup  API List View - Supports Listing and Create
#################################################################################

class GroupFilter(django_filters.FilterSet):
    leaf = django_filters.NumberFilter(name='numchild',lookup_type='exact')
    class Meta:
        model = AttributeTagGroup
	fields = ('leaf',)
class AttributeTagGroupListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = AttributeTagGroupSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_class= GroupFilter
    search_fields = ('account__account_name','name','desc')
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
#         if(ProfileCheck().get_filter(usr,'attributetaggroup') == True):
#             return AttributeTagGroup.objects.all()
#         else:
#             return AttributeTagGroup.objects.filter(account__key = acct.key)
        #queryset = AttributeTagGroup.objects.all()
        return AttributeTagGroup.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return AttributeTagGroupWriteSerializer
        return AttributeTagGroupSerializer
    def get(self,request,*args,**kwargs):
        tree_format = request.query_params.get('tree', None)
        
        if tree_format is not None:
            tree = AttributeTagGroup.dump_bulk(keep_ids=False)
            return Response(tree)
        else:
            return generics.ListCreateAPIView.get(self, request, *args, **kwargs)
    def post(self, request, *args, **kwargs):       
        node_data = request.data['node']
        grpNode = AttributeTagGroup()
        grpNode.name = node_data['name']
        grpNode.desc = node_data['desc']
        usr = request.user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        grpNode.account = aUsr[0].account
        grpNode.tag_owner = aUsr[0]
        if 'root' in request.data :
            rootElem = AttributeTagGroup.objects.get(key=request.data['root'])
            rootElem.add_child(instance=grpNode)
            serializer = AttributeTagGroupSerializer(grpNode)
            return Response(serializer.data,HTTP_201_CREATED)
        else :
            AttributeTagGroup.add_root(instance=grpNode)
            serializer = AttributeTagGroupSerializer(grpNode)
            return Response(serializer.data,HTTP_201_CREATED)
            #return Response(serializer.errors,HTTP_400_BAD_REQUEST)
        
#################################################################################
# AttributeTagGroup  API Detail View - Supports Update/Patch and Deletion
#################################################################################
class AttributeTagGroupDetailView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = AttributeTagGroupSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name','name','desc')
    lookup_field = 'key'
    queryset = AttributeTagGroup.get_tree()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return AttributeTagGroupWriteSerializer
        return AttributeTagGroupSerializer
    
    def put(self, request, *args, **kwargs):
        if 'root' in request.data :
            rootElem = AttributeTagGroup.objects.get(key=request.data['root'])
            instance = self.get_object()
            instance.move(rootElem)
            serializer = AttributeTagGroupSerializer(instance)
            return Response(serializer.data,HTTP_200_OK)
        else :
            instance = self.get_object()
            instance.name = request.data['name']
            instance.desc = request.data['desc']
            instance.save()
            serializer = AttributeTagGroupSerializer(instance)
            return Response(serializer.data,HTTP_200_OK)
            
    def patch(self, request, *args, **kwargs):
        if 'root' in request.data :
            rootElem = AttributeTagGroup.objects.get(key=request.data['root'])
            instance = self.get_object()
            instance.move(rootElem,pos='sorted-child')
            serializer = AttributeTagGroupSerializer(instance)
            return Response(serializer.data,HTTP_200_OK)
        else :
            instance = self.get_object()
            if 'node' in request.data :
                if 'name' in request.data['node'] :
                    instance.name = request.data['node']['name']
                if 'desc' in request.data['node']:
                    instance.desc = request.data['node']['desc']
            instance.save()
            serializer = AttributeTagGroupSerializer(instance)
            return Response(serializer.data,HTTP_200_OK)
        
    def delete(self, request, *args, **kwargs):
        instance = self.get_object()
        instance.delete()
        return Response({"ok"},HTTP_200_OK)
    
class GetChildnodesAPIListView(generics.ListCreateAPIView): 
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    def post(self, request, *args, **kwargs):
        group_name = request.data['group_name']
        attrib_grp = AttributeTagGroup.objects.filter(name=group_name)
        res_data = []
        if attrib_grp is not None and len(attrib_grp) >0:
            children = attrib_grp[0].get_children()
            for child in children:
                serializer = AttributeTagGroupSerializer(child)
                res_data.append(serializer.data)
            return Response(res_data,HTTP_200_OK)
        else:
            return Response('Group not found',status = HTTP_400_BAD_REQUEST)
        return Response("HELLO")
        
