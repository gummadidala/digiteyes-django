from rest_framework import serializers
from boardcontentmgmt.accountmgmt.accountuserserializers import AccountUserSerializer, AccountUserShortSerializer
from boardcontentmgmt.models import Account,AccountUser,City,PrimaryLocationTag,PrimaryAttributeTag,AttributeTagGroup
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer

#################################################################################
# Serializer for PrimaryLocationTagSerializer
#################################################################################
class PrimaryLocationTagSerializer(serializers.ModelSerializer):
    account = AccountSerializer()
    tag_owner=AccountUserShortSerializer()
    class Meta:
        model= PrimaryLocationTag
        fields = ['name','account','key','desc','tag_owner']
   
#################################################################################
# Serializer for PrimaryLocationTagSerializer
#################################################################################    
   
class PrimaryLocationTagWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key', required=False)
    tag_owner = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key', required=False)
    class Meta:
        model= PrimaryLocationTag
        fields = ['name','account','key','desc','tag_owner']
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        validated_data['tag_owner'] = aUsr[0]
        return serializers.ModelSerializer.create(self, validated_data)




#################################################################################
# Serializer for PrimaryAttributeTagSerializer
#################################################################################
class PrimaryAttributeTagSerializer(serializers.ModelSerializer):
    account = AccountSerializer()
    tag_owner=AccountUserShortSerializer()
    class Meta:
        model= PrimaryAttributeTag
        fields = ['name','account','key','desc','tag_owner']
   
#################################################################################
# Serializer for PrimaryAttributeTagSerializer
#################################################################################    
   
class PrimaryAttributeTagWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    tag_owner = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key',required=False)
    class Meta:
        model= PrimaryAttributeTag
        fields = ['name','account','key','desc','tag_owner']
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        validated_data['tag_owner'] = aUsr[0]
        return serializers.ModelSerializer.create(self, validated_data)



#################################################################################
# Serializer for AttributeTagGroupSerializer
#################################################################################
class AttributeTagGroupShortSerializer(serializers.ModelSerializer):
    class Meta:
        model= AttributeTagGroup
        fields = ['name','key']
class AttributeTagGroupSerializer(serializers.ModelSerializer):
    account = AccountSerializer()
    tag_owner=AccountUserShortSerializer()
    # child_groups =self(many=True,required=False)
    #child_groups = serializers.SlugRelatedField(
    #    queryset=AttributeTagGroup.objects.all(),required=False,many=True,
    #    slug_field='key')
    
    class Meta:
        model= AttributeTagGroup
        fields = ['name','account','key','desc','tag_owner',]
   
#################################################################################
# Serializer for PrimaryAttributeTagSerializer
#################################################################################    
 
class AttributeTagGroupWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    tag_owner = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key',required=False)
    #child_groups = serializers.SlugRelatedField(
        #queryset=AttributeTagGroup.objects.all(),required=False,many=True,
        #slug_field='key')
    class Meta:
        model= AttributeTagGroup
        fields = ['name','account','key','desc','tag_owner',]
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        validated_data['tag_owner'] = aUsr[0]
        return serializers.ModelSerializer.create(self, validated_data)
