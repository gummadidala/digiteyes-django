from django.conf.urls import url


from boardcontentmgmt.screenmgmt import boardapiviews
from boardcontentmgmt.accountmgmt import userprofileapiviews
from boardcontentmgmt.tagmgmt import tagapiviews
from boardcontentmgmt.campaignmgmt import campaignapiviews
from boardcontentmgmt.contentmgmt import contentapiviews




from rest_framework.authtoken import views
from django.contrib.auth.decorators import login_required

from boardcontentmgmt.beaconmgmt import beaconapiviews
from boardcontentmgmt.accountmgmt import accountapiviews
from boardcontentmgmt.adpackmgmt import masteradpackapiviews
from boardcontentmgmt.accountmgmt import residentialcomplexapiview
from boardcontentmgmt.accountmgmt import screenownerapiviews
from boardcontentmgmt.campaignmgmt import campaignstatsapiviews
from . import facebookaccountsettingsapi
from boardcontentmgmt.showspotmgmt import showspotassetapiviews
from boardcontentmgmt.accountmgmt import advertiserapiviews
from boardcontentmgmt.devicemgmt import devicecontentadviceapiviews
from boardcontentmgmt.adpackmgmt import applicablemapapiviews
from boardcontentmgmt.adpackmgmt import bookedadpackapiviews
from boardcontentmgmt.consumermgmt import consumerapiviews
from boardcontentmgmt.utilities import masterdataapiviews,pullproduct
from boardcontentmgmt.utilities import triggerbookingalgoapiviews
from boardcontentmgmt.entitlementsmgmt import masterentitlementapiviews
from boardcontentmgmt.utilities import remainingentitledunitsapiviews
from boardcontentmgmt.servicesmgmt import userqueryapiviews
from boardcontentmgmt.permissionsmgmt import expirytokenauthenticationview
from boardcontentmgmt.paymentmgmt import initiatepaymentapiviews
from boardcontentmgmt.paymentmgmt import orderapiviews
from boardcontentmgmt.paymentmgmt import paymentsuccessurl, paymentfailureurl
from boardcontentmgmt.consumermgmt import consumersavedcontenttargetsapiviews
from testdata.createTestData import Test_DataAPIView
from boardcontentmgmt.servicesmgmt import campaigndashboardstatsapiviews
from boardcontentmgmt.servicesmgmt import campaignstatusapiviews
from boardcontentmgmt.revenuemgmt import revenueapiviews
from boardcontentmgmt.tracking import wificonsumertrackingapiviews
from boardcontentmgmt.contentmgmt import s3uploadcredentialsapiview
from boardcontentmgmt.accountmgmt import resetpasswordapiview
from boardcontentmgmt.devicemgmt import devicecontrolapiviews
from boardcontentmgmt.adpackmgmt import daypackapiviews
from boardcontentmgmt.adpackmgmt import applicabledaypackapiviews
from boardcontentmgmt.adpackmgmt import bookeddaypackapiviews
from boardcontentmgmt.devicemgmt import devicelastcontactapiviews
from boardcontentmgmt.devicemgmt import rpilastcontactapiviews
from boardcontentmgmt.contentmgmt import affiliatecontentapiviews
from boardcontentmgmt.accountmgmt import myuserdetailsapiview
from boardcontentmgmt.cuponmgmt import discountcouponapiviews
from boardcontentmgmt.cuponmgmt import validatecouponapiviews
from boardcontentmgmt.cuponmgmt import promoconditionapiviews
from boardcontentmgmt.tracking import consumertrackingapiviews
from boardcontentmgmt.layoutmgmt import layoutapiviews 
from boardcontentmgmt.servicesmgmt import campaignreportapiview
from boardcontentmgmt.paymentmgmt import noplaycreditapiview
from boardcontentmgmt.utilities import pptconversionapiviews,pullproduct
from boardcontentmgmt.servicesmgmt import businessmetricsapiviews
from boardcontentmgmt.campaignmgmt import apartmentadvertisingapiviews
import systemconfigurationapiviews
from boardcontentmgmt.contentmgmt import contentapprovals
from boardcontentmgmt import tappconfigurationapiviews
import daypartconfigurationapiviews
import devicesecretsapiviews
import traveldestinationlocationsapiviews
from devicemgmt import deviceconfigurationapiviews
from servicesmgmt import screenavailabilitystatsapiviews
from boardcontentmgmt.creditmgmt import credittransactionsapiviews
from servicesmgmt import handoverscreenpropertyapiview
from servicesmgmt import campaignwificountapiview
from accountmgmt import mobileverificationapiviews
from boardcontentmgmt.contentmgmt import azureuploadcredentialsapiview
from boardcontentmgmt.campaignmgmt import tickercampaignapiviews
from boardcontentmgmt.devicemgmt import rpicontrolapiviews
from boardcontentmgmt.historymgmt import historyapiviews
from boardcontentmgmt.bidmgmt import bidsforplayapiviews
from boardcontentmgmt.consumermgmt import userinitiatedvouchercta
from boardcontentmgmt.consumermgmt import claimedvouchercta
from boardcontentmgmt.servicesmgmt import screenstatusapiviews
from boardcontentmgmt.devicemgmt import rpidiagnosticsapiviews
from boardcontentmgmt.adpackmgmt import aradpackapiviews
urlpatterns = [
               # DRF Docs
               
               # Ad Content related apis
               url(r'^api/adcontent/contents/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                   contentapiviews.ContentUpdateView.as_view()),
               url(r'^api/adcontent/contents/$', contentapiviews.ContentList.as_view()),
               url(r'^api/subordinatecontents/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                   contentapiviews.SubordinateContentUpdateAPIView.as_view()),
               url(r'^api/subordinatecontents/$', contentapiviews.SubordinateContentListAPIView.as_view()),
               url(r'^api/adcontent/contentqueues/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                   contentapiviews.ContentQueueUpdateView.as_view()),
               url(r'^api/adcontent/contentqueues/$', contentapiviews.ContentQueueList.as_view()),
               
               # Board related apis
               url(r'^api/boardmgmt/boards/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                    boardapiviews.BoardUpdateView.as_view()),
               url(r'^api/boardmgmt/boards/$', boardapiviews.BoardListAPIView.as_view()),
               url(r'^api/boardmgmt/boardplayhistorys/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                    boardapiviews.BoardPlayHistoryUpdateView.as_view()),
               url(r'^api/boardmgmt/boardplayhistorys/$', boardapiviews.BoardPlayHistoryListView.as_view()),
               

               # Content Advice related apis
               url(r'^api/contentadvice/contentadvices/$', devicecontentadviceapiviews.ContentAdviceListAPIView.as_view()),
               #url(r'^api/contentadvice/device/contentadvices/$', contentadviceapiviews.ContentAdviceListView.as_view()),
               #url(r'^api/contentadvice/contentadvices/(?P<pk>[0-9]+)/$', contentadviceapiviews.ContentAdviceDetailView.as_view()),
               # Analytics related apis
               #url(r'^api/boardanalytics/boardanalyticsstats/$', boardanalyticsstatsapiviews.BoardAnalyticsStatsView.as_view()),
               # Authentication
               url(r'^api/authenticate/', views.obtain_auth_token),
               url(r'^api/myusepermissions/', accountapiviews.MyUserDetailView.as_view()),
               url(r'^api/userprofiles/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', userprofileapiviews.UserProfileDetailView.as_view()),
               url(r'^api/userprofiles/', userprofileapiviews.UserProfileListView.as_view()),
               url(r'^api/userpermissions/', userprofileapiviews.UserGroupsListView.as_view()),
               url(r'^api/accountusers/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', accountapiviews.AccountUserDetailView.as_view()),
               url(r'^api/accountusers/', accountapiviews.AccountUserListView.as_view()),
               
               #ResidentialComplexAPIView
               url(r'^api/residentialcomplex/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', residentialcomplexapiview.ResidentialComplexDetailView.as_view()),
               url(r'^api/residentialcomplex/', residentialcomplexapiview.ResidentialComplexListView.as_view()),
               
               #ScreenOwnerAPI View
               url(r'^api/screenowner/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', screenownerapiviews.ScreenOwnerDetailView.as_view()),
               url(r'^api/screenowner/', screenownerapiviews.ScreenOwnerListView.as_view()),
               
               #Show SpotAssets apiviews 
               url(r'^api/showspotasset/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', showspotassetapiviews.ShowSpotAssetDetailView.as_view()),
               url(r'^api/showspotasset/', showspotassetapiviews.ShowSpotAssetListView.as_view()),
               
                    
               # tags apiviews
               url(r'^api/primarylocationtag/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', tagapiviews.PrimaryLocationTagDetailView.as_view()),
               url(r'^api/primarylocationtag/', tagapiviews.PrimaryLocationTagListView.as_view()),
               url(r'^api/primaryattributetag/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', tagapiviews.PrimaryAttributeTagDetailView.as_view()),
               url(r'^api/primaryattributetag/', tagapiviews.PrimaryAttributeTagListView.as_view()),
               url(r'^api/attributetaggroup/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', tagapiviews.AttributeTagGroupDetailView.as_view()),
               url(r'^api/attributetaggroup/', tagapiviews.AttributeTagGroupListView.as_view()),
               url(r'^api/attributetaggroupchild/', tagapiviews.GetChildnodesAPIListView.as_view()),
               #Advertisers apiviews
               url(r'^api/advertiser/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', advertiserapiviews.AdvertiserDetailView.as_view()),
               url(r'^api/advertiser/', advertiserapiviews.AdvertiserListView.as_view()),
               
               
               # stores
               #url(r'^api/stores/', boardapiviews.StoreListView.as_view()),
               # Board Registrations
               url(r'^api/boardregistrations/', boardapiviews.BoardRegistrationListView.as_view()),
               url(r'^api/piregistrations/', boardapiviews.PiRegistrationListView.as_view()),
               url(r'^api/boardregistrationcodes/', boardapiviews.BoardRegistrationCodeListView.as_view()),
               # Accounts
               url(r'^api/accounts/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', accountapiviews.AccountDetailView.as_view()),
               url(r'^api/accounts/', accountapiviews.AccountListView.as_view()),
               
               # Campaigns
               url(r'^api/campaigns/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   campaignapiviews.CampaignDetailView.as_view()),
               url(r'^api/campaigns/', campaignapiviews.CampaignListView.as_view()),
               #url(r'^api/productinfo/', productinfoapiviews.ProductInfoView.as_view()),
               url(r'^api/beacon/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', beaconapiviews.BeaconDetailView.as_view()),
               url(r'^api/beacon/', beaconapiviews.BeaconListView.as_view()), 
               url(r'^api/beacondiagnostics/', beaconapiviews.BeaconDiagnosticsListView.as_view()), 
               url(r'^api/trafficpatterns/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   masteradpackapiviews.TrafficPatternUpdateView.as_view()),
               url(r'^api/trafficpatterns/', masteradpackapiviews.TrafficPatternListView.as_view()),
               url(r'^api/screenlocationtrafficstats/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                   masteradpackapiviews.ScreenLocationTrafficStatsUpdateView.as_view()),
               url(r'^api/screenlocationtrafficstats/', masteradpackapiviews.ScreenLocationTrafficStatsView.as_view()),
               url(r'^api/masteradpacks/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                   masteradpackapiviews.MasterAdPackUpdateView.as_view()),
               url(r'^api/masteradpacks/', masteradpackapiviews.MasterAdPackListView.as_view()),
               url(r'^api/masteradpackmappings/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                   masteradpackapiviews.MasterAdPackMappingsUpdateView.as_view()),
               url(r'^api/masteradpackmappings/', masteradpackapiviews.MasterAdPackMappingsListView.as_view()),
               url(r'^api/ctas/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                   contentapiviews.CTAUpdateView.as_view()),
               url(r'^api/ctas/', contentapiviews.CTAListView.as_view()),
               url(r'^api/submittedcontents/', contentapiviews.SubmittedContentsListAPIView.as_view()),
               url(r'^api/contenttargets/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                   contentapiviews.ContentTargetUpdateView.as_view()),
               url(r'^api/contenttargets/', contentapiviews.ContentTargetListView.as_view()),
               url(r'^api/consumercontenttargets/', consumerapiviews.ConsumerContentTargetsListView.as_view()),
               url(r'^api/campaigninterests/', campaignstatsapiviews.CampaignInterestsListView.as_view()),
               url(r'^api/userinitiatedctas/', campaignstatsapiviews.UserInitiatedCTAsListView.as_view()),
               url(r'^api/boarddiagnostics/', boardapiviews.BoardDiagnosticsListView.as_view()),
               url(r'^api/deviceconfigurations/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                   deviceconfigurationapiviews.DeviceConfigurationUpdateView.as_view()),
               url(r'^api/deviceconfigurations/', deviceconfigurationapiviews.DeviceConfigurationListView.as_view()),
               url(r'^api/deviceappversions/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                   deviceconfigurationapiviews.DeviceAppVersionUpdateView.as_view()),
               url(r'^api/deviceappversions/', deviceconfigurationapiviews.DeviceAppVersionListView.as_view()),
               url(r'^api/applicablemasterpacks/', applicablemapapiviews.ApplicableMasterAdPackListView.as_view()),
               url(r'^api/bookedadpacks/', bookedadpackapiviews.BookedAdPackListAPIView.as_view()),
               url(r'^api/accounttypes/', accountapiviews.AccountTypeListView.as_view()),
               url(r'^api/consumerauthenticate/',consumerapiviews.ConsumerAuthenticateView.as_view()),
               url(r'^api/consumertracking/',consumerapiviews.ConsumerTrackingListAPIView.as_view()),
               url(r'^api/masterdata/',masterdataapiviews.MasterDataListView.as_view()),
               url(r'^api/callbookingalgo/',triggerbookingalgoapiviews.TriggerBookingAlgorithmListAPIView.as_view()),
               url(r'^api/masterentitlement/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   masterentitlementapiviews.MasterEntitlementUpdateView.as_view()),
               url(r'^api/masterentitlement/',masterentitlementapiviews.MasterEntitlementListView.as_view()),
               #url(r'^api/trackentitlement/',trackentitlementapiviews.TrackEntitlementListView.as_view()),
               url(r'^api/freeentitledunits/',remainingentitledunitsapiviews.RemainingEntitledUnitsAssociationView.as_view()),
               url(r'^api/calendarfreeslots/',remainingentitledunitsapiviews.RemainingEntitledUnitsCalendarView.as_view()),
               url(r'^api/freeslots/',remainingentitledunitsapiviews.RemainingFreeSlotsView.as_view()),
               url(r'^api/userquery/',userqueryapiviews.UserQueryListView.as_view()),
               url(r'^api/authenticatetoken/',expirytokenauthenticationview.obtain_expiring_auth_token),
               url(r'^api/payment/',initiatepaymentapiviews.InitiatePaymentAPIView.as_view()),
               url(r'^ui/successurl/',paymentsuccessurl.Success,name="Success"),
               url(r'^ui/failureurl/',paymentfailureurl.Failure,name="Failure"),
               url(r'^api/consumersavedcontent/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   consumersavedcontenttargetsapiviews.ConsumerSavedContentTargetsUpdateView.as_view()),
               url(r'^api/consumersavedcontent/',consumersavedcontenttargetsapiviews.ConsumerSavedContentTargetsListView.as_view()),
               url(r'^api/campaignreach/',campaigndashboardstatsapiviews.CampaignReachCountView.as_view()),
               url(r'^api/campaigninterest/',campaigndashboardstatsapiviews.CampaignInterestCountView.as_view()),
               url(r'^api/campaignactions/',campaigndashboardstatsapiviews.CampaignActionsCountView.as_view()),
               url(r'^api/campaignplayscompleted/',campaigndashboardstatsapiviews.CampaignPlaysCompletedCountView.as_view()),
               url(r'^api/testdata/',Test_DataAPIView.as_view()),
               url(r'^api/campaignstatustest/',campaignstatusapiviews.CampaignStatusAPIView.as_view()),
               url(r'^api/boardrevenue/',revenueapiviews.BoardRevenueAPIView.as_view()),
               url(r'^api/showspotrevenue/',revenueapiviews.ShowspotRevenueAPIView.as_view()),
               url(r'^api/wificounter/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   wificonsumertrackingapiviews.WificounterDetailView.as_view()),
               url(r'^api/wificounter/',wificonsumertrackingapiviews.WificounterListView.as_view()),
               url(r'^api/wificonsumertracking/',wificonsumertrackingapiviews.WificonsumerTrackingListView.as_view()),
               url(r'^api/consumersignin/',consumerapiviews.ConsumerSignInAPIView.as_view()),
               url(r'^api/consumerverifyemailrequest/',consumerapiviews.ConsumerVerifyEmailRequestAPIView.as_view()),
               url(r'^api/consumerverifyemail/',consumerapiviews.ConsumerVerifyEmailAPIView.as_view()),
               url(r'^api/consumerforgotpassword/',consumerapiviews.ConsumerForgotPasswordAPIView.as_view()),
               url(r'^api/consumerresetpassword/',resetpasswordapiview.ConsumerResetPasswordAPIView.as_view()),
               url(r'^api/resetpasswordrequest/',resetpasswordapiview.ResetPasswordRequestAPIView.as_view()),
               url(r'^api/resetpassword/',resetpasswordapiview.ResetPasswordAPIView.as_view()),
               url(r'^api/createpassword/',resetpasswordapiview.CreatePasswordAPIView.as_view()),
               url(r'^api/s3uploadcredentials/',s3uploadcredentialsapiview.S3UploadCredentials.as_view()),
               url(r'^api/devicecontroller/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   devicecontrolapiviews.DevicecontrolUpdateView.as_view()),
               url(r'^api/devicecontroller/',devicecontrolapiviews.DevicecontrolListView.as_view()),
               url(r'^api/daypack/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   daypackapiviews.DayPackUpdateView.as_view()),
               url(r'^api/daypack/',daypackapiviews.DayPackListView.as_view()),
               url(r'^api/applicabledaypacks/',applicabledaypackapiviews.ApplicableDayPackListView.as_view()),
               url(r'^api/updatebookeddaypack/',bookeddaypackapiviews.BookedDayPackUpdateAPIView.as_view()),
               url(r'^api/bookeddaypack/',bookeddaypackapiviews.BookedDayPackListAPIView    .as_view()),
               url(r'^api/devicelastcontact/',devicelastcontactapiviews.DeviceLastContactListView.as_view()),
               url(r'^api/rpilastcontact/',rpilastcontactapiviews.RpiLastContactListView.as_view()),
               url(r'^api/affiliatecontent/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   affiliatecontentapiviews.AffiliateContentUpdateView.as_view()),
               url(r'^api/affiliatecontent/',affiliatecontentapiviews.AffiliateContentListView.as_view()),  
               url(r'^api/myuserdetails/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   myuserdetailsapiview.MyUserDetailsUpdateView.as_view()),
               url(r'^api/myuserdetails/',myuserdetailsapiview.MyUserDetailsListView.as_view()),
               url(r'^api/discountcoupon/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   discountcouponapiviews.DiscountCouponUpdateView.as_view()),
               url(r'^api/discountcoupon/',discountcouponapiviews.DiscountCouponListView.as_view()),
               url(r'^api/validatediscountcoupon/',validatecouponapiviews.ValidateDiscountCouponView.as_view()),
               url(r'^api/promocondition/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   promoconditionapiviews.PromoConditionUpdateView.as_view()),
               url(r'^api/promocondition/',promoconditionapiviews.PromoConditionListView.as_view()),
               url(r'^api/activeconsumertracking/',consumertrackingapiviews.ConsumerTrackingListView.as_view()),
               url(r'^api/layoutmapping/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   layoutapiviews.LayoutMappingsUpdateView.as_view()),
               url(r'^api/layoutmapping/',layoutapiviews.LayoutMappingsListView.as_view()),
               url(r'^api/layout/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   layoutapiviews.LayoutUpdateView.as_view()),
               url(r'^api/layout/',layoutapiviews.LayoutListView.as_view()),
               url(r'^api/campaignreport/',campaignreportapiview.campaignReportView.as_view()),
               url(r'^api/linkconsumeraccount/',apartmentadvertisingapiviews.LinkConsumerAccountAPIView.as_view()),
               url(r'^api/delinkconsumeraccount/',apartmentadvertisingapiviews.DelinkConsumerAccountAPIView.as_view()),
               url(r'^api/apartmentfreeslots/',apartmentadvertisingapiviews.ApartmentAdvertisingFreeSlotsAPIView.as_view()),
               url(r'^api/apartmentadvertising/',apartmentadvertisingapiviews.ApartmentAdvertisingListAPIView.as_view()),
               url(r'^api/localclassifieds/',apartmentadvertisingapiviews.LocalClassifiedsListView.as_view()),
               url(r'^api/channelfillrate/',businessmetricsapiviews.ChannelFillrateAPIView.as_view()),
               url(r'^api/screengrowth/',businessmetricsapiviews.ScreenGrowthAPIView.as_view()),
               url(r'^api/s3details/',s3uploadcredentialsapiview.AwsBucketDetailsListAPIView.as_view()),
                url(r'^api/webappconsumercontenttargets/',pullproduct.ConsumerAppContentTargetsView.as_view()),
               url(r'^ui/products/(?P<pid>[0-9a-zA-Z]{7})/$',pullproduct.get_product_giventime),
               url(r'^ui/products/(?P<pid>[0-9a-zA-Z]{4})/$',pullproduct.get_product_servertime),
               url(r'^api/pptforclient/',pptconversionapiviews.GetPPTAPIViewForClient.as_view()),
               url(r'^api/pptforwindows/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   pptconversionapiviews.GetPPTAPIViewForWSUpdateView.as_view()),
               url(r'^api/pptforwindows/',pptconversionapiviews.GetPPTAPIViewForWSListView.as_view()),
               url(r'^api/systemconfiguration/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   systemconfigurationapiviews.SystemConfigurationUpdateView.as_view()),
               url(r'^api/systemconfiguration/',systemconfigurationapiviews.SystemConfigurationListView.as_view()),
               url(r'^api/screenbygroup/',boardapiviews.GetScreensByGroupAPIListView.as_view()),
               url(r'^api/signup/',accountapiviews.SignUpAPIView.as_view()),
               url(r'^api/contentapprovals/',contentapprovals.ContentApprovalsAPIView.as_view()),
               url(r'^api/tappconfiguration/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   tappconfigurationapiviews.TappConfigurationUpdateView.as_view()),
               url(r'^api/tappconfiguration/',tappconfigurationapiviews.TappConfigurationListView.as_view()),
               url(r'^api/devicesecrets/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   devicesecretsapiviews.DeviceSecretsUpdateView.as_view()),
               url(r'^api/devicesecrets/',devicesecretsapiviews.DeviceSecretsListView.as_view()),
               url(r'^api/facebooksettings/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   facebookaccountsettingsapi.FacebookSettingsUpdateView.as_view()),
               url(r'^api/facebooksettings/',facebookaccountsettingsapi.FacebookSettingsListView.as_view()),
               url(r'^api/daypart/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   daypartconfigurationapiviews.DayPartUpdateView.as_view()),
               url(r'^api/daypart/',daypartconfigurationapiviews.DayPartListView.as_view()),
               url(r'^api/availabledayparts/',daypartconfigurationapiviews.GetAvilableDayParts.as_view()),
               url(r'^api/destiny/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   traveldestinationlocationsapiviews.TravelDestinationLocationsUpdateView.as_view()),
               url(r'^api/destiny/',traveldestinationlocationsapiviews.TravelDestinationLocationsListView.as_view()),
               url(r'^api/traveldestinations/',traveldestinationlocationsapiviews.GetTravelDestinationLocationsView.as_view()),
               url(r'^api/groupinfo/',campaignapiviews.GroupInfoView.as_view()),
               url(r'^api/loadcsvfile/',residentialcomplexapiview.LoadCsvFile.as_view()),
               url(r'^api/residentconsumer/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   residentialcomplexapiview.ResidentConsumerUpdateView.as_view()),
               url(r'^api/residentconsumer/',residentialcomplexapiview.ResidentConsumerListView.as_view()),
               url(r'^api/getlogourl/',accountapiviews.GetLogoUrlAPIView.as_view()),
               url(r'^api/screenavailabilitystats/',screenavailabilitystatsapiviews.ScreenAvailabilityStatsAPIView.as_view()),
               url(r'^api/order/',orderapiviews.MyOrderAPIView.as_view()),
               url(r'^api/accountcredittransactions/',credittransactionsapiviews.AccountCreditTransactionsAPIView.as_view()),
               url(r'^api/accountbalance/',credittransactionsapiviews.AccountCreditBalanceView.as_view()),
               url(r'^api/applyaccountbalance/',credittransactionsapiviews.ApplyCreditBalanceView.as_view()),
               url(r'^api/replacescreen/',handoverscreenpropertyapiview.HandoverScreenPropertyAPIView.as_view()),
               url(r'^api/campaignwificount/',campaignwificountapiview.CampaignWifiCountAPIView.as_view()),
               url(r'^api/localdeals/',apartmentadvertisingapiviews.LocalDealsListView.as_view()),
               url(r'^api/noplaycredit/',noplaycreditapiview.NoPlayCreditAPIView.as_view()),
               url(r'^api/sendotp/',mobileverificationapiviews.SendOTPAPIView.as_view()),
               url(r'^api/verifyotp/',mobileverificationapiviews.VerifyOTPAPIView.as_view()),
               url(r'^api/wifitraffic/',wificonsumertrackingapiviews.WifiTrafficView.as_view()),
               url(r'^api/campaignactions/',campaigndashboardstatsapiviews.CampaignActionsCountView.as_view()),
               url(r'^api/ctaparameters/',contentapiviews.CTAParametersListView.as_view()),
               url(r'^api/ctaparametersacted/',contentapiviews.CTAParameterActedListView.as_view()),
               url(r'^api/azureuploadcredentials/',azureuploadcredentialsapiview.AzureUploadCredentials.as_view()),
               url(r'^api/campaignctas/',campaigndashboardstatsapiviews.CampaignCTAView.as_view()),
               url(r'^api/tickercampaign/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   tickercampaignapiviews.TickerCampignsUpdateView.as_view()),
               url(r'^api/tickercampaign/',tickercampaignapiviews.TickerCampaingsListAPIView.as_view()),
               url(r'^api/rpicontroller/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   rpicontrolapiviews.RpicontrolUpdateView.as_view()),
               url(r'^api/rpicontroller/',rpicontrolapiviews.RpicontrolListView.as_view()),
               url(r'^api/historymgmt/history/$', historyapiviews.HistoryApiView.as_view()),
               url(r'^api/vouchercta/$', contentapiviews.VoucherCtaListView.as_view()),
               url(r'^api/bidsforplay/$', bidsforplayapiviews.BidsForPlayListView.as_view()),
               url(r'^api/userinitiatedvouchercta/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   userinitiatedvouchercta.UserInitiatedVoucherCTAUpdateView.as_view()),
               url(r'^api/userinitiatedvouchercta/$', userinitiatedvouchercta.UserInitiatedVoucherCTAListView.as_view()),
               url(r'^api/claimedvouchercta/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   claimedvouchercta.ClaimedVoucherCTAUpdateView.as_view()),
               url(r'^api/claimedvouchercta/$', claimedvouchercta.ClaimedVoucherCTAListView.as_view()),
               url(r'^api/bidtest/$', bidsforplayapiviews.BidTestView.as_view()),
               url(r'^api/screenstatussummary/$', screenstatusapiviews.ScreenStatusSummaryAPIView.as_view()),
               url(r'^api/rpiversion/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                   rpidiagnosticsapiviews.RpiVersionUpdateView.as_view()),
               url(r'^api/rpiversion/',rpidiagnosticsapiviews.RpiVersionListView.as_view()),
               url(r'^api/updaterpiversion/',rpidiagnosticsapiviews.RpiDiagnosticsUpdateView.as_view()),
               url(r'^api/rpidiagnostics/',rpidiagnosticsapiviews.RpiDiagnosticsListView.as_view()),
               url(r'^api/consumerattributes/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',consumerapiviews.ConsumerAttributesUpdateAPIView.as_view()),
               url(r'^api/consumerattributes/',consumerapiviews.ConsumerAttibutesListAPIView.as_view()),
               url(r'^api/rpidiagnostics/',rpidiagnosticsapiviews.RpiDiagnosticsListView.as_view()),
               url(r'^api/aradpacks/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                aradpackapiviews.ARAdPackUpdateView.as_view()),
               url(r'^api/aradpacks/',aradpackapiviews.ARAdPackListView.as_view()),
               ]