from rest_framework.views import APIView
from rest_framework import generics
from rest_framework import filters
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from django.http.response import Http404
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
import django_filters
from datetime import datetime,timedelta, date
from rest_framework.pagination import PageNumberPagination
from boardcontentmgmt.models import AccountUser, ConsumerContentTargets, AdvtCampaign,\
    CampaignInterests, UserInitiatedCTA, BoardPlayHistory, BookedAdPack, MyOrder
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.campaignmgmt.campaignstatsserializers import UserInitiatedCTASerializer
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from dateutil.parser import parse
from django.db.models import Max,Min

import logging
logger = logging.getLogger(__name__)

class CustomPagination(PageNumberPagination):
    page_size_query_param = 'page_size'
################################################################################
#Campaign Reach Count Api View
################################################################################
class CampaignReachCountView(generics.ListCreateAPIView):

    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name',)
    filter_fields = ('state__state_name',)
    pagination_class = CustomPagination
    def get(self,request):
        campaign_name = request.query_params.get('campaign', None)
        logger.info( 'campaign key:' + campaign_name)
        advtcmps = AdvtCampaign.objects.filter(key = campaign_name).annotate(
            planned_start_date = Min('planned_dates__date')).annotate(planned_end_date = Max('planned_dates__date'))
        if(len(advtcmps) > 0):
            bkap = BookedAdPack.objects.filter(applied_to__key = campaign_name)
            price = 0
            if bkap is not None and len(bkap) >0:
                for bp in bkap:
                    price += bp.price
            start_date = advtcmps[0].planned_start_date
            start_date_morning = datetime(start_date.year,start_date.month,start_date.day,0,0,0)
            start_date_night = datetime(start_date.year,start_date.month,start_date.day,23,59,59)
            end_date = advtcmps[0].planned_end_date
            end_date_night = datetime(end_date.year,end_date.month,end_date.day,23,59,59)
            result = []
            while start_date_morning <= end_date_night:
                i=0
                camps = ConsumerContentTargets.objects.filter(campaign = campaign_name,time__gte= start_date_morning, time__lte = start_date_night).count()
                campaignReach = {}
                campaignReach['date'] = start_date
                campaignReach['reach'] = camps
                campaignReach['amount'] = price
                result.append(campaignReach)
                start_date_morning = start_date_morning+timedelta(days=1)
                start_date_night = start_date_night+timedelta(days=1)
                start_date = start_date + timedelta(days=1)
                i += 1
            return Response(result) 
        else:
            error = {'error':'Campaign name does not match with the existing campaigns'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
################################################################################
#Campaign Interest Count Api View
################################################################################
class CampaignInterestCountView(generics.ListCreateAPIView):

    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name',)
    filter_fields = ('state__state_name',)
    pagination_class = CustomPagination
    def get(self,request):
        campaign_name = request.query_params.get('campaign', None)
        logger.info( 'campaign key:'+campaign_name)
        advtcmps = AdvtCampaign.objects.filter(key = campaign_name).annotate(
            planned_start_date = Min('planned_dates__date')).annotate(planned_end_date = Max('planned_dates__date'))
        if(len(advtcmps) > 0):
            bkap = BookedAdPack.objects.filter(applied_to__key = campaign_name)
            price = 0
            if bkap is not None and len(bkap) >0:
                for bp in bkap:
                    price += bp.price
            start_date = advtcmps[0].planned_start_date
            start_date_morning = datetime(start_date.year,start_date.month,start_date.day,0,0,0)
            start_date_night = datetime(start_date.year,start_date.month,start_date.day,23,59,59)
            end_date = advtcmps[0].planned_end_date
            end_date_night = datetime(end_date.year,end_date.month,end_date.day,23,59,59)
            result = []
            while start_date_morning <= end_date_night:
                i=0
                camps = CampaignInterests.objects.filter(assoc_campaign__key = campaign_name,interest_time__gte= start_date_morning, interest_time__lte = start_date_night).count()
                campaignInterests = {}
                campaignInterests['date'] = start_date
                campaignInterests['interests'] = camps
                campaignInterests['amount'] = price
                result.append(campaignInterests)
                start_date_morning = start_date_morning+timedelta(days=1)
                start_date_night = start_date_night+timedelta(days=1)
                start_date = start_date + timedelta(days=1)
                i += 1
                
            return Response(result)
        else:
            error = {'error':'Campaign name does not match with the existing campaigns'}
            return Response(error,status=HTTP_400_BAD_REQUEST)

################################################################################
#Campaign Actions Count Api View
################################################################################
class CampaignActionsCountView(generics.ListCreateAPIView):
 #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name',)
    filter_fields = ('state__state_name',)
    pagination_class = CustomPagination
    def get(self,request):
        campaign_name = request.query_params.get('campaign', None)
        logger.info( 'campaign key:'+campaign_name)
        advtcmps = AdvtCampaign.objects.filter(key = campaign_name).annotate(
            planned_start_date = Min('planned_dates__date')).annotate(planned_end_date = Max('planned_dates__date'))
        if(len(advtcmps) > 0):
            bkap = BookedAdPack.objects.filter(applied_to__key = campaign_name)
            price = 0
            if bkap is not None and len(bkap) >0:
                for bp in bkap:
                    price += bp.price
            start_date = advtcmps[0].planned_start_date
            start_date_morning = datetime(start_date.year,start_date.month,start_date.day,0,0,0)
            start_date_night = datetime(start_date.year,start_date.month,start_date.day,23,59,59)
            end_date = advtcmps[0].planned_end_date
            end_date_night = datetime(end_date.year,end_date.month,end_date.day,23,59,59)
            result = []
            while start_date_morning <= end_date_night:
                i=0
                camps = UserInitiatedCTA.objects.filter(assoc_campaign__key = campaign_name,cta_time__gte= start_date_morning, cta_time__lte = start_date_night).count()
                campaignActions = {}
                campaignActions['date'] = start_date
                campaignActions['actions'] = camps
                campaignActions['amount'] = price
                result.append(campaignActions)
                start_date_morning = start_date_morning+timedelta(days=1)
                start_date_night = start_date_night+timedelta(days=1)
                start_date = start_date+timedelta(days=1)
                i += 1
        
            return Response(result)
        else:
            error = {'error':'Campaign name does not match with the existing campaigns'}
            return Response(error,status=HTTP_400_BAD_REQUEST)

################################################################################
#Campaign Plays Completed Count Api View
################################################################################    
class CampaignPlaysCompletedCountView(generics.ListCreateAPIView):

    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name',)
    filter_fields = ('state__state_name',)
    pagination_class = CustomPagination
    def get(self,request):
        campaign_name = request.query_params.get('campaign', None)
        logger.info( 'campaign key:'+ campaign_name)
        advtcmps = AdvtCampaign.objects.filter(key = campaign_name).annotate(
            planned_start_date = Min('planned_dates__date')).annotate(planned_end_date = Max('planned_dates__date'))
        if(len(advtcmps) > 0):
            price = 0
            odr_obj = MyOrder.objects.filter(campaign__key=campaign_name)
            if odr_obj is not None and len(odr_obj)>0:
                odr = odr_obj[0]
                price = odr.paid_amount + odr.credit_amount
            #start_date = advtcmps[0].planned_start_date
            planned_dates = [] 
            for dt in  advtcmps[0].planned_dates.all():
                planned_dates.append(dt.date)
            result = []
            for start_date in planned_dates:
                start_date_morning = datetime(start_date.year,start_date.month,start_date.day,0,0,0)
                start_date_night = datetime(start_date.year,start_date.month,start_date.day,23,59,59)
                #end_date = advtcmps[0].planned_end_date
                #end_date_night = datetime(end_date.year,end_date.month,end_date.day,23,59,59)
            #while start_date_morning <= end_date_night:
                #i=0
                camps = BoardPlayHistory.objects.filter(campaign__key = campaign_name,content_to_time__gte= start_date_morning, content_to_time__lte = start_date_night).count()
                campaignPlaysCompleted = {}
                campaignPlaysCompleted['date'] = start_date
                campaignPlaysCompleted['playscompleted'] = camps
                campaignPlaysCompleted['amount'] = price
                result.append(campaignPlaysCompleted)
                #start_date_morning = start_date_morning+timedelta(days=1)
                #start_date_night = start_date_night+timedelta(days=1)
                #start_date = start_date+timedelta(days=1)
                #i += 1
            
            return Response(result)
        else:
            error = {'error':'Campaign name does not match with the existing campaigns'}
            return Response(error,status=HTTP_400_BAD_REQUEST)

class CampaignCTAView(generics.ListCreateAPIView):

    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name',)
    serializer_class = UserInitiatedCTASerializer
    filter_fields = ('state__state_name',)
    pagination_class = CustomPagination
    def get(self,request):
        res= []
        campaign_name = request.query_params.get('campaign', None)
        cta_type = request.query_params.get('cta_type', None)
        logger.info( 'campaign key:'+ campaign_name)
        advtcmps = AdvtCampaign.objects.filter(key = campaign_name).annotate(
            planned_start_date = Min('planned_dates__date')).annotate(planned_end_date = Max('planned_dates__date'))
        if(len(advtcmps) > 0):
            all_ctas = UserInitiatedCTA.objects.filter(assoc_campaign__key=advtcmps[0].key,
                                                       initiated_cta__type__name=cta_type)
            if all_ctas is not None and len(all_ctas)>0:
                for cta in all_ctas:
                    res.append(UserInitiatedCTASerializer(cta).data)
                return Response(res,HTTP_201_CREATED)
            else:
                error = {'error':'No user responses for this campaign'}
                return Response(error,status=HTTP_400_BAD_REQUEST)
        else:
            error = {'error':'Campaign name does not match with the existing campaigns'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
          
        
        
    
    
    