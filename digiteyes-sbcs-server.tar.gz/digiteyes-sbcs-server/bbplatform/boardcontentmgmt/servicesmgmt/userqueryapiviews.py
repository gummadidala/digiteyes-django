from boardcontentmgmt.models import UserQuery
from .userqueryserializers import UserQuerySerializer,UserQueryWriteSerializer
from djcelery.db import get_queryset
from datetime import date, datetime
from rest_framework import generics
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
#################################################################################
#User Query API List View - Supports Listing and Create
#################################################################################
class UserQueryListView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    #filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    serializer_class  = UserQuerySerializer
    
    queryset = UserQuery.objects.all()
    
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return UserQueryWriteSerializer
        return UserQuerySerializer