from rest_framework import serializers
from boardcontentmgmt.models import UserQuery

################################################################################
#Serilalizer for User Query submission
################################################################################
class UserQuerySerializer(serializers.ModelSerializer):
    class Meta:
        model = UserQuery
        fields = ['key','name','email','company_name','contact_num','query_desc','customer_type']
        
################################################################################
#Serilalizer for User Query submission
################################################################################
class UserQueryWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserQuery
        fields = ['key','name','email','company_name','contact_num','query_desc','customer_type']
        