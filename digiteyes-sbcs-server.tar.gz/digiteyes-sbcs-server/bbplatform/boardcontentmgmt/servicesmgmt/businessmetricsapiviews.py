from __future__ import division
from rest_framework.views import APIView
from rest_framework import generics
from rest_framework import filters
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from django.http.response import Http404
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
import django_filters
from boardcontentmgmt.utilities.algo_utilities import GetNumOfUnits_DayPart
from datetime import datetime,timedelta, date
from rest_framework.pagination import PageNumberPagination
from boardcontentmgmt.models import AccountUser,Board,AttributeTagGroup,ShowSpotAsset, BookedAdPack,DayPart,BoardRegistration
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from dateutil.parser import parse
from datetime import date,timedelta,datetime
from boardcontentmgmt.screenmgmt.boardserializers import BoardRegistrationSerializer

import logging
logger = logging.getLogger(__name__)
 



class CustomPagination(PageNumberPagination):
    page_size_query_param = 'page_size'
################################################################################
#Campaign Reach Count Api View
################################################################################
class ChannelFillrateAPIView(generics.ListCreateAPIView):

    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    def get(self,request):
        channel_key = request.query_params.get('group', None)
        first_date = parse(request.query_params.get('first_date', None)).date()
        last_date = parse(request.query_params.get('last_date', None)).date()
        logger.info( 'Group name:' + channel_key)
        print channel_key
        print first_date, last_date
        attrib_grp = AttributeTagGroup.objects.filter(key=channel_key)
        grp_list = []
        if attrib_grp is not None and len(attrib_grp) >0:
            children = attrib_grp[0].get_children()
            if len(children) > 0:
                for child in children:
                    child_grp = child.get_children()
                    if len(child_grp)>0:
                        for ch in child_grp:
                            grp_list.append(ch.key)
                    else:
                        grp_list.append(child.key)
            else:
                grp_list.append(attrib_grp[0].key)
        spot_list = []
        for grp in grp_list:
            show_spot = ShowSpotAsset.objects.filter(attached_attribute_tag__key = grp)
            if show_spot is not None and len(show_spot)>0:
                spot_list.extend(show_spot)
        logger.info("Length of showspots for selected location and group:"+str(len(spot_list)))
        channel_fillrate=[]
        day_count=0
        for dp in DayPart.objects.all():
            logger.debug('Daypart:'+str(dp.name))
            first_date = first_date+timedelta(days=-day_count)
            day_count=0
            logger.debug('first_date : '+str(first_date)+'last_date : '+str(last_date))
            slots_booked = 0.0
            while first_date <= last_date:
                day_count += 1
                board_count = 0
                for spot in spot_list:
                    board = Board.objects.filter(show_spot__key = spot.key)
                    if board is not None and len(board)>0:
                        board_count += 1
                        bookedadpack = BookedAdPack.objects.filter(booked_screen__key = board[0].key,
                                                               booking_state__name ="SUCCESS",
                                                               date_booked_for=first_date,
                                                               day_part_booked_for__name=dp.name)
                        if bookedadpack is not None and len(bookedadpack)>0:
                            for adpack in bookedadpack:
                                slots_booked += adpack.num_plays*adpack.units_per_play*adpack.unit_size/30
                logger.debug('slots booked:'+str(slots_booked))
                first_date = first_date+timedelta(days=1)
                logger.debug('first_date after increment:'+str(first_date))
            dp_units=GetNumOfUnits_DayPart(dp)
            logger.info('slots_booked:'+str(slots_booked))
            logger.info('daypart slots:'+str(dp_units))
            logger.info('day_count:'+str(day_count))
            logger.info('board_count:'+str(board_count))
            fill_rate=(slots_booked/(board_count*dp_units*day_count))*100
            if fill_rate > 100: #sometimes it is giving 101.66666666666%
                fill_rate = 100
            obj={'daypart':dp.name,'rate':fill_rate}
            channel_fillrate.append(obj)
        return Response(channel_fillrate)
            
            
def boardscount(Date,start_date):
    boards=BoardRegistration.objects.filter(registered_date__lte=Date,registered_date__gte=start_date)
    count=0
    if boards is not None and len(boards)>0:
        for bd in boards:
                count=count+1
    else:
        count=0 
    #print count
    return count        
          
class ScreenGrowthAPIView(generics.ListCreateAPIView):   
         
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,) 
    def get(self,request): 
        now = date.today() 
        screencount=[]    
        for i in range(0,12):
            month=now.strftime('%B'),now.year
            first_day = date(now.year, now.month, 1)
            screencount.append({'month':month,'count':boardscount(now,first_day)})
            now = first_day - timedelta(days=1)
        return Response(screencount)
        