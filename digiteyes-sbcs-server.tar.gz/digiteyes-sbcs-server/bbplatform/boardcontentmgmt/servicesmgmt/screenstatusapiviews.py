'''
Created on 19-Jun-2017

@author: saba
'''

from boardcontentmgmt.models import Board, AttributeTagGroup,DeviceLastContact
from boardcontentmgmt.models import RpiLastContact,BoardPlayHistory
from boardcontentmgmt.utilities.freeslotutilities import get_screens_for_tags
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response
import json
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from django.core.paginator import Paginator

#################################################################################
# Utility Methods to get latest records
#################################################################################
def get_device_last_contact(board_key):
    last_contact = DeviceLastContact.objects.filter(
        board__key=board_key).order_by('-last_contact_time')
    if len(last_contact) > 0:
        device_status = (last_contact[0].status)
        screen_status=""
        if device_status != "":
            status_obj = json.loads(device_status)
            if 'SCREENMGR-SERVICE' in screen_status:
                screen_status = status_obj['SCREENMGR-SERVICE']['SCREEN_POWER_STATUS']
            else :
                screen_status = "UNKNOWN"
        else :
            screen_status = "UNKNOWN"
        return (unicode(last_contact[0].last_contact_time),screen_status)
    else :
        return ("","")
    
def get_rpi_last_contact(board_key):
    last_contact = RpiLastContact.objects.filter(
        board__key=board_key).order_by('-last_contact_time')
    if len(last_contact) > 0:
        return unicode(last_contact[0].last_contact_time)
    else :
        return ""
    
def get_device_last_play(board_key):
    last_play = BoardPlayHistory.objects.filter(
        board__key=board_key).order_by('-content_to_time')
    if len(last_play) > 0:
        return unicode(last_play[0].content_to_time)
    else :
        return ""
    
##################################################################################

# APIView to get Screen Status Summary
##################################################################################
class ScreenStatusSummaryAPIView(APIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    def get(self,request,format = None):
        channel = self.request.query_params.get('channel', None)
        page = self.request.query_params.get('page', 1)
        boards = []
        if channel is not None:
            grpTag = AttributeTagGroup.objects.filter(name=channel)
            boards = get_screens_for_tags([],grpTag)
            boards = boards.exclude(board_state__name='CREATED').exclude(board_state__name='REGISTERED')
        else:
            boards = Board.objects.all().exclude(board_state__name='CREATED').exclude(board_state__name='REGISTERED')
        results = []
        for board in boards:
            status_obj={}
            status_obj['board']=board.key
            status_obj['board_name']=board.board_name
            device_status = get_device_last_contact(board.key)
            status_obj['device_last_contact']= device_status[0]
            status_obj['screen_power_status']=device_status[1]
            status_obj['rpi_last_contact']=get_rpi_last_contact(board.key)
            status_obj['status']=board.board_state.name
            status_obj['device_last_play']=get_device_last_play(board.key)
            results.append(status_obj)
	paginator = Paginator(results,10)
	objpage=None
	try:
		objpage=paginator.page(page)
	except:
		return Response({"count":len(results),"results":[]})		
        return Response({"count":len(results),"results":objpage.object_list})
            
            
        
        
