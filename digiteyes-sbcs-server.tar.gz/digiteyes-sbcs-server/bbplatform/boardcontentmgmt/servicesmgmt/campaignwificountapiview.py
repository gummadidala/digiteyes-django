from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST,HTTP_200_OK
import django_filters
from rest_framework import filters
from boardcontentmgmt.models import CampaignWifiCount,AdvtCampaign,ShowSpotAsset
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
import datetime
from rest_framework import serializers
import traceback,sys
from boardcontentmgmt.campaignmgmt.campaignserializers import AdvtCampaignShortSerializer
from boardcontentmgmt.showspotmgmt.showspotassetserializers import ShowSpotShortSerializer
from setuptools.package_index import HREF
#from boardcontentmgmt.utilities.wifireachutility import generate_wifi_reach_report
import logging
logger = logging.getLogger(__name__)
##################################################################################
#Serializer for CampaignWifiCount
#################################################################################
class CampaignWifiCountSerializer(serializers.ModelSerializer):
    campaign = AdvtCampaignShortSerializer()
    showspot = ShowSpotShortSerializer()
    class Meta:
        model = CampaignWifiCount
        fields = ['key','campaign','showspot','start_time','end_time']
class CampaignWifiCountWriteSerializer(serializers.ModelSerializer):
    campaign = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key')
    showspot = serializers.SlugRelatedField(
        queryset=ShowSpotAsset.objects.all(),
        slug_field='key')
    class Meta:
        model = CampaignWifiCount
        fields = ['key','campaign','showspot','start_time','end_time']
#################################################################################
#CampaignWifiCount API List View - Supports Listing and Create
#################################################################################
class CampaignWifiCountFilter(django_filters.FilterSet):
    spot = django_filters.CharFilter(name='showspot__key',lookup_type='exact')
    campaign = django_filters.CharFilter(name='campaign__key',lookup_type='exact')
    count = django_filters.CharFilter(name='count',lookup_type='exact')
    start_time  = django_filters.CharFilter(name='start_time',lookup_type='gte')
    end_time  = django_filters.CharFilter(name='end_time',lookup_type='lte')
    class Meta:
        model = CampaignWifiCount
	fields = ('spot','campaign','count','start_time','end_time',)
class CampaignWifiCountAPIView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated)#,DjangoModelPermissions,DjangoObjectPermissions,)
    serializer_class  = CampaignWifiCountSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('showspot__key','campaign__name','count')
    filter_class = CampaignWifiCountFilter
    lookup_field = 'key'
    def get(self,request):
        try:
            res=[]
            campaign = request.query_params.get('campaign', None)
            if campaign is None:
                error = {'error':'Campaign key is required!'}
                return Response(error,status=HTTP_400_BAD_REQUEST)
            camp_obj = AdvtCampaign.objects.filter(key=campaign) 
            if camp_obj is None and len(camp_obj)>0:
                error = {'error':'Invalid campaign!'}
                return Response(error,status=HTTP_400_BAD_REQUEST)
            '''
            wifiCount_objs = CampaignWifiCount.objects.filter(campaign__key = campaign)
            logger.info("length of wifiCount_objs are : "+str(len(wifiCount_objs)))
            if wifiCount_objs is not None and len(wifiCount_objs)>0:
                entry_dates = []
                for obj in wifiCount_objs:
                    if obj.start_time.date() not in entry_dates:
                        entry_dates.append(obj.start_time.date())
                logger.info('length of entry_dates: '+str(entry_dates))
                '''
            camp = camp_obj[0]
            planned_dates = camp.planned_dates.all()
            entry_dates = []
            for pd in planned_dates:
                entry_dates.append(pd.date)
            for dt in entry_dates:
                full_day_obj = {}
                strt_time = datetime.datetime.combine(dt, datetime.time(00, 00, 00, 000))
                end_time = datetime.datetime.combine(dt, datetime.time(23, 59, 59, 9999))
                full_day_obj['date'] = dt.strftime("%Y-%m-%d")
                full_day_obj['hourly_data'] = []
                day_count = 0
                for hr in range(24):
                    day_objs = CampaignWifiCount.objects.filter(campaign__key = campaign,
                                                        start_time__range=(strt_time,end_time),
                                                        start_time__hour = hr)
                    if day_objs is not None and len(day_objs)>0:
                        hour_obj = {}
                        hour_obj['hour'] = hr
                        count = 0
                        for obj in day_objs:
                            count = count+obj.count
                        hour_obj['count'] = count
                        day_count = day_count + count
                        if count > 0:
                            full_day_obj['hourly_data'].append(hour_obj)
                    full_day_obj['day_count'] = day_count
                res.append(full_day_obj)
            return Response(res)  
        except:
            logger.error ("ERROR While getting wifi count data for campaign "+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("ERROR While getting wifi count data for campaign "+str(tb))
            error = {'error':'ERROR!'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
    
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return CampaignWifiCountWriteSerializer
        return CampaignWifiCountSerializer
                
    

    
    
    
    
