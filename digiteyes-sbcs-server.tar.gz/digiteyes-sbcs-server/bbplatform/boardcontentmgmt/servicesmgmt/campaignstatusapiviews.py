from rest_framework.views import APIView
from boardcontentmgmt.models import BookedAdPack,BoardPlayHistory,BookingState
from rest_framework import generics
from datetime import datetime,timedelta
from rest_framework.response import Response
from rest_framework.pagination import PageNumberPagination
from rest_framework import serializers
#################################################################################
# Campaign status API List View
#################################################################################
class MySerializer(serializers.Serializer):
    total_plays_planned = serializers.CharField(max_length=200)
    name = serializers.CharField(max_length=200)
    state = serializers.CharField(max_length=200)
    total_plays_completed = serializers.CharField(max_length=200)
    unit_size = serializers.IntegerField()
    day_part = serializers.CharField(max_length=200)

class CampaignStatusAPIView(generics.ListCreateAPIView):
    serializer_class = MySerializer
    def get_queryset(self):
        screen = self.request.query_params.get('screen', None)
        bkdpcks = BookedAdPack.objects.filter(booked_screen__key = screen,
                                              date_booked_for = datetime.now().date(),
                                              booking_state__name='SUCCESS')
        campaigns = []
        responseData = []
        camp_keys=[]
        for bap in bkdpcks:
            if str(bap.applied_to.key) not in camp_keys:
                obj = {'key':str(bap.applied_to.key),
                       'name':bap.applied_to.name,
                       'state':bap.applied_to.state.state_name,
                       'total_plays_planned':bap.applied_to.selected_plays_per_day,
                       'unit_size':bap.unit_size,
                       'day_part':bap.day_part_booked_for.name}
                camp_keys.append(str(bap.applied_to.key))
                campaigns.append(obj)
        for obj in campaigns:
            brdplayhist = BoardPlayHistory.objects.filter(board__key = screen,
                                                          campaign__key = obj['key']).values_list('schedule_key', flat=True).distinct()
            if brdplayhist is not None and len(brdplayhist) > 0:
                obj['total_plays_completed'] = len(brdplayhist)
            else:
                obj['total_plays_completed'] = 0
            responseData.append(obj)
        return responseData
        
            