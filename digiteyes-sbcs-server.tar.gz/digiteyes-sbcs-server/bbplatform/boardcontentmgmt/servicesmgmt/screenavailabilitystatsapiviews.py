from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST,HTTP_200_OK
import django_filters
from rest_framework import filters
from boardcontentmgmt.models import ScreenAvailabilityStats, Board, ShowSpotAsset
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
import datetime
from rest_framework import serializers
from boardcontentmgmt.screenmgmt.boardserializers import BoardBasicSerializer
from boardcontentmgmt.showspotmgmt.showspotassetserializers import ShowSpotShortSerializer
##################################################################################
#Serializer for ScreenAvailabilityStats
#################################################################################
class ScreenAvailabilityStatsSerializer(serializers.ModelSerializer):
    board = BoardBasicSerializer()
    showspot = ShowSpotShortSerializer()
    class Meta:
        model = ScreenAvailabilityStats
        fields = ['key','date','board','availability','production_planned_slots','production_played_slots',
                  'normal_planned_slots','normal_played_slots','device_play_last_contacts','showspot']
class ScreenAvailabilityStatsSerializer(serializers.ModelSerializer):
    board = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='key')
    showspot = serializers.SlugRelatedField(
        queryset=ShowSpotAsset.objects.all(),
        slug_field='key')
    class Meta:
        model = ScreenAvailabilityStats
        fields = ['key','date','board','availability','production_planned_slots','production_played_slots',
                  'normal_planned_slots','normal_played_slots','device_play_last_contacts','showspot']
#################################################################################
#ScreenAvailabilityStats API List View - Supports Listing and Create
#################################################################################
class ScreenAvailabilityStatsFilter(django_filters.FilterSet):
    board = django_filters.CharFilter(name='board__key',lookup_type='exact')
    start_date  = django_filters.CharFilter(name='date',lookup_type='gte')
    end_date  = django_filters.CharFilter(name='date',lookup_type='lte')
    min_range_availability = django_filters.CharFilter(name='availability',lookup_type='gte')
    max_range_availability =django_filters.CharFilter(name='availability',lookup_type='lte')
    class Meta:
        model = ScreenAvailabilityStats
	fields = ('board','start_date','end_date','min_range_availability','max_range_availability',)
class ScreenAvailabilityStatsAPIView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated)#,DjangoModelPermissions,DjangoObjectPermissions,)
    serializer_class  = ScreenAvailabilityStatsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('board__key','baord__name','date')
    filter_class = ScreenAvailabilityStatsFilter
    lookup_field = 'key'
    def get_queryset(self):
        return ScreenAvailabilityStats.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ScreenAvailabilityStatsWriteSerializer
        return ScreenAvailabilityStatsSerializer
                
    

    
    
    
    
