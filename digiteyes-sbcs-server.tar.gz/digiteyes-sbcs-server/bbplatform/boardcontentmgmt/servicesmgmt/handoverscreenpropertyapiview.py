from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST,HTTP_200_OK
import django_filters
from rest_framework import filters
from boardcontentmgmt.models import BookedAdPack,ShowSpotAsset,Beacon,WifiCounter,Board,DayPart,\
                                    ScreenDiagnostics,ScreenAvailabilityStats,BoardPlayHistory,\
                                    ContentQueue,DeviceLastContact
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
import datetime
from rest_framework import serializers
from boardcontentmgmt.screenmgmt.boardserializers import BoardBasicSerializer
from datetime import timedelta
from django.db import IntegrityError, transaction

def create_screenavailability_stats_entry(brd,current_date,start_date_time,end_date_time):
    obj = ScreenAvailabilityStats()
    obj.board = brd
    obj.date = current_date
    baps = BookedAdPack.objects.filter(booked_screen__key=brd.key,
                                       date_booked_for = current_date,
                                       booking_state__name='SUCCESS') 
    auto_bs_count = 0
    normal_bs_count = 0
    for bap in baps:
        if bap.booking_type == 'auto_booking' or bap.booking_type == 'empty_booking':
            auto_bs_count = auto_bs_count + len(bap.slots_booked.all())
        else:
            normal_bs_count = normal_bs_count + len(bap.slots_booked.all()) 
    obj.production_planned_slots = auto_bs_count
    obj.normal_planned_slots = normal_bs_count
            
    dayparts =DayPart.objects.all()
    i=0
    for i in range(len(dayparts)):
        if i==0:
            start_time=dayparts[i].from_time
        if i==len(dayparts)-1:
            end_time=dayparts[i].to_time
                        
    normal_bph_count = 0
    auto_empty_bph_count = 0
    bphs = BoardPlayHistory.objects.filter(board__key=brd.key,
                                           content_from_time__gte=start_date_time,
                                           content_from_time__lte=end_date_time)
    production_cntnt = ContentQueue.objects.filter(content_queue_name = 'nearby_android_playlist')
    for bph in bphs:
        if bph.campaign.play_list.key == production_cntnt[0].key:
            auto_empty_bph_count = auto_empty_bph_count+1
        else:
            normal_bph_count = normal_bph_count +1
    obj.normal_played_slots = normal_bph_count
    obj.production_played_slots = auto_empty_bph_count
    dl = DeviceLastContact.objects.filter(board__key=brd.key,
                                          last_contact_time__gte=start_date_time,
                                          last_contact_time__lte=end_date_time)
    obj.device_play_last_contacts = len(dl)
    try:
        obj.availability = (normal_bph_count/normal_bs_count)*100
    except:
        obj.availability = 0
    if brd.show_spot is not None:
        obj.showspot = brd.show_spot
    obj.save()
    
def create_diags_entry(new_brd_obj,curr_brd_obj): 
    old_diags = ScreenDiagnostics.objects.filter(board = curr_brd_obj).order_by('-diagnostics_data_date')
    if old_diags is not None and len(old_diags)>0:
        diags = ScreenDiagnostics()
        diags.board = new_brd_obj
        diags.diagnostics_data_date = datetime.datetime.now()
        diags.number_of_resets_for_day = 0
        diags.wifi_num_failed_connections = 0
        diags.free_space = 0.0
        diags.wifi_average_speed = 0.0
        diags.schedule_lag_seconds = 0
        diags.average_memory_usage = 0
        diags.application_version = old_diags[0].application_version
        diags.data_usage = 0.0
        diags.device_settings = old_diags[0].device_settings
        diags.save()

class HandoverScreenPropertyAPIView(generics.ListCreateAPIView):
    def get_queryset(self):
        return Response('Get method is not implemented')
    
    def post(self,request, format=None):
        with transaction.atomic():
            parsed_data = request.data
            if 'current_screen' not in parsed_data:
                return Response("current_screen is needed!",status=HTTP_400_BAD_REQUEST)
            if 'new_screen' not in parsed_data:
                return Response("new_screen is needed!",status=HTTP_400_BAD_REQUEST)
            
            current_screen = parsed_data['current_screen']
            new_screen = parsed_data['new_screen']
            
            curr_brd_obj = Board.objects.filter(board_serial_number = current_screen)
            if len(curr_brd_obj) <=0 or curr_brd_obj is None:
                return Response("Current board not found!",status=HTTP_400_BAD_REQUEST)
            new_brd_obj = Board.objects.filter(board_serial_number = new_screen)
            if len(new_brd_obj) <=0 or new_brd_obj is None:
                return Response("New board not found!",status=HTTP_400_BAD_REQUEST)
            
            old_screen = curr_brd_obj[0]
            new_screen = new_brd_obj[0]
            
            if old_screen.show_spot is None:
                return Response("Current device must be having assigned to showspot!",status=HTTP_400_BAD_REQUEST)
            if new_screen.show_spot is not None:
                return Response("Please make sure that new screen is not assigned to any other showspot!",status=HTTP_400_BAD_REQUEST)
            
            current_date = datetime.datetime.now().date()
            #print current_date
            current_date_time = datetime.datetime.now()
            #print current_date_time
            
            curr_dayparts = []
            all_dayparts = DayPart.objects.all()
            i=0
            for i in range(len(all_dayparts)):
                to_time = all_dayparts[i].to_time
                to_date_time = datetime.datetime.combine(datetime.datetime.now().date(),to_time)
                from_time = all_dayparts[i].from_time
                from_date_time = datetime.datetime.combine(datetime.datetime.now().date(),from_time)
                if i==0:
                    start_time = from_date_time
                if  i== len(all_dayparts)-1:
                    end_time = from_date_time
                if current_date_time <= to_date_time:
                    curr_dayparts.append(all_dayparts[i])
            
            print start_time,end_time
            
            if current_date_time >= end_time:
                curr_dayparts = DayPart.objects.all()
                current_date = current_date+timedelta(days=1)
            elif current_date_time <= start_time:
                curr_dayparts = DayPart.objects.all()
                    
            bookedadpacks = BookedAdPack.objects.filter(booked_screen__board_serial_number = current_screen,
                                                        date_booked_for = current_date.strftime("%Y-%m-%d"),
                                                        day_part_booked_for__in = curr_dayparts)
            for bap in bookedadpacks:
                bap.booked_screen = new_screen
                bap.save()
                
            bookedadpacks = BookedAdPack.objects.filter(booked_screen__board_serial_number = current_screen,
                                                        date_booked_for__gt = current_date.strftime("%Y-%m-%d"))
            for bap in bookedadpacks:
                bap.booked_screen = new_screen
                bap.save()
            
            create_screenavailability_stats_entry(old_screen,
                                                  current_date_time.date(),
                                                  start_time,end_time)
                
            new_screen.show_spot = old_screen.show_spot
            new_screen.save()
            if len(new_screen.show_spot.attached_wificounters.all())>0:
                new_screen.show_spot.attached_wificounters = new_screen.attached_wificounters.all()
            if len(new_screen.show_spot.attached_beacons.all())>0:
                new_screen.show_spot.attached_beacons = new_screen.attached_beacons.all()
            new_screen.show_spot.save()
            new_screen.save()
            
            old_screen.show_spot = None
            old_screen.save()
            
            create_diags_entry(new_screen,old_screen) 
             
            return Response("SUCCESS!",status = HTTP_201_CREATED)