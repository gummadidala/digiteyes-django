from rest_framework import serializers
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from boardcontentmgmt.models import Account, DayPart, ConsumerSavedContentTargets,ContentTarget,AccountUser,AdvtCampaign
from boardcontentmgmt.contentmgmt.adcontentserializers import ContentTargetSerializer
from boardcontentmgmt.models import Content
from boardcontentmgmt.contentmgmt.adcontentserializers import ContentSubordinateTextShortSerializer

##################################################################################
#Serializer for ConsumerSavedContentTargets
#################################################################################
class ConsumerSavedContentTargetsSerializer(serializers.ModelSerializer):
    account = AccountSerializer()
    content_target = ContentTargetSerializer()
    campaign = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key')
    content = ContentSubordinateTextShortSerializer()
    class Meta:
        model = ConsumerSavedContentTargets
        fields = ['key','account','date_time','content_target','campaign','content']
        
#################################################################################
##Serializer for ConsumerSavedContentTargets
#################################################################################
class ConsumerSavedContentTargetsWriteSerializer(serializers.ModelSerializer):
    content_target = serializers.SlugRelatedField(
        queryset=ContentTarget.objects.all(),
        slug_field='key')
    campaign = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key',required=False)
    content = serializers.SlugRelatedField(
        queryset=Content.objects.all(),
        slug_field='key',required=False)
    class Meta:
        model= ConsumerSavedContentTargets
        fields = ['key','date_time','content_target','campaign','content']
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        if 'content' not in validated_data:
            validated_data['content'] = None
        if 'campaign' not in validated_data:
            validated_data['campaign'] = None
        return serializers.ModelSerializer.create(self, validated_data)
