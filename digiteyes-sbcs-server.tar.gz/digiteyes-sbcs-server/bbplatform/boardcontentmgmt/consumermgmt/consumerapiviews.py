from rest_framework import generics
from django.contrib.auth.models import Group
from rest_framework.views import APIView
from boardcontentmgmt.models import Consumer, ConsumerAttributes, ConsumerTracking, AccountUser
from boardcontentmgmt.models import Account, AccountType, ConsumerContentTargets,UserProfile
from .consumerserializers import ConsumerSerilizer, ConsumerWriteSerilizer
from .consumerserializers import ConsumerAttributesSerializer
from .consumerserializers import ConsumerTrackingSerializer

from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters
import facebook
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from django.db.models import Q
import django_filters
from django.contrib.auth.models import User
from dateutil.parser import parse, parserinfo
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST, HTTP_401_UNAUTHORIZED,HTTP_200_OK
from django.db import IntegrityError, transaction
from boardcontentmgmt.tasks import fill_consumer_content_targets_for_userevent
from .consumerserializers import ConsumerContentTargetSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.Create_UserProfiles_for_users import Create_Profile
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from oauth2client.client import AccessTokenCredentials
from apiclient.discovery import build
from httplib2 import Http
import httplib2
from oauth2client.client import flow_from_clientsecrets
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
import random
import string
from boardcontentmgmt.accountmgmt.accountapiviews import email_activateaccount
import hashlib
import sys, zipfile
import traceback
from bbplatform.settings import HOSTING_SERVER,Adiot_logo_url
from django.template.loader import get_template
from django.template import Context
from boardcontentmgmt.tasks import send_email,send_email_ses
from boardcontentmgmt.accountmgmt.resetpasswordapiview import send_alert
from boardcontentmgmt.contentmgmt.adcontentserializers import ConsumerContentTargetWriteSerializer
import logging
logger = logging.getLogger(__name__)
#################################################################################
# Consumer List API List View
#################################################################################
class ConsumerListAPIView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = ConsumerSerilizer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('facebook_id','google_id','primary_device_id')
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'consumer') == True):
            return Consumer.objects.all()
        else:
            return Consumer.objects.filter(account__key = acct.key)
        #return Consumer.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ConsumerWriteSerilizer
        return ConsumerSerilizer
#################################################################################
# Consumer Update API List View
#################################################################################
class ConsumerUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = ConsumerSerilizer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('facebook_id','google_id','primary_device_id')
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'consumer') == True):
            return Consumer.objects.all()
        else:
            return Consumer.objects.filter(account__key = acct.key)
        #return Consumer.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return ConsumerWriteSerilizer
        return ConsumerSerilizer
#################################################################################
# Consumer Attributes List API List View
#################################################################################
class ConsumerAttibutesListAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = ConsumerAttributesSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('attribute_name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'consumerattributes') == True):
            return ConsumerAttributes.objects.all()
        else:
            return ConsumerAttributes.objects.filter(account__key = acct.key)
        

class ConsumerAttributesUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = ConsumerAttributesSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('attribute_name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'consumerattributes') == True):
            return ConsumerAttributes.objects.all()
        else:
            return ConsumerAttributes.objects.filter(account__key = acct.key)
    
class ConsumerTrackingFilter(django_filters.FilterSet):
    start_time = django_filters.CharFilter(name='event_time_stamp', lookup_type="gte")
    end_time = django_filters.BooleanFilter(name='event_time_stamp',lookup_type="lte")
    class Meta:
        model = ConsumerTracking
        fields = ['start_time','end_time',]

#################################################################################
# Consumer Tracking List API List View
#################################################################################
class ConsumerTrackingListAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    #permission_classes = (IsAuthenticated)
    serializer_class = ConsumerTrackingSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_class = ConsumerTrackingFilter
    search_fields = ('attribute_name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'consumertracking') == True):
            return ConsumerTracking.objects.all()
        else:
            return ConsumerTracking.objects.filter(consumer_account__key = acct.key)
        #return ConsumerTracking.objects.all()
    def perform_create(self, serializer):
        logger.debug( "perform create ConsumerTracking")
        generics.ListCreateAPIView.perform_create(self, serializer)
        logger.debug( serializer.instance)
        fill_consumer_content_targets_for_userevent.delay(str(serializer.instance.key))
        

def create_user(username,firstname,lastname,email):
    usr = User()
    usr.username = username.lower()
    usr.first_name = firstname
    usr.last_name = lastname
    usr.email = email.lower()
    usr.save()
    return usr
def create_consumer_account(account_name):
    acct = Account()
    acct_types = AccountType.objects.filter(
        Q(type_name = 'CONSUMER') & 
        Q(type_of_customer = 'INDIVIDUAL'))
    acct.account_name = account_name
    acct.account_type = acct_types[0]
    acct.save()
    return acct
def create_user_and_give_token(fb_token):
    graph = facebook.GraphAPI(access_token=fb_token, version='2.5')
    res =graph.request('me?fields=id,name,first_name,last_name,email,gender,birthday,age_range')
    account = create_consumer_account(res['id'])
    if 'email' not in res:
        res['email'] = ''
    if 'first_name' not in res:
        res['first_name'] = ''
    if 'last_name' not in res:
        res['last_name'] = ''
    user = create_user(res['id'],res['first_name'],res['last_name'],res['email'])
    act_user = AccountUser()
    act_user.account_user = user
    act_user.account = account
    act_user.save()
    #assigning user profile
    Create_Profile().ConsumerProfile(account)
    act_user.user_profiles = UserProfile.objects.filter(profile_name='Consumer Profile', account = act_user.account)
    act_user.save()
    for each_profile in act_user.user_profiles.all():
        for each_group in each_profile.user_groups.all():
            act_user.account_user.groups.add(Group.objects.get(name=each_group))
            act_user.save()
        
    consumer = Consumer()
    consumer.facebook_id = res['id']
    if 'gender' in res:
        consumer.gender=res['gender']
    else :
        consumer.gender=res['Unknown']
    if 'birthday' in res:
        consumer.date_of_birth = parse(res['birthday'],parserinfo=parserinfo(dayfirst=False))
    else:
        consumer.date_of_birth = '1970-01-01'
    
    consumer.account = account
    consumer.save()
    tkn = Token.objects.get(user__username=user.username)
    return tkn.key

def create_user_give_token_google(google_token):
    credentials = AccessTokenCredentials(google_token,'my-user-agent/1.0')
    http_auth = credentials.authorize(httplib2.Http())
    service = build('plus', 'v1', http=http_auth)
    res = service.people().get(userId='me').execute()
    #res =graph.request('me?fields=id,name,first_name,last_name,email,gender,birthday,age_range')
    account = create_consumer_account(res['id'])
    user = create_user(res['id'],res['name']['givenName'],res['name']['familyName'],res['emails'][0]['value'])
    act_user = AccountUser()
    act_user.account_user = user
    act_user.account = account
    act_user.save()
    #assigning user profile
    Create_Profile().ConsumerProfile(account)
    act_user.user_profiles = UserProfile.objects.filter(profile_name='Consumer Profile', account = act_user.account)
    act_user.save()
    for each_profile in act_user.user_profiles.all():
        for each_group in each_profile.user_groups.all():
            act_user.account_user.groups.add(Group.objects.get(name=each_group))
            act_user.save()
        
    consumer = Consumer()
    consumer.google_id = res['id']
    if 'gender' in res:
        consumer.gender=res['gender']
    else :
        consumer.gender='Unknown'
    if 'birthday' in res:
        consumer.date_of_birth = parse(res['birthday'],parserinfo=parserinfo(dayfirst=False))
    else:
        consumer.date_of_birth = '1970-01-01'
    
    consumer.account = account
    consumer.save()
    tkn = Token.objects.get(user__username=user.username)
    return tkn.key

def check_or_create_consumer_record(fb_id,fb_token):
    consumers = Consumer.objects.filter(facebook_id=fb_id)
    if consumers and consumers is not None:
        acct = consumers[0].account
        accountUsers = AccountUser.objects.filter(account__key = acct.key)
        if accountUsers and accountUsers is not None:
            tkn = Token.objects.get(user__username= accountUsers[0].account_user.username)
            return tkn.key
    else :
        with transaction.atomic():
            return create_user_and_give_token(fb_token)

def check_or_create_google(google_id,google_token):
    consumers = Consumer.objects.filter(google_id=google_id)
    if consumers and consumers is not None:
        acct = consumers[0].account
        accountUsers = AccountUser.objects.filter(account__key = acct.key)
        if accountUsers and accountUsers is not None:
            tkn = Token.objects.get(user__username= accountUsers[0].account_user.username)
            return tkn.key
    else :
        with transaction.atomic():
            return create_user_give_token_google(google_token)
        
class ConsumerAuthenticateView(APIView):
    def post(self,request):
        google_id = self.request.query_params.get('google_id', None)
        fb_id = self.request.query_params.get('fb_id', None)
        fb_token = self.request.query_params.get('fb_token', None)
        google_token = self.request.query_params.get('google_token', None)
        username = self.request.query_params.get('username', None)
        password = self.request.query_params.get('password', None)
        
        authentication_type = request.data['auth_type']
        
        if authentication_type is not None :
            if authentication_type == 'FACEBOOK' :
                fb_token = request.data['fb_token']
                fb_id = request.data['fb_id']
                graph = facebook.GraphAPI(access_token=fb_token, version='2.5')
                try:
                    res = graph.request('/me?fields=id')
                    if res['id'] == fb_id :
                        userToken = check_or_create_consumer_record(fb_id,fb_token)
                        data = {'token':userToken}
                        return Response(data,status=HTTP_201_CREATED)
                    else :
                        return Response({"error":"ID not matching"},status=HTTP_401_UNAUTHORIZED)
                except:
                    return Response({"error":"Invalid token/id"},status=HTTP_401_UNAUTHORIZED)
                
            elif authentication_type == 'GOOGLE' :
                google_token = request.data['google_token']
                google_id = request.data['google_id']
                credentials = AccessTokenCredentials(google_token,'my-user-agent/1.0')
                http_auth = credentials.authorize(httplib2.Http())
                service = build('plus', 'v1', http=http_auth)
                res = service.people().get(userId='me').execute()
                if res['id'] == google_id :
                    userToken = check_or_create_google(google_id,google_token)
                    data = {'token':userToken}
                    return Response(data,status=HTTP_201_CREATED)
                else :
                    return Response({"error":"ID not matching"},status=HTTP_401_UNAUTHORIZED)

def filter_dups(qs,value):
    cts = qs.order_by('content_target__key').values('content_target__key').distinct()
    cts_list = list(cts)
    filtered_keys = []
    #print unicode(cts)
    for cct in qs:
        if {'content_target__key':cct.content_target.key} in cts_list:
            filtered_keys.append(cct.key)
            cts_list.remove({'content_target__key':cct.content_target.key})
    return qs.filter(key__in=filtered_keys)
class ConsumerTargetFilter(django_filters.FilterSet):
    start_time = django_filters.DateTimeFilter(name='time',lookup_type='gte')
    end_time = django_filters.DateTimeFilter(name='time',lookup_type='lte')
    location = django_filters.CharFilter(name="show_spot_beacon_touched")
    remove_dups = django_filters.MethodFilter(action=filter_dups)
    class Meta:
        model = ConsumerContentTargets
	fields = ('start_time','end_time','location','remove_dups',)
        

class ConsumerContentTargetsListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = ConsumerContentTargetSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_class = ConsumerTargetFilter
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'consumercontenttargets') == True):
            return ConsumerContentTargets.objects.all()
        else:
            return ConsumerContentTargets.objects.filter(account__key = acct.key).order_by('-time')
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ConsumerContentTargetWriteSerializer
        return ConsumerContentTargetSerializer
                
class ConsumerSignInAPIView(generics.ListAPIView):
    def post(self,request):
        with transaction.atomic():
            logger.info("CONSUMER_SIGNIN_START")
            username = request.data['username']
            user_email = request.data['user_email']
            account=create_consumer_account(username)
            password = request.data['password']
            try:
                _usr = User.objects.get(email = user_email)
                return Response("Email-address already exists!",status=HTTP_400_BAD_REQUEST)
            except:
                logger.info('Nothing to worry, test passed!')
            #password = ''.join(random.choice(string.ascii_lowercase + string.ascii_uppercase + string.digits) for i in range(15))
            try:
                usr=User.objects.create_user(username,user_email,password)
                usr.first_name = ''
                usr.last_name = ''
                usr.save()
                print 'user:',usr
                act_user = AccountUser()
                act_user.account_user = usr
                act_user.account = account
                act_user.account_user_phone_no = ''
                act_user.save()
                #assigning user profile
                Create_Profile().ConsumerProfile(account)
                act_user.user_profiles = UserProfile.objects.filter(profile_name='Consumer Profile', account = act_user.account)
                act_user.save()
                for each_profile in act_user.user_profiles.all():
                    for each_group in each_profile.user_groups.all():
                        act_user.account_user.groups.add(Group.objects.get(name=each_group))
                        act_user.save()
                #email_activateaccount(user_email)
                tkn = Token.objects.get(user__username=username)
                data = {'token':tkn.key}
                return Response(data,status=HTTP_201_CREATED)
            except:
                logger.error ("CONSUMER_SIGNIN_ERROR :"+str(sys.exc_info()[0]))
                tb = traceback.format_exc()
                logger.error ("CONSUMER_SIGNIN_ERROR "+str(tb))
                logger.info("CONSUMER_SIGNIN_END")
                return Response("Error while sign up!",status=HTTP_400_BAD_REQUEST)
            
class ConsumerVerifyEmailRequestAPIView(generics.ListAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    def get_queryset(self):
        return Response('Get method is not implemented')
    def post(self,request):
        logger.info("CONSUMER_EMAILVERIFY_REQUEST_START")
        user_email = request.data['user_email']
        try:
            usr = User.objects.filter(email = user_email)
            if len(usr) > 1:
                error = 'Duplicate entries are found, please try contacting admin to solve your problem.'
                return Response(error,status=HTTP_400_BAD_REQUEST)
            elif len(usr) <=0 :
                error = 'User not found or already verified.'
                return Response(error,status=HTTP_400_BAD_REQUEST)
            user_name = usr[0].first_name+" "+usr[0].last_name
            hash = hashlib.sha512(user_email.lower()+'All@thebest.,of_luck').hexdigest().lower()
            logger.info('Hash generated: '+str(hash))
            link = HOSTING_SERVER+'consumerverifyemail/?user_email='+user_email+'&hash='+hash
            logger.info("CONSUMER_EMAILVERIFY_REQUEST_STATS: USER_MAIL : "+str(user_email)+
                        "LINK : "+str(link))
            htmly  = get_template('consumer_verifyemail.html')
            d = Context({ 'link': link,'username':user_name,'logo_url':Adiot_logo_url})
            subject = 'Verify your email address!'
            html_content = htmly.render(d)
            #send_email.delay(user_email,subject,html_content,link,"")
            send_email_ses.delay(user_email,subject,html_content,link,"")
            logger.info('email verification mail sent successfully to: '+str(user_email))
            logger.info("CONSUMER_EMAILVERIFY_REQUEST_END")
            return Response('Email verification mail sent successfully!',status = HTTP_201_CREATED)
        except:
            logger.error ("CONSUMER_EMAILVERIFY_REQUEST_ERROR :"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("CONSUMER_EMAILVERIFY_REQUEST_END "+str(tb))
            logger.info("CONSUMER_EMAILVERIFY_REQUEST_END")
            return Response('Something went wrong!',status=HTTP_400_BAD_REQUEST)
class ConsumerVerifyEmailAPIView(generics.ListAPIView):
    def post(self,request):
        user_email = ''
        logger.info("CONSUMER_EMAILVERIFY_START")
        if 'user_email' in request.data and 'hash' in request.data:
            user_email = request.data['user_email']
            try:
                usr = User.objects.filter(email = user_email)
                if len(usr) > 1:
                    error = 'Duplicate entries are found, please try contacting admin to solve your problem.'
                    return Response(error,status=HTTP_400_BAD_REQUEST)
                elif len(usr) <=0 :
                    error = 'User not found or already verified.'
                    return Response(error,status=HTTP_400_BAD_REQUEST)
                hash = hashlib.sha512(user_email+'All@thebest.,of_luck').hexdigest().lower()
                logger.info('Re-calculated hash at server: '+str(hash))
                logger.info('Hash from client: '+str(request.data['hash']))
                if hash == request.data['hash']:
                    usr[0].is_active = True
                    usr[0].save()
                    acct_usr = AccountUser.objects.filter(account_user__username=usr[0].username)
                    if acct_usr is not None and len(acct_usr)>0:
                        acct_usr[0].is_activeuser = True
                        acct_usr[0].save()
                    _user_name = usr[0].first_name+" "+usr[0].last_name
                    subject = "Email-address verified successfully!"
                    text1 = 'Thank you for activating your account.'
                    text2 = ""
                    text3 = "for login."
                    link = "https://play.google.com/store/apps/details?id=com.Digiteyes91.adiot.tapp"
                    send_alert(_user_name,user_email,subject,link,text1,text2,text3)
                    logger.info('Email verification is done successfully for : '+str(user_email))
                    return Response('Email verification done successfully!',status = HTTP_201_CREATED)
                else:
                    logger.info('Invalid Hash for Email verification')
                    return Response('Some thing went wrong!',status=HTTP_400_BAD_REQUEST)
            except:
                logger.error ("CONSUMER_EMAILVERIFY_ERROR :"+str(sys.exc_info()[0]))
                tb = traceback.format_exc()
                logger.error ("CONSUMER_EMAILVERIFY_ERROR "+str(tb))
                logger.info("CONSUMER_EMAILVERIFY_END")
                return Response('Something went wrong!',status=HTTP_400_BAD_REQUEST)
        else:
            logger.info('fields user_email and hash are mandatory') 
            return Response('Fields user_email and hash are mandatory!',status=HTTP_400_BAD_REQUEST)

class ConsumerForgotPasswordAPIView(generics.ListAPIView):
    def post(self,request):
        user_email = request.data['user_email']
        try:
            usr = User.objects.filter(email = user_email)
            if len(usr) > 1:
                error = 'Duplicate entries are found, please try contacting admin to solve your problem.'
                return Response(error,status=HTTP_400_BAD_REQUEST)
            elif len(usr) <=0 :
                error = 'User with email address not found.'
                return Response(error,status=HTTP_400_BAD_REQUEST)
            hash = hashlib.sha512(user_email+'All@thebest.,of_luck').hexdigest().lower()
            logger.info('Hash generated: '+str(hash))
            #print 'Hash generated:',hash
            user_name = usr[0].first_name+" "+usr[0].last_name
            link = HOSTING_SERVER+'consumerresetpassword/?user_email='+user_email+'&hash='+hash
            htmly  = get_template('email_resetpassword.html')
            d = Context({ 'link': link,'username':user_name,'logo_url':Adiot_logo_url})
            subject = 'Reset password!'
            html_content = htmly.render(d)
            #send_email.delay(user_email,subject,html_content,link,"")
            send_email_ses.delay(user_email,subject,html_content,link,"")
            logger.info('reset password mail sent successfully to: '+str(user_email))
            return Response('reset password mail sent successfully',status = HTTP_200_OK)
        except:
            logger.error ("Error :"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("Stack Trace: "+str(tb))
            print "Stack Trace: ",str(tb)
            return Response('Something went wrong!',status=HTTP_400_BAD_REQUEST)
