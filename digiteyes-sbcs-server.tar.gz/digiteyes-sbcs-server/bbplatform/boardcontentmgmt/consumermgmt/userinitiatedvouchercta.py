from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework import filters
from rest_framework import serializers
from boardcontentmgmt.models import UserInitiatedVoucherCTA,AccountUser,Account,CTA,AdvtCampaign
from boardcontentmgmt.models import VoucherCTAState
from .consumersavedcontenttargetsserializers import ConsumerSavedContentTargetsWriteSerializer,ConsumerSavedContentTargetsSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from boardcontentmgmt.contentmgmt.adcontentserializers import CTASerializer
from boardcontentmgmt.utilities.qrcodegenerator import generate_and_upload_qrcode

class UserInitiatedVoucherCTASerilizer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key')
    interested_user = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key')
    initiated_cta = CTASerializer()
    assoc_campaign = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key')
    status = serializers.SlugRelatedField(
        queryset=VoucherCTAState.objects.all(),
        slug_field='name')
    class Meta:
        model = UserInitiatedVoucherCTA
        fields = ('account','key','interested_user','initiated_cta','assoc_campaign',
                  'cta_time','voucher_qr_code','claimed_time','claimed_amount','claimed_percentage',
                  'status')
class UserInitiatedVoucherCTAWriteSerilizer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    interested_user = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key',required=False)
    initiated_cta = serializers.SlugRelatedField(
        queryset=CTA.objects.all(),
        slug_field='key')
    assoc_campaign = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key',required=False)
    status = serializers.SlugRelatedField(
        queryset=VoucherCTAState.objects.all(),
        slug_field='name',required=False)
    class Meta:
        model = UserInitiatedVoucherCTA
        fields = ('account','key','interested_user','initiated_cta','assoc_campaign',
                  'cta_time','voucher_qr_code','claimed_time','claimed_amount','claimed_percentage',
                  'status')

class UserInitiatedVoucherCTAListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = UserInitiatedVoucherCTASerilizer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'userinitiatedvouchercta') == True):
            return UserInitiatedVoucherCTA.objects.all().order_by('-cta_time')
        else:
            return UserInitiatedVoucherCTA.objects.filter(account__key = acct.key).order_by('-cta_time')
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return UserInitiatedVoucherCTAWriteSerilizer
        return UserInitiatedVoucherCTASerilizer
    def post(self,request,format=None):
        parsed_data = request.data
        username = self.request.user.username
        acct_user = AccountUser.objects.filter(account_user__username=username)
        acct = acct_user[0].account
        parsed_data['account'] = acct.key
        existing_objs = UserInitiatedVoucherCTA.objects.filter(
                                                               initiated_cta__key = parsed_data['initiated_cta'],
                                                               interested_user__key = acct_user[0].key)
        if existing_objs is not None and len(existing_objs)>0:
            serializer = UserInitiatedVoucherCTAWriteSerilizer(existing_objs[0])
            return Response(serializer.data,status=HTTP_201_CREATED)
        parsed_data['interested_user'] = acct_user[0].key
        parsed_data['status']  = "UNCLAIMED"
        serializer = UserInitiatedVoucherCTAWriteSerilizer(data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            serializer.instance.voucher_qr_code = generate_and_upload_qrcode(str(serializer.instance.key),str(serializer.instance.account.account_name))
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)

class UserInitiatedVoucherCTAUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = UserInitiatedVoucherCTASerilizer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'userinitiatedvouchercta') == True):
            return UserInitiatedVoucherCTA.objects.all().order_by('-cta_time')
        else:
            return UserInitiatedVoucherCTA.objects.filter(account__key = acct.key).order_by('-cta_time')
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return UserInitiatedVoucherCTAWriteSerilizer
        return UserInitiatedVoucherCTASerilizer
        
