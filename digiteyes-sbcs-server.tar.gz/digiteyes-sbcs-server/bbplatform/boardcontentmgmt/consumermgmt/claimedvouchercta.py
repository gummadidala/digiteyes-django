from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework import filters
from rest_framework import serializers
from boardcontentmgmt.models import UserInitiatedVoucherCTA,AccountUser,Account,CTA,AdvtCampaign
from boardcontentmgmt.models import VoucherCTAState,ClaimedVoucherCTA
from .consumersavedcontenttargetsserializers import ConsumerSavedContentTargetsWriteSerializer,ConsumerSavedContentTargetsSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from boardcontentmgmt.consumermgmt.userinitiatedvouchercta import UserInitiatedVoucherCTASerilizer
from datetime import datetime
import random
import copy


class ClaimedVoucherCTASerilizer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key')
    initiated_vouchercta = UserInitiatedVoucherCTASerilizer()
    claim_for = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key')
    class Meta:
        model = ClaimedVoucherCTA
        fields = ('account','key','claimed_time','claimed_amount','claimed_percentage',
                  'claim_for','initiated_vouchercta')
class ClaimedVoucherCTAWriteSerilizer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key')
    initiated_vouchercta = serializers.SlugRelatedField(
        queryset=UserInitiatedVoucherCTA.objects.all(),
        slug_field='key')
    claim_for = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key')
    class Meta:
        model = ClaimedVoucherCTA
        fields = ('account','key','claimed_time','claimed_amount','claimed_percentage',
                  'claim_for','initiated_vouchercta')
    

class ClaimedVoucherCTAListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = ClaimedVoucherCTASerilizer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'claimedvouchercta') == True):
            return ClaimedVoucherCTA.objects.all().order_by('-claimed_time')
        else:
            return ClaimedVoucherCTA.objects.filter(account__key = acct.key).order_by('-claimed_time')
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ClaimedVoucherCTAWriteSerilizer
        return ClaimedVoucherCTASerilizer
    def post(self,request,format=None):
        parsed_data = copy.deepcopy(request.data)
        username = self.request.user.username
        acct_user = AccountUser.objects.filter(account_user__username=username)
        acct = acct_user[0].account
        parsed_data['account'] = acct.key
        user_init_vouchercta_obj = UserInitiatedVoucherCTA.objects.filter(key=parsed_data['initiated_vouchercta'])
        if user_init_vouchercta_obj is None or len(user_init_vouchercta_obj) == 0:
            error = {'error':'object does not exist!'}
            return Response(data=error,status=HTTP_400_BAD_REQUEST)
        vouchercta_obj = user_init_vouchercta_obj[0].initiated_cta.voucher
        if vouchercta_obj is None:
            error = {'error':'voucher does not exist!'}
            return Response(data=error,status=HTTP_400_BAD_REQUEST)
        existing_claimed_vouchers = ClaimedVoucherCTA.objects.filter(initiated_vouchercta__key=parsed_data['initiated_vouchercta']) 
        if existing_claimed_vouchers is not None and len(existing_claimed_vouchers)>0:
            error = {'error':'Invalid voucher or voucher already claimed!'}
            return Response(data=error,status=HTTP_400_BAD_REQUEST)
        if acct.account_type.type_name != 'ADVERTISER':
            error = {'error':'Invalid operation to perform by this account/user!'}
            return Response(data=error,status=HTTP_400_BAD_REQUEST)
        
        if vouchercta_obj.validity < datetime.now():
            error = {'error':'Invalid or expired voucher!'}
            return Response(data=error,status=HTTP_400_BAD_REQUEST)
        if vouchercta_obj.isSuprise:
            if vouchercta_obj.type.name == 'PERCENT':
                rand_percent = random.randint(vouchercta_obj.percentage_minimum,
                                              vouchercta_obj.percentage_maximum)
                user_init_vouchercta_obj[0].claimed_percentage = rand_percent
                parsed_data['claimed_percentage'] = rand_percent
                user_init_vouchercta_obj[0].save()
            elif vouchercta_obj.type.name == 'FLAT':
                rand_amount = random.randint(vouchercta_obj.flat_amount_minimum,
                                              vouchercta_obj.flat_amount_maximum)
                user_init_vouchercta_obj[0].claimed_amount = rand_percent
                parsed_data['claimed_amount'] = rand_amount
                user_init_vouchercta_obj[0].save()    
        else:
            if vouchercta_obj.type.name == 'PERCENT':
                user_init_vouchercta_obj[0].claimed_percentage = vouchercta_obj.percentage
                parsed_data['claimed_percentage'] = vouchercta_obj.percentage
                user_init_vouchercta_obj[0].save()
            elif vouchercta_obj.type.name == 'FLAT':
                user_init_vouchercta_obj[0].claimed_amount = vouchercta_obj.flat_amount
                parsed_data['claimed_amount'] = vouchercta_obj.flat_amount
                user_init_vouchercta_obj[0].save()
        user_init_vouchercta_obj[0].state = VoucherCTAState.objects.filter(name='CLAIMED')[0]
        user_init_vouchercta_obj[0].save()
	parsed_data['claim_for']=user_init_vouchercta_obj[0].assoc_campaign.key
        serializer = ClaimedVoucherCTAWriteSerilizer(data=parsed_data)
        if serializer.is_valid():
            serializer.save()
	    user_init_vouchercta_obj[0].save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)

class ClaimedVoucherCTAUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = ClaimedVoucherCTASerilizer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'claimedvouchercta') == True):
            return ClaimedVoucherCTA.objects.all().order_by('-claimed_time')
        else:
            return ClaimedVoucherCTA.objects.filter(account__key = acct.key).order_by('-claimed_time')
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return ClaimedVoucherCTAWriteSerilizer
        return ClaimedVoucherCTASerilizer
        
