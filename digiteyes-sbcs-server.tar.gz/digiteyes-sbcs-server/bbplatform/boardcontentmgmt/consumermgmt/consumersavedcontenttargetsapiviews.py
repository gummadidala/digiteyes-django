from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework import filters
from boardcontentmgmt.models import ConsumerSavedContentTargets,AccountUser
from .consumersavedcontenttargetsserializers import ConsumerSavedContentTargetsWriteSerializer,ConsumerSavedContentTargetsSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
#################################################################################
#ConsumerSavedContentTargets API List View - Supports Listing and Create
#################################################################################
class ConsumerSavedContentTargetsListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = ConsumerSavedContentTargetsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name','date_time')
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'consumersavedcontenttargets') == True):
            return ConsumerSavedContentTargets.objects.all().order_by('-date_time')
        else:
            return ConsumerSavedContentTargets.objects.filter(account__key = acct.key).order_by('-date_time')
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ConsumerSavedContentTargetsWriteSerializer
        return ConsumerSavedContentTargetsSerializer
#################################################################################
# Devicecontrol  API Detail View - Supports Update/Patch and Deletion
#################################################################################
class ConsumerSavedContentTargetsUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions)#,DjangoObjectPermissions)
    serializer_class  = ConsumerSavedContentTargetsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('board__board_name','command__name','request_state__name')
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'consumersavedcontenttargets') == True):
            return ConsumerSavedContentTargets.objects.all().order_by('-date_time')
        else:
            return ConsumerSavedContentTargets.objects.filter(account__key = acct.key).order_by('-date_time')
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return ConsumerSavedContentTargetsSerializer
        return ConsumerSavedContentTargetsWriteSerializer
    
    
    
    
    