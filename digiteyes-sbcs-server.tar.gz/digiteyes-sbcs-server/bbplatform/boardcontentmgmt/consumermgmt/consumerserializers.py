from rest_framework import serializers

from boardcontentmgmt.models import Consumer, ConsumerAttributes, ConsumerTracking, Account
from boardcontentmgmt.models import Beacon, AccountUser, ConsumerContentTargets
from django.contrib.auth.models import User
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from boardcontentmgmt.contentmgmt.adcontentserializers import ContentTargetSerializer, ContentShortSerializerForTaPP

#################################################################################
# Consumer Serializers
#################################################################################
class ConsumerSerilizer(serializers.ModelSerializer):
    account = AccountSerializer()
    class Meta:
        model = Consumer
        fields = ('account','facebook_id','google_id', 'age_range_min',
                  'age_range_max', 'date_of_birth','gender')
class ConsumerWriteSerilizer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    facebook_id = serializers.CharField(required=False)
    google_id = serializers.CharField(required=False)
    primary_device_id = serializers.CharField(required=False)
    age_range_min = serializers.IntegerField(required=False)
    age_range_max = serializers.IntegerField(required=False)
    date_of_birth = serializers.DateField(required=False)
    gender = serializers.CharField(required=False)
    username = serializers.CharField()
    email = serializers.CharField()
    password = serializers.CharField()
    phone_num = serializers.CharField()
    first_name = serializers.CharField(required=False)
    last_name = serializers.CharField(required=False)
    class Meta:
        model = Consumer
        fields = ('account','facebook_id','google_id', 'primary_device_id','age_range_min',
                  'age_range_max', 'date_of_birth','gender','username','email',
                  'password','phone_num','first_name','last_name','key')
   

#################################################################################
# Consumer Attributes Serializers
#################################################################################
class ConsumerAttributesSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    class Meta:
        model = ConsumerAttributes
        fields = ('account','attribute_name','attribute_value','key',)
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        return serializers.ModelSerializer.create(self, validated_data)
#################################################################################
# Consumer Tacking Serializers
#################################################################################
class ConsumerTrackingSerializer(serializers.ModelSerializer):
    event_location = serializers.SlugRelatedField(
        queryset=Beacon.objects.all(),
        slug_field='mac_address')
    consumer_account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    class Meta:
        model = ConsumerTracking
        fields = ('event_type','event_time_stamp','event_location','consumer_account','key',)
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['consumer_account'] = aUsr[0].account
        return serializers.ModelSerializer.create(self, validated_data)
class ConsumerContentTargetSerializer(serializers.ModelSerializer):
    content_target = ContentTargetSerializer()
    content = ContentShortSerializerForTaPP()
    account = AccountSerializer()
    class Meta:
        model = ConsumerContentTargets
        fields = ('key','show_spot_location_lat','show_spot_location_long','show_spot_location_key',
            'show_spot_beacon_touched','content_target','campaign','time','show_spot_location_image_url',
            'content','account')
