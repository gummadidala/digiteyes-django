from rest_framework import serializers
from boardcontentmgmt.models import BookedAdPack, BookingState, DayPart, Board,BookedDayPack,MyOrder,DayPack,MasterAdPack,ContentQueue
from boardcontentmgmt.models import Account, AdvtCampaign, AccountUser,MasterAdPackMappings,ScreenLocationTrafficStats,AttributeTagGroup
from .masteradpackserializers import DayPartSerializer
from boardcontentmgmt.screenmgmt.boardserializers import BoardBasicSerializer
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from .daypackserializers import DayPackShortSerializer
from boardcontentmgmt.campaignmgmt.campaignserializers import AdvtCampaignShortSerializer
from .bookedadpackserializers import BookedAdPackWriteSerializer
from boardcontentmgmt.utilities.freeslotutilities import get_board_num_free_slots_against_order,get_board_num_free_slots_against_entitlement
from datetime import datetime
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from applicabledaypackapiviews import get_screens_for_tags
from django.db import IntegrityError, transaction
from boardcontentmgmt.utilities.algo_utilities import get_available_day_parts
import logging
logger = logging.getLogger(__name__)

'''
def CreateBookedAdPack(mpack,validated_data):
    print 'in CreateBookedAdPack'
    required_slots = validated_data['units_per_play'] * mpack.num_plays
    campaign_obj = validated_data['applied_to']
    if(validated_data['against_order'] == True):
        free_slots = get_board_num_free_slots_against_order(validated_data['booked_screen'],
                            validated_data['date_booked_for'],
                            validated_data['day_part_booked_for'].from_time,
                            validated_data['day_part_booked_for'].to_time,
                            validated_data['day_part_booked_for'],campaign_obj.type.name)

        if(free_slots >= required_slots):
            validated_data['booking_state'] = BookingState.objects.all().filter(name ='INITIATED')[0]
    elif(validated_data['against_entitlement'] == True):
        free_slots = get_board_num_free_slots_against_entitlement(validated_data['booked_screen'],
                            validated_data['date_booked_for'],
                            validated_data['day_part_booked_for'],
                            validated_data['account'],campaign_obj.type.name)
        if(free_slots >= required_slots):
            validated_data['booking_state'] = BookingState.objects.all().filter(name ='SUCCESS')[0]
    else:
        #error = {'error':'Booking can happen through either purchased order or entitlement'}
        logger.error('Booking can happen through either purchased order or entitlement')
        return None
         
    if free_slots < required_slots :
        logger.error('Not enough Free slots available in the given Day Part ,Available : '+
        str(free_slots) +' Required : '+str(required_slots)+' In Day Part '+
        validated_data['day_part_booked_for'].name+ ' For Board: '+
        validated_data['booked_screen'].board_name)
        return None    
    bkdpck = BookedAdPack()
    bkdpck.booked_screen = validated_data['booked_screen']
    bkdpck.date_booked_for = validated_data['date_booked_for']
    bkdpck.account= validated_data['account']
    bkdpck.against_order=validated_data['against_order']
    bkdpck.against_entitlement=validated_data['against_order']
    bkdpck.booking_state=validated_data['booking_state']
    bkdpck.units_per_play=validated_data['units_per_play']
    bkdpck.when_booked=validated_data['when_booked']
    bkdpck.day_part_booked_for=validated_data['day_part_booked_for']
    bkdpck.num_plays =  validated_data['num_plays']
    bkdpck.price = validated_data['price']
    if 'applied_to' in validated_data:
        bkdpck.applied_to=validated_data['applied_to']
    if 'entitlement' in validated_data:
        bkdpck.entitlement=validated_data['entitlement']
    if 'play_list' in validated_data:
        bkdpck.playlist = validated_data['play_list']
    else:
        validated_data['play_list'] = None
    bkdpck.save()  
    return bkdpck
    
def get_details_of_daypack(day_pack):
    res_obj_array = []
    dpack = DayPack.objects.filter(name = day_pack)
    if dpack is not None and len(dpack) > 0:
        basepacks = dpack[0].base_pack.all()
        masteradpacks = []
        for bp in basepacks:      
            mp = MasterAdPack.objects.filter(key = bp.pack.key)
            if mp is not None and len(mp) > 0:
                masteradpacks.append({'mp':mp[0],'count':bp.count})
        for mpack in masteradpacks:
            obj={}
            obj['madpack'] = mpack['mp']
            obj['count'] = mpack['count']
            obj['day_part'] = []
            mapping = MasterAdPackMappings.objects.filter(maps_to_pack__key = mpack['mp'].key)
            if mapping is not None and len(mapping) > 0:
                for mapp in mapping:
                    day_parts = []
                    traffic = ScreenLocationTrafficStats.objects.filter(associated_traffic__key = mapp.traffic_pattern.key)
                    if traffic is not None and len(traffic) > 0:
                        for traff in traffic:
                            day_parts.append(traff.day_part)
                            #obj['day_part'] = traff.day_part
                            #obj['madpack'] = mpack['mp']
                            #obj['count'] = mpack['count']
                    obj['day_part'] = day_parts
            res_obj_array.append(obj)
    return res_obj_array
'''

class BookedDayPackSerializer(serializers.ModelSerializer):
    booked_screen_groups = serializers.SlugRelatedField(
        queryset=AttributeTagGroup.objects.all(),
        many=True,slug_field='key')
    account = AccountSerializer()
    applied_to = AdvtCampaignShortSerializer()
    booking_state = serializers.SlugRelatedField(
        queryset=BookingState.objects.all(),
        slug_field='name')
    booked_ad_pack = serializers.SlugRelatedField(
        queryset=BookedAdPack.objects.all(),
        many=True,slug_field='key')
    day_pack = DayPackShortSerializer()
    class Meta:
        model = BookedDayPack
        fields = ('booked_ad_pack','date_booked_for','booked_screen_groups', 'order_id',
                  'account','when_booked','against_order','against_entitlement','entitlement',
                  'applied_to','booking_state', 'key','num_plays','units_per_play','price',
                  'unit_size','booking_type','day_pack')
class BookedDayPackWriteSerializer(serializers.ModelSerializer):
    booked_screen_groups = serializers.SlugRelatedField(
        queryset=AttributeTagGroup.objects.all(),
        many = True,slug_field='key')
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key', required=False)
    applied_to = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key',required=False)
    booking_state = serializers.SlugRelatedField(
        queryset=BookingState.objects.all(),
        slug_field='name', required=False)
    when_booked = serializers.DateTimeField(default=datetime.now())
    order_id = serializers.CharField(default="")
    booked_ad_pack = serializers.SlugRelatedField(
        queryset=BookedAdPack.objects.all(),
        many=True,slug_field='key', required=False)
    day_pack = serializers.SlugRelatedField(
        queryset=DayPack.objects.all(),
        slug_field='key')
    play_list = serializers.SlugRelatedField(
        queryset=ContentQueue.objects.all(),
        slug_field='key',required=False,allow_null=True)
    class Meta:
        model = BookedDayPack
        fields = ('booked_ad_pack','date_booked_for','booked_screen_groups', 'order_id',
                  'account','when_booked','against_order','against_entitlement','entitlement',
                  'applied_to','booking_state', 'key','num_plays','units_per_play','price',
                  'unit_size','booking_type','day_pack','play_list')
    '''
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        validated_data['when_booked'] = datetime.now()
        validated_data['booking_state'] = BookingState.objects.filter(name ='INITIATED')[0]
        dpack = DayPack.objects.filter(name = validated_data['day_pack'].name)
        if dpack is not None and len(dpack) > 0:
            validated_data['num_plays'] = dpack[0].num_plays
            validated_data['units_per_play'] = dpack[0].units_per_play
            #validated_data['price'] = dpack[0].price
        else:
            error = {'error':'day_pack is not listed in the system'}    
            #return Response(error,status=HTTP_400_BAD_REQUEST)
        basepacks_in_daypack = get_details_of_daypack(validated_data['day_pack'].name,validated_data['date_booked_for'])   
        other_details = {#'booked_screen':validated_data['booked_screen'],
                            'date_booked_for':validated_data['date_booked_for'],
                             'account':aUsr[0].account,
                             'against_order':validated_data['against_order'],
                             'against_entitlement':validated_data['against_order'],
                             'booking_state':validated_data['booking_state'],
                             'units_per_play':validated_data['units_per_play'],
                             'when_booked':validated_data['when_booked'],
                        }
        bkdadpcksList = []
            
        if 'applied_to' in validated_data:
            other_details['applied_to']=validated_data['applied_to']
        if 'entitlement' in validated_data:
            other_details['entitlement']=validated_data['entitlement']
        if 'playlist' in validated_data:
            other_details['play_list']=validated_data['play_list']
        else:
            validated_data['play_list'] = None
        group_tags_list = validated_data['booked_screen_groups']
        boards = get_screens_for_tags(group_tags_list)
        for brd in boards:
            for bp_ref in basepacks_in_daypack:
                cnt = 0
                i = 0
                while cnt < int(bp_ref['count']):
                    other_details['day_part_booked_for'] = bp_ref['day_part'][i]
                    other_details['num_plays'] =bp_ref['madpack'].num_plays
                    other_details['price'] = bp_ref['madpack'].price
                    other_details['booked_screen'] = brd
                    bap = CreateBookedAdPack(bp_ref['madpack'],other_details)
                    if bap is not None:    
                        bkdadpcksList.append(bap)
                        cnt = cnt + 1
                    else:
                        if i <= len(bp_ref['day_part'])-2: 
                            i = i+1
                    
            
        validated_data['booked_ad_pack'] = bkdadpcksList
        return serializers.ModelSerializer.create(self, validated_data)
        '''
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 