'''
Created on 09-Aug-2017

@author: saba
'''
from rest_framework import serializers
from rest_framework import generics
from boardcontentmgmt.models import ARAdPack, PackState, Account, AccountUser
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework import filters
from rest_framework.permissions import IsAuthenticated
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions

class ARAdPackSerializer(serializers.ModelSerializer):
    pack_state=serializers.SlugRelatedField(
        queryset=PackState.objects.all(),
        slug_field='name')
    account = serializers.SlugRelatedField(
        queryset=PackState.objects.all(),
        slug_field='key')
    class Meta:
        model = ARAdPack
        fields = ['key','pack_name', 'pack_description','applicable_days',
            'pack_state','no_of_unique_scans','price_per_scan','no_of_unique_cta_actions',
            'price_per_cta_action','price','account']

class ARAdPackWriteSerializer(serializers.ModelSerializer): 
    pack_state=serializers.SlugRelatedField(
        queryset=PackState.objects.all(),
        slug_field='name',required=False)
    account = serializers.SlugRelatedField(
        queryset=PackState.objects.all(),
        slug_field='key', required=False)
    class Meta:
        model = ARAdPack
        fields = ['key','pack_name', 'pack_description','applicable_days',
            'pack_state','no_of_unique_scans','price_per_scan','no_of_unique_cta_actions',
            'price_per_cta_action','price','account']
    def create(self,validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        validated_data['pack_state']=PackState.objects.filter(name='CREATED')[0]
        return serializers.ModelSerializer.create(self,validated_data)
    
class ARAdPackListView(generics.ListCreateAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,)
    serializer_class = ARAdPackSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('pack_name','pack_description',)
    filter_fields = ('pack_state__name','applicable_days')
    lookup_field = 'key'
    def get_queryset(self):
        return ARAdPack.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ARAdPackWriteSerializer
        return ARAdPackSerializer
class ARAdPackUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = ARAdPackSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('pack_name','pack_description',)
    filter_fields = ('applicable_days',)
    lookup_field = 'key'
    def get_queryset(self):
        return ARAdPack.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return ARAdPackWriteSerializer
        return ARAdPackSerializer
