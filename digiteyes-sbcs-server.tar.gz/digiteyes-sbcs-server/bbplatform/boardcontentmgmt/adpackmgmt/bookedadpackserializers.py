from rest_framework import serializers
from boardcontentmgmt.models import BookedAdPack, BookingState, DayPart, Board
from boardcontentmgmt.models import Account, AdvtCampaign, AccountUser,ContentQueue
from .masteradpackserializers import DayPartSerializer
from boardcontentmgmt.screenmgmt.boardserializers import BoardBasicSerializer
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from boardcontentmgmt.campaignmgmt.campaignserializers import AdvtCampaignShortSerializer
from boardcontentmgmt.utilities.freeslotutilities import get_board_num_free_slots_against_order,get_board_num_free_slots_against_entitlement
from datetime import datetime
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import sys,traceback
import logging
from django.db import IntegrityError, transaction
logger = logging.getLogger(__name__)

class BookedAdPackSerializer(serializers.ModelSerializer):
    day_part_booked_for = DayPartSerializer()
    booked_screen = BoardBasicSerializer()
    #reference_master_pack = MasterAdPackShortSerializer()
    account = AccountSerializer()
    applied_to = AdvtCampaignShortSerializer()
    booking_state = serializers.SlugRelatedField(
        queryset=BookingState.objects.all(),
        slug_field='name')
    class Meta:
        model = BookedAdPack
        fields = ('date_booked_for','day_part_booked_for','booked_screen', 'order_id',
                  'account','when_booked','against_order','against_entitlement_association',
                  'against_entitlement_association','entitlement',
                  'applied_to','booking_state', 'key','num_plays','units_per_play','price')
class BookedAdPackWriteSerializer(serializers.ModelSerializer):
    day_part_booked_for = serializers.SlugRelatedField(
        queryset=DayPart.objects.all(),
        slug_field='name')
    booked_screen = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='key')
    #reference_master_pack = serializers.SlugRelatedField(
        #queryset=MasterAdPack.objects.all(),
        #slug_field='key')
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key', required=False)
    applied_to = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key')
    booking_state = serializers.SlugRelatedField(
        queryset=BookingState.objects.all(),
        slug_field='name', required=False)
    when_booked = serializers.DateTimeField(default=datetime.now())
    order_id = serializers.CharField(default="")
    play_list = serializers.SlugRelatedField(
        queryset=ContentQueue.objects.all(),
        slug_field='key',required=False,allow_null=True)
    
    class Meta:
        model = BookedAdPack
        fields = ('date_booked_for','day_part_booked_for','booked_screen', 'order_id',
                  'account','when_booked','against_order','against_entitlement_association',
                  'against_entitlement_association','entitlement',
                  'applied_to','booking_state', 'key','num_plays','units_per_play','price','play_list')
    def create(self, validated_data):
        try:
            usr = self.context['request'].user
            aUsr = AccountUser.objects.filter(account_user__username = usr.username)
            validated_data['account'] = aUsr[0].account
            if 'play_list' not in validated_data:
                validated_data['play_list'] = None
            required_slots = validated_data['units_per_play'] * validated_data['num_plays']
            campaign_obj = validated_data['applied_to']
            if(validated_data['against_order'] == True):
                free_slots = get_board_num_free_slots_against_order(validated_data['booked_screen'],
                            validated_data['date_booked_for'],
                            validated_data['day_part_booked_for'].from_time,
                            validated_data['day_part_booked_for'].to_time,
                            validated_data['day_part_booked_for'],campaign_obj.type.name)
                if(free_slots >= required_slots):
                    validated_data['booking_state'] = BookingState.objects.all().filter(name ='INITIATED')[0]
            elif(validated_data['against_entitlement_association'] == True):
                validated_data['booking_type'] = 'association_booking'
                free_slots = get_board_num_free_slots_against_entitlement(validated_data['booked_screen'],
                            validated_data['date_booked_for'],
                            validated_data['day_part_booked_for'],
                            validated_data['account'],campaign_obj.type.name)
                if(free_slots >= required_slots):
                    validated_data['booking_state'] = BookingState.objects.all().filter(name ='SUCCESS')[0]
            else:
                error = {'error':'Booking can happen through either purchased order or entitlement'}
                return Response(error,status=HTTP_400_BAD_REQUEST)
                #required_slots = validated_data['units_per_play'] * validated_data['num_plays']
                 
            if free_slots < required_slots :
                errormsg = 'Not enough Free slots available in the given Day Part','Available : '
                +str(free_slots)+ ' Required : '+str(required_slots)+' In Day Part '
                +  validated_data['day_part_booked_for'].name+ ' For Board: '
                + validated_data['booked_screen'].board_name
                return Response(errormsg,status=HTTP_400_BAD_REQUEST)
            logger.info("BOOKED_ADPACK_CREATED")
            return serializers.ModelSerializer.create(self, validated_data)
        except:
            logger.error ("BOOKED_ADPACK_CREATION_ERROR "+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("BOOKED_ADPACK_CREATION_ERROR "+str(tb))
            return None