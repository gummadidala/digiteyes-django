
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated


from rest_framework.response import Response
from boardcontentmgmt.screenmgmt.boardserializers import BoardBasicSerializer
from boardcontentmgmt.utilities.freeslotutilities import get_screens_for_tags, get_master_pack

from rest_framework.views import APIView
import datetime
from dateutil.parser import parse
from boardcontentmgmt.models import AttributeTagGroup,DayPart
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication

import logging
logger = logging.getLogger(__name__)


class ApplicableMasterAdPackListView(APIView):
    #authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated, )  
    permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)  
    #serializer_class = MasterAdPackSerializer
    def post(self,request):
        from_date = request.data['from_date']
        #to_date = request.data['to_date']
        spot_tags = request.data['location_tags']
        group_tags = request.data['group_tags']
        num_plays_per_day = request.data['num_plays']
        units_per_play = request.data['units']
        day_part = request.data['day_part']
        #spot_tag_selection = self.request.query_params.get('selection','and')
        dayPart = DayPart.objects.filter(name = day_part)
        
        start_time = dayPart[0].from_time
        end_time = dayPart[0].to_time
        group_tags_list = AttributeTagGroup.objects.filter(name=group_tags)
        logger.debug( group_tags_list)
        boards = get_screens_for_tags(spot_tags,group_tags_list)
        board_packs = []
        for board in boards:
            master_packs = get_master_pack(board,parse(from_date).date(),start_time,
                end_time,int(num_plays_per_day),int(units_per_play),dayPart[0])
            board_packs.append(
                {"board": BoardBasicSerializer(board).data,
                 "pack_availability":master_packs})
        return Response(board_packs)
