
from rest_framework import generics
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters

from boardcontentmgmt.models import DayPack,MasterAdPackReference,MasterAdPack,MasterAdPackMappings,ScreenLocationTrafficStats
from django.contrib.admin.utils import lookup_field
from .daypackserializers import DayPackSerializer, DayPackWriteSerializer,MasterAdPackReferenceSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from rest_framework.response import Response

import django_filters
from rest_framework.pagination import PageNumberPagination
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
#################################################################################
# DayPack API List View - Supports Listing and Creation
#################################################################################
class DayPackListView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    #permission_classes = (IsAuthenticated, PermissionCheck)
    serializer_class = DayPackSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name',)
    filter_fields = ('state__name','num_plays','units_per_play', 'price',)
    lookup_field = 'key'
    queryset = DayPack.objects.all()
    def post(self,request,format=None,**kwargs):
        validated_data = request.data
        basepacks = validated_data['base_pack']
        for bp in basepacks:
            madpack = MasterAdPack.objects.filter(key = bp['pack'])
            if madpack is not None and len(madpack) > 0:
                if madpack[0].units_per_play != int(validated_data['units_per_play']):
                    error = {'error':'Units_per_play of referencing masterad pack should match with Units_per_play of creating DayPack'}
                    return Response(error,status = HTTP_400_BAD_REQUEST)
        validated_data['num_plays'] = 0
        kwargs['context'] = self.get_serializer_context()
        serializer = DayPackWriteSerializer(data=validated_data,**kwargs)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)
              
#################################################################################
# DayPack Update View - Supports Update/Patch and Deletion
#################################################################################
class DayPackUpdateView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    #permission_classes = (IsAuthenticated, PermissionCheck)
    serializer_class = DayPackSerializer
    search_fields = ('name',)
    filter_fields = ('state__name','num_plays','units_per_play', 'price',)
    lookup_field = 'key'
    queryset = DayPack.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return DayPackWriteSerializer
        return DayPackSerializer 

    def patch(self,request,format=None,*args,**kwargs):
        validated_data = request.data
        basepacks = validated_data['base_pack']
        for bp in basepacks:
            madpack = MasterAdPack.objects.filter(key = bp['pack'])
            if madpack is not None and len(madpack) > 0:
                if madpack[0].units_per_play != validated_data['units_per_play']:
                    error = {'error':'Units_per_play of referencing masterad pack should match with Units_per_play of creating DayPack'}
                    return Response(error,status = HTTP_400_BAD_REQUEST)
        return generics.RetrieveUpdateDestroyAPIView.patch(self,request,*args,**kwargs)
    
    def put(self,request,format=None,**kwargs):
        validated_data = request.data
        basepacks = validated_data['base_pack']
        for bp in basepacks:
            madpack = MasterAdPack.objects.filter(key = bp['pack'])
            if madpack is not None and len(madpack) > 0:
                if madpack[0].units_per_play != validated_data['units_per_play']:
                    error = {'error':'Units_per_play of referencing masterad pack should match with Units_per_play of creating DayPack'}
                    return Response(error,status = HTTP_400_BAD_REQUEST)
        kwargs['context'] = self.get_serializer_context()
        serializer = DayPackWriteSerializer(data=validated_data,**kwargs)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)   
    
class DaypartsOfDaypackListView(generics.ListCreateAPIView):
     #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    #permission_classes = (IsAuthenticated, PermissionCheck)
    serializer_class = DayPackSerializer
    queryset = DayPack.objects.all()
    
    def post(self,request,format=None):
        day_pack = request.data['day_pack']
        if 'day_pack' not in request.data:
            error = {'error':'Please send the daypack'}
            return Response(error,status = HTTP_400_BAD_REQUEST)
        res_obj_array = []
        dpack = DayPack.objects.filter(name = day_pack)
        if dpack is not None and len(dpack) > 0:
            basepacks = dpack[0].base_pack.all()
            masteradpacks = []
            for bp in basepacks:
                mp = MasterAdPack.objects.filter(key = bp.pack.key)
                if mp is not None and len(mp) > 0:
                    masteradpacks.append({'mp':mp[0],'count':bp.count})
            for mpack in masteradpacks:
                obj={}
                mapping = MasterAdPackMappings.objects.filter(maps_to_pack__key = mpack['mp'].key)
                if mapping is not None and len(mapping) > 0:
                    traffic = ScreenLocationTrafficStats.objects.filter(associated_traffic__key = mapping[0].traffic_pattern.key)
                    if traffic is not None and len(traffic) > 0:
                        obj['day_part'] = traffic[0].day_part.name
                        obj['num_plays'] = mpack['mp'].num_plays
                        obj['master_ad_pack'] = mpack['mp'].name
                        obj['count'] = mpack['count']
                        res_obj_array.append(obj)
        else:
            error = {'error':'Given Day Pack is not matching with any daypack in system'}
            return Response(error,status = HTTP_400_BAD_REQUEST)
        return Response (res_obj_array,status=HTTP_201_CREATED)
