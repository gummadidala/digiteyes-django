from rest_framework import serializers
from boardcontentmgmt.models import DayPack,PackState,MasterAdPack,MasterAdPackReference,AccountUser    
from django.utils import timezone
from boardcontentmgmt.accountmgmt.accountuserserializers import AccountUserShortSerializer
from .masteradpackserializers import MasterAdPackShortSerializer
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
################################################################################
# MasterAdPackReferencePackSerializer
#################################################################################
class MasterAdPackReferenceSerializer(serializers.ModelSerializer):
    pack = MasterAdPackShortSerializer()
    class Meta:
        model = MasterAdPackReference
        fields = ['key','pack','count']
#################################################################################
#  DayPackWriteSerializer
#################################################################################
class MasterAdPackReferenceWriteSerializer(serializers.ModelSerializer):
    pack = serializers.SlugRelatedField(
        queryset=MasterAdPack.objects.all(),
        slug_field='key')
    class Meta:
        model = MasterAdPackReference
        fields = ['key','pack','count']
#################################################################################
# DayPackSerializer
#################################################################################
class DayPackSerializer(serializers.ModelSerializer):
    state = serializers.SlugRelatedField(
        queryset=PackState.objects.all(),
        slug_field='name')
    created_by = AccountUserShortSerializer()
    last_updated_by = AccountUserShortSerializer()
    base_pack = MasterAdPackReferenceSerializer(many = True)
    class Meta:
        model = DayPack
        fields = ['name','num_plays', 'units_per_play', 'price','created_by',
            'created_date','last_updated_by','last_updated','state','key','base_pack']
#################################################################################
#  DayPackWriteSerializer
#################################################################################
class DayPackWriteSerializer(serializers.ModelSerializer):
    state = serializers.SlugRelatedField(
        queryset=PackState.objects.all(),
        slug_field='name')
    created_by = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key', required=False)
    created_date = serializers.DateTimeField(default=timezone.now())
    last_updated = serializers.DateTimeField(default=timezone.now())
    last_updated_by = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key', required=False)
    base_pack = MasterAdPackReferenceWriteSerializer(many=True)
    class Meta:
        model = DayPack
        fields = ['name','num_plays', 'units_per_play', 'price','created_by',
            'created_date','last_updated','last_updated_by','state','key','base_pack']
    def create(self,validated_data):
        day_pack = DayPack()
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        day_pack.created_by = aUsr[0]
        day_pack.last_updated_by = aUsr[0]
        day_pack.name = validated_data['name']
        day_pack.units_per_play = validated_data['units_per_play']
        day_pack.price = validated_data['price']
        day_pack.state = validated_data['state']
        day_pack.created_date = timezone.now()
        day_pack.last_updated = timezone.now()
        madpacks = validated_data['base_pack']
        packList = []
        for p in madpacks:
            refpack = MasterAdPackReferenceWriteSerializer().create(p)
            refpack.save()
            packList.append(refpack)
        total_plays = 0
        for pck in packList:
            mP = MasterAdPack.objects.filter(key = pck.pack.key)
            if len(mP) <= 0 and mP is not None:
                error = {'error':'no masteradpack is found with the given pack key'}
                return Response(error,status=HTTP_400_BAD_REQUEST)
            total_plays += pck.count*mP[0].num_plays
        day_pack.num_plays = total_plays
        day_pack.save()
        day_pack.base_pack = packList
        day_pack.save()
        return day_pack
    def update(self, instance, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        instance.name = validated_data['name']
        instance.state = validated_data['state']
        instance.price = validated_data['price']
        instance.units_per_play = validated_data['units_per_play']
        instance.last_updated_by = aUsr[0]
        instance.last_updated = timezone.now()
        madpacks = validated_data['base_pack']
        packList = []
        for p in madpacks:
            refpack = MasterAdPackReferenceWriteSerializer().create(p)
            refpack.save()
            packList.append(refpack)
        instance.base_pack = packList
        total_plays = 0
        for pck in packList:
            mP = MasterAdPack.objects.filter(key = pck.pack.key)
            if len(mP) <= 0 and mP is not None:
                error = {'error':'no masteradpack is found with the given pack key'}
                return Response(error,status=HTTP_400_BAD_REQUEST)
            total_plays += int(pck.count)*int(mP[0].num_plays)
        instance.num_plays = total_plays
        instance.save()
        return instance
class DayPackShortSerializer(serializers.ModelSerializer):
    state = serializers.SlugRelatedField(
        queryset=PackState.objects.all(),
        slug_field='name')
    class Meta:
        model = DayPack
        fields = ['name','num_plays', 'units_per_play', 'price',
                  'state','key']