from rest_framework import generics
from boardcontentmgmt.models import BookedDayPack, AccountUser, BookingState,ContentQueue,\
    DayPack,MasterAdPack,MasterAdPackMappings,ScreenLocationTrafficStats,AttributeTagGroup ,\
    AdvtCampaign,BookedAdPack
from .bookeddaypackserializers import BookedDayPackSerializer, BookedDayPackWriteSerializer
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated, DjangoModelPermissions
from rest_framework import filters
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from rest_framework.response import Response
from datetime import datetime
from boardcontentmgmt.utilities.freeslotutilities import get_board_num_free_slots_against_order,get_board_num_free_slots_against_entitlement
from applicabledaypackapiviews import get_screens_for_tags
from boardcontentmgmt.utilities.algo_utilities import get_available_day_parts
import logging
logger = logging.getLogger(__name__)

def CreateBookedAdPack(mpack,validated_data):
    required_slots = validated_data['units_per_play'] * mpack.num_plays
    campaign_obj = AdvtCampaign.objects.filter(key=validated_data['applied_to'])[0]
    if(validated_data['against_order'] == "True"):
        free_slots = get_board_num_free_slots_against_order(validated_data['booked_screen'],
                            validated_data['date_booked_for'],
                            validated_data['day_part_booked_for'].from_time,
                            validated_data['day_part_booked_for'].to_time,
                            validated_data['day_part_booked_for'],campaign_obj.type.name)

        if(free_slots >= required_slots):
            validated_data['booking_state'] = 'INITIATED'
    elif(validated_data['against_entitlement'] == "True"):
        free_slots = get_board_num_free_slots_against_entitlement(validated_data['booked_screen'],
                            validated_data['date_booked_for'],
                            validated_data['day_part_booked_for'],
                            validated_data['account'],campaign_obj.type.name)
        if(free_slots >= required_slots):
            validated_data['booking_state'] = 'SUCCESS'
    else:
        #error = {'error':'Booking can happen through either purchased order or entitlement'}
        logger.error('Booking can happen through either purchased order or entitlement')
        return None
         
    if free_slots < required_slots :
        logger.error('Not enough Free slots available in the given Day Part ,Available : '+
        str(free_slots) +' Required : '+str(required_slots)+' In Day Part '+
        validated_data['day_part_booked_for'].name+ ' For Board: '+
        validated_data['booked_screen'].board_name)
        return None    
    bkdpck = BookedAdPack()
    bkdpck.booked_screen = validated_data['booked_screen']
    bkdpck.date_booked_for = validated_data['date_booked_for']
    bkdpck.account= validated_data['account']
    bkdpck.against_order=validated_data['against_order']
    bkdpck.against_entitlement=validated_data['against_order']
    bkdpck.booking_state=BookingState.objects.filter(name =validated_data['booking_state'])[0]
    bkdpck.units_per_play=validated_data['units_per_play']
    bkdpck.when_booked=datetime.now()
    bkdpck.day_part_booked_for=validated_data['day_part_booked_for']
    bkdpck.num_plays =  validated_data['num_plays']
    bkdpck.price = validated_data['price']
    if 'applied_to' in validated_data:
        bkdpck.applied_to=AdvtCampaign.objects.filter(key=validated_data['applied_to'])[0]
    if 'entitlement' in validated_data:
        bkdpck.entitlement=validated_data['entitlement']
    if 'play_list' in validated_data and validated_data['play_list'] is not None:
        bkdpck.play_list = ContentQueue.objects.filter(key=validated_data['play_list'])[0]
    else:
        bkdpck.play_list = None
    bkdpck.save()
    logger.info('BookedAdPack created for : plays : '+ str(validated_data['num_plays'])+
        ' Day Part : '+ validated_data['day_part_booked_for'].name+ ' For Board: '+
        validated_data['booked_screen'].board_name+' Date : ' + str(validated_data['date_booked_for']))  
        
    return bkdpck.key


def get_details_of_daypack(day_pack):
    logger.info("In get_details_of_daypack")
    res_obj_array = []
    dpack = DayPack.objects.filter(key = day_pack)
    if dpack is not None and len(dpack) > 0:
        basepacks = dpack[0].base_pack.all()
        masteradpacks = []
        for bp in basepacks:      
            mp = MasterAdPack.objects.filter(key = bp.pack.key)
            if mp is not None and len(mp) > 0:
                masteradpacks.append({'mp':mp[0],'count':bp.count})
        for mpack in masteradpacks:
            logger.info( mpack['mp'].name)
            obj={}
            obj['madpack'] = mpack['mp']
            obj['count'] = mpack['count']
            obj['day_part'] = []
            mapping = MasterAdPackMappings.objects.filter(maps_to_pack__key = mpack['mp'].key)
            if mapping is not None and len(mapping) > 0:
                for mapp in mapping:
                    day_parts = []
                    traffic = ScreenLocationTrafficStats.objects.filter(associated_traffic__key = mapp.traffic_pattern.key)
                    if traffic is not None and len(traffic) > 0:
                        for traff in traffic:
                            if traff.day_part not in day_parts:
                                logger.info("traff.day_part... : "+str(traff.day_part.name))
                                day_parts.append(traff.day_part)
                            #obj['day_part'] = traff.day_part
                            #obj['madpack'] = mpack['mp']
                            #obj['count'] = mpack['count']
                    obj['day_part'] = day_parts
            res_obj_array.append(obj)
    return res_obj_array

#################################################################################
# BookedDayPack List API List View
#################################################################################
class BookedDayPackListAPIView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = BookedDayPackSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'bookeddaypack') == True):
            return BookedDayPack.objects.all()
        else:
            return BookedDayPack.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return BookedDayPackWriteSerializer
        return BookedDayPackSerializer
    
    def create(self, request, *args, **kwargs):
        username = self.request.user.username
        accnt_user = AccountUser.objects.filter(account_user__username=username)
        acct = accnt_user[0].account
        validated_data  = request.data
        print 'from_client : ',validated_data
        validated_data['account'] = acct.key
        validated_data['booking_state'] = 'INITIATED'
        dpack = DayPack.objects.filter(key = validated_data['day_pack'])
        if dpack is not None and len(dpack) > 0:
            validated_data['num_plays'] = dpack[0].num_plays
            validated_data['units_per_play'] = dpack[0].units_per_play
        else:
            error = {'error':'day_pack is not listed in the system'}
            return Response(error,HTTP_400_BAD_REQUEST)
        basepacks_in_daypack = get_details_of_daypack(validated_data['day_pack'])
        logger.info('basepacks_in_daypack : '+str(basepacks_in_daypack))
        other_details = {'date_booked_for':datetime.strptime(validated_data['date_booked_for'],"%Y-%m-%d").date(),
                         'account':acct,
                         'against_order':validated_data['against_order'],
                         'against_entitlement':validated_data['against_order'],
                         'booking_state':validated_data['booking_state'],
                         'units_per_play':validated_data['units_per_play'],
                        }
        if 'applied_to' in validated_data:
            other_details['applied_to']=validated_data['applied_to']
        if 'entitlement' in validated_data:
            other_details['entitlement']=validated_data['entitlement']
        if 'play_list' in validated_data:
            other_details['play_list']=validated_data['play_list']
        else:
            validated_data['play_list'] = None
        bkdadpcksList = []
        group_tags_list = AttributeTagGroup.objects.filter(key__in = validated_data['booked_screen_groups'])
        boards = get_screens_for_tags(group_tags_list)
        logger.info("length of boards : "+str(len(boards)) )
        total_pack_count_check = 0
        
        availble_dayparts = get_available_day_parts(other_details['date_booked_for'])
        logger.info("length of available dayparts : "+str(len(availble_dayparts)))
        for brd in  boards:
            logger.info('booking board :'+str(brd.board_name))
            for bp_ref in basepacks_in_daypack:
                logger.info('booking_pack : '+str(bp_ref['madpack'].name))
                for dp in bp_ref['day_part']:
                    logger.info('logging_dp : '+str(dp.name))
                total_pack_count_check = total_pack_count_check + int(bp_ref['count'])
                cnt = 0
                i = 0 
                while cnt < int(bp_ref['count']):
                    logger.info("Count : "+str(cnt)+" i : "+str(i))
                    if  bp_ref['day_part'][i] in availble_dayparts:
                        logger.info("bp_ref['day_part'][i] : "+str(bp_ref['day_part'][i].name))
                        other_details['day_part_booked_for'] = bp_ref['day_part'][i]
                        other_details['num_plays'] =bp_ref['madpack'].num_plays
                        other_details['price'] = bp_ref['madpack'].price
                        other_details['booked_screen'] = brd
                        bap = CreateBookedAdPack(bp_ref['madpack'],other_details)
                        if bap is not None:    
                            bkdadpcksList.append(bap)
                            cnt = cnt + 1
                        else:
                            if i <= len(bp_ref['day_part'])-2: 
                                i = i+1
                            else:
                                break
                    else:
                        logger.info("non-available-daypart : "+str(bp_ref['day_part'][i].name))
                        if i <= len(bp_ref['day_part'])-2: 
                            i = i+1
                        else:
                            break
        validated_data['booked_ad_pack'] = bkdadpcksList
        
        logger.info("length of bkdadpcksList : "+str(len(bkdadpcksList))+" total_pack_count_check : "+str(total_pack_count_check))
        if len(bkdadpcksList) < total_pack_count_check:
            for bp in bkdadpcksList:
                obj = BookedAdPack.objects.filter(key=bp)
                if obj is not None and len(obj) > 0:
                    obj[0].booking_state = BookingState.objects.filter(name='FAILED')[0]
            error = {'error':'Error while creating BookedDayPack'}
            return Response(error,HTTP_400_BAD_REQUEST)
        
        return generics.ListCreateAPIView.create(self, request, *args, **kwargs)
    
class BookedDayPackUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'bookeddaypack') == True):
            return BookedDayPack.objects.all()
        else:
            return BookedDayPack.objects.filter(account__key = acct.key)
    def post(self,request):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        block = BookingState.objects.filter(name='BLOCKED')[0]
        success = BookingState.objects.filter(name='SUCCESS')[0]
        cancel = BookingState.objects.filter(name='CANCELLED')[0]
        parsed_data = request.data
        res_obj_array = {}
        if parsed_data['booking_state'] == success.name:
            bkddaypck = BookedDayPack.objects.filter(applied_to__key = parsed_data['campaign'],account__key=acct.key)
            if bkddaypck is not None and len(bkddaypck) >0:
                for each_pack in bkddaypck:
                    if each_pack.applied_to.play_list is None and 'play_list' not in parsed_data:
                        error = {'error':'Can not update with out play list'}
                        return Response(error,status = HTTP_400_BAD_REQUEST)
                    if each_pack.booking_state == cancel:
                        error = {'error':'Can not update!'}
                        return Response(error,status = HTTP_400_BAD_REQUEST)
                    play_list = ContentQueue.objects.filter(key = parsed_data['play_list'])
                    if play_list is not None and len(play_list)>0:
                        pl = play_list[0]
                    else:
                        error = {'error':'play list is not found in the system'}
                        return Response(error,status = HTTP_400_BAD_REQUEST)   
                    each_pack.booking_state = success
                    each_pack.applied_to.play_list = pl
                    each_pack.save()
                    baps = each_pack.booked_ad_pack.all()
                    if baps is not None and len(baps) > 0:
                        for bap in baps:
                            bap.booking_state = success
                            bap.applied_to.play_list = pl
                            bap.save()
            res_obj_array = {"status":"Update done successfully!"}
        if parsed_data['booking_state'] == cancel.name:
            bkddaypck = BookedDayPack.objects.filter(applied_to__key = parsed_data['campaign'],account__key=acct.key)
            if bkddaypck is not None and len(bkddaypck) >0:
                for each_pack in bkddaypck:
                    each_pack.booking_state = cancel    
                    each_pack.save()
                    baps = each_pack.booked_ad_pack.all()
                    if baps is not None and len(baps) > 0:
                        for bap in baps:
                            bap.booking_state = cancel
                            bap.save()
            res_obj_array = {"status":"Cancelation done successfully!"}
        return Response (res_obj_array,status=HTTP_201_CREATED)