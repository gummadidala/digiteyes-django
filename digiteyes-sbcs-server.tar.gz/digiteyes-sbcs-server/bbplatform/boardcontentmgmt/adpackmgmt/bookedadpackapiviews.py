from rest_framework import generics
from boardcontentmgmt.models import BookedAdPack, AccountUser
from .bookedadpackserializers import BookedAdPackSerializer, BookedAdPackWriteSerializer

from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated, DjangoModelPermissions
from rest_framework import filters
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
import sys,traceback
import logging
logger = logging.getLogger(__name__)
#################################################################################
# Board List API List View
#################################################################################
class BookedAdPackListAPIView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = BookedAdPackSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_fields = ('board_state__name', 'account__account_name','account')
    #search_fields = ('board_name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'bookedadpack') == True):
            return BookedAdPack.objects.all()
        else:
            return BookedAdPack.objects.filter(account__key = acct.key)
        #return BookedAdPack.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return BookedAdPackWriteSerializer
        return BookedAdPackSerializer
    