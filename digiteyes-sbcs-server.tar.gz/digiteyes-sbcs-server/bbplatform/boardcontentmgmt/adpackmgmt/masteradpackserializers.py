from rest_framework import serializers
from boardcontentmgmt.models import MasterAdPack, MasterAdPackMappings,TrafficPattern,MasterAdPackReference,DayPack
from boardcontentmgmt.models import PrimaryLocationTag, PackState,PrimaryAttributeTag, AccountUser
from boardcontentmgmt.models import DayPart,ScreenLocationTrafficStats, DayQualifier
from django.utils import timezone
from boardcontentmgmt.accountmgmt.accountuserserializers import AccountUserShortSerializer


#################################################################################
# Serializer for Traffic Pattern
#################################################################################
class DayPartSerializer(serializers.ModelSerializer):
    class Meta:
        model = DayPart
        fields = ['name','from_time','to_time']
#################################################################################
# Serializer for Traffic Pattern
#################################################################################
class TrafficPatternSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrafficPattern
        fields = ['name','desc','key']
#################################################################################
# Serializer for ScreenLocationTrafficStatsSerializer
#################################################################################
class ScreenLocationTrafficStatsWriteSerializer(serializers.ModelSerializer):
    day_qualifier = serializers.SlugRelatedField(
        queryset=DayQualifier.objects.all(),
        slug_field='name')
    location = serializers.SlugRelatedField(
        queryset=PrimaryLocationTag.objects.all(),
        slug_field='key')
    associated_traffic = serializers.SlugRelatedField(
        queryset=TrafficPattern.objects.all(),
        slug_field='name')
    day_part = serializers.SlugRelatedField(
        queryset=DayPart.objects.all(),
        slug_field='name')
    class Meta:
        model = ScreenLocationTrafficStats
        fields = ['location','day_part', 'day_qualifier',
            'associated_traffic','key']
#################################################################################
# Serializer for ScreenLocationTrafficStatsSerializer
#################################################################################
class ScreenLocationTrafficStatsSerializer(serializers.ModelSerializer):
    day_qualifier = serializers.SlugRelatedField(
        queryset=DayQualifier.objects.all(),
        slug_field='name')
    location = serializers.SlugRelatedField(
        queryset=PrimaryLocationTag.objects.all(),
        slug_field='key')
    associated_traffic = TrafficPatternSerializer()
    day_part = DayPartSerializer()
    class Meta:
        model = ScreenLocationTrafficStats
        fields = ['location','day_part', 'day_qualifier',
            'associated_traffic','key']
#################################################################################
# Serializer for MasterAdPackSerializer
#################################################################################
class MasterAdPackSerializer(serializers.ModelSerializer):
    state = serializers.SlugRelatedField(
        queryset=PackState.objects.all(),
        slug_field='name')
    created_by = AccountUserShortSerializer()
    last_updated_by = AccountUserShortSerializer()
    class Meta:
        model = MasterAdPack
        fields = ['name','num_plays', 'units_per_play', 'price','created_by',
            'created_date','last_updated_by','last_updated','state','key']
#################################################################################
# Serializer for MasterAdPackSerializer
#################################################################################
class MasterAdPackWriteSerializer(serializers.ModelSerializer):
    state = serializers.SlugRelatedField(
        queryset=PackState.objects.all(),
        slug_field='name')
    created_by = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key', required=False)
    created_date = serializers.DateTimeField(default=timezone.now())
    last_updated = serializers.DateTimeField(default=timezone.now())
    last_updated_by = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key', required=False)
    class Meta:
        model = MasterAdPack
        fields = ['name','num_plays', 'units_per_play', 'price','created_by',
            'created_date','last_updated','last_updated_by','state','key']
    def create(self,validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['created_by'] = aUsr[0]
        validated_data['last_updated_by'] = aUsr[0]
        return serializers.ModelSerializer.create(self,validated_data)
    def update(self, instance, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['created_by'] = instance.created_by
        validated_data['last_updated_by'] = aUsr[0]
        if 'state' in validated_data:
            if validated_data['state'].name == 'INACTIVE':
                masterApObj = MasterAdPackReference.objects.filter(pack__key=instance.key)
                if masterApObj is not None and len(masterApObj)>0:
                    for masterap in masterApObj:
                        daypackObj = DayPack.objects.filter(base_pack__key__in = [masterap.key])
                        if daypackObj is not None and len(daypackObj)>0:
                            for daypack in daypackObj:
                                daypack.state = PackState.objects.filter(name='INACTIVE')[0]
                                daypack.save()
        return serializers.ModelSerializer.update(self, instance, validated_data)
class MasterAdPackShortSerializer(serializers.ModelSerializer):
    state = serializers.SlugRelatedField(
        queryset=PackState.objects.all(),
        slug_field='name')
    class Meta:
        model = MasterAdPack
        fields = ['name','num_plays', 'units_per_play', 'price',
                  'state','key']
#################################################################################
# Serializer for MasterAdPackMappingsSerializer
#################################################################################
class MasterAdPackMappingsSerializer(serializers.ModelSerializer):
    location_attribute = serializers.SlugRelatedField(
        queryset=PrimaryAttributeTag.objects.all(),
        slug_field='key')
    traffic_pattern = TrafficPatternSerializer()
    maps_to_pack = MasterAdPackSerializer()
    created_by = AccountUserShortSerializer()
    class Meta:
        model = MasterAdPackMappings
        fields = ['location_attribute','traffic_pattern', 'maps_to_pack', 
            'created_by','created_date','key']
#################################################################################
# Serializer for MasterAdPackMappingsSerializer
#################################################################################
class MasterAdPackMappingsWriteSerializer(serializers.ModelSerializer):
    location_attribute = serializers.SlugRelatedField(
        queryset=PrimaryAttributeTag.objects.all(),
        slug_field='key')
    traffic_pattern = serializers.SlugRelatedField(
        queryset=TrafficPattern.objects.all(),
        slug_field='name')
    maps_to_pack = serializers.SlugRelatedField(
        queryset=MasterAdPack.objects.all(),
        slug_field='key')
    created_by = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key',required=False)
    last_updated_by = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key',required=False)
    last_updated_date = serializers.DateTimeField(default=timezone.now())
    created_date = serializers.DateTimeField(default=timezone.now())
    class Meta:
        model = MasterAdPackMappings
        fields = ['location_attribute','traffic_pattern', 'maps_to_pack', 
            'created_by','created_date','last_updated_by','last_updated_date','key']
    def create(self,validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['created_by'] = aUsr[0]
        validated_data['last_updated_by'] = aUsr[0]
        return serializers.ModelSerializer.create(self,validated_data)