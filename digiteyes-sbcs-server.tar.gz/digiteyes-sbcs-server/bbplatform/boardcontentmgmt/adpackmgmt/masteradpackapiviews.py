
from rest_framework import generics
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters

from boardcontentmgmt.models import TrafficPattern, ScreenLocationTrafficStats, MasterAdPack , MasterAdPackMappings,AccountUser
from .masteradpackserializers import TrafficPatternSerializer, ScreenLocationTrafficStatsWriteSerializer ,ScreenLocationTrafficStatsSerializer
from django.contrib.admin.utils import lookup_field
from .masteradpackserializers import MasterAdPackSerializer, MasterAdPackWriteSerializer, MasterAdPackMappingsSerializer, MasterAdPackMappingsWriteSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck

import django_filters
from rest_framework.pagination import PageNumberPagination
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
#################################################################################
# Traffic Pattern API List View - Supports Listing and Creation
#################################################################################
class TrafficPatternListView(generics.ListCreateAPIView):
    """
    Traffic Patterns List
    ========
    ##GET:
    List of Traffic Patterns already defined. 
    
    ###Search Fileds:
    
        1. name
        2. desc
                
    ##POST:
    
    Create a Traffic Pattern
    ###Required fields are
        1. name 
        2. desc
        
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = TrafficPatternSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name','desc',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'trafficpattern') == True):
            return TrafficPattern.objects.all()
        else:
            return TrafficPattern.objects.filter(account__key = acct.key)
        #return TrafficPattern.objects.all()
#################################################################################
# Traffic Pattern API Update View - Supports Update/Patch and Deletion
#################################################################################
class TrafficPatternUpdateView(generics.RetrieveUpdateDestroyAPIView):
    """
    Traffic Patterns List
    ========
    ##GET:
    Retrieves the traffic pattern specified by the key.
    
    ###Search Fileds:
    
        1. name
        2. desc
        
    ##PUT:
    
    Updates a Traffic Pattern
    ###Required fields are
        1. name 
        2. desc
        
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = TrafficPatternSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name','desc',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'trafficpattern') == True):
            return TrafficPattern.objects.all()
        else:
            return TrafficPattern.objects.filter(account__key = acct.key)
        #return TrafficPattern.objects.all()


def filter_location(queryset,value):
    if value:
        value = value.split(',')
        return queryset.filter(location__name__in=value)
    return queryset
class LocationStatsFilter(django_filters.FilterSet):
    location_name = django_filters.CharFilter(name='location__name',action=filter_location)
    class Meta:
        model = ScreenLocationTrafficStats
        fields = []
#################################################################################
# Screen Location Traffic Stats API List View - Supports Listing and Creation
#################################################################################
class CustomPagination(PageNumberPagination):
    page_size_query_param = 'page_size'
class ScreenLocationTrafficStatsView(generics.ListCreateAPIView):
    """
    Screen Location Traffic Stats List
    ========
    ##GET:
    List of Screen Location Traffic Stats
    
    ###Search Fileds:
    
        1. Location name
        2. Traffic Name
        
    ##POST:
    
    Create a Traffic Pattern
    ###Required fields are
        1. location (key) 
        2. traffic (pattern)
        3. start time
        4. end time
        5. Day Qualifier (name)
        
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = ScreenLocationTrafficStatsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_fields = ('location__name',)
    filter_class = LocationStatsFilter
    search_fields = ('location__name','associated_traffic__name',)
    #lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'screenlocationtrafficstats') == True):
            return ScreenLocationTrafficStats.objects.all()
        else:
            return ScreenLocationTrafficStats.objects.filter(account__key = acct.key)
    #       return ScreenLocationTrafficStats.objects.all()
    pagination_class = CustomPagination
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ScreenLocationTrafficStatsWriteSerializer
        return ScreenLocationTrafficStatsSerializer
#################################################################################
# Screen Location Traffic Stats Update View - Supports Update/Patch and Deletion
#################################################################################

class ScreenLocationTrafficStatsUpdateView(generics.RetrieveUpdateDestroyAPIView):
    """
     Screen Location Traffic Stats List
    ========
    ##GET:
    Retrieves the Screen Location Traffic Stats specified by the key.
    
    ##PUT:
    
    Updates Screen Location Traffic Stats
     ###Required fields are
        1. location (key) 
        2. traffic (pattern)
        3. start time
        4. end time
        5. Day Qualifier (name)
        
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = ScreenLocationTrafficStatsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('location__name',)
    search_fields = ('location__name','associated_traffic__name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'screenlocationtrafficstats') == True):
            return ScreenLocationTrafficStats.objects.all()
        else:
            return ScreenLocationTrafficStats.objects.filter(account__key = acct.key)
    #       return ScreenLocationTrafficStats.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return ScreenLocationTrafficStatsWriteSerializer
        return ScreenLocationTrafficStatsSerializer
#################################################################################
# Screen Location Traffic Stats API List View - Supports Listing and Creation
#################################################################################
class MasterAdPackListView(generics.ListCreateAPIView):
    """
    MasterAdPacks List
    ========
    ##GET:
    List of Master Ad Packs List
    ## Filter Fields
        1. state
        2. price
        3. num_plays
        4. units_per_play
        
    ###Search Fileds:
        1. name
    ##POST:
    
    Create a Master Ad Packs
    ###Required fields are
        1. name 
        2. num_plays
        3. units_per_play
        4. price
        
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = MasterAdPackSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name',)
    filter_fields = ('name','state__name','num_plays','units_per_play', 'price',)
    #lookup_field = 'key'
    queryset = MasterAdPack.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return MasterAdPackWriteSerializer
        return MasterAdPackSerializer
              
#################################################################################
# Screen Location Traffic Stats Update View - Supports Update/Patch and Deletion
#################################################################################
class MasterAdPackUpdateView(generics.RetrieveUpdateDestroyAPIView):
    """
     MasterAdPacks 
    ========
    ##GET:
    Retrieves the SMasterAdPack specified by the key.
    
    ##PUT:
    
    Updates MasterAdPacks 
     ###Required fields are
        1. name 
        2. num_plays
        3. units_per_play
        4. price
        
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    #permission_classes = (IsAuthenticated, PermissionCheck)
    serializer_class = MasterAdPackSerializer
    search_fields = ('name',)
    filter_fields = ('state__name','num_plays','units_per_play', 'price',)
    lookup_field = 'key'
    queryset = MasterAdPack.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return MasterAdPackWriteSerializer
        return MasterAdPackSerializer     


#################################################################################
# Custom Filters for Mappings
#################################################################################
def filter_attribute(queryset,value):
    if value:
        value = value.split(',')
        return queryset.filter(location_attribute__name__in=value)
    return queryset
class MappingsFilter(django_filters.FilterSet):
    attribute = django_filters.CharFilter(name='location_attribute__name',
        action=filter_attribute)
    class Meta:
        model = MasterAdPackMappings
        fields = []
#################################################################################
# MasterAdPackMappings API List View - Supports Listing and Creation
#################################################################################
class MasterAdPackMappingsListView(generics.ListCreateAPIView):
    """
    MasterAdPackMappings List
    ========
    ##GET:
    List of MasterAdPackMappings List
    ## Filter Fields
        1. Location Attribute Tag Name (e.g. Rich, Posh etc.,) (location_attrigute__name)
        2. traffic pattern (traffic_pattern__name)
        3. master ad pack ( maps_to_pack__name)
        
        
    ###Search Fileds:
        1. Location Name
        2. traffic pattern
        
    ##POST:
    
    Create a Master Ad Packs
    ###Required fields are
        1. Location Attribute Tag (PrimaryAttributeTag key)
        2. Traffic Pattern (Traffic Pattern Key)
        3. Mapped Ad Pack (Mapped ad pack Key)
             
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = MasterAdPackMappingsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('location_attribute__name','traffic_pattern__name','maps_to_pack__name',)
    filter_class = MappingsFilter
    #filter_fields = ('location_attribute__name','traffic_pattern__name','maps_to_pack__name',)
    #lookup_field = 'key'
    pagination_class = CustomPagination
    queryset = MasterAdPackMappings.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return MasterAdPackMappingsWriteSerializer
        return MasterAdPackMappingsSerializer
#################################################################################
# MasterAdPackMappings Update View - Supports Update/Patch and Deletion
#################################################################################
class MasterAdPackMappingsUpdateView(generics.RetrieveUpdateDestroyAPIView):
    """
     MasterAdPackMappings 
    ========
    ##GET:
    Retrieves the MasterAdPackMappings specified by the key.
    
    ##PUT:
    
    Updates MasterAdPacks 
     ###Required fields are
        1. name 
        2. num_plays
        3. units_per_play
        4. price
        
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = MasterAdPackMappingsSerializer
    search_fields = ('location_attribute__name','traffic_pattern__name','maps_to_pack__name',)
    filter_fields = ('location_attribute__name','traffic_pattern__name','maps_to_pack__name',)
    lookup_field = 'key'
    queryset = MasterAdPackMappings.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return MasterAdPackMappingsWriteSerializer
        return MasterAdPackMappingsSerializer     
   