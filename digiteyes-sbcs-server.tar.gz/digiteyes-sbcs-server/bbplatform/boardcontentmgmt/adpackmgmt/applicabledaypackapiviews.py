from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated


from rest_framework.response import Response
from boardcontentmgmt.models import DayPart
from boardcontentmgmt.screenmgmt.boardserializers import BoardBasicSerializer
from boardcontentmgmt.utilities.freeslotutilities import get_master_pack,find_diff_in_secs

from rest_framework.views import APIView
import datetime
from dateutil.parser import parse
from boardcontentmgmt.models import AttributeTagGroup,DayPart,DayPack,Board,ShowSpotAsset,MasterAdPackReference
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from datetime import datetime,timedelta, date
from boardcontentmgmt.utilities.freeslotutilities import get_board_num_free_slots_against_order
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from .daypackserializers import DayPackShortSerializer,MasterAdPackReferenceSerializer
import math
from boardcontentmgmt.utilities.algo_utilities import get_available_day_parts
import logging
import numbers
logger = logging.getLogger(__name__)

def fill_all_child_tags(grpTag,all_tags):
    if grpTag not in all_tags:
        descendents = AttributeTagGroup.get_tree(grpTag)
        print descendents
        for tag in descendents:
            all_tags.append(tag.name)
def get_screens_for_tags(group_list):
    grp_tag_list_incl_children = []
    for grpTag in group_list:
        grp_tag_list_incl_children.append(grpTag.name)
        logger.debug( grpTag.name)
        fill_all_child_tags(grpTag, grp_tag_list_incl_children)
        logger.debug(str(grp_tag_list_incl_children))
    spots = ShowSpotAsset.objects.filter(
        attached_attribute_tag__name__in = grp_tag_list_incl_children)
    keyList = []
    for spot in spots:
        keyList.append(spot.key)
    related_boards = Board.objects.filter(show_spot__key__in=keyList)
    logger.info( related_boards)
    return related_boards
class ApplicableDayPackListView(APIView):
    #authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated, )  
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)  
    def get(self,request):
        from_date = parse(request.query_params.get('from_date', None)).date()
        to_date = parse(request.query_params.get('to_date', None)).date()
        group_tags = request.query_params.getlist('group_tags', None)
        #num_plays_per_day = self.request.query_params.get('num_plays', None)
        units_per_play = self.request.query_params.get('units', None)
        day_pack = request.query_params.get('day_pack', None)
        daypacks = []
        if day_pack is None:
            daypacks = DayPack.objects.all()
        else:
            DPack = day_pack.split(',')
            for dp in DPack:
                dp_obj = DayPack.objects.filter(key = dp)
                if dp_obj is not None and len(dp_obj) > 0:
                    if dp_obj[0].units_per_play != int(units_per_play):
                        error = {'error':'daypack units and units passed must match'}
                        return Response(error,status = HTTP_400_BAD_REQUEST)
                    daypacks.append(dp_obj[0])
                else:
                    error = {'error':'no day pack matching with the given day pack key'}
                    return Response(error,status = HTTP_400_BAD_REQUEST)
        #day_parts = DayPart.objects.all()
        #daypartlen = len(day_parts)
        if group_tags is None:
            error = {'error':'group tags is not given'}
            return Response(error,status = HTTP_400_BAD_REQUEST)
        group_tags_list = AttributeTagGroup.objects.filter(name__in=group_tags)
        logger.debug( group_tags_list)
        boards = get_screens_for_tags(group_tags_list)
        brdslen = len(boards)
        res_obj = []
        while from_date <= to_date:
            if from_date == datetime.now().date():
                day_parts = get_available_day_parts(from_date)
            else:
                day_parts = DayPart.objects.all()
            daypartlen = len(day_parts)
            logger.info('date : '+str(from_date))
            day_all_brd_packs = []
            tmp = []
            help_counter = []
            if boards is not None and len(boards) > 0:
                for brd in boards:
                    brd_all_daypart_packs = []
                    print 'board: ',brd.board_name
                    for dayPart in day_parts:
                        print 'day part: ',dayPart.name
                        start_time = dayPart.from_time
                        end_time = dayPart.to_time 
                        num_plays_per_day = int(find_diff_in_secs(start_time,end_time)/30)
                        master_packs = get_master_pack(brd,from_date,start_time,
                            end_time,num_plays_per_day,int(units_per_play),dayPart)
                        print 'masteradpacks:',master_packs
                        logger.info("Board : "+str(brd.board_name)+
                                    "DayPart : "+str(dayPart.name)+
                                    "masteradpacks : "+str(master_packs))
                        for mp in  master_packs:
                            if len(brd_all_daypart_packs) > 0:
                                i = 0
                                cnt = 0
                                for i in range(len(brd_all_daypart_packs)): 
                                    if mp['pack']['key'] == brd_all_daypart_packs[i]['pack']['key']:
                                        brd_all_daypart_packs[i]['available'] += mp['available']
                                    else:
                                        cnt +=1 
                                    if cnt == len(brd_all_daypart_packs):
                                        brd_all_daypart_packs.append(mp)
                            else:
                                brd_all_daypart_packs.append(mp)
                    print 'brd_all_daypart_packs for board :',brd.board_name,' are :',brd_all_daypart_packs
                    for badp in brd_all_daypart_packs:
                        tmp.append(badp)
                        help_counter.append(badp['pack']['key'])    
            else:
                error = {'error':'no screens in the given group tags'}
                return Response(error,status = HTTP_400_BAD_REQUEST)
            if len(tmp) > 0:
                k = 0
                for k in range(len(tmp)):
                    cnt = help_counter.count(tmp[k]['pack']['key'])
                    if cnt == brdslen:
                        if len(day_all_brd_packs) > 0:
                            j = 0
                            cnt = 0
                            for j in range(len(day_all_brd_packs)):
                                if tmp[k]['pack']['key'] == day_all_brd_packs[j]['pack']['key']:
                                    if tmp[k]['available'] < day_all_brd_packs[j]['available']:
                                        day_all_brd_packs[j]['available'] = tmp[k]['available']
                                else:
                                    cnt += 1
                                if cnt == len(day_all_brd_packs):
                                    day_all_brd_packs.append(tmp[k])                                
                        else:
                            day_all_brd_packs.append(tmp[k])
            print 'day_all_brd_packs for day: ',from_date,' are: ',day_all_brd_packs
            for each_dayPack in daypacks:
                print 'daypack:',each_dayPack.name
                refpacks = []
                refpacks.extend(each_dayPack.base_pack.all())
                #minimum_available = 999999999999
                avail_count = []
                for rp in refpacks:
                    i = 0
                    non_match_count = 0
                    for i in range(len(day_all_brd_packs)):
                        if str(rp.pack.key) == str(day_all_brd_packs[i]['pack']['key']): 
                            avail_count.append(int(day_all_brd_packs[i]['available']/rp.count))
                            print avail_count
                        else:
                            non_match_count = non_match_count + 1
                    if non_match_count == len(day_all_brd_packs):
                        avail_count.append(0)
                print 'count : ',min(avail_count)
                obj = {'daypack_name': each_dayPack.name,
                      'daypack_key': each_dayPack.key,
                      'avial_count':min(avail_count),
                      'date':from_date}
                res_obj.append(obj)
                
                
                '''
                    non_match_count = 0
                    i = 0
                    for i in range(len(day_all_brd_packs)):
                        if str(rp.pack.key) == str(day_all_brd_packs[i]['pack']['key']): 
                            avail_units_for_mpack = float(day_all_brd_packs[i]['pack']['num_plays'])*float(day_all_brd_packs[i]['available'])
                            print 'avail_units_for_mpack : ',avail_units_for_mpack
                            print 'minimum_available : ',minimum_available
                            if minimum_available != -1 and minimum_available > avail_units_for_mpack:
                                minimum_available = avail_units_for_mpack
                                print 'minimum_available : ',minimum_available
                        else:
                            non_match_count = non_match_count+1
                    if non_match_count == len(day_all_brd_packs):
                        minimum_available = -1
                        print minimum_available
                if minimum_available == -1:
                    dpack_avail_count = 0
                else:
                    print 'minimum_available..... : ',minimum_available
                    dpack_avail_count = math.floor(minimum_available/each_dayPack.num_plays)
                print 'availability:',dpack_avail_count
                
                ob = {'daypack_name': each_dayPack.name,
                      'daypack_key': each_dayPack.key,
                      'avial_count':dpack_avail_count,
                      'date':from_date}       
                res_obj.append(ob)
                '''
            from_date  = from_date+timedelta(days=1)
        return Response(res_obj,status = HTTP_201_CREATED)
                