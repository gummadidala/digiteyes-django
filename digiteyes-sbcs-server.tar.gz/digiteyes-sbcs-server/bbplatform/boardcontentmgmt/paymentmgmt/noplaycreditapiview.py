from __future__ import division
from rest_framework.views import APIView
from rest_framework import generics
from boardcontentmgmt.tasks import NoPlayCredit
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED,HTTP_400_BAD_REQUEST
from boardcontentmgmt.models import AdvtCampaign, AccountUser
from boardcontentmgmt.utilities.triggerbookingalgoserializers import TrackBookingAlgoSerializer,TrackBookingAlgoWriteSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
import logging
logger = logging.getLogger(__name__)

class NoPlayCreditAPIView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, )  
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions) 
    def post(self,request):
        username = self.request.user.username
        camp_key = request.data['campaign']
        camp = AdvtCampaign.objects.filter(key = camp_key)
        if camp is None and len(camp) ==0:
            return Response("Given Campaign does not exist",status = HTTP_400_BAD_REQUEST)
        #making field to empty (reset to null)
        NoPlayCredit.delay(camp_key) 
        return Response("Success!")