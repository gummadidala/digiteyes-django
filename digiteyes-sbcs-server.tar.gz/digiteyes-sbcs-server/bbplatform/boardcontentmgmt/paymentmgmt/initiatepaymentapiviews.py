from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters
from rest_framework import serializers
from rest_framework.response import Response
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.models import MyOrder,AccountUser, BookedAdPack,BookingState,\
            CampaignState,ItemType,BookedDayPack,DiscountCoupon,AdvtCampaign
import django_filters
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST,HTTP_302_FOUND
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework import generics
from boardcontentmgmt.tasks import check_booking_status
#from datetime import datetime
from django.shortcuts import render, render_to_response
from django.http import HttpResponse,HttpResponseRedirect
from django.template.loader import get_template
from django.template import Context, Template,RequestContext
import datetime
import hashlib
from random import randint
from django.views.decorators.csrf import csrf_protect, csrf_exempt
from django.core.context_processors import csrf
import celery
import string, random
from boardcontentmgmt.tasks import change_item_status,InvoiceGeneration
from bbplatform.settings import HOSTING_SERVER
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from boardcontentmgmt.utilities.freeslotutilities import get_board_num_free_slots_against_order
from boardcontentmgmt.utilities.credittransactionutilities import create_credit_transaction_from_system
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
import logging
logger = logging.getLogger(__name__)
    
def check_for_freeslots(order,status):
    print 'In check_for_freeslots'
    success = BookingState.objects.filter(name = 'SUCCESS')[0]
    blocked = BookingState.objects.filter(name = 'BLOCKED')[0]
    cancelled = BookingState.objects.filter(name = 'CANCELLED')[0]
    item_keys = order.items.split(',')
    masteradpack = ItemType.objects.filter(name = 'MasterAdPack')[0]
    daypack = ItemType.objects.filter(name = 'DayPack')[0]
    if order.item_type == masteradpack:
        count = 0
        blocked_packs = []
        for pck_key in item_keys:
            bap = BookedAdPack.objects.filter(key = pck_key)
            bp= bap[0]
            required_slots = bp.units_per_play * bp.num_plays
            res = get_board_num_free_slots_against_order(bp.booked_screen,bp.date_booked_for,
                                                            bp.day_part_booked_for.from_time,
                                                            bp.day_part_booked_for.to_time,
                                                            bp.day_part_booked_for,
                                                            bp.applied_to.type.name)
            if res < required_slots:
                amount = order.paid_amount + order.credit_amount
                reason = "PAYMENT TIMEOUT - DELAYED TRANSACTION"
                desc = "payment happened after system has time out the transaction"
                create_credit_transaction_from_system(order.account,amount,reason,desc)
                for bp in blocked_packs:
                        bp.booking_state = cancelled
                        bp.save()   
                        return False
            else:
                count = count + 1
                bp.booking_state = status
                bp.save()
                blocked_packs.append(bp)
        if count == len(item_keys):
            for bp in blocked_packs:
                change_item_status(bp,success)
            order.status = success
            if order.applied_credit_trasaction is not None and len(order.applied_credit_trasaction.all()) > 0:
                order.applied_credit_trasaction.all()[0].transaction_status = status
                order.applied_credit_trasaction.all()[0].save()
            order.save()
            logger.info("calling InvoiceGeneration task")
            InvoiceGeneration.delay(str(order.txnid))
                
    elif order.item_type == daypack:
        count = 0
        blocked_packs = []
        total_baps = 0
        for pck_key in item_keys:
            bdp = BookedDayPack.objects.filter(key = pck_key)[0]
            total_baps = total_baps + len(bdp.booked_ad_pack.all())
        for pck_key in item_keys:
            bdp = BookedDayPack.objects.filter(key = pck_key)[0]
            baps = bdp.booked_ad_pack.all()
            for bp in baps:
                required_slots = bp.units_per_play * bp.num_plays
                res = get_board_num_free_slots_against_order(bp.booked_screen,bp.date_booked_for,
                                                            bp.day_part_booked_for.from_time,
                                                            bp.day_part_booked_for.to_time,
                                                            bp.day_part_booked_for,
                                                            bp.applied_to.type.name)
                if res < required_slots:
                    amount = order.paid_amount + order.credit_amount
                    reason = "PAYMENT TIMEOUT - DELAYED TRANSACTION"
                    desc = "payment happened after system has time out the transaction"
                    create_credit_transaction_from_system(order.account,amount,reason,desc)
                    
                    for bp in blocked_packs:
                        bp.booking_state = cancelled
                        bp.save()   
                        return False
                else:
                    count = count + 1
                    bp.booking_state = status
                    bp.save()
                    blocked_packs.append(bp)
                    
        if count == total_baps:
            for pck_key in item_keys:
                bdp = BookedDayPack.objects.filter(key = pck_key)[0]
                change_item_status(bdp,status)
            for bp in blocked_packs:
                change_item_status(bp,status)
            order.status = status
            if order.applied_credit_trasaction is not None and len(order.applied_credit_trasaction.all()) > 0:
                order.applied_credit_trasaction.all()[0].transaction_status = status
                order.applied_credit_trasaction.all()[0].save()
            order.save()
            logger.info("calling InvoiceGeneration task")
            InvoiceGeneration.delay(str(order.txnid))
    return True

def change_order_status(order,status):
    item_keys = order.items.split(',')
    masteradpack = ItemType.objects.filter(name = 'MasterAdPack')[0]
    daypack = ItemType.objects.filter(name = 'DayPack')[0]
    res = False
    if order.item_type == masteradpack:
        for pck_key in item_keys:
            bap = BookedAdPack.objects.filter(key = pck_key)
            bp= bap[0]
            if status.name == 'BLOCKED' or status.name == 'SUCCESS':
                return check_for_freeslots(order,status)
            else:
                change_item_status(bap[0],status) 
    elif order.item_type == daypack:
        for pck_key in item_keys:
            bdp = BookedDayPack.objects.filter(key = pck_key)
            if bdp[0].applied_to is not None:
                change_item_status(bdp[0],status)
                baps = bdp[0].booked_ad_pack.all()
                for each_bap in baps:
                    if status.name == 'BLOCKED' or status.name == 'SUCCESS':
                        return check_for_freeslots(order,status)
                    else:
                        change_item_status(each_bap,status)
    if not res:
        cancel = BookingState.objects.filter(name = 'CANCELLED')[0]
        order.status = cancel
        if order.applied_credit_trasaction is not None and len(order.applied_credit_trasaction.all()) > 0:
            order.applied_credit_trasaction.all()[0].transaction_status = cancel
            order.applied_credit_trasaction.all()[0].save()
    order.save()
    
################################################################################
#API for initiating the payment from the customer
################################################################################
class InitiatePaymentAPIView(generics.ListCreateAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name')
    lookup_field = 'txnid'
    def get_queryset(self):
        return Response('Get method is not implemented')
    
    def post(self,request, format=None):
        username = self.request.user.username
        parsed_data = request.data
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        today = datetime.datetime.now()
        #txnid = Transaction_number()
        odr_obj = MyOrder.objects.filter(txnid = parsed_data['txnid'])
        if odr_obj is None and len(odr_obj<=0):
            return Response('Order with txnid is not found!')
        order = odr_obj[0]
        '''
        if order.status.name not in ['INITIATED','BLOCKED'] :
            error = {'error':'Time out error, Please try again!'}
            return Response(error,HTTP_400_BAD_REQUEST)
            '''
        txnid = parsed_data['txnid']
        payu_amount = order.paid_amount
        success = BookingState.objects.filter(name = 'SUCCESS')[0]
        blocked = BookingState.objects.filter(name = 'BLOCKED')[0]
        print 'AMount to pay : ',parsed_data['amount']
        if parsed_data['item_type'] != 'ArAdPack':
            if payu_amount > 0:
                res = change_order_status(order,blocked)
                if not res:
                    error = {'error':'Slots are not available, please try again!'}
                    return Response(error,HTTP_400_BAD_REQUEST)
                else:
                    check_booking_status.apply_async((txnid,"BLOCKED"), countdown=300)
            else:
                res  = change_order_status(order,success)
                if not res:
                    error = {'error':'Slots are not available, please try again!'}
                    return Response(error,HTTP_400_BAD_REQUEST)
        else :
            order.campaign.state = CampaignState.objects.filter(state_name = 'RUNNING')[0]
            order.campaign.save()
            if payu_amount > 0:
                check_booking_status.apply_async((txnid,"BLOCKED"), countdown=300)
    ############################################################################
    #initiating the payment gateway
    ############################################################################
        MERCHANT_KEY ="k2ZXRBys"#"VIQcRibJ"
        key= "k2ZXRBys"
        SALT = "wy3dkGRRdR"
        posted={}
        posted['txnid']=txnid
        posted['amount'] = int(payu_amount)
        posted['productinfo'] = "UsedatAdiot.inforbookingthecampaign"
        posted['MERCHANT_KEY'] = MERCHANT_KEY
        posted['firstname'] = acct.account_name
        posted['email'] = self.request.user.email
        posted['phone'] = accounts[0].account_user_phone_no
        posted['udf1'] = ''
        posted['udf2'] = ''
        posted['udf3'] = ''
        posted['udf4'] = ''
        posted['udf5'] = ''
        posted['udf6'] = ''
        posted['udf7'] = ''
        posted['udf8'] = ''
        posted['udf9'] = ''
        posted['udf10'] = ''
        hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10"
        posted['key']=key
        hash_string=''
        hashVarsSeq=hashSequence.split('|')
        for i in hashVarsSeq:
            try:
                hash_string+=str(posted[i])
                hash_string+='|'
            except Exception:
                hash_string+=''
        hash_string+=SALT
        hashh=hashlib.sha512(hash_string).hexdigest().lower()
        order.hash = hashh
        order.save()
        posted['hash']= hashh
        posted['Surl'] = HOSTING_SERVER+'boardcontentmgmt/ui/successurl/'
        posted['Furl'] = HOSTING_SERVER+'boardcontentmgmt/ui/failureurl/'
        posted['hash_string'] = hash_string        
        if(posted.get("key")!=None and posted.get("txnid")!=None and posted.get("productinfo")!=None and 
           posted.get("firstname")!=None and posted.get("email")!=None):
            
            return Response(posted)
        else:
            error = {'error':'Mandatory fields are not filled'}
            return Response(error,HTTP_400_BAD_REQUEST)

        
        
        
        
        
        
        
        
        
        
        