from django.shortcuts import render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.auth import login, logout
from django.http import HttpResponseRedirect
import hashlib
from django.views.decorators.csrf import csrf_protect, csrf_exempt
from django.core.context_processors import csrf
from boardcontentmgmt.models import MyOrder , BookedAdPack ,BookingState
from django.shortcuts import render_to_response
from .initiatepaymentapiviews import change_order_status
import boardcontentmgmt.tasks
import logging
logger = logging.getLogger(__name__)

@csrf_protect
@csrf_exempt
def Failure(request):
    status=request.POST["status"]
    firstname=request.POST["firstname"]
    amount=request.POST["amount"]
    txnid=request.POST["txnid"]
    posted_hash=request.POST["hash"]
    key=request.POST["key"]
    productinfo=request.POST["productinfo"]
    email=request.POST["email"]
    salt="OfdX8PVgf3"
    try:
        additionalCharges=request.POST["additionalCharges"]
        retHashSeq=additionalCharges+'|'+salt+'|'+status+'|||||||||||'+email+'|'+firstname+'|'+productinfo+'|'+amount+'|'+txnid+'|'+key
    except Exception:
        retHashSeq = salt+'|'+status+'|||||||||||'+email+'|'+firstname+'|'+productinfo+'|'+amount+'|'+txnid+'|'+key
    hashh=hashlib.sha512(retHashSeq).hexdigest().lower()
    if(hashh !=posted_hash):
        logger.warn( "Invalid Transaction. Please try again Hash not matching")
    else:
        logger.info( "Thank You. Your order status is " + str(status))
        logger.info( "Your Transaction ID for this transaction is "+ str(txnid))
        logger.info( "We have received a payment of Rs. " + str(amount))
    ############################################################################
    #turn the status to failure in bookedadpack.booking_state
        order_obj = MyOrder.objects.filter(txnid = txnid)
        failed = BookingState.objects.filter(name = 'FAILED')[0]
        change_order_status(order_obj[0],failed)
    ############################################################################
    #return HttpResponseRedirect('boardcontentmgmt/paymentfailure.html')
    return render_to_response('paymentfailure.html')