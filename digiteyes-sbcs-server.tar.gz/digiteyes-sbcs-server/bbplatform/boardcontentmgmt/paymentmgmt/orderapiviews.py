from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters
from rest_framework import serializers
from rest_framework.response import Response
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.models import MyOrder,AccountUser, BookedAdPack,BookingState,\
            CampaignState,ItemType,BookedDayPack,DiscountCoupon,AdvtCampaign
import django_filters
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST,HTTP_302_FOUND
from rest_framework import generics
from boardcontentmgmt.tasks import check_booking_status
import datetime
import string, random
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from boardcontentmgmt.accountmgmt.accountserializers import AccountShortSerializer
from boardcontentmgmt.campaignmgmt.campaignserializers import AdvtCampaignShortSerializer
from boardcontentmgmt.accountmgmt.accountuserserializers import AccountUserShortSerializer
from boardcontentmgmt.creditmgmt.credittransactionsapiviews import AccountCreditTransactionsShortSerializer
import logging
logger = logging.getLogger(__name__)

def Transaction_number():
    tid = ''.join(random.choice(string.digits) for i in range(15))
    tid = 'DE' + datetime.datetime.now().date().strftime("%Y%m%d") + tid
    ordrs = MyOrder.objects.filter(txnid = tid)
    if(len(ordrs) > 0):
        Transaction_number()
    else:   
        return tid
    
def fill_reference_pack_items(parsed_data,order,bp_keys):
    masteradpack = ItemType.objects.filter(name = 'MasterAdPack')[0]
    daypack = ItemType.objects.filter(name = 'DayPack')[0]
    item_keys = ""
    for bp in bp_keys:
        if parsed_data['item_type'] == masteradpack.name:
            pck = BookedAdPack.objects.filter(key = bp)
        elif  parsed_data['item_type'] == daypack.name:
            pck = BookedDayPack.objects.filter(key = bp)
        item_keys = item_keys+str(pck[0].key)
        if len(bp_keys) > 1:
            item_keys = item_keys + ','
    if len(bp_keys) > 1:
        item_keys = item_keys[:-1]  
    order.items = item_keys 
    order.save()

##################################################################################
#Serializer for MyOrder
#################################################################################
class MyorderSerializer(serializers.ModelSerializer):
    status = serializers.SlugRelatedField(
        queryset=BookingState.objects.all(),
        slug_field='name')
    account = AccountShortSerializer()
    campaign = AdvtCampaignShortSerializer()
    applied_coupon = serializers.SlugRelatedField(
        queryset=DiscountCoupon.objects.all(),
        slug_field='coupon_code')
    item_type = serializers.SlugRelatedField(
        queryset=ItemType.objects.all(),
        slug_field='name')
    buyer = AccountUserShortSerializer()
    applied_credit_trasaction=AccountCreditTransactionsShortSerializer(many=True)
    class Meta:
        model = MyOrder
        fields = ['key','txnid','invoice','discounted_amount','credit_amount','paid_amount','status',
                  'order_date','account','campaign','applied_coupon','item_type','items','buyer',
                  'applied_credit_trasaction']
        
class MyOrderAPIView(generics.ListCreateAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)# DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = MyorderSerializer
    search_fields = ('account__account_name','txnid','campaign__key')
    filter_fields = ('account__account_name','txnid','campaign__key')
    lookup_field = 'txnid'
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(usr,'myorder') == True):
            return MyOrder.objects.all()
        else:
            return MyOrder.objects.filter(account__key = acct.key)
                
    def post(self,request, format=None):
        username = self.request.user.username
        parsed_data = request.data
        acct_user = AccountUser.objects.filter(account_user__username=username)
        initiated = BookingState.objects.filter(name = 'INITIATED')[0]
        acct = acct_user[0].account
        today = datetime.datetime.now()
        txnid = Transaction_number()
        order = MyOrder()
        order.actual_amount = parsed_data['amount']
        order.paid_amount = parsed_data['amount']
        order.campaign = AdvtCampaign.objects.filter(key=parsed_data['campaign'])[0]
        order.account = acct
        order.buyer = acct_user[0]
        order.txnid = txnid
        order.status = initiated
        order.order_date = datetime.datetime.now()
        order.item_type = ItemType.objects.filter(name = parsed_data['item_type'])[0]
        order.applied_coupon = None
        order.save()
        order.applied_credit_trasaction = []
        order.save()
        bp_keys = parsed_data['items']
        if order.campaign.type.name != 'AR':
            fill_reference_pack_items(parsed_data,order,bp_keys)
        check_booking_status.apply_async((txnid,"INITIATED"), countdown=600)
        return Response(MyorderSerializer(order).data,status = HTTP_201_CREATED)
        
        
        
        
        
        
        
        
        
        
        
        