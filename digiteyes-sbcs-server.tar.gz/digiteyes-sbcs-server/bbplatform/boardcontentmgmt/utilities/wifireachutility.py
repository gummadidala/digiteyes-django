'''
Created on 17-Feb-2017

@author: saba
'''
import datetime
from django.db.models import Sum, Avg
from boardcontentmgmt.models import CampaignWifiCount, AdvtCampaign, WifiConsumerTracking
from boardcontentmgmt.models import ShowSpotAsset, DayPart
def generate_wifi_reach_report(campaign_key):
    res={}
    camp_obj = AdvtCampaign.objects.filter(key=campaign_key) 
    if camp_obj is None and len(camp_obj)>0:
        return None
    completed_days=[]
    today=datetime.date.today()
    for day in camp_obj[0].planned_dates.all():
        if day.date < today:
            completed_days.append(day.date)
    res['days']=[]
    res['total']=0
    wifiCount_objs = CampaignWifiCount.objects.filter(campaign__key = campaign_key)
    if wifiCount_objs is not None and len(wifiCount_objs)>0:
        entry_dates = []
        for obj in wifiCount_objs:
            if obj.start_time.date() not in entry_dates and obj.start_time.date() in completed_days:
                entry_dates.append(obj.start_time.date())
        total=0
        for dt in entry_dates:
            full_day_obj = {}
            strt_time = datetime.datetime.combine(dt, datetime.time(00, 00, 00, 000))
            end_time = datetime.datetime.combine(dt, datetime.time(23, 59, 59, 9999))
            full_day_obj['date'] = dt.strftime("%Y-%m-%d")
            day_count = CampaignWifiCount.objects.filter(campaign__key = campaign_key,
                start_time__range=(strt_time,end_time)).aggregate(Sum('count'))
            full_day_obj['count'] = day_count['count__sum']
            total=total+day_count['count__sum']
            res['days'].append(full_day_obj)
        res['total']=total
    return res
def generate_wifi_count_stats(start_date,end_date,show_spot_key):
    stats={}
    show_spots = ShowSpotAsset.objects.filter(key=show_spot_key)
    if show_spots is None and len(show_spots) == 0 :
        return stats
    spot = show_spots[0]
    wifi_counters = spot.attached_wificounters.all()
    dayParts = DayPart.objects.all().order_by('from_time')
    day=start_date
    stats['days']=[]
    period_day_parts_sum = {}
    for dayPart in dayParts:
        period_day_parts_sum[dayPart.name]=0
    while day <= end_date:
        day_stats = {'date':day,'dayParts':[]}
        stats['days'].append(day_stats)
        for dayPart in dayParts:
            timestamp_start=datetime.datetime.combine(day,dayPart.from_time)
            timestamp_end=datetime.datetime.combine(day,dayPart.to_time)
            day_part_reach=WifiConsumerTracking.objects.filter(
                event_location__in=wifi_counters,start_time__range=
                (timestamp_start,timestamp_end)).aggregate(Sum('devices_count'))
            day_part_average=WifiConsumerTracking.objects.filter(
                event_location__in=wifi_counters,start_time__range=
                (timestamp_start,timestamp_end)).aggregate(Avg('devices_count'))
            reach_sum = 0
            if 'devices_count__sum' in day_part_reach and day_part_reach['devices_count__sum'] is not None:
                
                reach_sum = day_part_reach['devices_count__sum']
            
            dayPart_stats = {'day_part':dayPart.name,'from_time':dayPart.from_time,
                'to_time':dayPart.to_time,'count': reach_sum}
            dayPart_stats['slot_average']=0            
            if 'devices_count__avg' in day_part_average and day_part_average['devices_count__avg'] is not None:
                period_day_parts_sum[dayPart.name]=period_day_parts_sum[dayPart.name]+day_part_average['devices_count__avg']
                dayPart_stats['slot_average']=day_part_average['devices_count__avg']
            day_stats['dayParts'].append(dayPart_stats)
        day_sum = sum(daypart['count'] for daypart in day_stats['dayParts'])
        day_average_sum = sum(daypart['slot_average'] for daypart in day_stats['dayParts'])
        day_average = day_average_sum / len(dayParts)
        day_stats['day_count'] = day_sum
        day_stats['day_average'] = day_average
        day = day + datetime.timedelta(days=1)
    period_average_sum = sum(day_stats['day_average'] for day_stats in stats['days'])
    period_average =  period_average_sum / len(stats['days'])
    stats['start_date']=start_date
    stats['end_date']=start_date
    stats['period_average']=period_average
    num_days = len(stats['days'])
    period_day_parts_avg = []
    for dayPart in dayParts:
        period_day_parts_avg.append({'day_part':dayPart.name,'average':
            period_day_parts_sum[dayPart.name]/num_days})
    stats['period_daypart_averages']=period_day_parts_avg
    return stats
    
    
        
    
