'''
Created on 13-Feb-2017

@author: saba
'''
from django.db.models import Sum
from boardcontentmgmt.models import AccountCreditTransactions,TransactionReason, BookingState

#################################################################################
# Utility method to find account balance
#################################################################################
def find_account_balance(account):
    total_credit=0.0
    total_debit=0.0
    all_credits = AccountCreditTransactions.objects.filter(account__key=account.key,
        is_credit=True,transaction_status__name='SUCCESS').aggregate(Sum('amount'))
    all_debits = AccountCreditTransactions.objects.filter(account__key=account.key,
        is_credit=False,transaction_status__name__in=['SUCCESS','BLOCKED','INITIATED']).aggregate(Sum('amount'))
    if 'amount__sum' in all_credits and all_credits['amount__sum'] is not None:
        total_credit=all_credits['amount__sum']
    if 'amount__sum' in all_debits and all_debits['amount__sum'] is not None :
        total_debit=all_debits['amount__sum']
    print unicode(total_credit)
    print unicode(total_debit)
    balance = float(total_credit) - float(total_debit) 
    return balance
#################################################################################
# Creates a debit transaction for the given account.
##################################################################################
def create_debit_transaction_from_system(account,amount,transaction_reason,desc,state):
    # May be introduce transactions here... ???
    balance = find_account_balance(account)
    if balance < amount :
        return None
        #raise "Not enough account balance to perform this operation. Balance:" + unicode(balance) + " Debit requested:"+ amount
    transaction = AccountCreditTransactions()
    transaction.account = account
    transaction.transaction_reason = transaction_reason
    transaction.is_credit = False
    transaction.transaction_description = desc
    transaction.amount = amount
    transaction.transaction_status = state
    # Need to fill performing user to System user.
    transaction.save()
    return transaction

#################################################################################
# Creates a credit transaction for the given account.
##################################################################################
def create_credit_transaction_from_system(account,amount,transaction_reason,desc):
    # May be introduce transactions here... ???
    
    transaction = AccountCreditTransactions()
    transaction.account = account
    transaction.transaction_reason = transaction_reason
    transaction.is_credit = True
    transaction.transaction_description = desc
    transaction.amount = amount
    transaction.transaction_status = BookingState.objects.filter(name='SUCCESS')[0]
    # Need to fill performing user to System user.
    transaction.save()
    return transaction
    