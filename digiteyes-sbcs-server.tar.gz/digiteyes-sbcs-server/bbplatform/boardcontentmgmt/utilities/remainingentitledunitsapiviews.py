from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from boardcontentmgmt.models import DayPart
from rest_framework.views import APIView
from dateutil.parser import parse
from .freeslotutilities import get_board_num_free_slots_against_order
from boardcontentmgmt.models import AttributeTagGroup,AccountUser, ShowSpotAsset, Board,MasterEntitlement,BookedAdPack, Account
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from datetime import datetime,timedelta, date
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import math
from dateutil.relativedelta import relativedelta
from boardcontentmgmt.campaignmgmt.apartmentadvertisingapiviews import get_available_day_parts
import sys
from boardcontentmgmt.utilities.algo_utilities import get_available_day_parts

import logging
logger = logging.getLogger(__name__)


#################################################################################
# Utility method to find difference in seconds
#################################################################################
def find_diff_in_secs(time1,time2):
    st = datetime.now()
    st1 = st.replace(hour=time1.hour,minute=time1.minute,second=time1.second)
    et1 = st.replace(hour=time2.hour,minute=time2.minute,second=time2.second)
    td = et1 - st1
    td_seconds = td.total_seconds()
    return td_seconds

def get_board_num_free_slots_against_entitlement(board,date,day_part,accnt,camp_type):
    td_seconds = find_diff_in_secs(day_part.from_time,day_part.to_time)
    total_slots = int(td_seconds / 30)
    entitledSlots_per = MasterEntitlement.objects.filter(day_part_entitled = day_part,account__key = accnt.key)
    if(len(entitledSlots_per) > 0):
        if camp_type == 'NORMAL':
            total_free_slots = total_slots*entitledSlots_per[0].percent_slots_entitled_association / 100
        else:
            total_free_slots = total_slots*entitledSlots_per[0].ticker_slots_entitled / 100
        logger.info('total_entitled_slots: '+str(total_free_slots))
    else:
        return 0
    total_booked_slots = 0
    bkd_packs = BookedAdPack.objects.filter(booked_screen__key = board.key,day_part_booked_for = day_part,
                                                account__key=accnt.key, date_booked_for = date,
                                                applied_to__type__name=camp_type)
    if(len(bkd_packs) == 0):
        logger.info('booked_slots: '+str(total_booked_slots))
        return total_free_slots
    else:
        for pack in bkd_packs:
            booked_slots = pack.units_per_play * pack.num_plays
            total_booked_slots +=  booked_slots
        logger.info('booked_slots: '+str(total_booked_slots))
        total_free_slots -= total_booked_slots
        logger.info('free_slots: '+str(total_free_slots))
        if(total_free_slots < 0):
            total_free_slots = 0
        return math.floor(total_free_slots)
    
class RemainingEntitledUnitsCalendarView(APIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    #serializer_class = MasterAdPackSerializer
    def get(self,request):
	account = self.request.query_params.get('account', None)
	acct = None
	if account is None:
        	username = self.request.user.username
        	accounts = AccountUser.objects.filter(account_user__username=username)
        	acct = accounts[0].account
	else:
		accounts = Account.objects.filter(key=account)
		acct = accounts[0]
        
        day_part = self.request.query_params.get('day_part', None)
        date_ent = parse(request.query_params.get('date', None)).date()
        #last_day = date_ent + relativedelta(day=1, months=+1, days=-1)
        #first_day = date_ent + relativedelta(day=1)
        first_day = date_ent
        if day_part is None:
            dayParts = DayPart.objects.all()
        else :
            dayParts = DayPart.objects.filter(name = day_part)
              
        
        availability_list = []
        show_spots_in_account = ShowSpotAsset.objects.filter(account__key = acct.key)
        #start_day = first_day+relativedelta(months=3)
        #while first_day <= last_day and first_day < start_day:    
        if len(show_spots_in_account) > 0 and show_spots_in_account is not None:
            board = Board.objects.filter(show_spot__key = show_spots_in_account[0].key)
            for dp in dayParts:
                if len(board) >0 and board is not None:
                    remainig_units = get_board_num_free_slots_against_entitlement(board[0],
                    first_day,dp,acct,'NORMAL')
                    availability_list.append({'board':board[0].key,'day_part':dp.name,
                        'availability':remainig_units,'date':first_day})
                else:
                    error = {'error':'No boards found in the given association account showspots'}
                    return Response(error,status=HTTP_400_BAD_REQUEST)
        else:
            error = {'error':'No showspots found in the given association account'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
            #first_day = first_day+timedelta(days=1)
            #if  first_day > last_day:
                #last_day = last_day+relativedelta(months=1)
        return Response(availability_list)

class RemainingEntitledUnitsAssociationView(APIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    #serializer_class = MasterAdPackSerializer
    def get(self,request):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        
        day_part = self.request.query_params.get('day_part', None)
        date_ent = parse(request.query_params.get('date', None)).date()
        camp_type = self.request.query_params.get('campaign_type',None)
        
        if day_part is None:
            #dayParts = DayPart.objects.all()
            dayParts = get_available_day_parts(date_ent)
        else :
            dayParts = DayPart.objects.filter(name = day_part)
        availability_list = []
        show_spots_in_account = ShowSpotAsset.objects.filter(account__key = acct.key)    
        if len(show_spots_in_account) > 0 and show_spots_in_account is not None:
            for spot in show_spots_in_account:
                board = Board.objects.filter(show_spot__key = spot.key)
                if len(board) >0 and board is not None:
                    for dp in dayParts:
                        remainig_units = get_board_num_free_slots_against_entitlement(board[0],
                                                                                      date_ent,dp,acct,
                                                                                      camp_type)
                        obj={'day_part':dp.name,
                             'availability':remainig_units,
                             'date':date_ent,
                             'board':board[0].key}
                        availability_list.append(obj)
                else:
                    logger.error('boards not found in the given association account showspots')
                        #error = {'error':'boards not found in the given association account showspots'}
                        #return Response(error,status=HTTP_400_BAD_REQUEST)
        else:
            error = {'error':'No showspots found in the given association account'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        return Response(availability_list)
    
class RemainingFreeSlotsView(APIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    #serializer_class = MasterAdPackSerializer
    def post(self,request):
        day_part= request.data['day_part']
        start_date = parse(request.data['start_date']).date()
        end_date = parse(request.data['end_date']).date()
        camp_type = request.data['campaign_type']
        if end_date < start_date:
            error = {'error':'End_date can not be less than Start_date'}
            return Response(error,status = HTTP_400_BAD_REQUEST)
        
        dp_obj=DayPart.objects.filter(name=day_part)[0]
        available_dayParts=get_available_day_parts(start_date)
        if dp_obj not in available_dayParts:
            error = {'error':'Can not create campaign for given day part'}
            return Response(error,status = HTTP_400_BAD_REQUEST)
        
        if 'location' in request.data:
            location_key = request.data['location']
        screen_group = request.data['screen_group']
        dayPart = DayPart.objects.filter(name = day_part)[0]
        attrib_grp = AttributeTagGroup.objects.filter(key=screen_group)
        grp_list = []
        if attrib_grp is not None and len(attrib_grp) >0:
            children = attrib_grp[0].get_children()
            if len(children) > 0:
                for child in children:
                    child_grp = child.get_children()
                    if len(child_grp)>0:
                        for ch in child_grp:
                            grp_list.append(ch.key)
                    else:
                        grp_list.append(child.key)
            else:
                grp_list.append(attrib_grp[0].key)
        availability_list = []
        spot_list = []
        for grp in grp_list:
            if 'location' not in request.data or len(location_key) == 0:
                show_spot = ShowSpotAsset.objects.filter(attached_attribute_tag__key = grp)
            else:
                show_spot = ShowSpotAsset.objects.filter(attached_primary_location_tag__key__in = location_key,attached_attribute_tag__key = grp)
            if show_spot is not None and len(show_spot)>0:
                spot_list.extend(show_spot)
        logger.info("Length of showspots for selected location and group:"+str(len(spot_list)))
        if(len(spot_list) > 0):
            start_time = dayPart.from_time
            end_time = dayPart.to_time
            strt_date = start_date
            while strt_date <= end_date:
                free_slots = sys.maxint
                for each_spot in spot_list:
                    board = Board.objects.filter(show_spot__key = each_spot.key)
                    if len(board) > 0 and  board is not None:
                        remainig_units = get_board_num_free_slots_against_order(board[0],
                            strt_date,start_time,end_time,dayPart,camp_type)
                        if remainig_units < free_slots:
                             free_slots = remainig_units
                obj = {'date':strt_date,'free_slots':free_slots}
                strt_date = strt_date + timedelta(days=1)
                availability_list.append(obj)
            return Response(availability_list)
        else :
            error = {'error':'spots not found or may be empty in given details'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
