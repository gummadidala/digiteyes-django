from __future__ import division
from boardcontentmgmt.models import ScreenLocationTrafficStats, MasterAdPackMappings, MasterEntitlement,BookedAdPack
from boardcontentmgmt.adpackmgmt.masteradpackserializers import MasterAdPackShortSerializer
from datetime import timedelta
import datetime
from django.db.models import Q
from bbplatform.settings import ENTITLEMENTS
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from boardcontentmgmt.models import AttributeTagGroup, ShowSpotAsset, Board
import math

import logging
logger = logging.getLogger(__name__)
#################################################################################
# Filter method to add all the child tags of given group tag.
#################################################################################
def fill_all_child_tags(grpTag,all_tags):
    if grpTag not in all_tags:
        descendents = AttributeTagGroup.get_tree(grpTag)
        for tag in descendents:
            all_tags.append(tag.name)
    
##################################################################################
# Returns the list of screens indicated by location tags and group tags.
#################################################################################
def get_screens_for_tags(location_tag_list,group_list):
    grp_tag_list_incl_children = []
    for grpTag in group_list:
        grp_tag_list_incl_children.append(grpTag.name)
        logger.debug( grpTag.name)
        fill_all_child_tags(grpTag, grp_tag_list_incl_children)
        logger.debug(str(grp_tag_list_incl_children))
    if len(location_tag_list) > 0:
        spots = ShowSpotAsset.objects.filter(
            attached_primary_location_tag__name__in = location_tag_list,
            attached_attribute_tag__name__in = grp_tag_list_incl_children)
    else:
        spots = ShowSpotAsset.objects.filter(attached_attribute_tag__name__in = grp_tag_list_incl_children)
    keyList = []
    for spot in spots:
        keyList.append(spot.key)
    related_boards = Board.objects.filter(show_spot__key__in=keyList)
    logger.info( related_boards)
    return related_boards
#################################################################################
# Utility method to find difference in seconds
#################################################################################
def find_diff_in_secs(time1,time2):
    st = datetime.datetime.now()
    st1 = st.replace(hour=time1.hour,minute=time1.minute,second=time1.second)
    et1 = st.replace(hour=time2.hour,minute=time2.minute,second=time2.second)
    td = et1 - st1
    td_seconds = td.total_seconds()
    return td_seconds

def find_diff_in_days(date):
    d0 = datetime.datetime.now().date()
    d1 = date
    delta = d1 - d0
    return delta.days
#################################################################################
# Returns the number of booked slots between the given time, for the given date
# and screen.
#################################################################################
def get_board_booked_slots_against_order(board,date,start_time,end_time,booking_types,camp_type):
    booking_states = ['BLOCKED','SUCCESS']#,'INITIATED']
    bkd_packs = BookedAdPack.objects.filter(Q(booked_screen__key = board.key) &
       Q(date_booked_for = date) & 
       Q(day_part_booked_for__from_time=start_time) & 
       Q(day_part_booked_for__to_time=end_time)&
       Q(booking_state__name__in = booking_states)&
       Q(booking_type__in=booking_types)&
       Q(applied_to__type__name=camp_type))
    total_booked_slots=0
    for pack in bkd_packs:
        #booked_slots = pack.reference_master_pack.units_per_play * pack.reference_master_pack.num_plays
        #booked_slots = pack.units_per_play * pack.num_plays
        booked_slots = pack.units_per_play * pack.num_plays * pack.unit_size/30
        total_booked_slots = total_booked_slots + booked_slots
    return total_booked_slots
#################################################################################
#booking through entitlement
#################################################################################
def get_board_num_free_slots_against_entitlement(board,date,day_part,accnt,camp_type):
    td_days = find_diff_in_days(date)
    if (td_days <= ENTITLEMENTS):
        #error = {'error':'booking through entitlement can be happen only before two days'}
        return 0
    td_seconds = find_diff_in_secs(day_part.from_time,day_part.to_time)
    total_slots = int(td_seconds / 30)
    entitledSlots_per = MasterEntitlement.objects.filter(day_part_entitled = day_part,account__key = accnt.key)
    total_entitled_slots=0
    if entitledSlots_per is not None and len(entitledSlots_per)>0:
        if camp_type == 'NORMAL':
            total_entitled_slots = float(total_slots)*float(entitledSlots_per[0].percent_slots_entitled_association) / 100
        else:
            total_entitled_slots = float(total_slots)*float(entitledSlots_per[0].ticker_slots_entitled) / 100
        logger.info('total_entitled_slots: '+str(total_entitled_slots))
    else:
        logger.info('total_entitled_slots: '+str(total_entitled_slots))
        return 0
    total_booked_slots = 0
    booking_types=['association_booking']
    start_time = day_part.from_time
    end_time = day_part.to_time
    booked_slots = get_board_booked_slots_against_order(board,date,start_time,end_time,booking_types,camp_type)
    logger.info('booked_slots: '+str(booked_slots))
    free_slots=total_entitled_slots-booked_slots
    logger.info('free_slots: '+str(free_slots))
    logger.info("FREE_SLOTS_QUERIED: BOARD : "+str(board.board_name)+
                " DATE : "+str(date)+" FREE_UNITS : "+str(free_slots)+" AGANIST ENTITLEMENTS")
    if free_slots>0:
        return math.floor(free_slots)
    else:
        return 0
################################################################################
# Get the number of free slots for given screen on given date between times.
################################################################################    
def get_board_num_free_slots_against_order(board,date,start_time,end_time,dayPart,camp_type):
    logger.info( "get_board_num_free_slots "+ start_time.isoformat()+ " " + end_time.isoformat())
    
    #booking_date_limit_march = datetime.datetime(2017,3,31,0,0).date()
    booking_date_sixty_days = datetime.datetime.now().date()+timedelta(days=60)
    #booking_date_limit = min(booking_date_limit_march,booking_date_sixty_days)
    booking_date_limit  = booking_date_sixty_days
    if date > booking_date_limit:
        return 0
    
    st = datetime.datetime.now()
    st1 = st.replace(hour=start_time.hour,minute=start_time.minute,second=start_time.second)
    et1 = st.replace(hour=end_time.hour,minute=end_time.minute,second=end_time.second)
    td = et1 - st1
    td_seconds = td.total_seconds()
    total_slots = td_seconds / 30
    logger.info('total_slots: '+str(total_slots))
    '''
    td_days = find_diff_in_days(date)
    #if(td_days > 0):
    '''
    free_slots = 0
    booking_types=['affiliate_booking','Normal','auto_booking']
    booked_slots = get_board_booked_slots_against_order(board,date,start_time,end_time,booking_types,camp_type)
    logger.info('booked_slots: '+str(booked_slots))
    entitled_account=board.show_spot.account
    master_entitlement_obj=MasterEntitlement.objects.filter(day_part_entitled = dayPart,
                                                                account__key=entitled_account.key)
    total_entitled_slots=0
    if master_entitlement_obj is not None and len(master_entitlement_obj)>0:
        if camp_type == 'NORMAL':
            total_entitled_slots = float(master_entitlement_obj[0].percent_slots_entitled_association + 
                                    master_entitlement_obj[0].percent_slots_entitled_consumer)*float(total_slots) / 100
        else:
            total_entitled_slots = float(master_entitlement_obj[0].ticker_slots_entitled)*float(total_slots) / 100                            
    logger.info('total_entitled_slots: '+str(total_entitled_slots))
    free_slots = total_slots - booked_slots - total_entitled_slots
    '''
    else:
        booking_types=['affiliate_booking','Normal','auto_booking','consumer_booking','association_booking']
        booked_slots = get_board_booked_slots_against_order(board,date,start_time,end_time,booking_types,camp_type)
        logger.info('booked_slots: '+str(booked_slots))
        free_slots = total_slots - booked_slots
        
    #logger.info( "get_board_num_free_slots: " + str(math.floor(free_slots)))
    '''
    logger.info("FREE_SLOTS_QUERIED: BOARD : "+str(board.board_name)+ " DAYPART : "+str(dayPart.name)+
                " DATE : "+str(date)+" FREE_UNITS : "+str(free_slots)+" AGANIST ORDER")
    if free_slots >0:
        return math.floor(free_slots)
    else:
        return 0
#################################################################################
# Find the Master packs applicable.
#################################################################################
def find_master_packs(board,stat,start_time,end_time,num_plays,units_per_play,
    num_free_slots,master_packs):
    
    logger.info( 'find_master_packs ') 
    a_traffic_pattern = stat.associated_traffic
    master_pack_maps = MasterAdPackMappings.objects.filter(
        Q(traffic_pattern__key = a_traffic_pattern.key) &
        Q(location_attribute__name = board.show_spot.attached_primary_attribute_tag.name)
        )
    for packmap in master_pack_maps:
        logger.info( 'find_master_packs ' + packmap.traffic_pattern.name)
        mpack = packmap.maps_to_pack
        logger.info( 'find_master_packs ' + mpack.name + " "+ str(mpack.num_plays))
        if (mpack.num_plays <= num_plays and 
            mpack.units_per_play == units_per_play and
            mpack.state.name == 'LIVE') :
                num_slots_req = mpack.num_plays * mpack.units_per_play
                logger.info( 'find_master_packs - num slots req ' + str(num_slots_req))
                num_packs = num_free_slots / num_slots_req
                logger.info( 'find_master_packs - num packs '+ str(int(num_packs)))
                if num_packs > 0 :
                    master_packs.append(
                        {'pack':MasterAdPackShortSerializer(mpack).data,
                         'available':num_packs})
    return master_packs
#################################################################################
# Get the master packs.
#################################################################################
def get_master_pack(board,date,start_time,end_time,num_plays,units_per_play,dayPart):
    logger.info( 'get_master_pack ' + start_time.isoformat()+ " " + end_time.isoformat())
    logger.info( board.show_spot.attached_primary_location_tag.name)
    loc_stats = ScreenLocationTrafficStats.objects.filter(
        location__name = board.show_spot.attached_primary_location_tag.name)
    master_packs = []
    curr_start_time = start_time
    for stat in loc_stats:
        logger.info( 'get_master_pack '+ stat.location.name + " " + stat.day_part.from_time.isoformat()) 
        if stat.day_part.from_time == curr_start_time:
            #if stat.day_part.to_time >= end_time :
            if stat.day_part.to_time == end_time :
                num_free_slots = get_board_num_free_slots_against_order(board,date,curr_start_time,end_time,dayPart,'NORMAL')
                logger.info( 'get_master_pack ' + str(num_free_slots))
                found_packs = find_master_packs(board, stat, start_time, 
                    end_time, num_plays, units_per_play, num_free_slots,
                    master_packs)
                #master_packs.append(found_packs)
                break
            '''
            else :
                num_free_slots = get_board_num_free_slots_against_order(board,date,
                    curr_start_time,stat.day_part.to_time,day_part,'NORMAL')
                found_packs = find_master_packs(board, stat, start_time, 
                    end_time, num_plays, units_per_play, num_free_slots,
                    master_packs)
                #master_packs.append(found_packs)
                curr_start_time = stat.day_part.to_time
                '''
    return master_packs
