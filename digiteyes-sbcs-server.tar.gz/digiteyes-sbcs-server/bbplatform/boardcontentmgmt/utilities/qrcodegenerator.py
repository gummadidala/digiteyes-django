import qrcode
from boardcontentmgmt.tasks import create_random_temp_file,upload_file_to_remote_storage
from datetime import datetime
import os

def generate_and_upload_qrcode(data,acct_name):
    try:
        print "In generate_and_upload_qrcode"
        qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L,
                           box_size=10,border=4,)
        qr.add_data(data)
        qr.make(fit=True)
        img = qr.make_image()
        temp_file_img = create_random_temp_file("qrcode","PNG")
        image_file = open(temp_file_img,'w+') 
        img.save(image_file) 
        image_file.close()
        str_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        thumb_url = upload_file_to_remote_storage(temp_file_img, str_date+"_qrcode"+".png",acct_name,
                                                 "image/png",'MEDIA')
        if os.path.exists(temp_file_img):
            os.remove(temp_file_img)
        return thumb_url
    except:
        if os.path.exists(temp_file_img):
            os.remove(temp_file_img)
        return ""