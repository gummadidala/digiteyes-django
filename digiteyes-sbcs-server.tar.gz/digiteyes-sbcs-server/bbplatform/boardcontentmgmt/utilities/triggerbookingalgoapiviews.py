from rest_framework.views import APIView
from rest_framework import generics
from boardcontentmgmt.tasks import Call_AllocationAlgorithm
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED,HTTP_400_BAD_REQUEST
from boardcontentmgmt.models import TrackBookingAlgo, AccountUser,Board,DayPart
from boardcontentmgmt.utilities.triggerbookingalgoserializers import TrackBookingAlgoSerializer,TrackBookingAlgoWriteSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework.permissions import IsAuthenticated

import datetime
################################################################################
#List API View for  Trigger Booking Algorithm
################################################################################
class TriggerBookingAlgorithmListAPIView(generics.ListCreateAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class  = TrackBookingAlgoSerializer
    queryset = TrackBookingAlgo.objects.all().order_by('-trigger_time')
    
    def post(self,request):
        parsed_data = request.data
        screen_list = []
        if 'screens' in parsed_data and parsed_data['screens'] != "":
        #if screens is not None and len(screens)>0:
            screens = parsed_data['screens']
            list = screens.split(',')
            for scrn in list:
                print scrn
                brd_obj = Board.objects.filter(key = scrn)
                if brd_obj is not None and len(brd_obj) > 0:
                   screen_list.append(scrn) 
                else:
                    return Response({'error':scrn+' is not found in system'},status=HTTP_400_BAD_REQUEST)
        daypart_list = []
        if 'dayparts' in parsed_data and parsed_data['dayparts'] != "":
            dayparts = parsed_data['dayparts']
            list = dayparts.split(',')
            for d in list:
                dp_obj = DayPart.objects.filter(name=d)
                if dp_obj is not None and len(dp_obj)>0:
                    daypart_list.append(d)
                else:
                    return Response({'error':d+' is not found in system'},status=HTTP_400_BAD_REQUEST)
        Call_AllocationAlgorithm.delay(screen_list,daypart_list)
        '''
        parsed_data = request.data
        parsed_data['trigger_time'] = datetime.datetime.now()
        serializer = TrackBookingAlgoWriteSerializer(data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)
        '''
        data = {'trigger_time':datetime.datetime.now(),
                'status' :'Success! :)'}
        return Response(data,status=HTTP_201_CREATED)
        
