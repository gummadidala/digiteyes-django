'''
Created on 11-Feb-2017

@author: saba
'''
def get_all_perms(model_name,apps):
    Permission = apps.get_model("auth", "Permission")
    ContentType = apps.get_model("contenttypes", "ContentType")
    types = ContentType.objects.filter(app_label='boardcontentmgmt').filter(model=model_name)
    view_all = Permission.objects.filter(content_type__in=types).filter(codename='view_all_'+model_name)
    can_approve = Permission.objects.filter(content_type__in=types).filter(codename='can_approve_'+model_name)
    can_reject = Permission.objects.filter(content_type__in=types).filter(codename='can_reject_'+model_name)
    del_perms = []
    if len(view_all) > 0:
        del_perms.append(view_all[0].codename)
    if len(can_approve) > 0:
        del_perms.append(can_approve[0].codename)
    if len(can_reject) > 0:
        del_perms.append(can_reject[0].codename)
    perms = Permission.objects.filter(content_type__in=types).exclude(codename__in=del_perms)
    return perms
##################################################################################
# creates a new group and adds the given models 3 perms (add, edit, delete) into
# the group.
#################################################################################
def add_new_group(group_name,model,apps):
    Group = apps.get_model("auth", "Group")
    Permission = apps.get_model("auth", "Permission")
    g = Group()
    g.name=group_name
    g.save()
    perms=get_all_perms(model,apps)
    for perm in perms:
        g.permissions.add(perm)
        g.save()
##################################################################################
# creates a new group and adds the given models 3 perms (add, edit, delete) into
# the group.
#################################################################################
def add_to_existing_group(group_name,model_name,apps):
    Group = apps.get_model("auth", "Group")
    Permission = apps.get_model("auth", "Permission")
    g = Group.objects.filter(name = group_name)[0]
    perms = get_all_perms(model_name, apps)
    for perm in perms:
        perm_obj = Permission.objects.filter(codename=perm.codename)
        g.permissions.add(perm_obj[0])
        g.save()
##################################################################################
# Adds the given list of permissions to view_all group
##################################################################################
def add_to_view_all(view_all_list,apps):
    Group = apps.get_model("auth", "Group")
    Permission = apps.get_model("auth", "Permission")
    g = Group.objects.filter(name = 'view_all')[0]
    view_all_perms = view_all_list
    for perm in view_all_perms:
        perm_obj = Permission.objects.filter(codename=perm)
        g.permissions.add(perm_obj[0])
        g.save()
####################################################################################
# Adds the given permission group to the given profile.
# And also gives the permission to all the existing user with the profile.
#####################################################################################        
def add_group_to_profile(profile_to_add_name,group_name,apps):
    UserProfile = apps.get_model("boardcontentmgmt", "UserProfile")
    AccountUser = apps.get_model("boardcontentmgmt", "AccountUser")
    Group = apps.get_model("auth", "Group")
    Permission = apps.get_model("auth", "Permission")
    profiles = UserProfile.objects.filter(profile_name=profile_to_add_name)
    grps = [group_name]
    user_groups = Group.objects.filter(name__in=grps)
    for prof in profiles:
        for g in user_groups:
            prof.user_groups.add(g)
            prof.save()
    usrs = AccountUser.objects.filter(user_profiles__in = profiles)
    for usr in usrs:
        prev_groups =usr.account_user.groups.all()
        if(len(prev_groups) > 0):
            for grp in prev_groups:
                usr.account_user.groups.remove(Group.objects.get(name=grp.name))
                usr.account_user.save()
            #adding user groups   
        for each_profile in profiles:
            for each_group in each_profile.user_groups.all(): 
                usr.account_user.groups.add(Group.objects.get(name=each_group.name))
                usr.account_user.save()
                