from rest_framework import serializers
from boardcontentmgmt.models import City,SpotLocationType,ScreenSize,ScreenOrientation
from boardcontentmgmt.models import ShowSpotAssetState, SignalQuality, RequestState,ContentType
from boardcontentmgmt.models import ContentState, CTAType, ScreenStatus, DayQualifier,ItemType
from boardcontentmgmt.models import CampaignState,PackState,BookingState, AccountType,DeviceControlCommand
from boardcontentmgmt.models import  ContentLabel,LayoutLabel,LayoutMapping,PromoParam,ConditionOperator
from boardcontentmgmt.models import CampaignType,ContentQueueType,AppType, TransactionReason,RpiControlCommand
from boardcontentmgmt.models import VoucherCtaType,VoucherCTAState
class CitySerializer(serializers.ModelSerializer):
    class Meta:
        model= City
        fields = ['city_name',]
class SpotLocationTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model= SpotLocationType
        fields = ['name',]
class ScreenSizeSerializer(serializers.ModelSerializer):
    class Meta:
        model= ScreenSize
        fields = ['name',]

class ScreenOrientationSerializer(serializers.ModelSerializer):
    class Meta:
        model= ScreenOrientation
        fields = ['name',]

class ShowSpotAssetStateSerializer(serializers.ModelSerializer):
    class Meta:
        model= ShowSpotAssetState
        fields = ['name',]

class SignalQualitySerializer(serializers.ModelSerializer):
    class Meta:
        model= SignalQuality
        fields = ['name',]

class RequestStateSerializer(serializers.ModelSerializer):
    class Meta:
        model= RequestState
        fields = ['name',]

class ContentTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model= ContentType
        fields = ['type_name',]

class ContentStateSerializer(serializers.ModelSerializer):
    class Meta:
        model= ContentState
        fields = ['state_name',]

class CTATypeSerializer(serializers.ModelSerializer):
    class Meta:
        model= CTAType
        fields = ['name',]
class ScreenStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model= ScreenStatus
        fields = ['name',]
class DayQualifierSerializer(serializers.ModelSerializer):
    class Meta:
        model= DayQualifier
        fields = ['name',]
class CampaignStateSerializer(serializers.ModelSerializer):
    class Meta:
        model= CampaignState
        fields = ['state_name',]
        
class PackStateSerializer(serializers.ModelSerializer):
    class Meta:
        model= PackState
        fields = ['name',]
class BookingStateSerializer(serializers.ModelSerializer):
    class Meta:
        model= BookingState
        fields = ['name',]
class AccountTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model= AccountType
        fields = ['type_name','type_of_customer','key']
class DeviceControlCommandSerializer(serializers.ModelSerializer):
    class Meta:
        model= DeviceControlCommand
        fields = ['name','key']
class RpiControlCommandSerializer(serializers.ModelSerializer):
    class Meta:
        model= RpiControlCommand
        fields = ['name','key']
class ItemTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model= ItemType
class ContentLabelSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContentLabel
        fields = ['name']
class LayoutLabelSerializer(serializers.ModelSerializer):
    class Meta:
        model = LayoutLabel
        fields = ['name']
class PromoParamSerializer(serializers.ModelSerializer):
    class Meta:
        model = PromoParam
        fields = ['name']
class ConditionOperatorSerializer(serializers.ModelSerializer):
    class Meta:
        model = ConditionOperator
        fields = ['value']
class CampaignTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = CampaignType
        fields = ['name']
class ContentQueueTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContentQueueType
        fields = ['name']
class AppTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = AppType
        fields = ['type']
class TransactionReasonSerializer(serializers.ModelSerializer):
    class Meta:
        model = TransactionReason
        fields = ['key','reason_text']
class VoucherCtaTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = VoucherCtaType
        fields = ['name','key']
class VoucherCTAStateSerializer(serializers.ModelSerializer):
    class Meta:
        model = VoucherCTAState
        fields = ['name']