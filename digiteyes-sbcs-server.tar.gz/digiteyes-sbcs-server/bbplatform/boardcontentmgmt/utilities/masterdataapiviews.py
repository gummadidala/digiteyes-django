
from rest_framework.views import APIView

from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from .masterdataserializers import *
from boardcontentmgmt.models import *
from rest_framework.response import Response
from boardcontentmgmt.adpackmgmt.masteradpackserializers import DayPartSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication

class MasterDataListView(APIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    def get(self,request,format = None):
        master_data = [{'name':'AccountType',
                        'model':AccountType,'serializer_class':AccountTypeSerializer},
                       {'name':'City',
                        'model':City,'serializer_class':CitySerializer},
                       {'name':'SpotLocationType',
                        'model':SpotLocationType,'serializer_class':SpotLocationTypeSerializer},
                       {'name':'ScreenSize',
                        'model':ScreenSize,'serializer_class':ScreenSizeSerializer},
                       {'name':'ScreenOrientation',
                        'model':ScreenOrientation,'serializer_class':ScreenOrientationSerializer},
                       {'name':'ShowSpotAssetState',
                        'model':ShowSpotAssetState,'serializer_class':ShowSpotAssetStateSerializer},
                       {'name':'SignalQuality',
                        'model':SignalQuality,'serializer_class':SignalQualitySerializer},
                       {'name':'RequestState',
                        'model':RequestState,'serializer_class':RequestStateSerializer},
                       {'name':'ContentType',
                        'model':ContentType,'serializer_class':ContentTypeSerializer},
                       {'name':'ContentState',
                        'model':ContentState,'serializer_class':ContentStateSerializer},
                       {'name':'CTAType',
                        'model':CTAType,'serializer_class':CTATypeSerializer},
                       {'name':'ScreenStatus',
                        'model':ScreenStatus,'serializer_class':ScreenStatusSerializer},
                       {'name':'DayQualifier',
                        'model':DayQualifier,'serializer_class':DayQualifierSerializer},
                       {'name':'CampaignState',
                        'model':CampaignState,'serializer_class':CampaignStateSerializer},
                       {'name':'PackState',
                        'model':PackState,'serializer_class':PackStateSerializer},
                       {'name':'BookingState',
                        'model':BookingState,'serializer_class':BookingStateSerializer},
                       {'name':'DayPart',
                        'model':DayPart,'serializer_class':DayPartSerializer},
                       {'name':'DeviceControlCommand',
                        'model':DeviceControlCommand,'serializer_class':DeviceControlCommandSerializer},
                       {'name':'RpiControlCommand',
                        'model':RpiControlCommand,'serializer_class':RpiControlCommandSerializer},
                       {'name':'ItemType',
                        'model':ItemType,'serializer_class':ItemTypeSerializer},
                       {'name':'ContentLabel',
                        'model':ContentLabel,'serializer_class':ContentLabelSerializer},
                       {'name':'LayoutLabel',
                        'model':LayoutLabel,'serializer_class':LayoutLabelSerializer},
                       {'name':'PromoParam',
                        'model':PromoParam,'serializer_class':PromoParamSerializer},
                       {'name':'ConditionOperator',
                        'model':ConditionOperator,'serializer_class':ConditionOperatorSerializer},
                       {'name':'CampaignType',
                        'model':CampaignType,'serializer_class':CampaignTypeSerializer},
                       {'name':'ContentQueueType',
                        'model':ContentQueueType,'serializer_class':ContentQueueTypeSerializer},
                       {'name':'AppType',
                        'model':AppType,'serializer_class':AppTypeSerializer},
                       {'name':'TransactionReason',
                        'model':TransactionReason,'serializer_class':TransactionReasonSerializer},
                       {'name':'RpiControlCommand',
                        'model':RpiControlCommand,'serializer_class':RpiControlCommandSerializer},
                       {'name':'VoucherCtaType',
                        'model':VoucherCtaType,'serializer_class':VoucherCtaTypeSerializer},
                       {'name':'VoucherCTAState',
                        'model':VoucherCTAState,'serializer_class':VoucherCTAStateSerializer},]
        
        serialized_master_data_list = {}
        for data in master_data:
            name = data['name']
            if name == 'DayPart':
                objects = data['model'].objects.all().order_by('from_time')
            else:
                objects = data['model'].objects.all()
            serializer = data['serializer_class'](objects,many=True)
            serialized_master_data_list[name]=serializer.data
        return Response(serialized_master_data_list)
            
            
            
            
            
