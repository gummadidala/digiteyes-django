'''
Created on 15-Oct-2016

@author: saba
'''
from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from django.http.response import Http404
from django.shortcuts import render
from boardcontentmgmt.models import ShowSpotAsset, Board , BoardPlayHistory, DayPart,ContentTarget,Content
from boardcontentmgmt.models import CampaignInterests
import datetime
import sys, zipfile
import traceback
from datetime import timedelta
from django.template.loader import get_template
from django.template import Context
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from django.contrib.auth.models import User
from boardcontentmgmt.models import AccountUser,Account,ConsumerContentTargets
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.consumermgmt.consumerserializers import ConsumerContentTargetSerializer

import logging
logger = logging.getLogger(__name__)

def get_anonymous_user_token():
    usr = User.objects.filter(username='anonymoususer')[0]
    token=Token.objects.get_or_create(user=usr)[0]
    n=8
    token_array = [str(token.key)[i:i+n] for i in range(0, len(str(token.key)), n)]
    return token_array


def create_campaigninterest(playhistory):
    ci = CampaignInterests()
    ci.interested_content = playhistory.content_played.content_target
    ci.assoc_campaign = playhistory.campaign
    ci.interest_time = datetime.datetime.now()
    ci.save()
def get_campaign_key(ct,play_histories):
    res = []
    contents = Content.objects.filter(content_target__key = ct.key)
    if contents is not None and len(contents) >0:
        for cntnt in contents:
            play_history = BoardPlayHistory.objects.filter(content_played__key = cntnt.key)
            if play_history is not None and len(play_history)>0:
                for pl in play_history:
                    for plh in play_histories:
                        if str(pl.key) == str(plh.key):
                            res=str(plh.campaign.key).split('-')
    return res
def get_content_key(ct,play_histories):
    res = []
    contents = Content.objects.filter(content_target__key = ct.key)
    if contents is not None and len(contents) >0:
        for cntnt in contents:
            play_history = BoardPlayHistory.objects.filter(content_played__key = cntnt.key)
            if play_history is not None and len(play_history)>0:
                for pl in play_history:
                    for plh in play_histories:
                        if str(pl.key) == str(plh.key):
                            res=str(cntnt.key).split('-')
    return res
def get_board_playhistory(board,minute):
    logger.debug("In get_board_playhistory->"+ " board: "+ str(board.board_name)+" time_string: "+str(minute))
    day_parts = DayPart.objects.all()
    dp_start_time = day_parts[0].from_time
    start_day = datetime.date.today()
    start_time = datetime.datetime.combine(start_day,dp_start_time)
    start_time = start_time + timedelta(minutes=minute-1)
    logger.info("pull_product start time:"+str(start_time))
    end_time = start_time + timedelta(minutes=2)
    logger.info("pull_product end time:"+str(end_time))
    return BoardPlayHistory.objects.filter(board__key=board.key, 
        content_from_time__gte=start_time, content_to_time__lte=end_time).order_by('-content_from_time')
    
def create_dynamic_html_content(play_histories):
    res_obj = {}
    res_obj['title']=''
    html_content_list = []
    content_target_list = []
    duplicate_content_target_list = []
    for ph in play_histories:
        if ph.content_played.content_target is not None:
            create_campaigninterest(ph)
            ct = ph.content_played.content_target
            if str(ct.key) not in duplicate_content_target_list:
                duplicate_content_target_list.append(str(ct.key))
    if len(duplicate_content_target_list) > 0:
        for ctl in duplicate_content_target_list:
            cntnt_target = ContentTarget.objects.filter(key=ctl)
            content_target_list.append(cntnt_target[0])
    if len(content_target_list)>0:
        k=0
        for ct in content_target_list:
            ct_obj = {}
            ct_obj['token'] = get_anonymous_user_token()
            ct_obj['content_key']  = get_content_key(ct,play_histories)
            ct_obj['campaign_key'] = get_campaign_key(ct,play_histories)
            if hasattr(ct, 'target_image_url'):
                ct_obj['target_image_url']=ct.target_image_url
            if hasattr(ct, 'target_title'):
                ct_obj['target_title']=ct.target_title
                if res_obj['title'] == '':
                    res_obj['title'] = ct.target_title
            if hasattr(ct, 'target_description'):
                ct_obj['target_description']=ct.target_description
            str_key = []
            str_key = str(ct.key).split('-')
            ct_obj['ct_key']=str_key
            ct_obj['index']=k
            if hasattr(ct, 'target_cta'):
                cta_list = []
                for cta in ct.target_cta.all():
                    cta_obj = {'cta_type':cta.type.name}
                    if hasattr(cta, 'call_number'):
                        cta_obj['call_number'] = cta.call_number
                    if hasattr(cta, 'url'):
                        cta_obj['url'] = cta.url
                    if hasattr(cta, 'app_name'):
                        cta_obj['app_name'] = cta.app_name
                    if hasattr(cta, 'app_link'):
                        cta_obj['app_link'] = cta.app_link
                    cta_list.append(cta_obj)
                ct_obj['cta'] = cta_list
                html_content_list.append(ct_obj)
            k=k+1
    if 'title' not in res_obj:
        res_obj['title'] = 'Adiot'
    res_obj['html_content_list'] = html_content_list
    return res_obj

def get_product_giventime(request,pid):
    logger.info(str(request.META))
    logger.info(str(request.COOKIES))
    b_key=pid[:-3]
    t_stamp=pid[-3:]
    t_int = int(t_stamp)
    boards = Board.objects.filter(beacon_key = b_key)
    unknown_token = get_anonymous_user_token()
    if boards and len(boards) == 1 :
        play_histories=get_board_playhistory(boards[0], t_int)
        logger.info("length of play_histories:"+str(len(play_histories)))
        html_content_list = []
        if play_histories is not None and len(play_histories)>0:
            res = create_dynamic_html_content(play_histories)
            return render(request,
                          'productpage.html',
                          {'html_contents':res['html_content_list'],'title':res['title'],'token':unknown_token})
    return render(request,'productpage.html')
def get_minutes():
    day_parts = DayPart.objects.all()
    dp_start_time = day_parts[0].from_time
    current_time =  str(datetime.datetime.now().time())
    minute_string = (int(current_time.split(':')[0]) - int(str(dp_start_time).split(':')[0]))*60+int(current_time.split(':')[1])
    return minute_string
def get_product_servertime(request,pid):
    logger.info(str(request.META))
    logger.info(str(request.COOKIES))
    b_key=pid    
    t_int = int(get_minutes())
    unknown_token = get_anonymous_user_token()
    boards = Board.objects.filter(beacon_key = b_key)
    if boards and len(boards) == 1 :
        play_histories=get_board_playhistory(boards[0], t_int)
        logger.info("length of play_histories:",str(len(play_histories)))
        html_content_list = []
        if play_histories is not None and len(play_histories)>0:
            res = create_dynamic_html_content(play_histories)
            return render(request,
                          'productpage.html',
                          {'html_contents':res['html_content_list'],'title':res['title'],'token':unknown_token})
    return render(request,'productpage.html')


#################################################################################
# Board List API List View
#################################################################################
def create_consumercontenttargets(play_histories,acct,brd):
    spot = ShowSpotAsset.objects.filter(key=brd.show_spot.key)
    ct_list=[]
    try:
        cntnt_targets = ConsumerContentTargets.objects.filter(account__key=acct.key,
                                                              time__gte=datetime.datetime.now().replace(hour=0,minute=0,second=0,microsecond=0))
        camp_list=[]
        target_list=[]
        content_list = []
        temp_camp_list=[]
        temp_ct_list=[]
        temp_cntnt_list = []
        logger.debug("length of cntnt_targets:"+str(len(cntnt_targets)))
        logger.debug("length of playhistories:"+str(len(play_histories)))
        if cntnt_targets is not None and len(cntnt_targets)>0:
            for ctt in cntnt_targets:
                camp_list.append(str(ctt.campaign))
                target_list.append(str(ctt.content_target.target_image_url))
                content_list.append(str(ctt.content.key))
        logger.info('create_consumercontenttargets__target_list'+str(target_list))
        if spot is not None and len(spot)>0:
            for plh in play_histories:
                #if str(plh.campaign.key) not in camp_list and str(plh.campaign.key) not in temp_camp_list and plh.content_played.content_target is not None:
                    #logger.info("Image_url_step1:"+str(plh.content_played.content_target.target_image_url))
                    #if str(plh.content_played.key) not in content_list and str(plh.content_played.key) not in temp_cntnt_list:
                        #logger.info("Image_url_step2:"+str(plh.content_played.content_target.target_image_url))
                        if plh.content_played.content_target is not None: #and str(plh.content_played.content_target.target_image_url) not in target_list and str(plh.content_played.content_target.target_image_url) not in temp_ct_list:
                            ct = ConsumerContentTargets()
                            ct.show_spot_location_lat = spot[0].spot_location_lat
                            ct.show_spot_location_long = spot[0].spot_location_long
                            ct.show_spot_location_key = spot[0].key
                            ct.show_spot_location_image_url = spot[0].spot_location_image_url
                            ct.show_spot_beacon_touched = spot[0].attached_beacons.all()[0].mac_address
                            ct.content_target = plh.content_played.content_target
                            ct.content = plh.content_played
                            ct.time = plh.content_to_time
                            ct.campaign = plh.campaign.key
                            ct.account = acct
                            ct.save()
                            ct_list.append(ct)
                            temp_camp_list.append(str(plh.campaign.key))
                            temp_cntnt_list.append(str(plh.content_played.key))
                            temp_ct_list.append(str(plh.content_played.content_target.target_image_url))
        return ct_list
    except:
        logger.error ("Error while creating consumer content target"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("Stack Trace: "+str(tb))
        return ct_list
    
class ConsumerAppContentTargetsView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = ConsumerContentTargetSerializer
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    def get_queryset(self):
        return Response("Nothing to do with get call on this API",status=HTTP_400_BAD_REQUEST)
    def post(self, request, *args, **kwargs):
        username = self.request.user.username
        acct_user = AccountUser.objects.filter(account_user__username=username)
        acct = acct_user[0].account
        if 'beacon_string' in request.data:
            beacon_string = request.data['beacon_string']
            logger.debug('Beacon_string got:'+str(beacon_string))
            b_key=beacon_string[:-3]
            t_stamp=beacon_string[-3:]
            t_int = int(t_stamp)
            boards = Board.objects.filter(beacon_key = b_key)
            if boards and len(boards) >0 :
                logger.debug("Borad_name:"+str(boards[0].board_name))
                play_histories=get_board_playhistory(boards[0], t_int)
                logger.info("length of play_histories:"+str(len(play_histories)))
                if boards[0].show_spot is None:
                    error = {'error':'Board is not assigned to any showspot!'}
                    return Response(error,status=HTTP_400_BAD_REQUEST)
                if play_histories is not None and len(play_histories)>0:
                    res = create_consumercontenttargets(play_histories,acct,boards[0])
                    logger.debug("length of consumer content targets created is:"+str(len(res)))
                    return Response("Created successfully!",status=HTTP_201_CREATED)
            else:
                error = {'error':'beacon_string does not match with any board!'}
                return Response(error,status=HTTP_400_BAD_REQUEST)
        else:
            error = {'error':'beacon_string is needed!'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        return generics.ListCreateAPIView.post(self, request, *args, **kwargs)
