from __future__ import division
from boardcontentmgmt.models import BookedAdPack
from datetime import datetime,timedelta
import logging,math,sys,traceback
from boardcontentmgmt.models import BookedAdPack,BookedSlot,DayPart,CampaignState,ContentQueue,BookingState,Board,Account, AccountUser,AdvtCampaign
from boardcontentmgmt.models import AffiliateContent,AttributeTagGroup,ShowSpotAsset,TrackBookingAlgo
logger = logging.getLogger("boardcontentmgmt.tasks")

def get_available_day_parts(date):
    print 'In get_available_day_parts'
    logger.info('In get_available_day_parts for date : '+str(date))
    all_dayparts = DayPart.objects.all().order_by('from_time')
    if date > datetime.now().date():
        return all_dayparts
    available_dayparts = []
    current_time = datetime.now()
    for each_dp in all_dayparts:
        from_time = each_dp.from_time
        dt = datetime.combine(datetime.now().date(),from_time)
        dp_start_time = dt + timedelta(minutes=-40)# advertisement has to place 30 mins before the start of day_part
        if current_time <= dp_start_time:
            logger.info(str(each_dp.name))
            available_dayparts.append(each_dp)
    return available_dayparts

def find_diff_in_secs(time1,time2):
    st = datetime.now()
    st1 = st.replace(hour=time1.hour,minute=time1.minute,second=time1.second)
    et1 = st.replace(hour=time2.hour,minute=time2.minute,second=time2.second)
    td = et1 - st1
    td_seconds = td.total_seconds()
    if td_seconds < 0:
        td_seconds = -td_seconds
    return td_seconds
def get_daypart():
    day_parts=DayPart.objects.all().order_by('from_time')
    res = day_parts[0]
    check =  sys.maxint
    for dp in day_parts:
        time_gap = find_diff_in_secs(dp.from_time,datetime.now().time())
        if time_gap < check:
            check = time_gap
            res = dp      
    return [res]     
def GetNumOfUnits_DayPart(day_part):
    st = datetime.now()
    st1 = st.replace(hour=day_part.from_time.hour,minute=day_part.from_time.minute,second=day_part.from_time.second)
    et1 = st.replace(hour=day_part.to_time.hour,minute=day_part.to_time.minute,second=day_part.to_time.second)
    td = et1 - st1
    td_seconds = td.total_seconds()
    total_slots = int(td_seconds / 30)
    return total_slots

def convert_string_to_datetime(_date):
    strings = _date.split('-')
    date = date = datetime(int(strings[0]),int(strings[1]),int(strings[2])).date()
    return date

def ValidateAlgorithm(_date,day_part,board):
    try:
        dp = DayPart.objects.filter(name=day_part)[0]
        brd = Board.objects.filter(key=board)[0]
        date = convert_string_to_datetime(_date)
        logger.info("ALLOCATION_ALGO_VALIDATION_START : DAYPART : "+str(day_part)+
                    " DATE : "+str(date) +" SCREEN : "+str(brd.board_name))
        config_unit_size = 0
        production_cntnt = ContentQueue.objects.filter(content_queue_name = 'production_playlist')
        if production_cntnt is not None and len(production_cntnt)>0:
            config_unit_size = production_cntnt[0].unit_size/30
        ############################################################################
        #Checks for Over booking,Under booking, Matching the DayPart time 
        last_slot_booked_time = datetime.now()+timedelta(days=-1)
        normal_bookedPacks = BookedAdPack.objects.filter(date_booked_for=date,day_part_booked_for=dp,
                                                         booked_screen__key=brd.key,
                                                         applied_to__type__name = 'NORMAL',
                                                         booking_state__name = 'SUCCESS').exclude(booking_type__in =['auto_booking','empty_booking'])
        auto_bookedPacks = BookedAdPack.objects.filter(date_booked_for=date,day_part_booked_for=dp,
                                                       booked_screen__key=brd.key,booking_type__in =['auto_booking','empty_booking'],
                                                       applied_to__type__name = 'NORMAL',
                                                       booking_state__name = 'SUCCESS')
        total_units_asked_to_book = 0
        total_actual_units_booked = 0
        bookedappack_info = []
        for each_bp in normal_bookedPacks:
            each_bp_units_asked_to_book = each_bp.num_plays*each_bp.units_per_play*each_bp.unit_size/30
            each_bp_actual_units_booked =0
            total_units_asked_to_book += each_bp_units_asked_to_book
            booked_slots = each_bp.slots_booked.all()
            for sb in booked_slots:
                each_bp_actual_units_booked += (sb.num_units*sb.unit_size/30)
                dt = datetime.combine(date,sb.start_time)
                sb_end_time = dt + timedelta(seconds=sb.num_units*sb.unit_size)
                if last_slot_booked_time < sb_end_time:
                    last_slot_booked_time = sb_end_time
            bap_obj = {'campaign':each_bp.applied_to.name,
                       'asked units_to_book':each_bp_units_asked_to_book,
                       'actual_units_booked':each_bp_actual_units_booked}
            bookedappack_info.append(bap_obj)
            total_actual_units_booked += each_bp_actual_units_booked
        auto_booked_slots= []
        if auto_bookedPacks is not None and len(auto_bookedPacks) > 0:
            total_units_asked_to_book += auto_bookedPacks[0].num_plays*config_unit_size
            auto_booked_slots = auto_bookedPacks[0].slots_booked.all()
            total_actual_units_booked += len(auto_booked_slots)*config_unit_size
            for asd in auto_booked_slots:
                dt = datetime.combine(date,asd.start_time)
                sb_end_time = dt + timedelta(seconds=asd.num_units*asd.unit_size)
                if last_slot_booked_time < sb_end_time:
                    last_slot_booked_time = sb_end_time
            bap_obj = {'campaign':auto_bookedPacks[0].applied_to.name,
                       'asked units_to_book':auto_bookedPacks[0].num_plays*config_unit_size,
                       'actual_units_booked':len(auto_booked_slots)*config_unit_size}
            bookedappack_info.append(bap_obj)
        ############################################################################
        #Duplicate Check
        brd_bookedadpacks = BookedAdPack.objects.filter(date_booked_for=date,booked_screen__key=brd.key,
                                                        applied_to__type__name = 'NORMAL',
                                                        day_part_booked_for=dp,
                                                        booking_state__name = 'SUCCESS')
        brd_booked_slots = []
        duplicate_entries = []
        duplicate = False
        for bap in brd_bookedadpacks:
            brd_booked_slots.extend(bap.slots_booked.all())
        for bbs in brd_booked_slots:
            for i in range(len(brd_booked_slots)):
                count = 0
                if bbs == brd_booked_slots[i]:
                    count += 1
                if count > 1 :
                    duplicate = True
                    duplicate_entries.append(str(bbs.start_time))
        duplicate_info = {'duplicates':duplicate,
                          'duplicate_entries':duplicate_entries}
        ############################################################################
        #Overlap Check
        brd_bookedadpacks = BookedAdPack.objects.filter(date_booked_for=date,booked_screen__key=brd.key,
                                                        applied_to__type__name = 'NORMAL',
                                                        day_part_booked_for=dp,
                                                        booking_state__name = 'SUCCESS')
        brd_booked_slots = []
        overlapped_entries = []
        overlap = False
        for bap in brd_bookedadpacks:
            brd_booked_slots.extend(bap.slots_booked.all())
        brd_booked_slots.sort(key=lambda r: r.start_time)
        for i in range(len(brd_booked_slots)):
            dt = datetime.combine(date,brd_booked_slots[i].start_time)
            next_slot_time = dt + timedelta(seconds=brd_booked_slots[i].num_units*brd_booked_slots[i].unit_size)
            if i < len(brd_booked_slots)-1:
                if next_slot_time.time() != brd_booked_slots[i+1].start_time:
                    obj = {'strt_time':str(brd_booked_slots[i].start_time),
                           'unit_size':brd_booked_slots[i].unit_size,
                           'end_time':str(brd_booked_slots[i+1].start_time)}
                    overlapped_entries.append(obj)
                    overlap = True    
        overlap_info = {'overlaps':overlap,
                        'overlapped_entries':overlapped_entries}
        ############################################################################
        total_dp_units = GetNumOfUnits_DayPart(dp)
        overall_info = {'last_slot_booked_time':str(last_slot_booked_time.time()),
                        'day_part_end_time':str(dp.to_time),
                        'Total_units_available_in_day_plart':total_dp_units,
                        'total_units_asked_to_book':total_units_asked_to_book,
                        'total_units_booked':total_actual_units_booked,
                        'overlap_entries_info':overlap_info,
                        'duplicate_entries_info':duplicate_info,
                        'auto_booked_slots': len(auto_booked_slots),
                        'All_booked_ap_packs_info': bookedappack_info
                        }
        logger.info("ALLOCATION_ALGO_VALIDATION_STATUS : "+str(overall_info))
    except:
        logger.error ("ALLOCATION_ALGO_VALIDATION_ERROR "+ str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("ALLOCATION_ALGO_VALIDATION_ERROR "+str(tb))
    
    logger.info("ALLOCATION_ALGO_VALIDATION_END : DAYPART : "+str(day_part)+
                    " DATE : "+str(_date))