from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from rest_framework.response import Response
import json
import re
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from boardcontentmgmt.models import PPTConversion,Content,ContentState,ContentType
from rest_framework import serializers
from boardcontentmgmt.tasks import fill_content_length
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions

import logging
logger = logging.getLogger(__name__)

class PPTSerializer(serializers.ModelSerializer):
    class Meta:
        model = PPTConversion
        fields = ['key','status','ppt_url','conversion_id','video_url','content_key']
        
class GetPPTAPIViewForClient(generics.ListCreateAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,DjangoModelPermissions,DjangoObjectPermissions,)
    def get_queryset(self):
        ppt_info_List = PPTConversion.objects.filter(status="SUBMITTED")
        return ppt_info_List
    def post(self,request):
        parsed_data = request.data
        ppt_info = PPTConversion()
        ppt_info.ppt_url = parsed_data['ppt_url']
        ppt_info.content_key = parsed_data['content_key']
        ppt_info.status = 'SUBMITTED'
        ppt_info.save()
        return Response("Success")
    
class GetPPTAPIViewForWSListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = PPTSerializer
    def get_queryset(self):
        ppt_info_List = PPTConversion.objects.filter(status="SUBMITTED")
        return ppt_info_List
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return PPTSerializer
        return PPTSerializer
    
class GetPPTAPIViewForWSUpdateView(generics.RetrieveUpdateDestroyAPIView):
    lookup_field = 'key'
    serializer_class = PPTSerializer
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    def get_queryset(self):
        return PPTConversion.objects.all()
    '''
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return PPTWriteSerializer
        return PPTSerializer
    '''
    def put(self,request,key,format=None,**kwargs):
        obj=PPTConversion.objects.get(key=key)
        validated_data = request.data
        logger.debug("Incoming patch request from windows server : "+str(validated_data))
        draft_state = ContentState.objects.filter(state_name = 'DRAFT')
        failed_state = ContentState.objects.filter(state_name = 'FAILED')
        video_type=ContentType.objects.filter(type_name = 'VIDEO')
        if validated_data['status']=='COMPLETED':
            content_obj = Content.objects.filter(key=validated_data['content_key'])
            if content_obj is not None and len(content_obj)>0:
                content_obj[0].content_source=validated_data['video_url']
                content_obj[0].content_type = video_type[0]
                #content_obj[0].content_state=draft_state[0]
                content_obj[0].save()
            pptconversion_obj = PPTConversion.objects.filter(content_key=validated_data['content_key'])
            pptconversion_obj.status=validated_data['status']
            fill_content_length.delay(str(validated_data['content_key']))
        elif validated_data['status']=='FAILED':
            content_obj = Content.objects.filter(key=validated_data['content_key'])
            if content_obj is not None and len(content_obj)>0:
                content_obj[0].content_state=failed_state[0]
                content_obj[0].save()
        kwargs['context'] = self.get_serializer_context()
        serializer = PPTSerializer(obj,data=validated_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)
            
            