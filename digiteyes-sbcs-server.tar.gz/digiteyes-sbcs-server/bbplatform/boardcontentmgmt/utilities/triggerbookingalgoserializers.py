from rest_framework import serializers
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from boardcontentmgmt.models import Account, TrackBookingAlgo

################################################################################
#Serializer for Track Booking Algorithm
################################################################################
class TrackBookingAlgoSerializer(serializers.ModelSerializer):
    #account = AccountSerializer()
    class Meta:
        model = TrackBookingAlgo
        fields = ['key','trigger_time','end_time']
        
################################################################################
#Serializer for Track Booking Algorithm
################################################################################
class TrackBookingAlgoWriteSerializer(serializers.ModelSerializer):
#     account = serializers.SlugRelatedField(
#         queryset=Account.objects.all(),
#         slug_field='key')
    class Meta:
        model = TrackBookingAlgo
        fields = ['key','trigger_time','end_time']
        