from rest_framework import generics
from rest_framework.response import Response
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters
import django_filters
from rest_framework.views import APIView
from boardcontentmgmt.models import TravelDestinationLocations,AccountUser,ResidentialComplex,Board,ShowSpotAsset
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from rest_framework.status import HTTP_201_CREATED,HTTP_400_BAD_REQUEST,HTTP_200_OK
from rest_framework import serializers

class TravelDestinationLocationsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TravelDestinationLocations
        fields = ('name','key','latitude','longitude')

class TravelDestinationLocationsFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(name='name',lookup_type='exact')
    class Meta:
        model = TravelDestinationLocations
	fields = ('name',)
#################################################################################
# TravelDestinationLocationsListView
#################################################################################
class TravelDestinationLocationsListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = TravelDestinationLocationsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name', )
    filter_class = TravelDestinationLocationsFilter
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return TravelDestinationLocations.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return TravelDestinationLocationsSerializer
        return TravelDestinationLocationsSerializer
#################################################################################
# TravelDestinationLocationsUpdateView
#################################################################################
class TravelDestinationLocationsUpdateView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = TravelDestinationLocationsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name', )
    filter_class = TravelDestinationLocationsFilter
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return TravelDestinationLocations.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return TravelDestinationLocationsSerializer
        returnTravelDestinationLocationsSerializer


class GetTravelDestinationLocationsView(APIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    def get(self,request):
        res = {}
        screen = self.request.query_params.get('screen', None)
        brd_obj = Board.objects.filter(key=screen)
        if brd_obj is not None and len(brd_obj):
            spot = ShowSpotAsset.objects.filter(key=brd_obj[0].show_spot.key)
            if spot is not None and len(spot)>0:
                res['current_location']={'latitude':spot[0].spot_location_lat,
                                         'longitude':spot[0].spot_location_long}
                res_complex = ResidentialComplex.objects.filter(account__key=spot[0].account.key)
                if res_complex is not None and len(res_complex)>0:
                    dest_locations=[]
                    locations = res_complex[0].traveldestinationlocations.all()
                    if locations is not None and len(locations) >0: 
                        for loc in locations:
                            dest_locations.append(TravelDestinationLocationsSerializer(loc).data)
                        res['destination_locations']=dest_locations
                        return Response(res,status=HTTP_201_CREATED)
                else:
                    error = {'error':'ResidentialComplex does not exist for the given board!'}
                    return Response(error,status=HTTP_400_BAD_REQUEST)
            else:
                error = {'error':'Showspot does not exist for the given board!'}
                return Response(error,status=HTTP_400_BAD_REQUEST)
        else:
            error = {'error':'Screen does not exist!'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        
