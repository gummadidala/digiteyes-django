'''
Created on 12-Jun-2017

@author: saba
'''
from rest_framework import serializers, generics, filters
from boardcontentmgmt.models import DayPartBid,BidsForPlay, DayPart, AdvtCampaign, AttributeTagGroup
from boardcontentmgmt.models import Account, BookingState, BidAllocationState, AccountUser, Board
from boardcontentmgmt.campaignmgmt.campaignserializers import AdvtCampaignShortSerializer
from boardcontentmgmt.adpackmgmt.bookedadpackserializers import BookedAdPackSerializer
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.taskprocessors import bidallocator
from rest_framework.response import Response
import django_filters
from rest_framework.views import APIView

###################################################################################
# Serializers
####################################################################################
class DayPartBidSerializer(serializers.ModelSerializer):
    dayPart = serializers.SlugRelatedField(
        queryset=DayPart.objects.all(),
        slug_field='name',required=False)
    class Meta:
        model = DayPartBid
        fields = ['key','dayPart','plays','date','bid_amount_per_play','units']
class BidsForPlaySerializer(serializers.ModelSerializer):
    day_part_bids = DayPartBidSerializer(many=True)
    campaign = AdvtCampaignShortSerializer()
    booked_adpacks = BookedAdPackSerializer(many=True)
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key')
    bid_state = serializers.SlugRelatedField(
        queryset=BookingState.objects.all(),
        slug_field='name')
    allocation_state = serializers.SlugRelatedField(
        queryset=BidAllocationState.objects.all(),
        slug_field='name')
    channel = serializers.SlugRelatedField(
        queryset=AttributeTagGroup.objects.all(),
        slug_field='name')
    class Meta:
        model = BidsForPlay
        fields = ['key','day_part_bids','channel','campaign','account','bid_state',
            'allocation_state','booked_adpacks']
class BidsForPlayWriteSerializer(serializers.ModelSerializer):
    day_part_bids = DayPartBidSerializer(many=True)
    campaign = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key')
    channel = serializers.SlugRelatedField(
        queryset=AttributeTagGroup.objects.all(),
        slug_field='key')
    booked_adpacks = BookedAdPackSerializer(many=True,required=False)
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key', required=False)
    bid_state = serializers.SlugRelatedField(
        queryset=BookingState.objects.all(),
        slug_field='name', required=False)
    allocation_state = serializers.SlugRelatedField(
        queryset=BidAllocationState.objects.all(),
        slug_field='name', required=False)
    class Meta:
        model = BidsForPlay
        fields = ['key','day_part_bids','campaign','account','bid_state',
            'allocation_state','booked_adpacks','channel']
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        account = aUsr[0].account
        bids_for_play = BidsForPlay()
        bids_for_play.account = account
        bids_for_play.campaign = validated_data['campaign']
        bids_for_play.channel = validated_data['channel']
        bid_state = BookingState.objects.filter(name='SUCCESS')[0]
        allocation_state = BidAllocationState.objects.filter(name='NOT_ALLOCATED')[0]
        bids_for_play.bid_state = bid_state
        bids_for_play.allocation_state = allocation_state
        bids_for_play.save()
        bid_list = []
        for day_part_bid in validated_data['day_part_bids']:
            dp_bid = DayPartBidSerializer().create(day_part_bid)
            dp_bid.save()
            bid_list.append(dp_bid)
        bids_for_play.day_part_bids = bid_list
        bids_for_play.save()
        return bids_for_play
##################################################################################
# Filters and API Views
##################################################################################
class BidsFilter(django_filters.FilterSet):
    campaign = django_filters.CharFilter(name='campaign__key')
    class Meta:
        model = BidsForPlay
        fields = ['campaign']
class BidsForPlayListView(generics.ListCreateAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    filter_backends = (filters.DjangoFilterBackend,)
    filter_class = BidsFilter
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        return BidsForPlay.objects.filter(account__key=acct.key)
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return BidsForPlayWriteSerializer
        return BidsForPlaySerializer
class BidTestView(APIView):
    def get(self,request,format = None):
        board_key = request.query_params.get('board', None)
        day_part = request.query_params.get('day_part', None)
        if board_key is None or day_part is None:
            return Response("Board Key and day part should be provided")
        board = Board.objects.get(key=board_key)
        day_parts = DayPart.objects.filter(name=day_part)
        bidallocator.book_adpacks_for_bids(board,day_parts[0],60)
        return Response("Success")