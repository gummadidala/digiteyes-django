from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework import filters
from boardcontentmgmt.models import Beacon, BeaconDiagnostics
from .beaconserializers import BeaconWriteSerializer,BeaconSerializer, BeaconDiagnosticsSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
#################################################################################
# Beacon  API List View - Supports Listing and Create
#################################################################################

class BeaconDiagnosticsFilter(django_filters.FilterSet):
    beacon = django_filters.CharFilter(name='beacon__mac_address',lookup_type='exact')
    class Meta:
        model = BeaconDiagnostics
	fields = ('beacon',)

class BeaconListView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = BeaconSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name','mac_address','name')
    lookup_field = 'key'
    queryset = Beacon.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return BeaconWriteSerializer
        return BeaconSerializer
#################################################################################
# Beacon  API Detail View - Supports Update/Patch and Deletion
#################################################################################
class BeaconDetailView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = BeaconSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name','mac_address')
    lookup_field = 'key'
    queryset = Beacon.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return BeaconWriteSerializer
        return BeaconSerializer
#################################################################################
# Beacon  API List View - Supports Listing and Create
#################################################################################
class BeaconDiagnosticsListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = BeaconDiagnosticsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #search_fields = ('account__account_name','mac_address')
    lookup_field = 'key'
    filter_class = BeaconDiagnosticsFilter
    queryset = BeaconDiagnostics.objects.all()
    
