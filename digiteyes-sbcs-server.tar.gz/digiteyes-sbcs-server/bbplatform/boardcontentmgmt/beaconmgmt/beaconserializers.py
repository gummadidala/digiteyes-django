from rest_framework import serializers
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from boardcontentmgmt.models import Account,Beacon, AccountUser, BeaconDiagnostics

import random, string

#################################################################################
# Serializer for BeaconSerializer
#################################################################################
class BeaconShortSerializer(serializers.ModelSerializer):
    class Meta:
        model= Beacon
        fields = ['mac_address','name','key']
class BeaconSerializer(serializers.ModelSerializer):
    account = AccountSerializer()
    class Meta:
        model= Beacon
        fields = ['mac_address','account','manufacturer','name','namespace',
            'key','instance_id','tx_power','url','bluetooth_name',]
   
#################################################################################
# Serializer for BeaconSerializer
#################################################################################    
def generate_beacon_name():
    b_name = ''.join(random.choice(string.ascii_lowercase + string.ascii_uppercase + string.digits) for i in range(5))
    bcns = Beacon.objects.filter(name = b_name)
    if len(bcns) > 0:
        generate_beacon_name()
    else:
        return b_name
class BeaconWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    manufacturer = serializers.CharField(default="")
    name = serializers.CharField(default="")
    namespace = serializers.CharField(default="")
    instance_id = serializers.CharField(default="")
    tx_power = serializers.CharField(default="")
    url = serializers.CharField(default="")
    bluetooth_name = serializers.CharField(default="")
    class Meta:
        model= Beacon
        fields = ['mac_address','account','manufacturer','name','namespace',
            'key','instance_id','tx_power','url','bluetooth_name',]
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        # creating the random string of length 5 for 'name'
        validated_data['name'] = generate_beacon_name()
        #validated_data['name'] = ''.join(random.choice(string.ascii_lowercase + string.ascii_uppercase + string.digits) for i in range(5))
        validated_data['account'] = aUsr[0].account
        return serializers.ModelSerializer.create(self, validated_data)

class BeaconDiagnosticsSerializer(serializers.ModelSerializer):
    beacon = serializers.SlugRelatedField(
        queryset=Beacon.objects.all(),
        slug_field='mac_address',required=False)
    other_diags = serializers.CharField(default="")
    class Meta:
        model= BeaconDiagnostics
        fields = ['beacon','timestamp','battery_strength','other_diags','key']
