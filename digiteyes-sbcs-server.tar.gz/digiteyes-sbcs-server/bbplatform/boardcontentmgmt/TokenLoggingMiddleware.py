'''
Created on 09-Jun-2017

@author: saba
'''
class AuthMiddleware(object):
    """
    Convenience middleware for users of django-rest-framework-jwt.^M
    Fixes issue https://github.com/GetBlimp/django-rest-framework-jwt/issues/45^M
    """


    def get_user_jwt(self, request):
        from rest_framework.request import Request
        from rest_framework.exceptions import AuthenticationFailed
        from django.utils.functional import SimpleLazyObject
        from django.contrib.auth.middleware import get_user
        from rest_framework.authentication import TokenAuthentication

        user = get_user(request)
        if user.is_authenticated():
            return user
        try:
            user_jwt = TokenAuthentication().authenticate(Request(request))
            if user_jwt is not None:
                return user_jwt[0]
        except AuthenticationFailed:
            pass
        return user

    def process_request(self, request):
        from django.utils.functional import SimpleLazyObject
        assert hasattr(request, 'session'),\
        """The Django authentication middleware requires session middleware to be installed.^M
         Edit your MIDDLEWARE_CLASSES setting to insert 'django.contrib.sessions.middleware.SessionMiddleware'."""^M
        request.user = SimpleLazyObject(lambda: self.get_user_jwt(request))
