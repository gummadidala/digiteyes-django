from rest_framework import serializers
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from boardcontentmgmt.models import ShowSpotAsset,Account,AttributeTagGroup,PrimaryLocationTag, AccountUser
from boardcontentmgmt.models import PrimaryAttributeTag,Beacon,ShowSpotAssetState,ScreenSize,WifiCounter
from boardcontentmgmt.models import ScreenOrientation,SignalQuality,SpotLocationType
from boardcontentmgmt.tagmgmt.tagserializers import AttributeTagGroupSerializer,PrimaryLocationTagSerializer,PrimaryAttributeTagSerializer
from boardcontentmgmt.beaconmgmt.beaconserializers import BeaconSerializer
from boardcontentmgmt.tracking.wificonsumertrackingserializer import WifiCountingSerializer

#################################################################################
# Serializer for ShowSpotAssetSerializer
################################################################################# 
class ShowSpotAssetSerializer(serializers.ModelSerializer):
    account = AccountSerializer()
    attached_attribute_tag=AttributeTagGroupSerializer(many=True)
    attached_primary_location_tag=PrimaryLocationTagSerializer()
    attached_primary_attribute_tag=PrimaryAttributeTagSerializer()
    attached_beacons=BeaconSerializer(many=True)
    attached_wificounters = WifiCountingSerializer(many=True)
    asset_state= serializers.SlugRelatedField(
        queryset=ShowSpotAssetState.objects.all(),
        slug_field='name')
    spot_suggested_screen_size=serializers.SlugRelatedField(
        queryset=ScreenSize.objects.all(),
        slug_field='name')
    spot_suggested_screen_orientation=serializers.SlugRelatedField(
        queryset=ScreenOrientation.objects.all(),
        slug_field='name')
    signal_quality_3g=serializers.SlugRelatedField(
        queryset=SignalQuality.objects.all(),
        slug_field='name')
    signal_quality_4g=serializers.SlugRelatedField(
        queryset=SignalQuality.objects.all(),
        slug_field='name')
    spot_location_type = serializers.SlugRelatedField(
        queryset=SpotLocationType.objects.all(),
        slug_field='name')
    class Meta:
        model= ShowSpotAsset
        fields = ['name','account','key','spot_location_lat','spot_location_long',
                  'spot_location_floor','spot_location_type','attached_attribute_tag',
                  'attached_primary_location_tag','attached_primary_attribute_tag',
                  'attached_beacons','asset_state','spot_suggested_screen_size',
                  'spot_suggested_screen_orientation','signal_quality_3g',
                  'signal_quality_4g','power_availability','spot_location_image_url','attached_wificounters']
       
#################################################################################
# Serializer for ShowSpotAssetSerializer
#################################################################################    
   
class ShowSpotAssetWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    attached_attribute_tag = serializers.SlugRelatedField(
        queryset=AttributeTagGroup.objects.all(),
        many=True ,slug_field='key',required=False)
    attached_primary_location_tag = serializers.SlugRelatedField(
        queryset=PrimaryLocationTag.objects.all(),
        slug_field='key',required=False, allow_null=True)
    attached_primary_attribute_tag=serializers.SlugRelatedField(
        queryset=PrimaryAttributeTag.objects.all(),
        slug_field='key',required=False,allow_null=True)
    attached_beacons= serializers.SlugRelatedField(
        queryset=Beacon.objects.all(),
        many=True ,slug_field='key',required=False)
    attached_wificounters= serializers.SlugRelatedField(
        queryset=WifiCounter.objects.all(),
        many=True ,slug_field='key',required=False)
    asset_state= serializers.SlugRelatedField(
        queryset=ShowSpotAssetState.objects.all(),
        slug_field='name')
    spot_suggested_screen_size=serializers.SlugRelatedField(
        queryset=ScreenSize.objects.all(),
        slug_field='name')
    spot_suggested_screen_orientation=serializers.SlugRelatedField(
        queryset=ScreenOrientation.objects.all(),
        slug_field='name')
    signal_quality_3g=serializers.SlugRelatedField(
        queryset=SignalQuality.objects.all(),
        slug_field='name')
    signal_quality_4g=serializers.SlugRelatedField(
        queryset=SignalQuality.objects.all(),
        slug_field='name')
    spot_location_type = serializers.SlugRelatedField(
        queryset=SpotLocationType.objects.all(),
        slug_field='name')
    spot_location_lat = serializers.CharField(default="")
    spot_location_long = serializers.CharField(default="")
    power_availability = serializers.BooleanField(default=False)
    class Meta:
        model= ShowSpotAsset
        fields = ['name','account','key','spot_location_lat','spot_location_long',
                  'spot_location_floor','spot_location_type','attached_attribute_tag',
                  'attached_primary_location_tag','attached_primary_attribute_tag',
                  'attached_beacons','asset_state','spot_suggested_screen_size',
                  'spot_suggested_screen_orientation','signal_quality_3g',
                  'signal_quality_4g','power_availability','spot_location_image_url','attached_wificounters']
    def create(self, validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        if 'account' not in validated_data :
            validated_data['account'] = aUsr[0].account
        if 'attached_primary_location_tag' not in validated_data:
            validated_data['attached_primary_location_tag'] = None
        if 'attached_primary_attribute_tag' not in validated_data:
            validated_data['attached_primary_attribute_tag'] = None
        return serializers.ModelSerializer.create(self, validated_data)
   
    
class ShowSpotLocationSerializer(serializers.ModelSerializer): 
    class Meta:
        model= ShowSpotAsset
        fields =('spot_location_lat','spot_location_long','spot_location_floor','key',)

class ShowSpotShortSerializer(serializers.ModelSerializer): 
    attached_beacons=BeaconSerializer(many=True)
    attached_wificounters = WifiCountingSerializer(many=True)
    class Meta:
        model = ShowSpotAsset
        fields =('key','name','spot_location_lat','spot_location_long','attached_beacons','attached_wificounters')
    