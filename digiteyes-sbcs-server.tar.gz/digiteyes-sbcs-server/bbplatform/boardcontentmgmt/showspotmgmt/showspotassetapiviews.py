from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework import filters
from boardcontentmgmt.models  import ShowSpotAsset,AttributeTagGroup,ShowSpotAssetState,AccountUser,Beacon,WifiCounter
from boardcontentmgmt.showspotmgmt.showspotassetserializers import ShowSpotAssetSerializer,ShowSpotAssetWriteSerializer
from boardcontentmgmt.utilities.freeslotutilities import fill_all_child_tags
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
import logging
logger = logging.getLogger(__name__)
#################################################################################
# Custom filter method for show spots attached with given group tag or its 
# descendants.
#################################################################################    
def filter_group(qs,value):
    if value:
        at_group = AttributeTagGroup.objects.get(name=value)
        all_tags = []
        fill_all_child_tags(at_group,all_tags)
        logger.debug("All tags:"+str(all_tags))
        logger.debug("Query Set:"+str(qs))
        return qs.filter(attached_attribute_tag__name__in=all_tags)
    return qs
#################################################################################
# Custom Filter for Show spots.
#################################################################################
class ShowSpotFilter(django_filters.FilterSet):
    primary_location = django_filters.CharFilter(name='attached_primary_location_tag__name')
    group = django_filters.CharFilter(action=filter_group)
    state = django_filters.CharFilter(name='asset_state__name')
    account = django_filters.CharFilter(name='account__account_name')
    class Meta:
        model = ShowSpotAsset
        fields = ()

#################################################################################
# ShowSpotAsset  API List View - Supports Listing and Create
#################################################################################
class ShowSpotAssetListView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = ShowSpotAssetSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name','spot_suggested_screen_size__name','attached_primary_location_tag__name','attached_primary_attribute_tag__name','account__account_name')
    filter_class = ShowSpotFilter
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(usr,'showspotasset') == True):
            return ShowSpotAsset.objects.all()
        else:
            return ShowSpotAsset.objects.filter(account__key = acct.key)
    #queryset = ShowSpotAsset.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ShowSpotAssetWriteSerializer
        return ShowSpotAssetSerializer
#################################################################################
# ShowSpotAsset  API Detail View - Supports Update/Patch and Deletion
#################################################################################
def get_showspot_forbeacon(beacons):
    bcn_list=[]
    for bcn in beacons:
        obj = Beacon.objects.filter(key=bcn)
        if obj is not None and len(obj)>0:
            bcn_list.append(obj[0])
    spot = ShowSpotAsset.objects.filter(attached_beacons__in=bcn_list)
    if spot is not None and len(spot)>0:
        return spot[0]
    return None
def get_showspot_forwificounter(wifi_counters):
    wifi_counters_list=[]
    for wifi_cntr in wifi_counters:
        obj = WifiCounter.objects.filter(key=wifi_cntr)
        if obj is not None and len(obj)>0:
            wifi_counters_list.append(obj[0])
    spot = ShowSpotAsset.objects.filter(attached_wificounters__in=wifi_counters_list)
    if spot is not None and len(spot)>0:
        return spot[0]
    return None

class ShowSpotAssetDetailView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    permission_classes = (IsAuthenticated, PermissionCheck)
    serializer_class  = ShowSpotAssetSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name','spot_suggested_screen_size__name','attached_primary_location_tag__name','attached_primary_attribute_tag__name')
    lookup_field = 'key'
    def modify(self):
        field_permissions = [{'permission':'modify_all_showspotasset',
                              'model_name' : 'showspotasset'}]
        return field_permissions
    def special(self):
        approve = ShowSpotAssetState.objects.filter(name = 'APPROVED')[0]
        reject = ShowSpotAssetState.objects.filter(name = 'REJECTED')[0]
        field_permissions = [{'field_name' : 'asset_state', 'permission':['can_approve_showspotasset', 'can_reject_showspotasset'],
                              'state':[approve.name,reject.name],'model_name' : 'showspotasset'}]
        return field_permissions
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(usr,'showspotasset') == True):
            return ShowSpotAsset.objects.all()
        else:
            return ShowSpotAsset.objects.filter(account__key = acct.key)
    #queryset = ShowSpotAsset.objects.all()
    
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return ShowSpotAssetWriteSerializer
        return ShowSpotAssetSerializer
            
    def patch(self,request,format=None,*args,**kwargs):
        validated_data = request.data
        if 'attached_beacons' in validated_data:
            beacons = validated_data['attached_beacons']
            bcn_list = []
            for bcn in beacons:
                obj = Beacon.objects.filter(key=bcn)
                if obj is not None and len(obj)>0:
                    bcn_list.append(obj[0])
                else:
                    error = {'error':bcn+' Beacon not found'}
                    return Response(error,status = HTTP_400_BAD_REQUEST)
        elif 'attached_wificounters' in validated_data:
            wifi_counters = validated_data['attached_wificounters']
            wificounter_list = []
            for wifi_cntr in wificounter_list:
                obj = WifiCounter.objects.filter(key=wifi_cntr)
                if obj is not None and len(obj)>0:
                    wificounter_list.append(obj[0])
                else:
                    error = {'error':wifi_cntr+' WifiCounter not found'}
                    return Response(error,status = HTTP_400_BAD_REQUEST) 
        if 'attached_beacons' in validated_data and 'confirm' in validated_data:
            if validated_data['confirm'] != True:
                if get_showspot_forbeacon(beacons) is not None:
                    error = {'error':'This beacon is already assigned to showspot : '+str(get_showspot_forbeacon(beacons).name)+
                             '. If you continue, this beacon is no more attached to ' +str(get_showspot_forbeacon(beacons).name) +
                            '. Do you really want to continue??'}
                    return Response(error,status = HTTP_400_BAD_REQUEST)
            elif validated_data['confirm']:
                prev_show_spots_with_given_beacons = ShowSpotAsset.objects.filter(attached_beacons__in = bcn_list)
                if prev_show_spots_with_given_beacons is not None:
                    for each_spot in prev_show_spots_with_given_beacons:
                        each_spot.attached_beacons = []
                        each_spot.save()
        elif 'attached_wificounters' in validated_data and 'confirm' in validated_data:
            if validated_data['confirm'] != True:
                res = get_showspot_forwificounter(wifi_counters)
                if res is not None:
                    error = {'error':'This wificounter is already assigned to showspot : '+str(res.name)+
                             '. If you continue, this wificounter is no more attached to ' +str(res.name) +
                            '. Do you really want to continue??'}
                    return Response(error,status = HTTP_400_BAD_REQUEST)
            elif validated_data['confirm']:
                prev_show_spots_with_given_wificounters = ShowSpotAsset.objects.filter(attached_wificounters__in = wificounter_list)
                if prev_show_spots_with_given_wificounters is not None:
                    for each_spot in prev_show_spots_with_given_wificounters:
                        each_spot.attached_wificounters = []
                        each_spot.save()
        return generics.RetrieveUpdateDestroyAPIView.patch(self,request,*args,**kwargs)


    