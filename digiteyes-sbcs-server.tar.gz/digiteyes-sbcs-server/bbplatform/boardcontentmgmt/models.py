from django.db import models
from django.utils import timezone
import uuid 
from datetime import timedelta
from django.contrib.auth.models import Group, User
from django.db.models.signals import post_save,post_delete
from django.dispatch import receiver
from rest_framework.authtoken.models import Token
from treebeard.mp_tree import MP_Node
from celery.worker.strategy import default
import datetime
from django.db.models.fields import DateField
from audit_log.models.managers import AuditLog

#################################################################################
# Account Type  : Can be individual / firm and also used to distinquish
#                 Association / Screen Owner/ Advertiser & Consumer
#################################################################################
class AccountType(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    type_name = models.CharField(max_length=20)
    type_of_customer = models.CharField(max_length=20) 
#################################################################################
# City : Master data for list of Cities
#################################################################################
class City(models.Model):
    city_name = models.CharField(max_length=50)
#################################################################################
# SpotLocationType : Spot Location (Indoor / Semi Out door/ Out door (Master data
#################################################################################
class SpotLocationType(models.Model):
    name = models.CharField(max_length=20)
#################################################################################
# Various Screen Sizes - Master Data
#################################################################################
class ScreenSize(models.Model):
    name = models.CharField(max_length=50)
#################################################################################
# Various Screen Orientations - Master Data
#################################################################################    
class ScreenOrientation(models.Model):
    name = models.CharField(max_length=50)
#################################################################################
# ShowSpotAssetState - Master data Proposed/Approved/Leveraged/Live
#################################################################################
class ShowSpotAssetState(models.Model):
    name = models.CharField(max_length=50)
#################################################################################
# Signal Quality Master data - Not Available/Poor/Average/Good/Excellent
#################################################################################    
class SignalQuality(models.Model):
    name = models.CharField(max_length=20)
#################################################################################
# Leverage Request Master data - 
#################################################################################    
class RequestState(models.Model):
    name = models.CharField(max_length=20)
#################################################################################
# List of Content Types
#################################################################################
class ContentType(models.Model):
    type_name = models.CharField(max_length=20)
    def __unicode__(self):
        return self.type_name
#################################################################################
# List of Content States
#################################################################################
class ContentState(models.Model):
    state_name = models.CharField(max_length=25)
#################################################################################
# Model for CTA Type - Master Data
#################################################################################
class CTAType(models.Model):
    name = models.CharField(max_length=25)
#################################################################################
# Model for Item Type(MasterAdPack/DayPack/WeekPack/WeekendPack/MonthPack) - Master Data
#################################################################################
class ItemType(models.Model):
    name = models.CharField(max_length=25)
#################################################################################
# Screen Status - Master Data ( Not Active / Live  etc) 
#################################################################################
class ScreenStatus(models.Model):
    name = models.CharField(max_length=20)
#################################################################################
# List of Day qualifiers
#################################################################################
class DayQualifier(models.Model):
    name = models.CharField(max_length=50)
#################################################################################
# List of Campaign States
#################################################################################
class CampaignState(models.Model):
    state_name = models.CharField(max_length=20)
#################################################################################
# List of Campaign Types
#################################################################################
class CampaignType(models.Model):
    name = models.CharField(max_length=20)
#################################################################################
# List of ContentQueue Types
#################################################################################
class ContentQueueType(models.Model):
    name = models.CharField(max_length=20)
#################################################################################
# Pack States - Master Data : Active / Draft/ Approved etc.,
#################################################################################   
class PackState(models.Model):
    name = models.CharField(max_length=50)

#################################################################################
# Booking States : BLOCKED / SUCCESS / FAILED / CANCELLED (Master Data)
#################################################################################
class BookingState(models.Model):
    name = models.CharField(max_length=50)
#################################################################################
# Account :  Every stakeholder's relationship is captured thru account
#################################################################################
class Account(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    account_name =  models.CharField(max_length=50)
    account_type = models.ForeignKey(AccountType,default="",null=True)
    consumer_accounts = models.ManyToManyField('self',default="",blank=True)
    audit_log = AuditLog()
################################################################################
#ContentLabel
################################################################################
class ContentLabel(models.Model):
    name = models.CharField(max_length=50)
################################################################################
#LayoutLabel
################################################################################
class LayoutLabel(models.Model):
    name = models.CharField(max_length=50)
################################################################################
#AppType
################################################################################
class AppType(models.Model):
    type = models.CharField(max_length=50)
################################################################################
#LayoutMapping
################################################################################
class LayoutMapping(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    layout_label = models.ForeignKey(LayoutLabel)
    content_label = models.ForeignKey(ContentLabel)
    account = models.ForeignKey(Account,default="",null=True,blank=True)
    class Meta:
        permissions = (
            ("view_all_layoutmapping", "Can view all LayoutMapping"),
        )
################################################################################
#Layout
################################################################################
class Layout(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)  
    name = models.CharField(max_length=50)
    layout_locations = models.ManyToManyField(LayoutMapping)
    class Meta:
        permissions = (
            ("view_all_layout", "Can view all Layout"),
        )
class ResidentConsumer(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)  
    name = models.CharField(max_length=100)
    flat_number = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=15,unique=True)
    account=models.ForeignKey(Account,default="",null=True,blank=True)
    class Meta:
        permissions = (
            ("view_all_residentconsumer", "Can view all ResidentConsumer"),
            ("modify_all_residentconsumer", "Can modify all ResidentConsumer"),
        )
#################################################################################
#TravelDestinationLocations
#################################################################################
class TravelDestinationLocations(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name=models.CharField(max_length=500,default = "",null=True,blank=True)
    latitude = models.CharField(max_length=20,default="",null=True)
    longitude = models.CharField(max_length=20,default="",null=True)
    account=models.ForeignKey(Account,default="",null=True,blank=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_traveldestinationlocations", "Can view all TravelDestinationLocations"),
        )
#################################################################################
# User Profile : Defines the list of permissions (based on the group linkages)
#################################################################################
class UserProfile(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    profile_name = models.CharField(max_length=50) 
    user_groups = models.ManyToManyField(Group)
    account = models.ForeignKey(Account)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_userprofile", "Can view all UserProfile"),
        )
#################################################################################
# AccountUser : Users within an account. If it is an individual account, there 
#                shall be only one entry against that account.
#################################################################################
class AccountUser(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    account_user_phone_no = models.CharField(max_length=50)
    account_user = models.ForeignKey(User, on_delete=models.CASCADE) 
    account = models.ForeignKey(Account)
    user_profiles = models.ManyToManyField(UserProfile,default="")
    profile_picture = models.TextField(default="",null=True,blank=True)
    gender = models.CharField(max_length=50,default="",null=True,blank=True)
    birth_date = models.DateField(null=True,blank=True)
    is_activeuser = models.NullBooleanField(default=False,null=True,blank=True)
    verified_mobile = models.NullBooleanField(default=False,null=True,blank=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_accountuser", "Can view all AccountUser"),
        )
#################################################################################
# ResidentialComplex : Model Representing Residential Complext details
#################################################################################
class ResidentialComplex(models.Model): 
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name = models.CharField(max_length=100)
    address = models.CharField(max_length=200)
    city_sub_area = models.CharField(max_length=150)
    city = models.ForeignKey(City)
    project_area = models.IntegerField()
    project_occupancy = models.IntegerField()
    num_of_flats = models.IntegerField()
    amenities = models.CharField(max_length=500)
    num_of_parking_lots = models.IntegerField()
    account = models.ForeignKey(Account)
    traveldestinationlocations = models.ManyToManyField(TravelDestinationLocations,default="")
    image_url = models.TextField(blank=True,null=True,default="")
    logo_url = models.TextField(blank=True,null=True,default="")
    residents = models.ManyToManyField(ResidentConsumer,default="")
    service_people = models.ManyToManyField(AccountUser,default="")
    audit_log = AuditLog()
    service_phone_number = models.CharField(max_length=15,default="")
    # Bank details.. ??
    class Meta:
        permissions = (
            ("view_all_residentialcomplex", "Can view all ResidentialComplex"),
            ("modify_all_residentialcomplex", "Can modify all ResidentialComplex"),
        )
#################################################################################
# ScreenOwner : Model for Screen Owner
#################################################################################
class ScreenOwner(models.Model):
    # Bank account details
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    firm_name = models.CharField(max_length=150)
    address = models.CharField(max_length=200)
    account = models.ForeignKey(Account)
    city = models.ForeignKey(City)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_screenowner", "Can view all ScreenOwner"),
        )
#################################################################################
# Advertiser : Model for Advertiser
#################################################################################
class Advertiser(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    account = models.ForeignKey(Account)
    firm_name = models.CharField(max_length=500)
    address = models.CharField(max_length=200)
    city = models.ForeignKey(City)
    type_of_business = models.CharField(max_length=500)
    image_url = models.TextField(default="",null=True,blank=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_advertiser", "Can view all Advertiser"),
        )
#################################################################################
# Consumer Model
#################################################################################
class Consumer(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    account = models.ForeignKey(Account)
    facebook_id = models.CharField(max_length=200,unique=True,null=True)
    google_id = models.CharField(max_length=200,unique=True,null=True)
    primary_device_id = models.CharField(max_length=200,unique=True,null=True)
    age_range_min = models.IntegerField(default=0)
    age_range_max = models.IntegerField(default=0)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=10)
    class Meta:
        permissions = (
            ("view_all_consumer", "Can view all Consumer"),
        )
#################################################################################
# Consumer Attributes
#################################################################################
class ConsumerAttributes(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    account = models.ForeignKey(Account)
    attribute_name = models.CharField(max_length=100)
    attribute_value = models.CharField(max_length=500)
    class Meta:
        permissions = (
            ("view_all_consumerattributes", "Can view all ConsumerAttributes"),
        )

#################################################################################
# Tags Applied to Screen
#################################################################################
class AttributeTagGroup(MP_Node):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name = models.CharField(max_length=50)
    desc = models.CharField(max_length=200,default="")
    tag_owner = models.ForeignKey(AccountUser,default="")
    account = models.ForeignKey(Account,default="")
    audit_log = AuditLog()
    #child_groups = models.ManyToManyField('self')
    node_order_by = ['name']
    class Meta:
        permissions = (
            ("view_all_attributegaggroup", "Can view all AttributeTagGroup"),
        )
#################################################################################
# PrimaryLocationTag - Things like Lobby/Entrance/Exit/Clubhouse etc.,
#################################################################################
class PrimaryLocationTag(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name = models.CharField(max_length=50)
    desc = models.CharField(max_length=200,default="")
    tag_owner = models.ForeignKey(AccountUser,default="")
    account = models.ForeignKey(Account,default="")
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_primarylocationtag", "Can view all PrimaryLocationTag"),
        )
#################################################################################
# PrimaryAttributeTag - Rich/Posh/ etc.,
#################################################################################
class PrimaryAttributeTag(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name = models.CharField(max_length=50)
    desc = models.CharField(max_length=200,default="")
    tag_owner = models.ForeignKey(AccountUser,default="")
    account = models.ForeignKey(Account,default="")
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_primaryattributetag", "Can view all PrimaryAttributeTag"),
        )
#################################################################################
# Beacon - Right now only the mac address is stored.
#################################################################################    
class Beacon(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name = models.CharField(max_length=10,default="")
    manufacturer = models.CharField(max_length=50,default="")
    namespace = models.CharField(max_length=20,default="")
    bluetooth_name = models.CharField(max_length=20,default="")
    url = models.TextField(default="",null=True,blank=True)
    instance_id =  models.CharField(max_length=10,default="")
    mac_address = models.CharField(max_length=50,unique=True)
    account = models.ForeignKey(Account,default="")
    tx_power = models.CharField(max_length=10,default="")
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_beacon", "Can view all Beacon"),
        )

#################################################################################
# Wifi Counter
#################################################################################
class WifiCounter(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    mac_address = models.CharField(max_length=50,unique=True,db_index=True)
    name = models.CharField(max_length=15,default="")
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_wificounter", "Can view all WifiCounter"),
        )
#################################################################################
# Model Changes for Apart Play
#################################################################################
class ShowSpotAsset(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name = models.CharField(max_length=50)
    spot_location_lat = models.CharField(max_length=20,default="",null=True)
    spot_location_long = models.CharField(max_length=20,default="",null=True)
    spot_location_floor = models.IntegerField(default=0)
    spot_location_type = models.ForeignKey(SpotLocationType,default="")
    account = models.ForeignKey(Account,default="")
    attached_attribute_tag = models.ManyToManyField(AttributeTagGroup,default="")
    attached_primary_location_tag = models.ForeignKey(PrimaryLocationTag,default="",null=True)
    attached_primary_attribute_tag = models.ForeignKey(PrimaryAttributeTag,default="",null=True)
    attached_beacons = models.ManyToManyField(Beacon)
    asset_state = models.ForeignKey(ShowSpotAssetState,default="")
    spot_suggested_screen_size = models.ForeignKey(ScreenSize,default="")
    spot_suggested_screen_orientation = models.ForeignKey(ScreenOrientation,default="")
    signal_quality_3g = models.ForeignKey(SignalQuality,related_name="signal_quality_3g",default="") 
    signal_quality_4g = models.ForeignKey(SignalQuality,related_name="signal_quality_4g",default="")
    power_availability = models.BooleanField(default=False)
    spot_location_image_url = models.TextField(default="",null=True,blank=True)
    attached_wificounters = models.ManyToManyField(WifiCounter,default="")
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_showspotasset", "Can view all ShowSpotAsset"),
            ("modify_all_showspotasset", "Can modify all ShowSpotAsset"),
            ("can_approve_showspotasset", "Can approve show spot"),
            ("can_reject_showspotasset", "Can reject show spot"),
        )
#################################################################################
# ShowSpotLeverageRequestFromSO
#################################################################################     
class ShowSpotLeverageRequestFromSO(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    selected_spot = models.ForeignKey(ShowSpotAsset)
    selected_for = models.ForeignKey(Account)
    selected_on = models.DateTimeField()
    request_state = models.ForeignKey(RequestState)
    class Meta:
        permissions = (
            ("view_all_showspotleveragerequestfromso", "Can view all ShowSpotLeverageRequestFromSO"),
        )
#################################################################################
# Consumer Tracking
#################################################################################
class ConsumerTracking(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    consumer_account = models.ForeignKey(Account)
    event_type = models.CharField(max_length=50)
    event_time_stamp = models.DateTimeField()
    event_location = models.ForeignKey(Beacon)
    class Meta:
        permissions = (
            ("view_all_consumertracking", "Can view all ConsumerTracking"),
        )
#################################################################################
# VOUCHER CTA TYPE
#################################################################################
class VoucherCtaType(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name = models.CharField(max_length=50)
#################################################################################
# VOUCHER CTA
#################################################################################
class VoucherCta(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    account = models.ForeignKey(Account,default="")
    name = models.CharField(max_length=50)
    type = models.ForeignKey(VoucherCtaType,default="")
    description = models.CharField(max_length=500,default="")
    isSuprise = models.BooleanField(default=False)
    percentage_minimum = models.DecimalField(max_digits=5,decimal_places=2,default=0)
    percentage_maximum = models.DecimalField(max_digits=5,decimal_places=2,default=0)
    flat_amount_minimum = models.DecimalField(max_digits=15,decimal_places=2,default=0)
    flat_amount_maximum = models.DecimalField(max_digits=15,decimal_places=2,default=0)
    percentage = models.DecimalField(max_digits=5,decimal_places=2,default=0)
    flat_amount = models.DecimalField(max_digits=15,decimal_places=2,default=0)
    validity = models.DateTimeField(default=timezone.now)
    creative_url = models.TextField(default="")
    term_conditions = models.TextField(default="")
    class Meta:
        permissions = (
            ("view_all_vouchercta", "Can view all VoucherCta"),
        )

#################################################################################
# Model for CTAParameters 
#################################################################################
class CTAParameters(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name = models.CharField(max_length=50)
    value = models.TextField()
    account = models.ForeignKey(Account,default="")
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_cta", "Can view all CTA"),
        )
#################################################################################
# Model for CTAParametersActed
#################################################################################
class CTAParametersActed(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name = models.CharField(max_length=50)
    value = models.TextField()
    account = models.ForeignKey(Account,default="")
    class Meta:
        permissions = (
            ("view_all_cta", "Can view all CTA"),
        )
#################################################################################
# Model for CTA 
#################################################################################
class CTA(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    type = models.ForeignKey(CTAType)
    cta_parameters = models.ManyToManyField(CTAParameters)
    account = models.ForeignKey(Account,default="")
    voucher = models.ForeignKey(VoucherCta,default="",null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_cta", "Can view all CTA"),
        )
#################################################################################
# Model for Content Target - Target behind each content played
#################################################################################
class ContentTarget(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    target_image_url = models.TextField(default="",null=True,blank=True)
    target_title = models.CharField(max_length=100)
    account = models.ForeignKey(Account,default="")
    target_description = models.CharField(max_length=300)
    target_cta = models.ManyToManyField(CTA)
    service_location_lat = models.CharField(max_length=15,blank=True)
    service_location_long = models.CharField(max_length=15,blank=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_contenttarget", "Can view all ContentTarget"),
        )
################################################################################
#SubordinateContent
################################################################################
class SubordinateContent(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name = models.CharField(max_length=50)
    type = models.ForeignKey(ContentType)
    url = models.TextField(default="",null=True,blank=True)
    text = models.TextField(null=True, blank=True,default = "")
    content_label = models.ForeignKey(ContentLabel)
    account = models.ForeignKey(Account,default="")
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_subordinatecontent", "Can view all SubordinateContent"),
        )
#################################################################################
# Model for Content 
#################################################################################
class Content(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    content_name = models.CharField(max_length=100,unique=True)
    content_type = models.ForeignKey(ContentType)
    content_source = models.TextField(default="",null=True,blank=True)
    content_state = models.ForeignKey(ContentState, default="")
    content_owner = models.ForeignKey(AccountUser, default="")
    last_updated_date = models.DateTimeField(default=timezone.now)
    content_play_time = models.DurationField(default=timedelta())
    account = models.ForeignKey(Account, default="")
    content_target = models.ForeignKey(ContentTarget,default="",null=True)
    portrait_content_source = models.TextField(default="",null=True,blank=True)
    thumbnail_source = models.TextField(default="",null=True,blank=True)
    content_primary_source = models.TextField(default="",null=True,blank=True)
    hash = models.CharField(max_length=500,default="",null=True)
    subordinate_content = models.ManyToManyField(SubordinateContent,default="")
    enable_ar=models.BooleanField(default=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_content", "Can view all Content"),
            ("can_approve_content", "Can approve content"),
            ("can_reject_content", "Can reject content"),
        )
#################################################################################
# Model for Content Schedule
#################################################################################
class ContentSchedule(models.Model):
    content = models.ForeignKey(Content)
    filler_time = models.DurationField(default=timedelta())
    repeat = models.IntegerField(default=1)
#################################################################################
# Model for Content Queue - Play list
#################################################################################
class ContentQueue(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    content_queue_name = models.CharField(max_length=100,unique=True)
    content_list = models.ManyToManyField(ContentSchedule)
    last_updated_date = models.DateTimeField(default=timezone.now)
    content_queue_owner = models.ForeignKey(AccountUser, default="")
    queue_state = models.CharField(max_length=20)
    num_units = models.IntegerField(default=0)
    unit_size = models.IntegerField(default=30)
    type = models.ForeignKey(ContentQueueType,default="",null=True,blank=True)
    account = models.ForeignKey(Account,default="")
    layout = models.ForeignKey(Layout,default="",blank=True,null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_contentqueue", "Can view all ContentQueue"),
        )
#################################################################################
# Model for Board
#################################################################################
class Board(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    board_name=models.CharField(max_length=50,unique=True)
    board_location_lat=models.CharField(max_length=20,default="",blank=True,null=True)
    board_location_long=models.CharField(max_length=20,default="",blank=True,null=True)
    board_owner= models.ForeignKey(AccountUser,default="",null=True)
    board_address=models.CharField(max_length=200,null=True,blank=True)
    board_city = models.CharField(max_length=50,default="",blank=True,null=True)
    board_size=models.ForeignKey(ScreenSize,default="",null=True)
    board_serial_number = models.CharField(max_length=50,default="",unique=True)
    working_start_time = models.CharField(default="00:00",max_length=10,null=True)
    working_end_time = models.CharField(default="23:59",max_length=10,null=True)
    account = models.ForeignKey(Account,default="",null=True)
    show_spot = models.ForeignKey(ShowSpotAsset,default="",null=True)
    board_state = models.ForeignKey(ScreenStatus,default="")
    beacon_key = models.CharField(max_length=4,unique=True,null=True)
    attached_wificounters = models.ManyToManyField(WifiCounter,default="")
    attached_beacons = models.ManyToManyField(Beacon)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_board", "Can view all Board"),
            ("modify_all_board", "Can modify all Board"),
        )
#################################################################################
# Model for Board Registrations
#################################################################################
class BoardRegistrationCode(models.Model):
    board = models.ForeignKey(Board)
    registration_code = models.CharField(max_length=6)
    code_validity = models.DateTimeField() 
    account = models.ForeignKey(Account,null=True)
    class Meta:
        permissions = (
            ("view_all_boardregistrationcode", "Can view all BoardRegistrationCode"),
        )
#################################################################################
# Device Registration details
#################################################################################  
class BoardRegistration(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    board = models.ForeignKey(Board)
    registered_date = models.DateTimeField(auto_now_add=True,null=True)
    registration_status = models.CharField(max_length=10)
    auth_code = models.CharField(max_length=6)
    account = models.ForeignKey(Account,null=True)
    class Meta:
        permissions = (
            ("view_all_boardregistration", "Can view all BoardRegistration"),
        )
#################################################################################
# List of Day parts
#################################################################################
class DayPart(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=20);
    from_time = models.TimeField()
    to_time = models.TimeField()
    account = models.ForeignKey(Account,null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_daypart", "Can view all DayPart"),
        )
#################################################################################
# Model for Advertisement Campaign
#################################################################################
class AdvtCampaignDate(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    date = models.DateField()

class AdvtCampaign(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name = models.CharField(max_length=50)
    type = models.ForeignKey(CampaignType,default="",null=True)
    owner = models.ForeignKey(AccountUser,default="")
    created_date = models.DateTimeField(auto_now_add=True)
    planned_dates = models.ManyToManyField(AdvtCampaignDate)
    state = models.ForeignKey(CampaignState)
    selected_plays_per_day = models.IntegerField(default=0)
    total_screens_selected = models.IntegerField(default=0)
    dayPart_selected = models.ForeignKey(DayPart,default="",null=True)
    screen_selection_tags = models.ManyToManyField(AttributeTagGroup)
    play_list = models.ForeignKey(ContentQueue,default="",null=True)
    account = models.ForeignKey(Account,default="")
    latest_report = models.URLField(null=True,default="",blank=True)
    units_per_play = models.IntegerField()
    ar_content = models.ForeignKey(Content,null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_advtcampaign", "Can view all AdvtCampaign"),
        )
#################################################################################
#  Master Ad Pack : Created by Sales / Marketing
#################################################################################
class MasterAdPack(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name = models.CharField(max_length=50)
    state = models.ForeignKey(PackState)
    num_plays = models.IntegerField()
    units_per_play = models.IntegerField()
    price = models.DecimalField(decimal_places=2,max_digits=15)
    created_by = models.ForeignKey(AccountUser,related_name="mp_created_by")
    created_date = models.DateTimeField()
    last_updated = models.DateTimeField()
    last_updated_by = models.ForeignKey(AccountUser,related_name="mp_updated_by")
    account = models.ForeignKey(Account,null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_masteradpack", "Can view all MasterAdPack"),
        )
#################################################################################
# Booked Slot
#################################################################################    
class BookedSlot(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    start_time = models.TimeField()
    num_units = models.IntegerField()
    unit_size = models.IntegerField()
    booking_state = models.ForeignKey(BookingState)
    account = models.ForeignKey(Account,null=True)
    class Meta:
        permissions = (
            ("view_all_bookedslot", "Can view all BookedSlot"),
        )
#################################################################################
# Booked Ad Pack for Entitlement
#################################################################################
class MasterEntitlement(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    account = models.ForeignKey(Account)
    day_part_entitled = models.ForeignKey(DayPart,default="")
    percent_slots_entitled_association = models.DecimalField(max_digits=5,decimal_places=2,default=0)
    percent_slots_entitled_consumer = models.DecimalField(max_digits=5,decimal_places=2,default=0)
    ticker_slots_entitled = models.DecimalField(max_digits=5,decimal_places=2,default=0)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_masterentitlement", "Can view all MasterEntitlement"),
            ("modify_all_masterentitlement", "Can modify all MasterEntitlement"),
        )
#################################################################################
# Booked Ad Pack
#################################################################################
class BookedAdPack(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    booked_screen = models.ForeignKey(Board)
    date_booked_for = models.DateField(db_index=True)
    day_part_booked_for = models.ForeignKey(DayPart,default="")
    slots_booked = models.ManyToManyField(BookedSlot)
    account=models.ForeignKey(Account)
    when_booked = models.DateTimeField()
    order_id = models.CharField(max_length=50,db_index=True)
    against_order = models.BooleanField(default=False)
    against_entitlement_association = models.BooleanField(default=False)
    against_entitlement_consumer = models.BooleanField(default=False)
    entitlement = models.ForeignKey(MasterEntitlement,null=True)
    applied_to = models.ForeignKey(AdvtCampaign,null=True)
    booking_state = models.ForeignKey(BookingState)
    num_plays = models.IntegerField()
    units_per_play = models.IntegerField()
    price = models.DecimalField(decimal_places=2,max_digits=15)
    unit_size = models.IntegerField(default=30)
    booking_type = models.CharField(max_length=50, default ="Normal")
    play_list = models.ForeignKey(ContentQueue,default="",null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_bookedadpack", "Can view all BookedAdPack"),
        )
#################################################################################
# Traffic Pattern - Master Data ( GREEN / ORANGE/ YELLOW
#################################################################################
class TrafficPattern(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=50)
    desc = models.CharField(max_length=500)
    account = models.ForeignKey(Account,null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_trafficpattern", "Can view all TrafficPattern"),
        )
#################################################################################
# Screen Location Traffic Stats - Entered against each primary location tag
#################################################################################
class ScreenLocationTrafficStats(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    location = models.ForeignKey(PrimaryLocationTag)
    day_part = models.ForeignKey(DayPart,default="")
    day_qualifier = models.ForeignKey(DayQualifier,null=True)
    associated_traffic = models.ForeignKey(TrafficPattern)
    account = models.ForeignKey(Account,null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_screenlocationtrafficstats", "Can view all ScreenLocationTrafficStats"),
        )
#################################################################################
#  Master Ad Pack Mappings - Map to different ad packs based on traffic stats
#                            and Primary attribute.
#################################################################################    
class MasterAdPackMappings(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    location_attribute = models.ForeignKey(PrimaryAttributeTag)
    traffic_pattern = models.ForeignKey(TrafficPattern)
    maps_to_pack = models.ForeignKey(MasterAdPack)
    created_by = models.ForeignKey(AccountUser,related_name="mpm_created_by")
    last_updated_by = models.ForeignKey(AccountUser,related_name="mpm_updated_by")
    last_updated_date = models.DateTimeField()
    created_date = models.DateTimeField()
    account = models.ForeignKey(Account,null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_masteradpackmappings", "Can view all MasterAdPackMappings"),
        )
#################################################################################
# CampaignInterests - Interests generated against campaign
#################################################################################
class CampaignInterests(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    interested_user = models.ForeignKey(AccountUser,null=True)
    interested_content = models.ForeignKey(ContentTarget)
    assoc_campaign = models.ForeignKey(AdvtCampaign,null=True)
    interest_time = models.DateTimeField()
    account = models.ForeignKey(Account,null=True)
    consumer_content_target_acted = models.UUIDField(null=True)
    class Meta:
        permissions = (
            ("view_all_campaigninterests", "Can view all CampaignInterests"),
        )
#################################################################################
# CTA's generated for the Campaign
#################################################################################
class UserInitiatedCTA(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    interested_user = models.ForeignKey(AccountUser,null=True)
    initiated_cta = models.ForeignKey(CTA)
    acted_cta_parameters = models.ManyToManyField(CTAParametersActed)
    assoc_campaign = models.ForeignKey(AdvtCampaign,null=True)
    cta_time = models.DateTimeField(default=timezone.now)
    account = models.ForeignKey(Account,null=True)
    consumer_content_target_acted = models.UUIDField(null=True)
    class Meta:
        permissions = (
            ("view_all_userinitiatedcta", "Can view all UserInitiatedCTA"),
        )
#################################################################################
# UserInitiatedVoucherCTA generated for the Campaign
#################################################################################
class VoucherCTAState(models.Model):
    name = models.CharField(max_length=50)
    
class UserInitiatedVoucherCTA(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    interested_user = models.ForeignKey(AccountUser,null=True)
    initiated_cta = models.ForeignKey(CTA)
    assoc_campaign = models.ForeignKey(AdvtCampaign,null=True)
    cta_time = models.DateTimeField(default=timezone.now)
    account = models.ForeignKey(Account,null=True)
    voucher_qr_code = models.TextField(default="")
    claimed_time = models.DateTimeField(default=timezone.now)
    claimed_amount = models.DecimalField(max_digits=15,decimal_places=2,default=0)
    claimed_percentage = models.DecimalField(max_digits=5,decimal_places=2,default=0)
    status= models.ForeignKey(VoucherCTAState)
    consumer_content_target_acted = models.UUIDField(null=True)
    class Meta:
        permissions = (
            ("view_all_userinitiatedvouchercta", "Can view all UserInitiatedVoucherCTA"),
        )
        
class ClaimedVoucherCTA(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    initiated_vouchercta = models.ForeignKey(UserInitiatedVoucherCTA)
    account = models.ForeignKey(Account,null=True)
    claimed_time = models.DateTimeField(default=timezone.now)
    claimed_amount = models.DecimalField(max_digits=15,decimal_places=2,default=0)
    claimed_percentage = models.DecimalField(max_digits=5,decimal_places=2,default=0)
    claim_for = models.ForeignKey(AdvtCampaign,null=True)
    class Meta:
        permissions = (
            ("view_all_claimedvouchercta", "Can view all ClaimedVoucherCTA"),
        )
    
#################################################################################
# Model for Board Play History
#################################################################################
class BoardPlayHistory(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    board = models.ForeignKey(Board)
    content_from_time = models.DateTimeField(default=timezone.now,db_index=True)
    content_to_time = models.DateTimeField(default=timezone.now,db_index=True)
    content_played = models.ForeignKey(Content)
    campaign = models.ForeignKey(AdvtCampaign,null=True)
    account = models.ForeignKey(Account,null=True)
    schedule_key = models.UUIDField(null=True)
    class Meta:
        permissions = (
            ("view_all_boardplayhistory", "Can view all BoardPlayHistory"),
        )
#################################################################################
# Model for Board Play History
#################################################################################
class ScreenDiagnostics(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    board = models.ForeignKey(Board)
    diagnostics_data_date = models.DateTimeField()
    number_of_resets_for_day = models.IntegerField()
    wifi_num_failed_connections = models.IntegerField()
    free_space = models.DecimalField(decimal_places=2,max_digits=10)
    wifi_average_speed = models.DecimalField(decimal_places=2,max_digits=10)
    schedule_lag_seconds = models.IntegerField()
    average_memory_usage = models.IntegerField()
    application_version = models.CharField(max_length=50)
    account = models.ForeignKey(Account,null=True)
    data_usage = models.DecimalField(decimal_places=2,max_digits=10,default=0.0)
    device_settings = models.CharField(max_length=500,default = "",null=True, blank=True)
    class Meta:
        permissions = (
            ("view_all_screendiagnostics", "Can view all ScreenDiagnostics"),
        )
#################################################################################
# Model for Device App Versions
#################################################################################
class DeviceAppVersion(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    app_version = models.CharField(max_length=50)
    release_date = models.DateTimeField(default=timezone.now)
    apk_location = models.TextField(default="",null=True,blank=True)
    account = models.ForeignKey(Account,null=True)
    hash = models.CharField(max_length=500, null=True, blank=True)
    app_type  = models.ForeignKey(AppType,default="")
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_deviceappversion", "Can view all DeviceAppVersion"),
        )
#################################################################################
# Device Configurations (For Each App Version)
#################################################################################
class DeviceConfiguration(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    applicable_app_version = models.CharField(max_length=50,db_index=True)
    upgrade_url = models.CharField(max_length=500)
    log_upload_url = models.TextField(default="",null=True,blank=True)
    log_upload_user = models.CharField(max_length=20)
    log_upload_password = models.CharField(max_length=20)
    account = models.ForeignKey(Account,null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_deviceconfiguration", "Can view all DeviceConfiguration"),
        )
#################################################################################
# Tapp Configurations
#################################################################################
class TappConfiguration(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    app_version = models.CharField(max_length=50,db_index=True)
    parameter = models.CharField(max_length=500,default="",null=True,blank=True)
    value = models.TextField(default="",null=True,blank=True)
    account = models.ForeignKey(Account,null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_tappconfiguration", "Can view all tappConfiguration"),
        )
#################################################################################
# Tapp Configurations
#################################################################################
class DeviceSecrets(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    board = models.ForeignKey(Board,default="",null=True,blank=True)
    parameter = models.CharField(max_length=500,default="",null=True,blank=True)
    value = models.TextField(default="",null=True,blank=True)
    account = models.ForeignKey(Account,null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_devicesecrets", "Can view all DeviceSecrets"),
        )
#################################################################################
# Model Capturing the Consumer viewer Contents
#################################################################################
class ConsumerContentTargets(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    show_spot_location_lat = models.CharField(max_length=20,blank=True)
    show_spot_location_long = models.CharField(max_length=20,blank=True)
    show_spot_location_key = models.UUIDField(null=True)
    show_spot_beacon_touched = models.CharField(max_length=20)
    show_spot_location_image_url = models.TextField(default="",null=True,blank=True)
    content_target = models.ForeignKey(ContentTarget)
    content = models.ForeignKey(Content,default="",null=True)
    time = models.DateTimeField()
    campaign = models.UUIDField(default=uuid.uuid4,db_index=True,null=True)
    account = models.ForeignKey(Account)
    class Meta:
        permissions = (
            ("view_all_consumercontenttargets", "Can view all ConsumerContentTargets"),
        )
##################################################################################
# All Signals
##################################################################################
class BeaconDiagnostics(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    beacon = models.ForeignKey(Beacon)
    timestamp = models.DateTimeField()
    battery_strength = models.DecimalField(max_digits=15,decimal_places=2)
    other_diags = models.CharField(max_length=500,default="")
    class Meta:
        permissions = (
            ("view_all_beacondiagnostics", "Can view all beacondiagnostics"),
        )
@receiver(post_save, sender=User)
def create_auth_token(sender, instance=None, created=False, **kwargs):
    if created:
        Token.objects.create(user=instance)
@receiver(post_delete, sender=AccountUser)
def delete_auth_user(sender, instance, **kwargs):
    print 'instance::::::::::',instance.account_user
    User.objects.filter(username = instance.account_user).delete()
    #instance.info.delete()
'''
@receiver(post_save, sender=Account)
def create_default_proflies(sender, instance=None, created=False, **kwargs):
    if created:
        admin_profile = UserProfile()
        admin_profile.profile_name = 'Account Admin'
        allowed_perms = ['manage_users','tag_screen','manage_userprofiles',
                         'manage_tags','manage_store','manage_content','manage_campaign', 
                         'change_account_settings']
        user_groups = []
        user_groups = Group.objects.filter(name__in=allowed_perms)
        admin_profile.account = instance
        admin_profile.save()
        admin_profile.user_groups = user_groups
        admin_profile.save()
'''        
class TrackBookingAlgo(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    trigger_time = models.DateTimeField(null=True, blank=True)
    end_time = models.DateTimeField(default=timezone.now) 
    
class UserQuery(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=30)
    company_name = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    contact_num = models.CharField(max_length=15)
    query_desc = models.CharField(max_length=1000)
    customer_type = models.CharField(max_length=50)
'''
################################################################################
#Model for Order Items Reference
################################################################################
class MyOrderItemsReference(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    item_type = models.CharField(max_length=50,null=True,blank=True,default = "")
    items = models.ManyToManyField(BookedAdPack)
'''
 
#################################################################################
#PromoParams
#################################################################################
class PromoParam(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=500)
    class Meta:
        permissions = (
            ("view_all_promoparam", "Can view all PromoParam"),
        )   
#################################################################################
#ConditionOperator
#################################################################################
class ConditionOperator(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    value = models.CharField(max_length=50)
    class Meta:
        permissions = (
            ("view_all_conditionoperator", "Can view all ConditionOperator"),
        )
#################################################################################
#PromoConditions
#################################################################################
class PromoCondition(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    parameter = models.ForeignKey(PromoParam)
    name=models.CharField(max_length=3,default="")
    last_modified_date = models.DateTimeField(default=timezone.now)
    value = models.CharField(max_length=500)
    description = models.TextField(null=True, blank=True,default="")
    operator = models.ForeignKey(ConditionOperator,null=True, blank=True,default="")
    class Meta:
        permissions = (
            ("view_all_promocondition", "Can view all PromoCondition"),
        )    
#################################################################################
#DiscountCoupon
#################################################################################
class DiscountCoupon(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    coupon_code = models.CharField(max_length=50,unique=True)
    coupon_conditions = models.ManyToManyField(PromoCondition)
    condition_expression = models.TextField(null=True, blank=True,default = "")
    last_modified_date = models.DateTimeField(default=timezone.now)
    expiry_date = models.DateField(default=timezone.now)
    valid_across_all_users = models.BooleanField(default=False)
    valid_users =  models.ManyToManyField(Account)
    discount_percentage = models.DecimalField(max_digits=5,decimal_places=2,default=0,null=True)
    max_amount_discounted =  models.DecimalField(decimal_places=2,max_digits=15,default=0,null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_discountcoupon", "Can view all DiscountCoupon"),
        )   

class TransactionReason(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    reason_text = models.CharField(max_length=150)
        
class AccountCreditTransactions(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    transaction_date = models.DateTimeField(auto_now=True)
    account=models.ForeignKey(Account)
    is_credit=models.BooleanField()
    amount=models.DecimalField(decimal_places=2,max_digits=15)
    transaction_reason = models.ForeignKey(TransactionReason)
    transaction_description = models.CharField(max_length=200)
    performing_user = models.ForeignKey(AccountUser,null=True)
    transaction_status = models.ForeignKey(BookingState)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_accountcredittransactions", "Can view all Credit transactions"),
        )
        
################################################################################
#Model for payment gateway integration
################################################################################
class MyOrder(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    items = models.TextField(null=True, blank=True,default = "")
    item_type = models.ForeignKey(ItemType,null=True, blank=True)
    order_date = models.DateField(auto_now=True,db_index=True)
    buyer = models.ForeignKey(AccountUser)
    txnid = models.CharField(max_length=36,db_index=True)
    actual_amount = models.FloatField(null=True, blank=True,default=0.0)
    hash = models.CharField(max_length=500, null=True, blank=True)
    status = models.ForeignKey(BookingState)
    account = models.ForeignKey(Account)
    applied_coupon = models.ForeignKey(DiscountCoupon,null=True, blank=True,default="")
    discounted_amount = models.FloatField(null=True, blank=True,default=0.0)
    campaign = models.ForeignKey(AdvtCampaign,null=True, blank=True,default="")
    credit_amount = models.FloatField(null=True, blank=True,default=0.0)
    paid_amount = models.FloatField(null=True, blank=True,default=0.0)
    applied_credit_trasaction = models.ManyToManyField(AccountCreditTransactions,default="")
    invoice = models.TextField(null=True, blank=True,default = "")
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_myorder", "Can view all MyOrder"),
        )
################################################################################
#model for consumer saved content targets
################################################################################
class ConsumerSavedContentTargets(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    content_target = models.ForeignKey(ContentTarget)
    date_time = models.DateTimeField(auto_now=True,db_index=True)
    account = models.ForeignKey(Account,null=True)
    campaign = models.ForeignKey(AdvtCampaign,null=True,default = "")
    content = models.ForeignKey(Content,null=True,default = "")
    class Meta:
        permissions = (
            ("view_all_consumersavedcontenttargets", "Can view all ConsumerSavedContentTargets"),
        )

#################################################################################
# Wifi Consumer Tracking
#################################################################################
class WifiConsumerTracking(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    start_time = models.DateTimeField(default=timezone.now,db_index=True)
    end_time = models.DateTimeField(default=timezone.now,db_index=True)
    devices_count = models.IntegerField(default=0,blank=True,null=True)
    event_location = models.ForeignKey(WifiCounter)
    class Meta:
        permissions = (
            ("view_all_wificonsumertracking", "Can view all WifiConsumerTracking"),
        )
        
#################################################################################
#Device Controller Commands
#################################################################################
class DeviceControlCommand(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=50,default = "")
    class Meta:
        permissions = (
            ("view_all_devicecontrolcommand", "Can view all DeviceControlCommand"),
        )
#################################################################################
#Device Controller
#################################################################################
class DeviceController(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    board = models.ForeignKey(Board)
    command = models.ForeignKey(DeviceControlCommand)
    request_start_time = models.DateTimeField(default=timezone.now)
    request_end_time = models.DateTimeField(default=timezone.now)
    request_state = models.ForeignKey(RequestState)
    parameter = models.CharField(max_length=500,default = "",null=True, blank=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_devicecontroller", "Can view all DeviceController"),
        )
################################################################################
#MasterAdPackReference
################################################################################
class MasterAdPackReference(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    count = models.IntegerField(default = 1)
    pack = models.ForeignKey(MasterAdPack)
    class Meta:
        permissions = (
            ("view_all_masteradpackreference", "Can view all MasterAdPackReference"),
        )
################################################################################
#DayPack
################################################################################
class DayPack(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name = models.CharField(max_length=50,unique=True)
    base_pack = models.ManyToManyField(MasterAdPackReference)
    state = models.ForeignKey(PackState)
    num_plays = models.IntegerField(db_index=True)
    units_per_play = models.IntegerField(db_index=True)
    price = models.DecimalField(decimal_places=2,max_digits=15)
    created_by = models.ForeignKey(AccountUser,related_name="dp_created_by")
    created_date = models.DateTimeField()
    last_updated = models.DateTimeField()
    last_updated_by = models.ForeignKey(AccountUser,related_name="dp_updated_by")
    account = models.ForeignKey(Account,null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_daypack", "Can view all DayPack"),
        )
class BookedDayPack(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    day_pack = models.ForeignKey(DayPack)
    booked_ad_pack = models.ManyToManyField(BookedAdPack)
    booked_screen_groups = models.ManyToManyField(AttributeTagGroup)
    date_booked_for = models.DateField(db_index=True)
    account=models.ForeignKey(Account)
    when_booked = models.DateTimeField()
    order_id = models.CharField(max_length=50,db_index=True)
    against_order = models.BooleanField(default=False)
    against_entitlement = models.BooleanField(default=False)
    entitlement = models.ForeignKey(MasterEntitlement,null=True)
    applied_to = models.ForeignKey(AdvtCampaign,null=True,blank = True)
    booking_state = models.ForeignKey(BookingState)
    num_plays = models.IntegerField()
    units_per_play = models.IntegerField(default=0,null=True,blank = True)
    price = models.DecimalField(decimal_places=2,max_digits=15)
    unit_size = models.IntegerField(default=30)
    booking_type = models.CharField(max_length=50, default ="Normal")
    play_list = models.ForeignKey(ContentQueue,default="",null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_bookeddaypack", "Can view all BookedDayPack"),
        )
#################################################################################
#Device DeviceLastContact
#################################################################################
class DeviceLastContact(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    last_contact_time = models.DateTimeField(default=timezone.now,db_index=True)
    board = models.ForeignKey(Board,default = "",null=True)
    status = models.TextField(default="",null=True,blank=True)
    class Meta:
        permissions = (
            ("view_all_devicelastcontact", "Can view all DeviceLastContact"),
        )
#################################################################################
# RpiLastContact
#################################################################################
class RpiLastContact(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    last_contact_time = models.DateTimeField(default=timezone.now,db_index=True)
    board = models.ForeignKey(Board,default = "",null=True)
    status = models.TextField(default="",null=True,blank=True)
    class Meta:
        permissions = (
            ("view_all_rpilastcontact", "Can view all RpiLastContact"),
        )
#################################################################################
#AfliateContent
#################################################################################
class AffiliateContent(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    planned_date = models.DateField(db_index=True)
    submitted_date= models.DateTimeField(default=timezone.now)
    play_list = models.ForeignKey(ContentQueue)
    screen_group = models.ManyToManyField(AttributeTagGroup)
    num_plays = models.IntegerField(default=0)
    play_order = models.IntegerField(default=0,db_index=True)
    submitted_account = models.ForeignKey(Account,default="",null=True,blank=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_affiliatecontent", "Can view all AffiliateContent"),
        )

class ActiveConsumerLocation(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    consumer_account = models.ForeignKey(Account)
    exit_time_stamp = models.DateTimeField(default=timezone.now,db_index=True)
    entry_time_stamp = models.DateTimeField(db_index=True)
    event_location = models.ForeignKey(ShowSpotAsset)
    is_active = models.BooleanField(db_index=True)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
    class Meta:
        permissions = (
            ("view_all_activeconsumerlocation", "Can view all ActiveConsumerLocation"),
        )
class DynamicSchedule(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    consumer_account = models.ForeignKey(Account,default="")
    board = models.ForeignKey(Board)
    play_list = models.ForeignKey(ContentQueue)
    created_time = models.DateTimeField()
    valid = models.BooleanField()
    invalidated_time = models.DateTimeField()
class ConsumerCuratedPlaylists(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    consumer_account = models.ForeignKey(Account)
    priority = models.IntegerField()
    play_list = models.ForeignKey(ContentQueue)

#################################################################################
#StorageAccount
#################################################################################
class StorageAccount(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    account = models.ForeignKey(Account)
    name = models.CharField(max_length=500,default = "",blank=True,null=True)
    class Meta:
        permissions = (
            ("view_all_storageaccount", "Can view all StorageAccount"),
        )
#################################################################################
#PPTConversion
#################################################################################
class PPTConversion(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    status = models.CharField(max_length=50,default = "",null=True,blank=True,db_index=True)
    ppt_url = models.CharField(max_length=500,default = "",null=True,blank=True)
    conversion_id = models.IntegerField(default = 0,null=True,blank=True)
    video_url = models.CharField(max_length=500,default = "",null=True,blank=True)
    content_key=models.UUIDField(default=uuid.uuid4)
    class Meta:
        permissions = (
            ("view_all_pptconversion", "Can view all PPTConversion"),
        )
        
class AffiliatePromotionPrefs(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    account = models.ForeignKey(Account)
    category = models.CharField(max_length=70)
    keywords = models.CharField(max_length=150,null=True,blank=True,default="")
    product_ids = models.CharField(max_length=200,null=True,blank=True,default="")
    date_from = models.DateField(db_index=True)
    date_to = models.DateField(db_index=True)
    preferred_daypart = models.ForeignKey(DayPart)
    priority = models.IntegerField(db_index=True)
    number_of_ads = models.IntegerField()
    channels_to_promote = models.ManyToManyField(AttributeTagGroup,default="")
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_affiliatepromotionprefs", "Can view all PromotionPrefs"),
        )
#################################################################################
#PPTConversion
#################################################################################
class PPTConversion(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    status = models.CharField(max_length=50,default = "",null=True,blank=True)
    ppt_url = models.TextField(default="",null=True,blank=True)
    conversion_id = models.IntegerField(default = 0,null=True,blank=True)
    video_url = models.TextField(default="",null=True,blank=True)
    content_key=models.UUIDField(default=uuid.uuid4)
    class Meta:
        permissions = (
            ("view_all_pptconversion", "Can view all PPTConversion"),
        )
#################################################################################
#SystemConfiguration
#################################################################################
class SystemConfiguration(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name=models.CharField(max_length=500,default = "",null=True,blank=True,db_index=True)
    value=models.TextField(null=True, blank=True,default = "")
    account=models.ForeignKey(Account,default="",null=True,blank=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_systemconfiguration", "Can view all SystemConfiguration"),
        )
#################################################################################
#ContentApprovals
#################################################################################
class ContentApprovals(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    content = models.ForeignKey(Content)
    action_state=models.ForeignKey(ContentState)
    action_takenby=models.ForeignKey(AccountUser)
    action_time=models.DateTimeField(default=timezone.now)
    action_comment = models.TextField(null=True, blank=True,default = "")
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_contentapprovals", "Can view all contentapprovals"),
        )
class FacebookSettings(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    account = models.ForeignKey(Account)
    fb_page_id = models.CharField(max_length=50)
    page_owner_id = models.CharField(max_length=50)
    posts_from_days_in_past = models.IntegerField(default=2)
    channels_to_promote = models.CharField(max_length=1000)
    enable = models.BooleanField(default=False)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_facebooksettings", "Can view all facebooksettings"),
        )
class ScreenAvailabilityStats(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    date = models.DateField(db_index=True)
    production_planned_slots = models.IntegerField(default=0)
    production_played_slots = models.IntegerField(default=0)
    normal_planned_slots = models.IntegerField(default=0)
    normal_played_slots = models.IntegerField(default=0)
    device_play_last_contacts = models.IntegerField(default=0)
    availability = models.DecimalField(max_digits=5,decimal_places=2,default=0)
    board = models.ForeignKey(Board)
    showspot = models.ForeignKey(ShowSpotAsset,default="") 
    screen_down_time = models.DurationField(default=timedelta())
    class Meta:
        permissions = (
            ("view_all_screenavailabilitystats", "Can view all ScreenAvailabilityStats"),
        )

class CampaignWifiCount(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    campaign = models.ForeignKey(AdvtCampaign)
    count = models.IntegerField(default=0)
    start_time = models.DateTimeField(db_index=True)
    end_time = models.DateTimeField(db_index=True)
    showspot = models.ForeignKey(ShowSpotAsset)
    class Meta:
        permissions = (
            ("view_all_campaignwificount", "Can view all CampaignWifiCount"),
        )
        
class MobileOTPCode(models.Model):
    account_user = models.ForeignKey(AccountUser)
    otp_code = models.CharField(max_length=6)
    code_validity = models.DateTimeField() 
    account = models.ForeignKey(Account,null=True)
    class Meta:
        permissions = (
            ("view_all_mobileotpcode", "Can view all MobileOTPCode"),
        )

#################################################################################
#Rpi Controller Commands
#################################################################################
class RpiControlCommand(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=50,default = "")
    class Meta:
        permissions = (
            ("view_all_rpicontrolcommand", "Can view all RpiControlCommand"),
        )
#################################################################################
#Rpi Controller
#################################################################################
class RpiController(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    board = models.ForeignKey(Board)
    command = models.ForeignKey(RpiControlCommand)
    request_start_time = models.DateTimeField(default=timezone.now)
    request_end_time = models.DateTimeField(default=timezone.now)
    request_state = models.ForeignKey(RequestState)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_rpicontroller", "Can view all RpiController"),
        )
class BidAllocationState(models.Model):
    key=models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    name=models.CharField(max_length=20)
#################################################################################
# Bid for a particluar day part and date
#################################################################################
class DayPartBid(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    dayPart = models.ForeignKey(DayPart)
    plays = models.IntegerField()
    bid_amount_per_play = models.FloatField()
    date = models.DateField()
    units = models.IntegerField()
#################################################################################
# Customer bids for the given channel and campaign
#################################################################################
class BidsForPlay(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    channel = models.ForeignKey(AttributeTagGroup)
    day_part_bids = models.ManyToManyField(DayPartBid)
    campaign = models.ForeignKey(AdvtCampaign)
    account = models.ForeignKey(Account)
    audit_log = AuditLog()
    bid_state = models.ForeignKey(BookingState)
    bid_time = models.DateTimeField(default=timezone.now)
    allocation_state = models.ForeignKey(BidAllocationState)
    booked_adpacks = models.ManyToManyField(BookedAdPack)
    class Meta:
        permissions = (
            ("view_all_bidsforplay", "Can view all BidsForPlay"),
        )
#################################################################################
# Model for Rpi Versions
#################################################################################
class RpiVersion(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    application_version = models.CharField(max_length=50)
    release_date = models.DateTimeField(default=timezone.now)
    code_location = models.TextField(default="",null=True,blank=True)
    account = models.ForeignKey(Account,null=True)
    hash = models.CharField(max_length=500, null=True, blank=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_rpiversion", "Can view all RpiVersion"),
        )
class RpiDiagnostics(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    board = models.ForeignKey(Board)
    application_version = models.CharField(max_length=50)
    account = models.ForeignKey(Account,null=True)
    class Meta:
        permissions = (
            ("view_all_rpidiagnostics", "Can view all RpiDiagnostics"),
        )
class ARAdPack(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False,db_index=True)
    pack_name=models.CharField(max_length=50)
    pack_description = models.TextField()
    applicable_days = models.IntegerField()
    pack_state=models.ForeignKey(PackState)
    no_of_unique_scans = models.IntegerField()
    price_per_scan = models.DecimalField(max_digits=5,decimal_places=2,default=0)
    no_of_unique_cta_actions = models.IntegerField()
    price_per_cta_action = models.DecimalField(max_digits=5,decimal_places=2,default=0)
    price = models.DecimalField(decimal_places=2,max_digits=15)
    account = models.ForeignKey(Account,null=True)
    audit_log = AuditLog()
    class Meta:
        permissions = (
            ("view_all_aradpack", "Can view all ArAdPack"),
        ) 
    
