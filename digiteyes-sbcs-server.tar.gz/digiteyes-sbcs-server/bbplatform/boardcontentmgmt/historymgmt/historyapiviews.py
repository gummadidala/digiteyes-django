'''
Created on 09-Jun-2017

@author: saba
'''
from rest_framework import generics
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from boardcontentmgmt.models import Board , BoardPlayHistory, AccountUser,  BoardRegistration,AttributeTagGroup
from boardcontentmgmt.models import BoardRegistrationCode, ScreenDiagnostics, ScreenStatus,ShowSpotAsset,WifiCounter
from django.contrib.auth.models import User

from boardcontentmgmt.models  import ResidentialComplex,AccountUser,ResidentConsumer,ContentState,CampaignState,ShowSpotAssetState

from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from rest_framework import filters
import django_filters
from django.apps import apps
from boardcontentmgmt.tasks import fill_consumer_content_targets_for_playhistory 
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework.pagination import PageNumberPagination
from rest_framework.authtoken.models import Token
from rest_framework.status import HTTP_400_BAD_REQUEST
from django.contrib.auth.models import User
#################################################################################
# Returns the change history of the given object
#################################################################################
class HistoryApiView(APIView):
    def get(self,request,format = None):
        modelname = request.query_params.get('model_name', None)
        keyn = request.query_params.get('object_key', None)
        if modelname is None or keyn is None:
            return Response("Model Name or Object key not provided", status=HTTP_400_BAD_REQUEST)
        model = apps.get_model(app_label='boardcontentmgmt', model_name=modelname+"AuditLogEntry")
        st=model.objects.filter(key=keyn)
        if len(st) == 0:
            return Response("No history records found for the given key", status=HTTP_400_BAD_REQUEST)
        list1=[]
        a=''
        count=len(st)
        index=0;
        dict_prev={}
        for item in st:
            if str(item.action_type)=='U':
                a="updated"
            if  str(item.action_type)=='I':
                a="created"
            user=User.objects.get(id=item.action_user_id)
            dict={'Serial number':str(count),
                  'user':user.first_name+" "+user.last_name,
                  'time':str(item.action_date),
                  'action':a}
            dict["log_records"]=[]
                
            if index!=len(st)-1:
                dict_current=item.__dict__
                dict_prev=st[index+1].__dict__
                for key in dict_current:
                    if dict_prev[key]!=dict_current[key]:
                        if key=="action_id" or key=="action_date" or key=="_state" or key=="action_type" or key=="action_user_id"  or key=="created_date":
                            pass
                        else:
                            print "index: ",index,key
                            if(modelname=="advtcampaign" and key=="state_id"):
                                p=CampaignState.objects.filter(id=unicode(dict_prev[key])).values()
                                c=CampaignState.objects.filter(id=unicode(dict_current[key])).values()
                                dict["log_records"].append({"field_name":unicode(key),
                                    "old_value":p[0]["state_name"],
                                    "new_value":c[0]["state_name"]})
                            elif(modelname=="content" and key=="content_state_id"):
                                p=ContentState.objects.filter(id=unicode(dict_prev[key])).values()
                                c=ContentState.objects.filter(id=unicode(dict_current[key])).values()
                                dict["log_records"].append({"field_name":unicode(key),
                                    "old_value":p[0]["state_name"],
                                    "new_value":c[0]["state_name"]})
                            elif(modelname=="showspotasset" and (key=="asset_state_id" or key=="attached_primary_location_tag_id" or key=="attached_primary_attribute_tag_id")):
                                c=ShowSpotAssetState.objects.filter(id=unicode(dict_current[key])).values()
                                if dict_prev[key] is None:
                                    dict["log_records"].append({"field_name":unicode(key),
                                        "old_value":"None",
                                        "new_value":c[0]["name"]})
                                else:
                                    p=ShowSpotAssetState.objects.filter(id=unicode(dict_prev[key])).values()
                                    dict["log_records"].append({"field_name":unicode(key),
                                        "old_value":p[0]["name"],
                                        "new_value":c[0]["name"]})
                            else:
                                dict["log_records"].append({"field_name":unicode(key),
                                    "old_value":unicode(dict_prev[key]),
                                    "new_value":unicode(dict_current[key])})
            if((dict["action"]=="updated" and len(dict["log_records"])>0) or dict["action"]=="created"):
                list1.append(dict)
            count=count-1
            index=index+1
        return Response(list1)

