from rest_framework import generics

from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters
import django_filters
from boardcontentmgmt.models import DeviceSecrets,AccountUser,Board
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from rest_framework import serializers
from boardcontentmgmt.screenmgmt.boardserializers import BoardBasicSerializer

class DeviceSecretsSerializer(serializers.ModelSerializer):
    board = BoardBasicSerializer()
    class Meta:
        model = DeviceSecrets
        fields = ('board','key','parameter','value')

class DeviceSecretsWriteSerializer(serializers.ModelSerializer):
    board = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='key')
    class Meta:
        model = DeviceSecrets
        fields = ('board','key','parameter','value')

class DeviceSecretsFilter(django_filters.FilterSet):
    board = django_filters.CharFilter(name='board__key',lookup_type='exact')
    parameter = django_filters.CharFilter(name='parameter',lookup_type='exact')
    class Meta:
        model = DeviceSecrets
	fields = ('board','parameter',)
#################################################################################
# DeviceAppConfigurationListView
#################################################################################
class DeviceSecretsListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = DeviceSecretsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('parameter', )
    filter_class = DeviceSecretsFilter
    search_fields = ('parameter',)
    lookup_field = 'key'
    def get_queryset(self):
        return DeviceSecrets.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return DeviceSecretsWriteSerializer
        return DeviceSecretsSerializer
#################################################################################
# DeviceAppConfigurationUpdateView
#################################################################################
class DeviceSecretsUpdateView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = DeviceSecretsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('parameter', )
    filter_class = DeviceSecretsFilter
    search_fields = ('parameter',)
    lookup_field = 'key'
    def get_queryset(self):
        return DeviceSecrets.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return DeviceSecretsWriteSerializer
        return DeviceSecretsSerializer
