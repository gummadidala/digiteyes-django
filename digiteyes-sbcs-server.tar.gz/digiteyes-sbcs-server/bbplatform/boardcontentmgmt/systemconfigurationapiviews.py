from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework import filters
from .models import SystemConfiguration,AccountUser
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
import datetime
from rest_framework import serializers
from boardcontentmgmt.screenmgmt.boardserializers import BoardBasicSerializer
##################################################################################
#Serializers for SystemConfiguration
#################################################################################
class SystemConfigurationSerializer(serializers.ModelSerializer):
    class Meta:
        model = SystemConfiguration
        fields = ['key','name','value']
class SystemConfigurationWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model = SystemConfiguration
        fields = ['key','name','value']
        
    def create(self,validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        return serializers.ModelSerializer.create(self,validated_data)
    
#################################################################################
#DeviceLastContact API List View - Supports Listing and Create
#################################################################################
class SystemConfigurationFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(name='name',lookup_type='exact')
    value  = django_filters.CharFilter(name='value',lookup_type='exact')
    class Meta:
        model = SystemConfiguration
	fields = ('name','value',)
class SystemConfigurationListView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,DjangoModelPermissions,DjangoObjectPermissions,)
    serializer_class  = SystemConfigurationSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name','value')
    filter_class = SystemConfigurationFilter
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'systemconfiguration') == True):
            return SystemConfiguration.objects.all()
        else:
            return SystemConfiguration.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return SystemConfigurationWriteSerializer
        return SystemConfigurationSerializer

class SystemConfigurationUpdateView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,DjangoModelPermissions,DjangoObjectPermissions,)
    serializer_class  = SystemConfigurationSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('name','value')
    filter_class = SystemConfigurationFilter
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'systemconfiguration') == True):
            return SystemConfiguration.objects.all()
        else:
            return SystemConfiguration.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return SystemConfigurationWriteSerializer
        return SystemConfigurationSerializer
        

    
    
    
    
