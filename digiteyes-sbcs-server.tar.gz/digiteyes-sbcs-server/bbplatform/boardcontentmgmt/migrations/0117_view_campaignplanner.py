from __future__ import unicode_literals
from django.contrib.auth.models import Group,Permission
from django.db import migrations
from django.db import IntegrityError, transaction
from boardcontentmgmt.models import UserProfile
from django.contrib.contenttypes.models import ContentType
from boardcontentmgmt.models import UserProfile,AccountUser

def view_campaign_planner(apps,schema_editor):
    with transaction.atomic():
        
        #Removing view_campaignpalnner group from users and profile
        UserProfile = apps.get_model("boardcontentmgmt", "UserProfile")
        AccountUser = apps.get_model("boardcontentmgmt", "AccountUser")
        Group = apps.get_model("auth", "Group")
        Permission = apps.get_model("auth", "Permission")
        prof = UserProfile.objects.filter(profile_name='Production Admin Profile')[0]
        grps = ['view_campaignpalnner']
        user_groups = Group.objects.filter(name__in=grps)
        for g in user_groups:
            prof.user_groups.remove(g)
            prof.save()
        profiles = [prof]
        usrs = AccountUser.objects.filter(user_profiles__in = profiles)
        for usr in usrs:
            prev_groups =usr.account_user.groups.all()
            if(len(prev_groups) > 0):
                for grp in prev_groups:
                    usr.account_user.groups.remove(Group.objects.get(name=grp.name))
                    usr.account_user.save()
                    
        profile = UserProfile.objects.filter(profile_name='Association Profile')
        if profile is not None and len(profile)>0:
            prof = profile[0] 
            grps = ['view_campaignpalnner']
            user_groups = Group.objects.filter(name__in=grps)
            for g in user_groups:
                prof.user_groups.remove(g)
                prof.save()
            profiles = [prof]
            usrs = AccountUser.objects.filter(user_profiles__in = profiles)
            for usr in usrs:
                prev_groups =usr.account_user.groups.all()
                if(len(prev_groups) > 0):
                    for grp in prev_groups:
                        usr.account_user.groups.remove(Group.objects.get(name=grp.name))
                        usr.account_user.save()
        
        #creating new view_campaignplanner group 
        g = Group()
        g.name = 'view_campaignplanner'
        g.save()
        
        
        #adding view_campaignpalnner group from users and profile
        prof = UserProfile.objects.filter(profile_name='Production Admin Profile')[0]
        grps = ['view_campaignplanner']
        user_groups = Group.objects.filter(name__in=grps)
        for g in user_groups:
            prof.user_groups.add(g)
            prof.save()
        profiles = [prof]
        usrs = AccountUser.objects.filter(user_profiles__in = profiles)
        for usr in usrs:
            prev_groups =usr.account_user.groups.all()
            if(len(prev_groups) > 0):
                for grp in prev_groups:
                    usr.account_user.groups.remove(Group.objects.get(name=grp.name))
                    usr.account_user.save()
            #adding user groups   
            for each_profile in profiles:
                for each_group in each_profile.user_groups.all(): 
                    usr.account_user.groups.add(Group.objects.get(name=each_group.name))
                    usr.account_user.save()
                    
        profile = UserProfile.objects.filter(profile_name='Association Profile')
        if profile is not None and len(profile)>0:
            prof = profile[0]
            grps = ['view_campaignplanner']
            user_groups = Group.objects.filter(name__in=grps)
            for g in user_groups:
                prof.user_groups.add(g)
                prof.save()
            profiles = [prof]
            usrs = AccountUser.objects.filter(user_profiles__in = profiles)
            for usr in usrs:
                prev_groups =usr.account_user.groups.all()
                if(len(prev_groups) > 0):
                    for grp in prev_groups:
                        usr.account_user.groups.remove(Group.objects.get(name=grp.name))
                        usr.account_user.save()
                #adding user groups   
                for each_profile in profiles:
                    for each_group in each_profile.user_groups.all(): 
                        usr.account_user.groups.add(Group.objects.get(name=each_group.name))
                        usr.account_user.save()

class Migration(migrations.Migration):

    dependencies = [
        ('boardcontentmgmt', '0116_modify_all_permission'),
    ]

    operations = [
        migrations.RunPython(view_campaign_planner)
    ]
