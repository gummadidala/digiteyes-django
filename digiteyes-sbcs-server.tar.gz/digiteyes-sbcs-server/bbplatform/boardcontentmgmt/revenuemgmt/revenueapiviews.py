from rest_framework import generics, serializers
from boardcontentmgmt.models import Board,ShowSpotAsset,BookedAdPack,AdvtCampaign,AccountUser
from rest_framework.response import Response
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from dateutil.parser import parse
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated

class BoardRevenueAPIView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions)
    def get(self,request):
        username = request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        brds  = Board.objects.filter(account__key = acct.key)
        total_revenue = 0
        if brds is not None and len(brds) > 0:
            for b in brds:
                baps = BookedAdPack.objects.filter(booked_screen__key = b.key)
                if baps is not None and len(baps) > 0:
                    for bp in baps:
                        total_revenue += bp.price
        responseData = {}
        responseData['total_revenue'] = total_revenue
        board = request.query_params.get('board', None)
        dt1 = parse(request.query_params.get('date1', None)).date()
        dt2 = parse(request.query_params.get('date2', None)).date()
        bkdadpcks = BookedAdPack.objects.filter(booked_screen__key = board, when_booked__gte = dt1,
                                               when_booked__lte = dt2 )
        revenue = 0
        if bkdadpcks is not None and len(bkdadpcks) > 0:
            for bp in bkdadpcks:
                revenue += bp.price
            responseData['revenue'] = revenue
            return Response(responseData) 
        else:  
            if 'total_revenue' not in responseData:
                responseData['total_revenue'] = 0
            if 'revenue' not in responseData:
                responseData['revenue'] = 0
            return Response(responseData)
        
class ShowspotRevenueAPIView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions)
    def get(self,request):
        username = request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        spots  = ShowSpotAsset.objects.filter(account__key = acct.key)
        total_revenue = 0
        for s in spots:
            board =  Board.objects.filter(show_spot__key = s.key)
            if board is not None and len(board) > 0:
                baps = BookedAdPack.objects.filter(booked_screen__key = board[0].key)
                if baps is not None and len(baps):
                    for bp in baps:
                        total_revenue += bp.price
        responseData = {}
        responseData['total_revenue'] = total_revenue
        
        shw_spot = request.query_params.get('show_spot', None)
        dt1 = parse(request.query_params.get('date1', None)).date()
        dt2 = parse(request.query_params.get('date2', None)).date()
        board =  Board.objects.filter(show_spot__key = shw_spot)
        revenue = 0
        if board is not None and len(board) > 0:
            bkdadpcks = BookedAdPack.objects.filter(booked_screen__key = board[0].key, when_booked__gte = dt1,
                                               when_booked__lte = dt2 )
            if bkdadpcks is not None and len(bkdadpcks) > 0:
                for bp in bkdadpcks:
                    revenue += bp.price
                responseData['revenue'] = revenue
            if 'total_revenue' not in responseData:
                responseData['total_revenue'] = 0
            if 'revenue' not in responseData:
                responseData['revenue'] = 0
            return Response(responseData) 
        else: 
            if 'total_revenue' not in responseData:
                responseData['total_revenue'] = 0
            if 'revenue' not in responseData:
                responseData['revenue'] = 0
            return Response(responseData) 