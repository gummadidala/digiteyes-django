from django.contrib.auth.models import Group
from boardcontentmgmt.models import Account,AccountUser,UserProfile

class Create_Profile():
    
    #create consumer profile
    def ConsumerProfile(self,acct):
        consumer_profile = UserProfile()
        consumer_profile.profile_name = 'Consumer Profile'
        allowed_perms = ['manage_consumers','contenttarget_view_all','manage_users']
        user_groups = Group.objects.filter(name__in=allowed_perms)
        consumer_profile.account = acct
        consumer_profile.user_group = []
        consumer_profile.save(force_insert=True)
        consumer_profile.user_groups = user_groups
        consumer_profile.save()
        
    #create advertiser profile
    def AdvertiserProfile(self,acct):
        advertiser_profile = UserProfile()
        advertiser_profile.profile_name = 'Advertiser Profile'
        allowed_perms = ['manage_users','manage_content','manage_campaign','manage_userprofiles',
                         'view_campaignplanner','showspot_view_all','primaryattributetag_view_all',
                         'primarylocationtag_view_all','manage_orders','manage_credit',
                         'primarylocationtag_view_all','view_discountcoupon']
        user_groups = Group.objects.filter(name__in=allowed_perms)
        advertiser_profile.account = acct
        advertiser_profile.user_group = []
        advertiser_profile.save(force_insert=True)
        advertiser_profile.user_groups = user_groups
        advertiser_profile.save()
        
    #create advertiser profile
    def AffiliateAdvertiserProfile(self,acct):
        advertiser_profile = UserProfile()
        advertiser_profile.profile_name = 'Affiliate Advertiser Profile'
        allowed_perms = ['manage_users','manage_content','manage_campaign','manage_userprofiles',
                         'view_campaignpalnner','showspot_view_all','primaryattributetag_view_all',
                         'primarylocationtag_view_all','view_discountcoupon','manage_affiliatecontent',
                         'manage_affiliateprefs']
        user_groups = Group.objects.filter(name__in=allowed_perms)
        advertiser_profile.account = acct
        advertiser_profile.user_group = []
        advertiser_profile.save(force_insert=True)
        advertiser_profile.user_groups = user_groups
        advertiser_profile.save()
        
    #create Association profile
    def AssociationProfile(self,acct):
        association_profile = UserProfile()
        association_profile.profile_name = 'Association Profile'
        allowed_perms = ['manage_users','manage_content','manage_userprofiles',
                         'view_showspot','showspot_approval','view_entitlement','manage_communitymessaging','manage_campaign']
        user_groups = Group.objects.filter(name__in=allowed_perms)
        association_profile.account = acct
        association_profile.user_group = []
        association_profile.save(force_insert=True)
        association_profile.user_groups = user_groups
        association_profile.save()
        
    #create Screen owner profile
    def ScreenOwnerProfile(self,acct):
        screen_owner_profile = UserProfile()
        screen_owner_profile.profile_name = 'ScreenOwner Profile'
        allowed_perms = ['view_screen']
        user_groups = Group.objects.filter(name__in=allowed_perms)
        screen_owner_profile.account = acct
        screen_owner_profile.user_group = []
        screen_owner_profile.save(force_insert=True)
        screen_owner_profile.user_groups = user_groups
        screen_owner_profile.save()
        
        
        