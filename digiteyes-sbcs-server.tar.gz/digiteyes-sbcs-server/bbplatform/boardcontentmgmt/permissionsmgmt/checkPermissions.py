from rest_framework import permissions
from boardcontentmgmt.models import AccountUser,UserProfile
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth.models import Permission

def get_perm(model_name, code_name):
    types = ContentType.objects.filter(app_label='boardcontentmgmt').filter(model=model_name)
    return Permission.objects.filter(content_type__in=types).filter(codename=code_name)[0]

def check_modify_perms(view,acct):
    values = []
    values = view.modify()
    if len(values) > 0:
        code_name=values[0]['permission'] 
        model_name=values[0]['model_name']
        perm_obj=get_perm(model_name, code_name)
                 
        grps = []
        profiles = UserProfile.objects.filter(account__account_name=acct.account_name)
        for prof in profiles.all():
            grps.extend(prof.user_groups.all())
            base_perms = []
            for gp in grps:
                base_perms.extend(gp.permissions.all())
            if perm_obj in base_perms:
                return True

class DjangoObjectPermissions(permissions.BasePermission):
    def has_permission(self, request, view):
        return True
    def has_object_permission(self, request, view, obj):
        #print 'Django has_object_permission:'
        if request.method in permissions.SAFE_METHODS:
            return True
        # Instance must have an attribute named `account`.
        username = request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if hasattr(view, 'modify'):
            return check_modify_perms(view,acct)
        if obj.account is not None:
            return obj.account.key == acct.key
        return True
    
    