from django.utils import timezone
from rest_framework import status
from django.utils.timezone import utc
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
import datetime
from rest_framework.authtoken.views import ObtainAuthToken
import logging
logger = logging.getLogger(__name__)
class ObtainExpiringAuthToken(ObtainAuthToken):
    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            token, created =  Token.objects.get_or_create(user=serializer.validated_data['user'])

            if not created:
                # update the created time of the token to keep it valid
                #token.created = datetime.datetime.utcnow().replace(tzinfo=utc)
                token.created = timezone.now()
                token.save()
                logger.info( 'created token at:' +token.created.isoformat())
            logger.info("CLIENT_LOGIN : USER : "+str(request.data['username']))
            return Response({'token': token.key})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

obtain_expiring_auth_token = ObtainExpiringAuthToken.as_view()