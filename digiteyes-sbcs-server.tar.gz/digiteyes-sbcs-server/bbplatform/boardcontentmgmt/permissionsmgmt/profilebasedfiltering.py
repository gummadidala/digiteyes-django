from boardcontentmgmt.models import AccountUser,UserProfile
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType
import logging
logger = logging.getLogger(__name__)

def get_perm(model_name, code_name):
    types = ContentType.objects.filter(app_label='boardcontentmgmt').filter(model=model_name)
    return Permission.objects.filter(content_type__in=types).filter(codename=code_name)[0]

class ProfileCheck():
    
    def get_filter(self,usr,model):
        logger.debug( 'inside get_user query filter')
        username = usr.username
        #print 'username:',username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        grps = []
        profiles = UserProfile.objects.filter(account__account_name=acct.account_name)
        for prof in profiles.all():
            grps.extend(prof.user_groups.all())
        base_perms = []
        for gp in grps:
            base_perms.extend(gp.permissions.all())
        #print 'base permissions:', base_perms
        permission  = 'view_all_'+model
        #print 'model:',model
        #print 'permission:',permission
        perm = get_perm(model,permission)
        #print 'permission:',permission
        if perm in base_perms:
            #print 'returning true'
            return True
        else:
            #print 'returning false'
            return False
    
