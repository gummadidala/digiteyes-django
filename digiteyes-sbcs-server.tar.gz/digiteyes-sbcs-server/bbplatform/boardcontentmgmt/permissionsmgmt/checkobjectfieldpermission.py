from rest_framework import permissions
from django.contrib.auth.models import Group
from boardcontentmgmt.models import AccountUser,UserProfile
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType

import logging
logger = logging.getLogger(__name__)

def get_perm(model_name, code_name):
    types = ContentType.objects.filter(app_label='boardcontentmgmt').filter(model=model_name)
    return Permission.objects.filter(content_type__in=types).filter(codename=code_name)[0]

class PermissionCheck(permissions.BasePermission):
    
    def has_permission(self, request, view):
        return True
    def has_object_permission(self, request, view,obj):
        logger.debug( 'inside field permission check')
        username = request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        grps = []
        profiles = UserProfile.objects.filter(account__account_name=acct.account_name)
        for prof in profiles.all():
            grps.extend(prof.user_groups.all())
        base_perms = []
        for gp in grps:
            base_perms.extend(gp.permissions.all())
        #print 'base permissions:', base_perms
        field_obj_perms = []
        if hasattr(view, 'special'):
            field_obj_perms = view.special()
        if len(field_obj_perms) > 0:
            field_perms = []
            states = []
            field_names = []
            model_names = []
            #print 'field_permissions:', view.field_permissions
            for vpf in field_obj_perms:
                field_names.append(vpf['field_name'])
                field_perms.extend(vpf['permission'])
                states.extend(vpf['state'])
                model_names.append(vpf['model_name'])
            #print 'states:', states
            #print 'field perms:', field_perms
            #print 'field_names:',field_names
        if (request.method == 'PUT' or request.method == 'PATCH'):
            #print "incoming data:", request.data
            for field in field_names:
                #print 'field:',field
                if field in request.data and request.data[field] in states: 
                    for per in field_perms:
                        perm = get_perm(model_names[0],per)
                        if perm in base_perms:
                            return True
                        else:
                            return False
                            logger.warn('User does not have permission to perform this action')
                else:
                    print ' field object perms failed calling django model and object permissions'
                    logger.info( 'field permissions is not present')
                    return DjangoModelPermissions().has_permission(request, view) and DjangoModelPermissions().has_object_permission(request, view, obj) and DjangoObjectPermissions().has_permission(request, view) and DjangoObjectPermissions().has_object_permission(request, view, obj)
        else:
            return DjangoModelPermissions().has_permission(request, view) and DjangoModelPermissions().has_object_permission(request, view, obj) and DjangoObjectPermissions().has_permission(request, view) and DjangoObjectPermissions().has_object_permission(request, view, obj)
                        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
