from rest_framework import serializers
from boardcontentmgmt.models import Account,ContentLabel,Layout,LayoutLabel,LayoutMapping,AccountUser
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer

class LayoutMappingSerializer(serializers.ModelSerializer):
    content_label=serializers.SlugRelatedField(
        queryset=ContentLabel.objects.all(),
        slug_field='name',required = False)
    layout_label=serializers.SlugRelatedField(
        queryset=LayoutLabel.objects.all(),
        slug_field='name',required = False)
    class Meta:
        model = LayoutMapping
        fields = ['account','layout_label','key','content_label']

class LayoutMappingShortSerializer(serializers.ModelSerializer):
    content_label=serializers.SlugRelatedField(
        queryset=ContentLabel.objects.all(),
        slug_field='name',required = False)
    layout_label=serializers.SlugRelatedField(
        queryset=LayoutLabel.objects.all(),
        slug_field='name',required = False)
    class Meta:
        model = LayoutMapping
        fields = ['layout_label','key','content_label']

class LayoutMappingWriteSerializer(serializers.ModelSerializer):
    content_label =serializers.SlugRelatedField(
        queryset=ContentLabel.objects.all(),
        slug_field='name')
    layout_label = serializers.SlugRelatedField(
        queryset=LayoutLabel.objects.all(),
        slug_field='name')
    class Meta:
        model = LayoutMapping
        fields = ['account','layout_label','key','content_label']
    def create(self,validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        return serializers.ModelSerializer.create(self,validated_data)
class LayoutSerializer(serializers.ModelSerializer):
    layout_locations = LayoutMappingSerializer(many=True)
    class Meta:
        model = Layout
        fields = ['name','layout_locations','key']

class LayoutShortSerializer(serializers.ModelSerializer):
    layout_locations = LayoutMappingShortSerializer(many=True)
    class Meta:
        model = Layout
        fields = ['name','layout_locations','key']


class LayoutWriteSerializer(serializers.ModelSerializer):
    layout_locations= serializers.SlugRelatedField(
        queryset=LayoutMapping.objects.all(),
        slug_field='key',many=True)
    class Meta:
        model = Layout
        fields = ['name','layout_locations','key']