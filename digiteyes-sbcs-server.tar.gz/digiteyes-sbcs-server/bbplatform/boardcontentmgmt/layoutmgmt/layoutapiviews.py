from rest_framework.views import APIView
from rest_framework import generics
from rest_framework import filters
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from django.http.response import Http404
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.pagination import PageNumberPagination
import django_filters

from boardcontentmgmt.models import LayoutMapping, AccountUser, Layout
from .layoutserializers import LayoutMappingSerializer,LayoutSerializer,LayoutWriteSerializer,LayoutMappingWriteSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from dateutil.parser import parse
from datetime import datetime
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck

class LayoutMappingsListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = LayoutMappingSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('layout_label__name','content_label__name',)
    search_fields = ('layout_label__name','layout_label__name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        '''
        if(ProfileCheck().get_filter(self.request.user,'layoutmapping') == True):
            return LayoutMapping.objects.all()
        else:
        '''
        return LayoutMapping.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return LayoutMappingWriteSerializer
        return LayoutMappingSerializer
    
class LayoutMappingsUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = LayoutMappingSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('layout_label__name','content_label__name',)
    search_fields = ('layout_label__name','layout_label__name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        '''
        if(ProfileCheck().get_filter(self.request.user,'layoutmapping') == True):
            return LayoutMapping.objects.all()
        else:
        '''
        return LayoutMapping.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'PUT' or elf.request.method == 'PATCH' :
            return LayoutMappingWriteSerializer
        return LayoutMappingSerializer
    
class LayoutListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = LayoutSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        '''
        if(ProfileCheck().get_filter(self.request.user,'layout') == True):
            return Layout.objects.all()
        else:
        '''
        return Layout.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return LayoutWriteSerializer
        return LayoutSerializer

class LayoutUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = LayoutSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        '''
        if(ProfileCheck().get_filter(self.request.user,'layout') == True):
            return Layout.objects.all()
        else:
        '''
        return Layout.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or elf.request.method == 'PATCH' :
            return LayoutWriteSerializer
        return LayoutSerializer