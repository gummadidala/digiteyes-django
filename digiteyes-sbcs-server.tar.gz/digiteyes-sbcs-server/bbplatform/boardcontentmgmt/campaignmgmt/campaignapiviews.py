from rest_framework.views import APIView
from rest_framework import generics
from rest_framework import filters
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from django.http.response import Http404
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.pagination import PageNumberPagination
import django_filters

from boardcontentmgmt.models import Board, AdvtCampaign, AccountUser ,DayPart,\
        AttributeTagGroup,ResidentialComplex,ShowSpotAsset,ContentQueue,BookedAdPack
from .campaignserializers import AdvtCampaignSerializer,AdvtCampaignShortSerializer
from .campaignserializers import AdvtCampaignWriteSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from dateutil.parser import parse
import datetime
from datetime import timedelta
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from boardcontentmgmt.utilities.algo_utilities import get_available_day_parts
from boardcontentmgmt.accountmgmt.residentialcomplexserializers import ResidentialComplexSerializer
import sys,traceback
import logging
logger = logging.getLogger(__name__)
from django.db.models import Max,Min
################################################################################
#Datetime filter calss
################################################################################
def filter_start_date(queryset,value):
    if value is not None:
        logger.debug( "filter_start_date")
        queryset = queryset.annotate(start_date = Min('planned_dates__date')).filter(
                                                  start_date__gte= value)
        logger.debug( queryset)
    return queryset
def filter_end_date(queryset,value):
    if value is not None:
        logger.debug( "filter_end_date")
        queryset = queryset.annotate(end_date = Max('planned_dates__date')).filter(
                                                  end_date__lte = value)
        logger.debug( queryset)
    return queryset
class CustomPagination(PageNumberPagination):
    page_size_query_param = 'page_size'
class CampaignFilter(django_filters.FilterSet):
    #start_date = django_filters.DateFilter(name='planned_dates__date',lookup_type='contains')
    #end_date = django_filters.DateFilter(name='planned_dates__date',lookup_type='contains')
    start_date = django_filters.DateFilter(name='start_date',action=filter_start_date)
    end_date = django_filters.DateFilter(name='end_date',action=filter_end_date)
    state = django_filters.CharFilter(name='state__state_name',lookup_type='exact')
    play_list = django_filters.CharFilter(name='play_list',lookup_type='isnull')
    account = django_filters.CharFilter(name='account__account_name',lookup_type='exact')
    type = django_filters.CharFilter(name='type__name',lookup_type='exact')
    class Meta:
        model = AdvtCampaign
	fields = ('start_date','end_date','state','play_list','account',)
#################################################################################
# Campaign List API List View
#################################################################################
class CampaignListView(generics.ListCreateAPIView):
    """
    Campaign List
    =============
    ##GET:
    List of Campaigns available in the Account. Campaigns are planned for a goal, with targeting certain
    content at certain screens,
    ###Filter Fields:
        1. Campaign State (campaign_state)
        
    ###Search Fileds:
        1. Campaign Name
        
    ##POST:
    
    Create a Campaign with the Account.
    ###Required fields are
        1. Campaign Name (campaign_name)
        2. Start Date
        3. End Date
    
    Campaigns are automatically put into the logged user's Account, with which this create call is made. The logged
    in user automatically becomes the Campaign owner.
    """
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    serializer_class = AdvtCampaignSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('state__state_name')
    filter_class = CampaignFilter
    pagination_class = CustomPagination
    search_fields = ('name',)
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'advtcampaign') == True):
            return AdvtCampaign.objects.all()
        else:
            return AdvtCampaign.objects.filter(account__key = acct.key)
        #return AdvtCampaign.objects.filter(account__key = acct.key)
        
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return AdvtCampaignWriteSerializer
        return AdvtCampaignSerializer
    def post(self, request, *args, **kwargs):
        parsed_data = request.data
        planned_dates = parsed_data['planned_dates']
        #booking_date_limit_march = datetime.datetime(2017,3,31,0,0).date()
        booking_date_sixty_days = datetime.datetime.now().date()+timedelta(days=60)
        #booking_date_limit = min(booking_date_limit_march,booking_date_sixty_days)
        booking_date_limit = booking_date_sixty_days
        for dt in planned_dates:
            if datetime.datetime.strptime(dt['date'],"%Y-%m-%d").date() > booking_date_limit:
                return Response({'error':'Sorry! Campaign can not be created after March 31 2017 or 60 days from today.'},
                                status=HTTP_400_BAD_REQUEST)
        return generics.ListCreateAPIView.post(self, request, *args, **kwargs)
    
#################################################################################
#Campaign Detail API View
#################################################################################
def update_bookedadpacks(camp_key,play_list_key):
    print "In update_bookedadpacks"
    camp = AdvtCampaign.objects.filter(key=camp_key)[0]
    current_date = datetime.datetime.now().date()
    current_date_time = datetime.datetime.now()
    curr_dayparts = []
    all_dayparts = DayPart.objects.all()
    i=0
    for i in range(len(all_dayparts)):
        to_time = all_dayparts[i].to_time
        to_date_time = datetime.datetime.combine(datetime.datetime.now().date(),to_time)
        from_time = all_dayparts[i].from_time
        from_date_time = datetime.datetime.combine(datetime.datetime.now().date(),from_time)
        if i==0:
            start_time = from_date_time
        if  i== len(all_dayparts)-1:
            end_time = from_date_time
        if current_date_time <= to_date_time:
            curr_dayparts.append(all_dayparts[i])
        
    if current_date_time >= end_time:
        curr_dayparts = DayPart.objects.all()
        current_date = current_date+timedelta(days=1)
    elif current_date_time <= start_time:
        curr_dayparts = DayPart.objects.all()
                
    bookedadpacks = BookedAdPack.objects.filter(applied_to__key = camp_key,
                                                date_booked_for = current_date.strftime("%Y-%m-%d"),
                                                day_part_booked_for__in = curr_dayparts)
    if bookedadpacks is not None and len(bookedadpacks)>0:
        for bap in bookedadpacks:
            bap.play_list = ContentQueue.objects.filter(key=play_list_key)[0]
            bap.save()
            
    bookedadpacks = BookedAdPack.objects.filter(applied_to__key = camp_key,
                                                date_booked_for__gt = current_date.strftime("%Y-%m-%d"))
    if bookedadpacks is not None and len(bookedadpacks)>0:
        for bap in bookedadpacks:
            bap.play_list = ContentQueue.objects.filter(key=play_list_key)[0]
            bap.save()
    
class CampaignDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    Campaign Details
    =============
    ##GET:
    Details of the given Campaign queried with the key.
        
    ##PUT:
    
    Updates the given Campaign Object indicated by the key. Mostly used to update states, dates etc.,
    
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    serializer_class = AdvtCampaignSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_class = CampaignFilter
    search_fields = ('campaign_name',)
    pagination_class = CustomPagination
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'advtcampaign') == True):
            return AdvtCampaign.objects.all()
        else:
            return AdvtCampaign.objects.filter(account__key = acct.key)
        #return AdvtCampaign.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return AdvtCampaignWriteSerializer
        return AdvtCampaignSerializer
    
    '''
    def perform_update(self, serializer):
        print 'play_list :',serializer.instance.play_list
        username = self.request.user.username
        update_bookedadpacks(str(serializer.instance.key))
        '''
    def patch(self, request, *args, **kwargs):
        parsed_data = request.data
        camp_key = parsed_data['campaign']
        if 'play_list' in parsed_data and parsed_data['play_list'] is not None:
            update_bookedadpacks(camp_key,parsed_data['play_list'])
        return generics.RetrieveUpdateDestroyAPIView.patch(self, request, *args, **kwargs)
    
class GroupInfoView(generics.ListCreateAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    def get_queryset(self):
        return Response('Get method is not implemented')
    def get(self,request):
        res={}
        grp = self.request.query_params.get('group', None)
        if grp is not None:
            grp_obj = AttributeTagGroup.objects.filter(key=grp)
            if grp_obj is not None and len(grp_obj)>0:
                spot_obj = ShowSpotAsset.objects.filter(attached_attribute_tag__in=grp_obj)
                if spot_obj is not None and len(spot_obj)>0:
                    brd_cnt = 0
                    for obj in spot_obj:
                        brd = Board.objects.filter(show_spot__key=obj.key,board_state__name='LIVE')
                        if brd is not None and len(brd)>0:
                            brd_cnt = brd_cnt+1
                    res['screen_count']=brd_cnt
                    complex_obj = ResidentialComplex.objects.filter(account__key=spot_obj[0].account.key)
                    if complex_obj is not None and len(complex_obj)>0:
                        res['association']=ResidentialComplexSerializer(complex_obj[0]).data
                    else:
                        error = {'error':'apartment_complex is not found'}
                        return Response(error,status=HTTP_400_BAD_REQUEST)
                else:
                    error = {'error':'show spots not found'}
                    return Response(error,status=HTTP_400_BAD_REQUEST)
            else:
                error = {'error':'group not found'}
                return Response(error,status=HTTP_400_BAD_REQUEST)
        else:
            error = {'error':'Expecting attribute_tag_group key'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        return Response(res,status=HTTP_201_CREATED)  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
