from rest_framework import serializers
from boardcontentmgmt.models import CampaignInterests, UserInitiatedCTA, AdvtCampaign, Account
from boardcontentmgmt.models import AccountUser, CTA, ContentTarget,CTAParametersActed
from boardcontentmgmt.accountmgmt.accountuserserializers import AccountUserShortSerializer
from boardcontentmgmt.contentmgmt.adcontentserializers import CTASerializer,CTAParameterActedSerializer
from boardcontentmgmt.contentmgmt.adcontentserializers import ContentTargetSerializer
from datetime import datetime
from boto3.dynamodb.table import logger

class CampaignInterestsSerializer(serializers.ModelSerializer):
    interested_user = AccountUserShortSerializer()
    interested_content = ContentTargetSerializer()
    assoc_campaign = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key',required=False)
    class Meta:
        model = CampaignInterests
        fields = ('interested_user','interested_content','assoc_campaign',
                  'interest_time','key','consumer_content_target_acted')
class CampaignInterestsWriteSerializer(serializers.ModelSerializer):
    interested_content = serializers.SlugRelatedField(
        queryset=ContentTarget.objects.all(),
        slug_field='key')
    assoc_campaign = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key',required=False)
    consumer_content_target_acted = serializers.UUIDField(required=False)
    class Meta:
        model = CampaignInterests
        fields = ('interested_content','assoc_campaign',
                  'interest_time','key','consumer_content_target_acted')
    def create(self,validated_data):
        logger.debug('Incoming data in CampaignInterests:'+str(validated_data))
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['interested_user'] = aUsr[0]
        if 'assoc_campaign' not in validated_data:
            validated_data['assoc_campaign'] = None
        if 'consumer_content_target_acted'  not in validated_data:
            validated_data['consumer_content_target_acted'] = None
        return serializers.ModelSerializer.create(self,validated_data)

class UserInitiatedCTASerializer(serializers.ModelSerializer):
    interested_user = AccountUserShortSerializer()
    initiated_cta = CTASerializer()
    assoc_campaign = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key')
    acted_cta_parameters = CTAParameterActedSerializer(many=True,required=False)
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key')
    class Meta:
        model = UserInitiatedCTA
        fields = ('interested_user','initiated_cta','assoc_campaign',
                  'cta_time','key','acted_cta_parameters','account','consumer_content_target_acted')

class UserInitiatedCTAWriteSerializer(serializers.ModelSerializer):
    interested_user = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key',required=False)
    initiated_cta = serializers.SlugRelatedField(
        queryset=CTA.objects.all(),
        slug_field='key')
    assoc_campaign = serializers.SlugRelatedField(
        queryset=AdvtCampaign.objects.all(),
        slug_field='key',required=False)
    cta_time=serializers.DateTimeField(default=datetime.now())
    acted_cta_parameters = serializers.SlugRelatedField(
        queryset=CTAParametersActed.objects.all(),
        slug_field='key',required=False,many=True)
    consumer_content_target_acted = serializers.UUIDField(required=False)
    class Meta:
        model = UserInitiatedCTA
        fields = ('interested_user','initiated_cta','assoc_campaign',
                  'cta_time','key','acted_cta_parameters','consumer_content_target_acted')
    def create(self,validated_data):
        usr = self.context['request'].user
        if usr is not None:
            aUsr = AccountUser.objects.filter(account_user__username = usr.username)
            if aUsr is not None and len(aUsr)>0:
                acct = aUsr[0].account
                validated_data['interested_user'] = aUsr[0]
                validated_data['account']=acct
        if 'acted_cta_parameters' not in validated_data:
            validated_data['acted_cta_parameters']=[]
        if 'assoc_campaign' not in validated_data:
            validated_data['assoc_campaign'] = None
        if 'consumer_content_target_acted'  not in validated_data:
            validated_data['consumer_content_target_acted'] = None
        return serializers.ModelSerializer.create(self,validated_data)