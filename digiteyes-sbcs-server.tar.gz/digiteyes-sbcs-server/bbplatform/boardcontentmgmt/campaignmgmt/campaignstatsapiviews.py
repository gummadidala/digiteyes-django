from rest_framework import generics
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated

from rest_framework import filters
import django_filters
from boardcontentmgmt.campaignmgmt.campaignstatsserializers import CampaignInterestsSerializer,CampaignInterestsWriteSerializer
from boardcontentmgmt.models import CampaignInterests,UserInitiatedCTA,AccountUser,CTAParametersActed
from .campaignstatsserializers import UserInitiatedCTASerializer
from .campaignstatsserializers import UserInitiatedCTAWriteSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.contentmgmt.adcontentserializers import CTAParameterActedSerializer

class CTAParametersActedListView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)# DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = CTAParameterActedSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('type__name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        '''
        if(ProfileCheck().get_filter(self.request.user,'cta') == True):
            return CTA.objects.all()
        else:
            return CTA.objects.filter(account__key = acct.key)
            '''
        return CTAParametersActed.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return CTAParameterActedSerializer
        return CTAParameterActedSerializer
#################################################################################
# Campaign Interests List API List View
#################################################################################
class CampaignInterestsListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = CampaignInterestsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_fields = ('board_state__name', 'account__account_name','account')
    #search_fields = ('board_name',)
    lookup_field = 'key'
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'campaigninterests') == True):
            return CampaignInterests.objects.all()
        else:
            return CampaignInterests.objects.filter(account__key = acct.key)
        #return CampaignInterests.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return CampaignInterestsWriteSerializer
        return CampaignInterestsSerializer
class CTAFilter(django_filters.FilterSet):
    cta = django_filters.CharFilter(name='initiated_cta__key',lookup_type='exact')
    type=django_filters.CharFilter(name='initiated_cta__type__name',lookup_type='exact')
    campaign=django_filters.CharFilter(name='assoc_campaign__key',lookup_type='exact')
    class Meta:
        model = UserInitiatedCTA
	fields = ('cta','type','campaign',)
class UserInitiatedCTAsListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = UserInitiatedCTASerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_fields = ('initiated_cta__key', 'account__account_name','account__key','initiated_cta__type')
    
    
    #search_fields = ('initiated_cta__key', 'account__account_name','account__key','initiated_cta__type')
    filter_class = CTAFilter
    lookup_field = 'key'
    def get_queryset(self):
        cta_type = self.request.query_params.get('type', None)
        print 'type',cta_type
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if cta_type is not None and cta_type=="REVIEW":
            return UserInitiatedCTA.objects.all()
        if(ProfileCheck().get_filter(self.request.user,'userinitiatedcta') == True):
            return UserInitiatedCTA.objects.all()
        else:
            return UserInitiatedCTA.objects.filter(account__key = acct.key)
        return UserInitiatedCTA.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return UserInitiatedCTAWriteSerializer
        return UserInitiatedCTASerializer
