from rest_framework import serializers

from boardcontentmgmt.models import AdvtCampaign, AccountUser, Account, CampaignState, ContentQueue, CampaignType, Content
from boardcontentmgmt.accountmgmt.accountuserserializers import AccountUserShortSerializer
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from boardcontentmgmt.contentmgmt.adcontentserializers import ContentQueueSerializer, ContentSerializer
from boardcontentmgmt.tagmgmt.tagserializers import AttributeTagGroupShortSerializer
from boardcontentmgmt.models import DayPart,AdvtCampaignDate,AttributeTagGroup
import sys,traceback
from boardcontentmgmt.models import CampaignType
import logging
logger = logging.getLogger(__name__)

class AdvtCampaignDateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AdvtCampaignDate
        fields = ('date','key')
    def create(self, validated_data):
        obj = AdvtCampaignDate()
        obj.date = validated_data['date']
        obj.save()
        return obj
    
class AdvtCampaignSerializer(serializers.ModelSerializer):
    owner = AccountUserShortSerializer()
    state = serializers.SlugRelatedField(
        queryset=CampaignState.objects.all(),
        slug_field='state_name')
    type = serializers.SlugRelatedField(
        queryset=CampaignType.objects.all(),
        slug_field='name')
    account = AccountSerializer()
    play_list = ContentQueueSerializer()
    dayPart_selected = serializers.SlugRelatedField(
        queryset=DayPart.objects.all(),
        slug_field='name')
    planned_dates = serializers.SlugRelatedField(
        queryset=AdvtCampaignDate.objects.all(),
        slug_field='date',many=True)
    screen_selection_tags = AttributeTagGroupShortSerializer(many=True)
    ar_content = ContentSerializer()
    class Meta:
        model = AdvtCampaign
        fields = ('name','owner','created_date', 'planned_dates', 
                  'play_list','state','selected_plays_per_day',
                  'total_screens_selected','type','units_per_play',
                  'screen_selection_tags','dayPart_selected','account','key','latest_report','ar_content')
    
class AdvtCampaignWriteSerializer(serializers.ModelSerializer):
    owner = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key',required=False)
    state = serializers.SlugRelatedField(
        queryset=CampaignState.objects.all(),
        slug_field='state_name',required=False)
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    play_list = serializers.SlugRelatedField(
        queryset=ContentQueue.objects.all(),
        slug_field='key',required=False,allow_null=True)
    dayPart_selected = serializers.SlugRelatedField(
        queryset=DayPart.objects.all(),
        slug_field='name',required=False,allow_null=True)
    type = serializers.SlugRelatedField(
        queryset=CampaignType.objects.all(),
        slug_field='name')
    screen_selection_tags = serializers.SlugRelatedField(
        queryset=AttributeTagGroup.objects.all(),
        slug_field='key',many=True,required=False)
    '''
    planned_dates = serializers.SlugRelatedField(
        queryset=AdvtCampaignDate.objects.all(),
        slug_field='date',many=True)
        '''
    planned_dates=AdvtCampaignDateSerializer(many=True)
    ar_content = serializers.SlugRelatedField(
        queryset=Content.objects.all(),
        slug_field='key',required=False)
    
    class Meta:
        model = AdvtCampaign
        fields = ('name','owner','created_date', 'planned_dates', 
                  'state','selected_plays_per_day','units_per_play',
                  'total_screens_selected','type',
                  'screen_selection_tags','dayPart_selected',
                  'play_list','account','key','latest_report','ar_content')
    def create(self,validated_data):
        #print validated_data
        try:
            usr = self.context['request'].user
            aUsr = AccountUser.objects.filter(account_user__username = usr.username)
            submitted_state = CampaignState.objects.filter(state_name='SUBMITTED')
            planned_state= CampaignState.objects.filter(state_name='PLANNED')
            '''
            validated_data['account'] = aUsr[0].account
            validated_data['owner'] = aUsr[0]
            submitted_state = CampaignState.objects.filter(state_name='SUBMITTED')
            planned_state= CampaignState.objects.filter(state_name='PLANNED')
            incoming_date_list=validated_data['planned_dates'] 
            planned_dates_ist = []
            for dt in incoming_date_list:
                obj = AdvtCampaignDate()
                obj.date = dt
                obj.save()
                planned_dates_ist.append(obj)
            validated_data['planned_dates'] = planned_dates_ist
            if aUsr[0].account.account_type.type_name=='ASSOCIATION':
                validated_data['state'] = planned_state[0]
            else:
                validated_data['state'] = submitted_state[0]
            validated_data['dayPart_selected']=None
            if 'play_list' not in validated_data:
                validated_data['play_list']=None
            logger.info("CAMPAIGN_CREATED NAME : "+str(validated_data['name'])+
                        "Planned Dates : "+str(validated_data['planned_dates']))
            return serializers.ModelSerializer.create(self,validated_data)
            '''
            camp = AdvtCampaign()
            camp.name = validated_data['name']
            planned_date_list = []
            for dt in validated_data['planned_dates']:
                planned_date = AdvtCampaignDateSerializer().create(dt)
                planned_date.save()
                planned_date_list.append(planned_date)
            #camp.planned_dates= planned_date_list
            #camp.save()
            camp.account = aUsr[0].account
            camp.owner = aUsr[0]
            camp.selected_plays_per_day = validated_data['selected_plays_per_day']
            camp.total_screens_selected=validated_data['total_screens_selected']
            if aUsr[0].account.account_type.type_name=='ASSOCIATION':
                camp.state = planned_state[0]
            else:
                camp.state = submitted_state[0]
            if 'play_list' not in validated_data:
                camp.play_list=None
            else:
                camp.play_list = validated_data['play_list']
            if 'dayPart_selected' not in validated_data:
                camp.dayPart_selected=None
            else:
                camp.dayPart_selected  = name=validated_data['dayPart_selected']
            camp.type = validated_data['type']
            bid_type = CampaignType.objects.get(name='BID')
            if camp.type == bid_type:
                camp.state = planned_state[0] # if the type is BID, put to planned state.
            camp.units_per_play = validated_data['units_per_play']
            camp.save()
            if 'screen_selection_tags' not in validated_data:
                camp.screen_selection_tags=[]
            else:
                camp.screen_selection_tags = validated_data['screen_selection_tags']
            if 'ar_content' in validated_data:
                camp.ar_content = validated_data['ar_content'] 
            camp.planned_dates= planned_date_list
            camp.save()
            return camp
        except:
            logger.error ("CAMPAIGN_CREATION_ERROR "+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("CAMPAIGN_CREATION_ERROR "+str(tb))
            return None
    
class AdvtCampaignShortSerializer(serializers.ModelSerializer):
    state = serializers.SlugRelatedField(queryset=CampaignState.objects.all(),slug_field='state_name')
    class Meta:
        model = AdvtCampaign
        fields = ('name','state','key')

