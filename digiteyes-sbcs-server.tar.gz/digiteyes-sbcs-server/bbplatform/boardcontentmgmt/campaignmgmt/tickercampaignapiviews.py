from __future__ import division
from rest_framework import generics
from boardcontentmgmt.models import BookedAdPack,AccountUser,Account,AdvtCampaign,CTAParameters
from boardcontentmgmt.models import ContentQueue,CTA,ContentTarget,Content,ContentType
from boardcontentmgmt.models import Layout,ContentState,BookingState,CampaignState,ContentSchedule
from boardcontentmgmt.models import LayoutMapping,LayoutLabel,ContentLabel,SubordinateContent
from boardcontentmgmt.models import ResidentialComplex,MasterEntitlement,DayPart,\
CTAType,CampaignType,ContentQueueType,AdvtCampaignDate,DeviceController,RequestState
from boardcontentmgmt.models import Board,ShowSpotAsset,DeviceControlCommand
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated, DjangoModelPermissions
from rest_framework import filters
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED,HTTP_400_BAD_REQUEST,HTTP_200_OK
import random,string,sys
from boardcontentmgmt.tasks import calculate_hash
from datetime import datetime,timedelta,date
from boardcontentmgmt.utilities.algo_utilities import GetNumOfUnits_DayPart
from boardcontentmgmt.tasks import Call_AllocationAlgorithm
from dateutil.parser import parse
from boardcontentmgmt.contentmgmt.adcontentserializers import ContentTargetSerializer, ContentShortSerializerForTaPP
import sys, zipfile
import traceback
import logging
import hashlib
from .campaignserializers import AdvtCampaignSerializer,AdvtCampaignShortSerializer
from django.db.models import Max,Min
from _mysql import NULL
from affiliateads.tasks import approve_contents_email_notification
logger = logging.getLogger(__name__)

def get_all_screens(parsed_data):
    print 'In get_all_screens'
    logger.info('In get_all_screens')
    screen_list = []
    screen_list_keys = []
    show_spots = ShowSpotAsset.objects.filter(account__key = parsed_data['account'].key)
    logger.info('showspots length:'+str(len(show_spots)))
    if show_spots is not None and len(show_spots) >0 :
        for spot in show_spots:
            brd = Board.objects.filter(show_spot__key=spot.key)
            if brd is not None and len(brd)>0:
                screen_list.append(brd[0])
                screen_list_keys.append(str(brd[0].key))
            else:
                logger.debug('Screen not found for spot:'+str(spot.name))
    logger.info('get_all_screens length:'+str(len(screen_list)))
    parsed_data['boards'] = screen_list
    parsed_data['board_keys'] = screen_list_keys
    return parsed_data

def get_residential_complex_details(parsed_data):
    res_complex_obj = ResidentialComplex.objects.filter(account__key=parsed_data['account'].key)
    if res_complex_obj is not None and len(res_complex_obj)>0:
        parsed_data['logo_url'] = res_complex_obj[0].logo_url
    else:
        parsed_data['logo_url'] = "https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/Adiot-logo.jpg"
    return get_all_screens(parsed_data)
                           
def create_content_target(parsed_data):
    print 'In create_content_target'
    logger.info('In create_content_target')
    ct = ContentTarget()
    ct.account = parsed_data['account']
    ct.target_title = parsed_data['title']
    ct.target_description = parsed_data['message_content']
    ct.target_image_url = parsed_data['logo_url']
    ct.save()
    if 'cta' in parsed_data:
        ct.target_cta = parsed_data['cta']
    ct.save()
    parsed_data['ct'] = ct
    return parsed_data

def create_cta(parsed_data):
    print 'In create_cta'
    logger.info('In create_cta')
    cta = CTA()
    cta.type = CTAType.objects.get(name='CALL')
    cta.account = parsed_data['account']
    cta.save()
    if not 'mobile_number' in parsed_data:
        return parsed_data
        
    cta_param = CTAParameters()
    cta_param.name = 'call_number'
    cta_param.value = parsed_data['mobile_number']
    cta_param.account = parsed_data['account']
    cta.cta_parameters = []
    cta_param.save()
    cta.cta_parameters.add(cta_param)    
    cta.save()
    parsed_data['cta'] = [cta,]
    return parsed_data

def create_content(parsed_data):
    print 'In create_content'
    logger.info('In create_content')
    cont = Content()
    cont.content_name = parsed_data['title']+''.join(
            random.choice(string.ascii_lowercase + string.ascii_uppercase + 
            string.digits) for i in range(5))
    cont.account = parsed_data['account'] 
    cont.content_type = ContentType.objects.get(type_name='TEXT')
    cont.content_owner = AccountUser.objects.get(account__key=parsed_data['account'].key)
    cont.content_source = parsed_data['message_content']
    cont.content_state = ContentState.objects.get(state_name='APPROVED')
    cont.content_target = parsed_data['ct']
    hasher = hashlib.sha512()
    msg = parsed_data['message_content']
    hasher.update(msg.encode('utf-8').strip())
    cont.hash = hasher.hexdigest()
    cont.save()
    parsed_data['content'] = cont
    return parsed_data

def create_playlist(parsed_data):
    print 'In create_playlist'
    logger.info('In create_playlist')
    try:
        parsed_data = create_cta(parsed_data)
        parsed_data = create_content_target(parsed_data)
        parsed_data = create_content(parsed_data)
        cq = ContentQueue()
        cq.content_queue_name = parsed_data['title']
        cs = ContentSchedule()
        cs.content = parsed_data['content']
        cs.repeat = 1
        cq.account = parsed_data['account']
        cq.content_queue_owner = parsed_data['account_user']
        cq.save()
        cs.save()
        cq.content_list = [cs]
        cq.queue_state = 'SEALED'
        cq.num_units = 1
        cq.unit_size = 30
        cq.type = ContentQueueType.objects.filter(name="TICKER")[0]
        cq.save()
        parsed_data['play_list'] = cq
        return parsed_data
    except:
        logger.error ("Error while creating playlist "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("Stack Trace: "+str(tb))
        parsed_data['play_list']=None
        return parsed_data

def create_campaign(parsed_data):
    parsed_data['campaign'] = None
    if len(parsed_data['boards'])> 0:
        campaign = AdvtCampaign()
        campaign.name = parsed_data['title']
        campaign.owner = AccountUser.objects.get(account__key=parsed_data['account'].key)
        campaign.created_date = datetime.now().date()
        campaign.state = CampaignState.objects.filter(state_name = 'PLANNED')[0]
        campaign.selected_plays_per_day = 0
        campaign.total_screens_selected = len(parsed_data['boards'])
        campaign.account = parsed_data['account']
        campaign.play_list = parsed_data['play_list']
        campaign.units_per_play=1
        campaign.type = CampaignType.objects.filter(name='TICKER')[0]
        campaign.save()
        for dt in parsed_data['planned_dates']: 
            obj = AdvtCampaignDate()
            obj.date = datetime.strptime(dt,"%Y-%m-%d")
            obj.save()
            campaign.planned_dates.add(obj)
        campaign.save()
        campaign.screen_selection_tags = []
        campaign.save()
        parsed_data['campaign'] = campaign
        return parsed_data
    return parsed_data

def get_num_plays(parsed_data):
    print 'In get_num_plays' 
    #existing_ticker_campaigns = AdvtCampaign.objects.filter(account__key=parsed_data['account'].key,
    #                                                        type__name = 'TICKER',
    #                                                        state__state_name__in = ['RUNNING','PLANNED','SUBMITTED'],
    #                                                        planned_dates__date__in = [parsed_data['date']]
    #                                                        )
    existing_ticker_campaigns = []
    existing_bookedad_packs = BookedAdPack.objects.filter(applied_to__type__name = "TICKER",
                                                          day_part_booked_for = parsed_data['day_part'],
                                                          date_booked_for  = parsed_data['date'],
                                                          booking_state__name__in = ["SUCCESS","BLOCKED"],
                                                          booked_screen__key = parsed_data['current_board'].key)
    for bp in existing_bookedad_packs:
        if bp.applied_to not in existing_ticker_campaigns:
            existing_ticker_campaigns.append(bp.applied_to)
    master_entitlement_obj = MasterEntitlement.objects.filter(account__key=parsed_data['account'].key,
                                                              day_part_entitled = parsed_data['day_part'])
    ticker_entitlements_percent = 0
    if master_entitlement_obj is not None and len(master_entitlement_obj)>0:
        ticker_entitlements_percent = master_entitlement_obj[0].ticker_slots_entitled
        if ticker_entitlements_percent == 0:
            parsed_data['num_plays'] = 0
            return parsed_data
        total_units_dp = GetNumOfUnits_DayPart(parsed_data['day_part'])
        entitled_units = total_units_dp*ticker_entitlements_percent/100
        num_plays = entitled_units/(len(existing_ticker_campaigns)+1) # +1 includes current bookedadpack
        parsed_data['num_plays']  = num_plays
        for camp in existing_ticker_campaigns:
            booked_ad_packs = BookedAdPack.objects.filter(applied_to__key = camp.key,
                                                          day_part_booked_for = parsed_data['day_part'],
                                                          date_booked_for  = parsed_data['date'])
            if booked_ad_packs is not None and len(booked_ad_packs)>0:
                for bap in booked_ad_packs:
                    bap.num_plays = num_plays
                    bap.save()
        return parsed_data
    else:
        parsed_data['num_plays'] = 0
        return parsed_data

def create_bookedadpack(parsed_data):
    print 'In create_bookedadpack'
    logger.info('In create_bookedadpack')
    available_day_parts = get_available_day_parts(parsed_data)
    for dp in available_day_parts:
        for brd in parsed_data['boards']:
            parsed_data['day_part'] = dp
            parsed_data['current_board'] = brd
            parsed_data = get_num_plays(parsed_data)
            if parsed_data['num_plays'] >0:
            #for brd in parsed_data['boards']:
                bap = BookedAdPack()
                bap.booked_screen = brd
                bap.date_booked_for = parsed_data['date']
                booking_state = BookingState.objects.filter(name = 'SUCCESS')[0]
                bap.booking_state = booking_state 
                bap.play_list = parsed_data['play_list']
                bap.when_booked = datetime.now().date()
                bap.num_plays = parsed_data['num_plays']
                bap.booking_type = 'association_booking'
                bap.units_per_play = 1
                bap.day_part_booked_for = parsed_data['day_part']
                bap.against_entitlement_association = True
                bap.price = 0
                bap.account = parsed_data['account']
                bap.unit_size = 30
                bap.applied_to = parsed_data['campaign']
                bap.save()
                #logger.info('bookedadpack created with plays: '+str(num_plays)+ 'unit_size :'+str(cntnt.unit_size)+
                            #'day_part:'+str(dp.name)+'brd: '+str(brd.board_name)+'date:'+str(date)+'state: '+bap_state)
        
def get_available_day_parts(parsed_data):
    print 'In get_available_day_parts', parsed_data['date']
    all_dayparts = DayPart.objects.all()
    current_time = datetime.now()
    if parsed_data['date'] > datetime.now().date() or current_time < datetime.now().replace(hour=5):
        return all_dayparts
    available_dayparts = []
    for each_dp in all_dayparts:
        from_time = each_dp.from_time
        to_time = each_dp.to_time
        dp_start_time = datetime.combine(parsed_data['date'],from_time)
        dp_end_time = datetime.combine(parsed_data['date'],to_time)
        if current_time < dp_end_time:
            logger.info(str(each_dp.name))
            available_dayparts.append(each_dp)
            print each_dp.name
    return available_dayparts

def alert_screens_for_ticker_changes(parsed_data):
    for brd in parsed_data['boards']:
        dc = DeviceController()
        dc.board = brd
        dc.command = DeviceControlCommand.objects.filter(name="REFRESH_TICKER")[0]
        dc.request_state = RequestState.objects.filter(name = "SUBMITTED")[0]
        dc.save()
        
class TickerCampaingsListAPIView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)# DjangoModelPermissions,DjangoObjectPermissions)
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    queryset=AdvtCampaign.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return AdvtCampaignSerializer
        return AdvtCampaignSerializer
    def post(self,request):
        username = request.user.username
        account_user = AccountUser.objects.filter(account_user__username=username)
        acct = account_user[0].account
        parsed_data = request.data
        parsed_data['account'] = acct
        parsed_data['account_user'] = account_user[0]
        
        parsed_data = get_residential_complex_details(parsed_data)
        
        parsed_data = create_playlist(parsed_data)
        if parsed_data['play_list'] is None:
            error = {'error':'Title already taken!'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        
        parsed_data = create_campaign(parsed_data)
        if parsed_data['campaign'] is None:
            error = {'error':'Screens are not available!'}
            return Response(error,status=HTTP_400_BAD_REQUEST)

        for dt in parsed_data['planned_dates']:
            parsed_data['date'] = datetime.strptime(dt,"%Y-%m-%d").date()
            create_bookedadpack(parsed_data)
        Call_AllocationAlgorithm.delay(parsed_data['board_keys'],[],['TICKER'])
        alert_screens_for_ticker_changes(parsed_data)
    
        return Response({'status':'Campaign created Successfully!'},status=HTTP_201_CREATED)

class TickerCampignsUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)# DjangoModelPermissions,DjangoObjectPermissions)
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    lookup_field = 'key'
    queryset=AdvtCampaign.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return AdvtCampaignSerializer
        return AdvtCampaignSerializer
    def patch(self, request, *args, **kwargs):
        username = request.user.username
        account_user = AccountUser.objects.filter(account_user__username=username)
        acct = account_user[0].account
        parsed_data = request.data
        parsed_data['account'] = acct
        parsed_data = get_all_screens(parsed_data)
        camp_obj = AdvtCampaign.objects.filter(key=parsed_data['camp_key'])
        if camp_obj is not None and len(camp_obj)>0:
            parsed_data['campaign'] = camp_obj[0]
            parsed_data['play_list'] = camp_obj[0].play_list
            
            if 'message_content' in parsed_data:
                cntnts = camp_obj[0].play_list.content_list.all()
                for cnt in cntnts:
                    cnt.content.content_source = parsed_data['message_content']
                    hasher = hashlib.sha512()
                    msg = parsed_data['message_content']
                    hasher.update(msg.encode('utf-8').strip())
                    cnt.content.hash = hasher.hexdigest()
                    cnt.content.save()
                camp_obj[0].save()
                booked_ad_packs = BookedAdPack.objects.filter(applied_to__key = camp_obj[0].key)
                if booked_ad_packs is not None and len(booked_ad_packs)>0:
                    for bap in booked_ad_packs:
                        bap.play_list = camp_obj[0].play_list
                        bap.save()
            
            if 'planned_dates' in parsed_data:
                campaign_dates = camp_obj[0].planned_dates.all()
                existing_campaign_dates = []
                for camp_dt in campaign_dates:
                     existing_campaign_dates.append(camp_dt.date)
                camp_dates = sorted(existing_campaign_dates)
                changed_dates_list = sorted([datetime.strptime(date, "%Y-%m-%d").date() for date in parsed_data['planned_dates']])
                
                last_camp_date = camp_dates[-1]
                last_change_date = changed_dates_list[-1]
                
                print camp_dates
                print changed_dates_list
                #logic for increased dates
                if last_camp_date < last_change_date:
                    print "Increased"
                    n = changed_dates_list.index(last_camp_date)
                    for i in range(n+1,len(changed_dates_list)):
                        obj = AdvtCampaignDate()
                        obj.date = changed_dates_list[i]
                        obj.save()
                        camp_obj[0].planned_dates.add(obj)
                        parsed_data['date'] = changed_dates_list[i]
                        create_bookedadpack(parsed_data)
                
                #logic for reduced dates
                elif last_camp_date > last_change_date:
                    print "Decreased"
                    n = camp_dates.index(last_change_date)
                    for i in range(n+1,len(camp_dates)):
                        camp_date_obj = AdvtCampaignDate.objects.filter(date = camp_dates[i])
                        for dt_obj in camp_date_obj:
                            if dt_obj in campaign_dates:
                                camp_obj[0].planned_dates.remove(dt_obj)
                                camp_obj[0].save()
                        baps = BookedAdPack.objects.filter(applied_to__key = camp_obj[0].key,
                                                           date_booked_for = camp_dates[i])
                        if baps is not None and len(baps)>0:
                            for bap in baps:
                                bap.delete()
            
            if 'camp_state' in parsed_data:
                camp_obj[0].state = CampaignState.objects.filter(state_name = "PAUSED")[0]
                camp_obj[0].save()
                baps = BookedAdPack.objects.filter(applied_to__key = camp_obj[0].key)
                if baps is not None and len(baps)>0:
                    for bap in baps:
                        bap.booking_state = BookingState.objects.filter(name='CANCELLED')[0]
                        bap.save()
        Call_AllocationAlgorithm(parsed_data['board_keys'],[],['TICKER'])
        alert_screens_for_ticker_changes(parsed_data)
        return Response("updated successfully",status=HTTP_200_OK) 
        