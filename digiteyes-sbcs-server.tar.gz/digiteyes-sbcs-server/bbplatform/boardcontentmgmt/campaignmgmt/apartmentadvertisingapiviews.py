from __future__ import division
from rest_framework import generics
from boardcontentmgmt.models import BookedAdPack,AccountUser,Account,AdvtCampaign,CTAParameters
from boardcontentmgmt.models import ContentQueue,CTA,ContentTarget,Content,ContentType
from boardcontentmgmt.models import Layout,ContentState,BookingState,CampaignState,ContentSchedule
from boardcontentmgmt.models import LayoutMapping,LayoutLabel,ContentLabel,SubordinateContent
from boardcontentmgmt.models import ResidentialComplex,MasterEntitlement,DayPart,\
CTAType,CampaignType,ContentQueueType,AdvtCampaignDate
from boardcontentmgmt.models import Board,ShowSpotAsset
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated, DjangoModelPermissions
from rest_framework import filters
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED,HTTP_400_BAD_REQUEST,HTTP_200_OK
import random,string,sys
from boardcontentmgmt.tasks import calculate_hash
from datetime import datetime,timedelta,date
from boardcontentmgmt.utilities.algo_utilities import GetNumOfUnits_DayPart
from dateutil.parser import parse
from boardcontentmgmt.contentmgmt.adcontentserializers import ContentTargetSerializer, ContentShortSerializerForTaPP
import sys, zipfile
import traceback
import logging
from django.db.models import Max,Min
from _mysql import NULL
from affiliateads.tasks import approve_contents_email_notification
logger = logging.getLogger(__name__)
################################################################################
#ApartmentAdvertising API View 
################################################################################
def get_all_screens(assosc_acct):
    print 'In get_all_screens'
    logger.info('In get_all_screens')
    screen_list = []
    show_spots = ShowSpotAsset.objects.filter(account__key = assosc_acct.key)
    logger.info('showspots length:'+str(len(show_spots)))
    if show_spots is not None and len(show_spots) >0 :
        for spot in show_spots:
            brd = Board.objects.filter(show_spot__key=spot.key)
            if brd is not None and len(brd)>0:
                screen_list.append(brd[0])
            else:
                logger.debug('Screen not found for spot:'+str(spot.name))
    logger.info('get_all_screens length:'+str(len(screen_list)))
    return screen_list
    
def daypart_freeslots(dp,date,assosc_acct,brd):
    print 'In daypart_freeslots'
    logger.info('In daypart_freeslots')
    master_entitlement_obj = MasterEntitlement.objects.filter(account__key=assosc_acct.key,
                                                              day_part_entitled = dp)
    consumer_entitlements_percent = 0
    if master_entitlement_obj is not None and len(master_entitlement_obj)>0:
        consumer_entitlements_percent = master_entitlement_obj[0].percent_slots_entitled_consumer
        logger.debug('consumer_entitlements_percent:'+str(consumer_entitlements_percent))
    else:
        return 0
    total_units_dp = GetNumOfUnits_DayPart(dp)
    entitled_units = total_units_dp*consumer_entitlements_percent/100
    logger.debug('equation used for entitled_units:'+str(total_units_dp)+
                 '*'+str(consumer_entitlements_percent)+'/'+str(100))
    logger.debug('entitled_units : '+str(entitled_units))
    slots_booked = 0
    booking_states = ['BLOCKED','SUCCESS']
    for acct in assosc_acct.consumer_accounts.all():
        booked_adpacks = BookedAdPack.objects.filter(date_booked_for=date,
                                                     account__key = acct.key,
                                                     booking_type='consumer_booking',
                                                     booking_state__name__in= booking_states,
                                                     booked_screen__key=brd.key,
                                                     day_part_booked_for=dp,
                                                     applied_to__type__name='NORMAL')
        if booked_adpacks is not None and len(booked_adpacks)>0:
            for bp in booked_adpacks:
                slots_booked += (bp.num_plays*bp.units_per_play*bp.unit_size/30)
    logger.debug('slots_booked:'+str(slots_booked))
    remaining_slots = float(entitled_units)-float(slots_booked)
    if remaining_slots < 0:
        remaining_slots = 0
    logger.info('daypart_freeslots'+str(remaining_slots))
    return remaining_slots
def get_association_account(acct):
    logger.info('In get_association_account')
    res_complex = ResidentialComplex.objects.all()
    if res_complex is not None and len(res_complex)>0:
        for complex in res_complex:
            consumer_accounts = complex.account.consumer_accounts.all()
            if len(consumer_accounts) > 0 and consumer_accounts is not None:
                if acct in consumer_accounts:
                    return complex.account
        error = {'error':'apartment_complex is not linked for the user'}
        return Response(error,status=HTTP_400_BAD_REQUEST)
def create_cta(parsed_data,acct):
    print 'In create_cta'
    logger.info('In create_cta')
    cta = CTA()
    cta.type = CTAType.objects.get(name='CALL')
    cta.account = acct
    cta.save()
    if 'mobile_num' in parsed_data:
        cta_param = CTAParameters()
        cta_param.name = 'call_number'
        cta_param.value = parsed_data['mobile_num']
        cta_param.account = acct
        cta.cta_parameters = []
        cta_param.save()
        cta.cta_parameters.add(cta_param)    
        cta.save()
    return cta
def create_content_target(cta_list,parsed_data,acct):
    print 'In create_content_target'
    logger.info('In create_content_target')
    ct = ContentTarget()
    ct.account = acct
    ct.target_title = parsed_data['title']
    ct.target_description = parsed_data['subordinate_contents'][1]
    ct.target_image_url = parsed_data['image_url']
    ct.save()
    ct.target_cta = cta_list
    ct.save()
    return ct
def create_subordinate_contents(parsed_data,acct):
    print 'In create_subordinate_contents'
    logger.info('In create_subordinate_contents')
    sub_content_list = []
    try:
        i = 0
        logger.debug('subordinate contents:',str(parsed_data['subordinate_contents']))
        logger.debug('length of subordinate contents:'+str(len(parsed_data['subordinate_contents'])))
        for sub in parsed_data['subordinate_contents']:
            logger.debug('sub:'+str(sub))
        for i in range(len(parsed_data['subordinate_contents'])):
            logger.debug('SubordinateContent:'+str(parsed_data['subordinate_contents'][i]))
            sub_cnt = SubordinateContent()
            sub_cnt.name = 'SubordinateContent'+str(i)
            sub_cnt.type = ContentType.objects.filter(type_name='TEXT')[0]
            sub_cnt.text = parsed_data['subordinate_contents'][i]
            sub_cnt.account = acct
            cntnt_label=ContentLabel.objects.filter(name = "SUB"+str(i+1))
            if cntnt_label is not None and len(cntnt_label)>0:
                sub_cnt.content_label = cntnt_label[0]
                sub_cnt.save()
            else:
                logger.info('ContentLabel SUB'+str(i+1)+"is not found")
            sub_content_list.append(sub_cnt)
        return sub_content_list
    except:
        logger.error('Some thing went wrong while creating subordinate_contents')
        return sub_content_list
        
def create_content(content_target,subordinate_content_list,parsed_data,acct):
    print 'In create_content'
    logger.info('In create_content')
    cont = Content()
    cont.content_name = parsed_data['title']+''.join(
            random.choice(string.ascii_lowercase + string.ascii_uppercase + 
            string.digits) for i in range(5))
    cont.account = acct 
    cont.content_type = ContentType.objects.get(type_name='IMAGE')
    cont.content_owner = AccountUser.objects.get(account=acct)
    cont.content_source = parsed_data['image_url']
    cont.content_state = ContentState.objects.get(state_name='DRAFT')
    cont.content_target = content_target
    cont.save()
    #calculate_hash(cont.key)
    #cont.refresh_from_db()
    #cont.content_state = ContentState.objects.get(state_name='APPROVED')
    #cont.save()
    cont.subordinate_content = subordinate_content_list
    cont.save()
    return cont
def create_playlist(parsed_data,acct):
    print 'In create_playlist'
    logger.info('In create_playlist')
    try:
        cta = create_cta(parsed_data,acct)
        content_target = create_content_target([cta,],parsed_data,acct)
        sub_ordinate_contents = create_subordinate_contents(parsed_data,acct)
        content = create_content(content_target,sub_ordinate_contents,parsed_data,acct)
        layout = Layout.objects.filter(name = "APARTMENT_ADVERTISEMENT")
        cq = ContentQueue()
        cq.content_queue_name = parsed_data['title']
        cs = ContentSchedule()
        content.content_state=ContentState.objects.get(state_name='SUBMITTED')
        content.save()
        cs.content = content
        cs.repeat = 1
        cq.account = acct
        cq.content_queue_owner = AccountUser.objects.get(account=acct)
        cq.save()
        cs.save()
        cq.content_list = [cs]
        #cq.queue_state = 'SEALED'
        cq.num_units = 1
        cq.unit_size = 10
        cq.layout = layout[0]
        cq.type = ContentQueueType.objects.filter(name="NORMAL")[0]
        cq.save()
        return cq
    except:
        logger.error ("Error while creating playlist "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("Stack Trace: "+str(tb))
        return None

def create_campaign(parsed_data,cntnt,acct):
    assosc_acct=get_association_account(acct)
    date = parse(parsed_data['date']).date()
    boards = get_all_screens(assosc_acct)
    if len(boards)> 0:
        campaign = AdvtCampaign()
        campaign.name = parsed_data['title']
        campaign.owner = AccountUser.objects.get(account=acct)
        campaign.created_date = datetime.now().date()
        campaign.state = CampaignState.objects.filter(state_name = 'SUBMITTED')[0]
        campaign.selected_plays_per_day = 0
        campaign.total_screens_selected = len(boards)
        #campaign.dayPart_selected = dp 
        campaign.account = acct
        campaign.play_list = cntnt
        campaign.units_per_play=1
        campaign.type = CampaignType.objects.filter(name='NORMAL')[0]
        campaign.save()
        obj = AdvtCampaignDate()
        obj.date = datetime.now().today().strftime("%Y-%m-%d")
        obj.save()
        campaign.planned_dates = [obj]
        campaign.save()
        campaign.screen_selection_tags = []
        campaign.save()
        return campaign
    return None
    
def create_bookedadpack_campaign(parsed_data,cntnt,acct,dp,permission,campaign):
    print 'In create_bookedadpack_campaign'
    logger.info('In create_bookedadpack_campaign')
    date = parse(parsed_data['date']).date()
    assosc_acct=get_association_account(acct)
    boards = get_all_screens(assosc_acct)
    logger.info('Num of screens:'+str(len(boards)))
    master_entitlement_obj = MasterEntitlement.objects.filter(account__key=assosc_acct.key,
                                                              day_part_entitled = dp)
    consumer_entitlements_percent = 0
    if master_entitlement_obj is not None and len(master_entitlement_obj)>0:
        consumer_entitlements_percent = master_entitlement_obj[0].percent_slots_entitled_consumer
    total_given_units = GetNumOfUnits_DayPart(dp)*consumer_entitlements_percent/100
    total_given_units /= 3 #divide total among 3
    num_plays = total_given_units*30/ cntnt.unit_size
    
    if len(boards)> 0:
        '''
        campaign = AdvtCampaign()
        campaign.name = parsed_data['title']
        campaign.owner = AccountUser.objects.get(account=acct)
        campaign.created_date = datetime.now().date()
        campaign.planned_start_date = date
        campaign.planned_end_date = date
        campaign.state = CampaignState.objects.filter(state_name = 'SUBMITTED')[0]
        campaign.selected_plays_per_day = 0
        campaign.screen_selection_tags = ""
        campaign.total_screens_selected = 1
        campaign.dayPart_selected = dp 
        campaign.account = acct
        campaign.play_list = cntnt
        campaign.save()
        '''
        plays = 0
        for brd in boards:
            bap_state = ''
            free_slots = daypart_freeslots(dp,date,assosc_acct,brd)
            logger.info('free_slots:'+str(free_slots))
            if free_slots <= 0 or permission==False:
                bap_state = 'FAILED'
            else:
                bap_state = 'BLOCKED'
                if free_slots < num_plays*cntnt.num_units*cntnt.unit_size/30:
                    num_plays=free_slots*30/cntnt.num_units*cntnt.unit_size
            bap = BookedAdPack()
            bap.booked_screen = brd
            bap.date_booked_for = date
            booking_state = BookingState.objects.filter(name = bap_state)[0]
            bap.booking_state = booking_state 
            bap.when_booked = datetime.now().date()
            bap.num_plays = num_plays
            bap.booking_type = 'consumer_booking'
            bap.units_per_play = cntnt.num_units
            bap.day_part_booked_for = dp
            bap.against_entitlement_consumer = True
            bap.price = 0
            bap.account = acct
            bap.unit_size = cntnt.unit_size
            bap.applied_to = campaign
            bap.save()
            plays += num_plays
            logger.info('bookedadpack created with plays: '+str(num_plays)+ 'unit_size :'+str(cntnt.unit_size)+
                        'day_part:'+str(dp.name)+'brd: '+str(brd.board_name)+'date:'+str(date)+'state: '+bap_state)
        campaign.selected_plays_per_day = plays
        
        campaign.save()

def get_available_day_parts(date):
    print 'In get_available_day_parts'
    all_dayparts = DayPart.objects.all()
    if date > datetime.now().date():
        return all_dayparts
    available_dayparts = []
    current_time = datetime.now()
    for each_dp in all_dayparts:
        from_time = each_dp.from_time
        dt = datetime.combine(datetime.now().date(),from_time)
        dp_start_time = dt + timedelta(minutes=-40)# advertisement has to place 30 mins before the start of day_part
        if current_time <= dp_start_time:
            logger.info(str(each_dp.name))
            available_dayparts.append(each_dp)
            print each_dp.name
    return available_dayparts

class ApartmentAdvertisingListAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    queryset=AdvtCampaign.objects.all()
    def post(self,request):
        username = request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        parsed_data = request.data
        logger.debug('Incoming data for ApartmentAdvertisingListAPIView:'+str(parsed_data))
        date = parse(request.data['date']).date()
        if 'image_url' not in parsed_data:
            error = {'error':'please mention the image url'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        available_dayparts = []
        if 'day_part' in parsed_data and parsed_data['day_part'] != 'ALL':
            all_available_dayparts = get_available_day_parts(date)
            given_daypart = DayPart.objects.filter(name=parsed_data['day_part'])
            count = 0
            for dp in all_available_dayparts:
                if dp.name==given_daypart[0].name:
                    available_dayparts.append(given_daypart[0])
                else:
                    count = count+1
            if count==len(all_available_dayparts):
                error = {'error':'Can not book for the day part selected'}
                return Response(error,status=HTTP_400_BAD_REQUEST)
        elif 'day_part' not in parsed_data or parsed_data['day_part'] == 'ALL':
            available_dayparts = get_available_day_parts(date)
        play_list = create_playlist(parsed_data,acct)
        if play_list is None:
            error = {'error':'Error while creating play list!'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        campaign = create_campaign(parsed_data,play_list,acct)
        if campaign is not None:
            if len(available_dayparts) > 0:
                for dp in available_dayparts:
                    create_bookedadpack_campaign(parsed_data,play_list,acct,dp,True,campaign)
                approve_contents_email_notification()
                return Response({'status':'Campaign created Successfully!'},status=HTTP_201_CREATED)
            else:
                available_dayparts.append(DayPart.objects.filter(name='Night')[0])
                for dp in available_dayparts:
                    create_bookedadpack_campaign(parsed_data,play_list,acct,dp,False,campaign)
                    approve_contents_email_notification()
                return Response({'status':'Campaign created Successfully!'},status=HTTP_201_CREATED)
        else:
            error = {'error':'Screens are not available!'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
class ApartmentAdvertisingFreeSlotsAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    def get(self,request):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        user_acct = accounts[0].account
        date = parse(request.query_params.get('date', None)).date()
        apartment = request.query_params.get('apartment_complex', None)
        logger.debug('date : '+str(date))
        logger.debug('apartment : '+str(apartment))
        day_part = request.query_params.get('day_part', None)
        available_dayparts = []
        if day_part is not None and day_part != 'ALL':
            all_available_dayparts = get_available_day_parts(date)
            given_daypart = DayPart.objects.filter(name=day_part)
            count = 0
            for dp in all_available_dayparts:
                if dp.name==given_daypart[0].name:
                    available_dayparts.append(given_daypart[0])
                else:
                    count = count+1
            if count==len(all_available_dayparts):
                error = {'error':'Can not book for the day part selected'}
                return Response(error,status=HTTP_400_BAD_REQUEST)
        elif day_part is None or day_part == 'ALL':
            available_dayparts = get_available_day_parts(date)
        if len(available_dayparts) <= 0:
            available_dayparts.append(DayPart.objects.filter(name='Night')[0])
        complex = ResidentialComplex.objects.filter(name = apartment)
        if len(complex)==0:
            error = {'error':'apartment_complex is not found'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        assosc_acct= complex[0].account
        masterentitlement_obj = MasterEntitlement.objects.filter(account__key=assosc_acct.key)
        if masterentitlement_obj is None and len(masterentitlement_obj) == 0:
            error = {'error':'Given apartment is not having any entitlements'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        if user_acct not in assosc_acct.consumer_accounts.all():
            error = {'error':'user is not registered with the given apartment'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        all_scrns = get_all_screens(assosc_acct)
        logger.debug('all_scrns: '+str(len(all_scrns)))
        print len(all_scrns)
        if len(all_scrns) <= 0:
            error = {'error':'screens not found for the apartment!'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        res_freeslots_obj = sys.maxint
        logger.debug('length of available dayparts : '+str(len(available_dayparts)))
        for dp in available_dayparts:
            for brd in all_scrns:
                free_slots = daypart_freeslots(dp,date,assosc_acct,brd)
                logger.debug('free_slots for daypart: '+str(dp.name)+' screen: '+str(brd.board_name)+' is:'+str(free_slots))
                if free_slots < res_freeslots_obj:
                    res_freeslots_obj = free_slots
        logger.debug('resulting free slots : '+str(res_freeslots_obj))
        return Response({'free_slots':res_freeslots_obj},status=HTTP_201_CREATED)

def check_consumer_inall_apartments(acct):
    obj={'check':False,
         'complex':''}
    all_rescomplex=ResidentialComplex.objects.all()
    if all_rescomplex is not None and len(all_rescomplex)>0:
            for complex in all_rescomplex:
                consumer_accounts = complex.account.consumer_accounts.all()
                if len(consumer_accounts) > 0 and consumer_accounts is not None:
                    if acct in consumer_accounts:
                        obj={'check':True,
                             'complex':complex.name}
                        return obj
    return obj

class LinkConsumerAccountAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    def get(self,request):
        username = request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        res=check_consumer_inall_apartments(acct)
        if res['check']:
            return Response({'apartment':res['complex']},status=HTTP_200_OK)
        else:
            error = {'error':'apartment_complex is not linked for the user'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
    def post(self,request):
        username = request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        user_acct = accounts[0].account
        parsed_data = request.data
        
        complex = ResidentialComplex.objects.filter(name = parsed_data['apartment'])
        if len(complex)==0:
            error = {'error':'apartment_complex is not found'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        res=check_consumer_inall_apartments(user_acct)
        if res['check']:
            error = {'error':'You are already part of: '+res['complex']}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        else:
            ph = accounts[0].account_user_phone_no
            if ph is None:
                error = {'error':'Please update your profile with a valid phone number'}
                return Response(error,status=HTTP_400_BAD_REQUEST)
            all_complex_contacts = []
            for i in complex[0].residents.all():
                all_complex_contacts.append(i.phone_number)
            if ph in all_complex_contacts:
                assosc_acct= complex[0].account
                assosc_acct.consumer_accounts.add(user_acct)
                assosc_acct.save()
                return Response({'status':'Updated successfully!'},status=HTTP_201_CREATED)
            else:
                error = {'error':'please contact the admin of: '+res['complex']+' to add your contact number in list'}
                return Response(error,status=HTTP_400_BAD_REQUEST)

class DelinkConsumerAccountAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    def get(self,request):
        return Response("Nothing to do with get call on this Api",status=HTTP_400_BAD_REQUEST)
    def post(self,request):
        username = request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        user_acct = accounts[0].account
        res=check_consumer_inall_apartments(user_acct)
        if res['check']:
            logger.info('User found in:'+str(res['complex']))
            complex = ResidentialComplex.objects.filter(name = res['complex'])
            assosc_acct= complex[0].account
            assosc_acct.consumer_accounts.remove(user_acct)
            assosc_acct.save()
            return Response({'status':'Deleted user successfully from: '+res['complex']},status=HTTP_201_CREATED)
        else:
            error = {'error':'user is not found in any complex'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        
class LocalClassifiedsListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    lookup_field = 'key'
    def get(self,request):
        res_complex = self.request.query_params.get('res_complex', None)
        start_date = parse(self.request.query_params.get('start_date', None)).date()
        end_date = parse(self.request.query_params.get('end_date', None)).date()
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        assoc_acct = get_association_account(acct)
        if assoc_acct is None:
            error = {'error':'apartment_complex is not linked for the user'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        all_complex_accounts = []
        logger.debug("association account:"+str(assoc_acct))
        complex_accounts = assoc_acct.consumer_accounts.all()
        for act in complex_accounts:
            all_complex_accounts.append(act)   
        all_complex_accounts.append(assoc_acct)   
        logger.debug("length of all_complex_accounts :"+str(len(all_complex_accounts)))
        content_target_list = []
        res = []
        '''
        campaigns = AdvtCampaign.objects.filter(planned_start_date__gte=start_date,
                                                planned_start_date__lte=end_date,
                                                account__in = all_complex_accounts).exclude(state__state_name ='REJECTED')
        '''
        campaigns = AdvtCampaign.objects.annotate(planned_start_date = Min('planned_dates__date')).filter(
                                                  planned_start_date__gte = start_date,
                                                  planned_start_date__lte=end_date,
                                                  account__in = all_complex_accounts).exclude(state__state_name ='REJECTED')
        logger.debug('length of localclassifieds : '+str(len(campaigns)))
        if campaigns is not None and len(campaigns)>0:
            for camp in campaigns:
                logger.debug("campaign name:"+str(camp.name))
                play_list = ContentQueue.objects.filter(key = camp.play_list.key)
                if play_list is not None and len(play_list)>0:
                    content_schedules = play_list[0].content_list.all()
                    if content_schedules is not None and len(content_schedules)>0:
                        for cs in content_schedules:
                            if cs.content.content_target is not None:
                                if cs.content.content_target.key not in content_target_list:
                                    cntnt = Content.objects.filter(key=cs.content.key)
                                    cntnt_serializer = ContentShortSerializerForTaPP(cntnt[0])
                                    cntnt_target = ContentTarget.objects.filter(key=cs.content.content_target.key)
                                    cntnt_target_serializer = ContentTargetSerializer(cntnt_target[0])
                                    obj = {'content':cntnt_serializer.data,
                                            'campaign':camp.key,
                                            'publisher':camp.owner.account_user.first_name+
                                                        ' '+camp.owner.account_user.last_name,
                                            'content_target':cntnt_target_serializer.data}
                                    res.append(obj)
                                    content_target_list.append(cs.content.content_target.key)
        return Response(res,status=HTTP_201_CREATED)  

class LocalDealsListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    lookup_field = 'key'
    def get(self,request):
        res = []
        content_target_list = []
        start_date = parse(self.request.query_params.get('start_date', None)).date()
        end_date = parse(self.request.query_params.get('end_date', None)).date()
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        assoc_acct = get_association_account(acct)
        if assoc_acct is None:
            error = {'error':'apartment_complex is not linked for the user'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        
        screen_list = Board.objects.filter(show_spot__account__key = assoc_acct.key)
        if screen_list is not None and len(screen_list)>0:
            for brd in screen_list:
                baps = BookedAdPack.objects.filter(booked_screen__key=brd.key,
                                                   date_booked_for__range=(start_date,end_date),
                                                   booking_state__name = 'SUCCESS').exclude(play_list__isnull=True)
                if baps is not None and len(baps)>0:
                     for bap in baps:
                        camp = bap.applied_to
                        content_schedules = bap.play_list.content_list.all()
                        if content_schedules is not None and len(content_schedules)>0:
                            for cs in content_schedules:
                                if cs.content.content_target is not None:
                                    if cs.content.content_target.key not in content_target_list:
                                        cntnt = Content.objects.filter(key=cs.content.key)
                                        cntnt_serializer = ContentShortSerializerForTaPP(cntnt[0])
                                        cntnt_target = ContentTarget.objects.filter(key=cs.content.content_target.key)
                                        cntnt_target_serializer = ContentTargetSerializer(cntnt_target[0])
                                        obj = {'content':cntnt_serializer.data,
                                                'campaign':camp.key,
                                                'publisher':camp.owner.account_user.first_name+
                                                            ' '+camp.owner.account_user.last_name,
                                                'content_target':cntnt_target_serializer.data}
                                        res.append(obj)
                                        content_target_list.append(cs.content.content_target.key)
        return Response(res,status=HTTP_201_CREATED)  