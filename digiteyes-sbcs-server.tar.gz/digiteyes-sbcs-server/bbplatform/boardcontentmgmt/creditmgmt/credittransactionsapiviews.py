'''
Created on 11-Feb-2017

@author: saba
'''
from rest_framework import serializers
from boardcontentmgmt.accountmgmt.accountserializers import AccountShortSerializer
from boardcontentmgmt.accountmgmt.accountuserserializers import AccountUserShortSerializer, AccountUserSerializer
from boardcontentmgmt.models import AccountCreditTransactions,TransactionReason, BookingState,MyOrder
from boardcontentmgmt.models import Account, AccountUser
from rest_framework.response import Response
from rest_framework import generics
from rest_framework import filters
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework.permissions import DjangoModelPermissions
from rest_framework.permissions import IsAuthenticated
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from django.db.models import Sum
from rest_framework.views import APIView
from rest_framework import filters
from boardcontentmgmt.utilities.credittransactionutilities import find_account_balance,create_debit_transaction_from_system
from boardcontentmgmt.tasks import send_sms_plivo
import logging
import sys,traceback
logger = logging.getLogger(__name__)

class AccountCreditTransactionsSerializer(serializers.ModelSerializer):
    account = AccountShortSerializer()
    transaction_reason = serializers.SlugRelatedField(
        queryset=TransactionReason.objects.all(),
        slug_field='reason_text')
    performing_user = AccountUserShortSerializer()
    transaction_status = serializers.SlugRelatedField(
        queryset=BookingState.objects.all(),
        slug_field='name')
    class Meta:
        model = AccountCreditTransactions
        fields = ('key','transaction_date','account','is_credit','amount',
            'transaction_reason','transaction_description','performing_user',
            'transaction_status')
class AccountCreditTransactionsShortSerializer(serializers.ModelSerializer):
    transaction_reason = serializers.SlugRelatedField(
        queryset=TransactionReason.objects.all(),
        slug_field='reason_text')
    transaction_status = serializers.SlugRelatedField(
        queryset=BookingState.objects.all(),
        slug_field='name')
    class Meta:
        model = AccountCreditTransactions
        fields = ('key','transaction_date','is_credit','amount',
            'transaction_reason','transaction_description','transaction_status')

###################################################################################
# Serializer for Account Credit Transactions.
###################################################################################
class AccountCreditTransactionsWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key', required=False)
    transaction_reason = serializers.SlugRelatedField(
        queryset=TransactionReason.objects.all(),
        slug_field='key')
    performing_user = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key', required=False)
    transaction_status = serializers.SlugRelatedField(
        queryset=BookingState.objects.all(),
        slug_field='name')
    class Meta:
        model = AccountCreditTransactions
        fields = ('key','transaction_date','account','is_credit','amount',
            'transaction_reason','transaction_description','performing_user',
            'transaction_status')
    def create(self,validated_data):
        if 'account' not in validated_data:
            usr = self.context['request'].user
            aUsr = AccountUser.objects.filter(account_user__username = usr.username)
            validated_data['account'] = aUsr[0].account
            user_name = aUsr[0].account_user.first_name+' '+aUsr[0].account_user.last_name
        if 'performing_user' not in validated_data:
            usr = self.context['request'].user
            aUsr = AccountUser.objects.filter(account_user__username = usr.username)
            validated_data['performing_user'] = aUsr[0]
        if not validated_data['is_credit']:
            balance = find_account_balance(validated_data['account'])
            if float(validated_data['amount']) > balance:
                raise serializers.ValidationError("Not enough balance to perform this operation" + "Requested Debit :"+ unicode(validated_data['amount'])+ " Available Balance :"+ unicode(balance))
        '''    
            if aUsr[0].verified_mobile:
                txt_msg  = ' Rs.'+str(validated_data['amount']) +'/- has been from your credit balance'
                phone_numbers = [aUsr[0].account_user_phone_no] 
                send_sms_plivo(user_name, txt_msg, phone_numbers)
        else:
            if aUsr[0].verified_mobile:
                txt_msg  = ' Rs.'+str(validated_data['amount']) +'/- has been credited to your credit balance'
                phone_numbers = [aUsr[0].account_user_phone_no] 
                send_sms_plivo(user_name, txt_msg, phone_numbers)
                '''
        return serializers.ModelSerializer.create(self, validated_data)
####################################################################################
# API View to get all the transactions in an account. Ordered by date.
#####################################################################################
class AccountCreditTransactionsAPIView(generics.ListCreateAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions)
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    serializer_class = AccountCreditTransactionsSerializer
    search_fields = ('account__account_name','transaction_reason__reason_text','transaction_description')
    filter_fields = ('performing_user','performing_user__key','is_credit','account__key',)
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        if(ProfileCheck().get_filter(usr,'accountcredittransactions') == True):
            return AccountCreditTransactions.objects.all().order_by('-transaction_date')
        else:
            accounts = AccountUser.objects.filter(account_user__username=username)
            acct = accounts[0].account
            return AccountCreditTransactions.objects.filter(account__key = acct.key).order_by('-transaction_date')
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return AccountCreditTransactionsWriteSerializer
        return AccountCreditTransactionsSerializer
###################################################################################
# API View to get only the balance
###################################################################################
class AccountCreditBalanceView(APIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    def get(self,request):
        username = request.user.username
	usr = self.request.user
	if(ProfileCheck().get_filter(usr,'accountcredittransactions') == True):
		account_key = request.query_params.get('account',None)
		if account_key is not None:
			accounts = Account.objects.filter(key=account_key)
			if len(accounts) > 0:
				balance= find_account_balance(accounts[0])
				return Response({'account_balance':unicode(balance)},status=HTTP_201_CREATED)	
			else :
				return Response({'error':'Given account does not exist'},status=HTTP_400_BAD_REQUEST)
        accounts = AccountUser.objects.filter(account_user__username=username)
        account = accounts[0].account
        balance=find_account_balance(account)
        bal = {'account_balance':unicode(balance)}
        return Response(bal,status=HTTP_201_CREATED)
###################################################################################
# API View to apply the balance
###################################################################################
class ApplyCreditBalanceView(generics.ListCreateAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name')
    lookup_field = 'txnid'
    def get_queryset(self):
        return Response('Get method is not implemented')
        
    def post(self,request, format=None):
        try:
            logger.info ("ApplyCreditBalance_START")
            username = request.user.username
            user_name = str(username)
            act_user = AccountUser.objects.filter(account_user__username=username)
            acct = act_user[0].account
            parsed_data = request.data
            if 'txnid' not in parsed_data:
                error = {'error':'txnid is mandatory!'}
                logger.info ("ApplyCreditBalance_END")
                return Response(error,status = HTTP_400_BAD_REQUEST)
            txnid = parsed_data['txnid']
            order_obj = MyOrder.objects.filter(txnid = parsed_data['txnid'],
                                                   account__key = acct.key)
            if order_obj is None or len(order_obj) ==0:
                error = {'error':'No order found with given txnid in your account!'}
                logger.info ("ApplyCreditBalance_END")
                return Response(error,status = HTTP_400_BAD_REQUEST)
            odr = order_obj[0]
            pay_amount = odr.paid_amount
            credit_amount = 0.0
            balance =  find_account_balance(acct)
            initiated_state = BookingState.objects.filter(name='INITIATED')[0]
            if balance > 0:
                if balance >= pay_amount:
                    desc = str(balance)+" - "+str(pay_amount)+" = "+str(float(balance - pay_amount)) + ' for the campaign : '+str(odr.campaign.name)
                    balance = balance - pay_amount
                    #transaction_reason = "Applied for campaign : "+str(odr.campaign.name)
                    transaction_reason = TransactionReason.objects.filter(reason_text='Debit for Campaign')[0]
                    transaction = create_debit_transaction_from_system(acct,pay_amount,
                                                        transaction_reason,desc,initiated_state)
                    txt_msg  = ' Rs.'+str(pay_amount) +'/- has been debited from your credit balance for the order no: '+str(odr.txnid)
                    phone_numbers = [act_user[0].account_user_phone_no] 
                    send_sms_plivo(user_name, txt_msg, phone_numbers)
                    if transaction is not None:
                        if odr.applied_credit_trasaction is None or len(odr.applied_credit_trasaction.all())== 0:
                            odr.applied_credit_trasaction = [transaction]
                        else:
                            odr.applied_credit_trasaction.append(transaction)
                        odr.credit_amount = pay_amount
                        odr.paid_amount = 0.0
                        odr.save()
                        res_obj = {'amount_to_pay':0.0,
                                   'applied_credit_amount':pay_amount}
                        return Response(res_obj,status=HTTP_201_CREATED)
                    else:
                        error = {'error':'You do not have enough credits in your account!'}
                        logger.info ("ApplyCreditBalance_END")
                        return Response(error,status = HTTP_400_BAD_REQUEST)
                else:
                    desc = str(pay_amount)+" - "+str(balance)+" = "+str(float(pay_amount - balance))
                    pay_amount = pay_amount - balance
                    odr.credit_amount = balance
                    #transaction_reason = "Applied for campaign : "+str(odr.campaign.name)
                    transaction_reason = TransactionReason.objects.filter(reason_text='Debit for Campaign')[0]
                    transaction = create_debit_transaction_from_system(acct,balance,
                                                        transaction_reason,desc,initiated_state)
                    txt_msg  = ' Rs.'+str(balance) +'/- has been debited from your credit balance for the order no: '+str(odr.txnid)
                    phone_numbers = [act_user[0].account_user_phone_no] 
                    send_sms_plivo(user_name, txt_msg, phone_numbers)
                    if transaction is not None:
                        if odr.applied_credit_trasaction is None or len(odr.applied_credit_trasaction.all())== 0:
                            odr.applied_credit_trasaction = [transaction]
                        else:
                            odr.applied_credit_trasaction.append(transaction)
                        odr.credit_amount = balance
                        odr.paid_amount = pay_amount
                        odr.save()
                        res_obj = {'amount_to_pay':pay_amount,
                                   'applied_credit_amount':balance}
                        return Response(res_obj,status=HTTP_201_CREATED)
                    else:
                        error = {'error':'You do not have enough credits in your account!'}
                        logger.info ("ApplyCreditBalance_END")
                        return Response(error,status = HTTP_400_BAD_REQUEST)
            else:
                error = {'error':'You do not have enough credits in your account!'}
                logger.info ("ApplyCreditBalance_END")
                return Response(error,status = HTTP_400_BAD_REQUEST)
                logger.info ("ApplyCreditBalance_END")
        except:
            logger.error ("ApplyCreditBalance_ERROR "+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("ApplyCreditBalance_ERROR "+str(tb))
            logger.info ("ApplyCreditBalance_END")
            error = {'error':'Error while applying credit balance!'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
