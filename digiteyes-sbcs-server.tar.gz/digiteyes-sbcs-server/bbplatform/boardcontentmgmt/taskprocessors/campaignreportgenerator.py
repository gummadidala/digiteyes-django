'''
Created on 16-Feb-2017

@author: saba
'''
from reportlab.lib.pagesizes import letter
#from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.colors import pink, black, red, blue, green
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Image 
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (Flowable, Paragraph, SimpleDocTemplate, Spacer)

from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.rl_config import defaultPageSize
from reportlab.lib.units import inch
from reportlab.lib.utils import ImageReader
from datetime import datetime
#from bbplatform.settings import Adiot_logo_url, DE_logo_white

Adiot_logo_url = "https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/Adiot-logo.jpg"
DE_logo_white="https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/DE91_full_white.jpg"

import copy
PAGE_HEIGHT=defaultPageSize[1]; PAGE_WIDTH=defaultPageSize[0]
styles = getSampleStyleSheet()

product_title = "ADiOT LIVESPACES"
report_title = "Advertiser Campaign Play Report"
preplay_report_title = "Advertiser Campaign Pre-Play Schedule Report"
pageinfo = "ADiOT LiveSpaces - Campaign Play Report"
preplay_pageinfo = "ADiOT LiveSpaces - Campaign Pre-Play Schedule Report"
company_name = "DIGITEYES 91 ADVENTURES PRIVATE LIMITED"
address="1154, 6th Main, 19th Cross, Sector 7, HSR Layout, Bengaluru - 560102"
email_info="Email:info@digiteyes91.com"
web_info="www.digiteyes91.com" 
invoice_title = "CAMPAIGN INVOICE"
invoice_pageinfo = "ADiOT LiveSpaces - Invoice"
def myFirstPage(canvas, doc):
    canvas.saveState()
    canvas.setFont('Times-Bold',18)
    image = ImageReader(Adiot_logo_url)
    image2 = ImageReader(DE_logo_white)
    canvas.drawImage(image,PAGE_WIDTH/2.0-270, PAGE_HEIGHT-98,100,40)
    canvas.drawImage(image2,PAGE_WIDTH/2.0+150, PAGE_HEIGHT-118,150,80)
    canvas.drawCentredString(PAGE_WIDTH/2.0, PAGE_HEIGHT-78, product_title)
    canvas.setFont('Times-Bold',16)
    canvas.drawCentredString(PAGE_WIDTH/2.0, PAGE_HEIGHT-100, report_title)
    canvas.setFont('Times-Roman',9)
    canvas.line(0,PAGE_HEIGHT-115,PAGE_WIDTH,PAGE_HEIGHT-115)
    canvas.drawString(inch, 0.75 * inch, "First Page / %s" % pageinfo)
    canvas.restoreState()

def preplay_first_Page(canvas, doc):
    canvas.saveState()
    canvas.setFont('Times-Bold',18)
    image = ImageReader(Adiot_logo_url)
    image2 = ImageReader(DE_logo_white)
    canvas.drawImage(image,PAGE_WIDTH/2.0-270, PAGE_HEIGHT-98,100,40)
    canvas.drawImage(image2,PAGE_WIDTH/2.0+150, PAGE_HEIGHT-118,150,80)
    canvas.drawCentredString(PAGE_WIDTH/2.0, PAGE_HEIGHT-78, product_title)
    canvas.setFont('Times-Bold',16)
    canvas.drawCentredString(PAGE_WIDTH/2.0, PAGE_HEIGHT-100, preplay_report_title)
    canvas.setFont('Times-Roman',9)
    canvas.line(0,PAGE_HEIGHT-115,PAGE_WIDTH,PAGE_HEIGHT-115)
    canvas.drawString(inch, 0.75 * inch, "First Page / %s" % preplay_pageinfo)
    canvas.restoreState()

def invoice_first_page(canvas,doc):
    canvas.saveState()
    canvas.setFont('Times-Bold',18)
    image = ImageReader(Adiot_logo_url)
    image2 = ImageReader(DE_logo_white)
    canvas.drawImage(image,PAGE_WIDTH/2.0-270, PAGE_HEIGHT-43,100,40)
    canvas.drawImage(image2,PAGE_WIDTH/2.0+150, PAGE_HEIGHT-68,150,80)
    canvas.drawCentredString(PAGE_WIDTH/2.0, PAGE_HEIGHT-58, company_name)
    canvas.setFont('Times-Bold',12)
    canvas.drawCentredString(PAGE_WIDTH/2.0, PAGE_HEIGHT-80, address)
    canvas.setFont('Times-Roman',9)
    canvas.drawString(PAGE_WIDTH/2.0+100, PAGE_HEIGHT-100, email_info)
    canvas.drawString(PAGE_WIDTH/2.0-200, PAGE_HEIGHT-100, web_info)
    canvas.setFont('Times-Bold',12)
    canvas.drawCentredString(PAGE_WIDTH/2.0, PAGE_HEIGHT-110, invoice_title)
    canvas.line(0,PAGE_HEIGHT-120,PAGE_WIDTH,PAGE_HEIGHT-120)
    canvas.drawString(inch, 0.75 * inch, "First Page / %s" % invoice_pageinfo)
    canvas.restoreState()
    
class MCLine(Flowable):
    #----------------------------------------------------------------------
    def __init__(self, width, height=0):
        Flowable.__init__(self)
        self.width = width
        self.height = height
 
    #----------------------------------------------------------------------
    def __repr__(self):
        return "Line(w=%s)" % self.width
 
    #----------------------------------------------------------------------
    def draw(self):
        """
        draw the line
        """
        self.canv.line(0, self.height, self.width, self.height)
 

def myLaterPages(canvas, doc):
    canvas.saveState()
    canvas.setFont('Times-Roman',9)
    canvas.drawString(inch, 0.75 * inch, "Page %d %s" % (doc.page, pageinfo))
    canvas.restoreState()

def preplay_footer(canvas, doc):
    canvas.saveState()
    canvas.setFont('Times-Roman',9)
    canvas.drawString(inch, 0.75 * inch, "Page %d %s" % (doc.page, preplay_pageinfo))
    canvas.restoreState()

def invoice_footer(canvas, doc):
    canvas.saveState()
    canvas.setFont('Times-Roman',9)
    canvas.drawString(inch, 0.75 * inch, "Page %d %s" % (doc.page, invoice_pageinfo))
    canvas.restoreState()

def add_preplay_header(preplay_data):
    para_list=[]
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    style=copy.deepcopy(normalStyle)
    style.alignment=1
    style.fontSize=12
    style.spaceBefore=10
    style.spaceAfter=10
    play_date=preplay_data['date']
    day_part=preplay_data['daypart_name']
    day_part_start_time=preplay_data['daypart_from_time']
    day_part_end_time=preplay_data['daypart_to_time']
    para_list.append(Paragraph("<b>SCHEDULE REPORTS </b>",style))
    para_list.append(Paragraph("<b> Date:"+preplay_data['date']+"  Day part: "+day_part+
        " "+day_part_start_time+" to "+day_part_end_time+" </b>",style))
    return para_list    
def add_wifi_reach_report(reach_data):
    para_list=[]
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    title_2_style=copy.deepcopy(normalStyle)
    title_2_style.fontSize=12
    title_2_style.spaceBefore=10
    title_2_style.spaceAfter=10
    para_list.append(Paragraph("<b>3. REACH REPORT:</b>",title_2_style))
    desc = "The reach report is based on the number of mobile phones passed by the screens when the campaign contents were playing.Counting of mobile phones depends on Wifi to be turned ON and certain approximations."
    normalStyle.spaceAfter=5
    para_list.append(Paragraph(desc,normalStyle))
    header = ['No.','Date','Projected Reach']
    data = []
    data.append(header)
    i=1
    for day in reach_data['days']:
        data.append([str(i),day['date'],day['count']])
        i=i+1
    data.append(['','Total',reach_data['total']])
    playTable = Table(data)
    playTable.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
        ('BOX', (0,0), (-1,-1), 0.25, colors.black),('BACKGROUND',(0,0),(3,0),colors.cyan),
        ('ALIGN',(0,1),(-2,-2),'CENTER')]))
    playTable.spaceAfter = 10
    para_list.append(playTable)
    return para_list
def add_one_screen_report(screen_data,date_index,screen_index,para_list,pre_play=False):
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    title_2_style=copy.deepcopy(normalStyle)
    title_2_style.fontSize=11
    title_2_style.spaceBefore=10
    title_2_style.spaceAfter=10
    para_prefix="4."
    if pre_play:
        para_prefix=""
    para_list.append(Paragraph("<b>"+para_prefix+str(date_index)+"."+str(screen_index)+" Screen :</b>"+screen_data['name'],title_2_style))
    header = ['Planned Plays', 'Completed Plays', 'Missed Plays*','Partial Plays*']
    data = [str(screen_data['total_planned_plays']),
        str(screen_data['completed_plays']),
        str(screen_data['missed_plays']),
        str(screen_data['partial_plays'])]
    table_data = [header,data]
    summaryTable = Table(table_data)
    summaryTable.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
        ('BOX', (0,0), (-1,-1), 0.25, colors.black),('BACKGROUND',(0,0),(-1,-2),colors.cyan),
        ('ALIGN',(0,1),(-2,-2),'CENTER')]))
    summaryTable.spaceAfter = 10
    para_list.append(summaryTable)
    para_list.append(Paragraph("<b>Schedule and Play Reports:</b>",normalStyle))
    play_header =['Schedule No.','Content','Type','Planned','Time(sec)','Played']
    play_tbl_data=[]
    play_tbl_data.append(play_header)
    i=0
    for play_data in screen_data['play_data']:
        if play_data['planned'] != ' ':
            i=i+1
            scheduleNo=str(i)
        else:
            scheduleNo=" "
        play_tbl_data.append([scheduleNo,Paragraph(play_data['content'],normalStyle),play_data['type'],
            play_data['planned'],play_data['play_time'],play_data['played']])
        
    playTable = Table(play_tbl_data)
    playTable.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
        ('BOX', (0,0), (-1,-1), 0.25, colors.black),('BACKGROUND',(0,0),(5,0),colors.cyan),
        ('ALIGN',(0,1),(-1,-1),'CENTER')]))
    playTable.spaceAfter = 10
    para_list.append(playTable)
    
                                                                                            
def add_one_day_report(day_data,index,para_list,pre_play=False):
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    title_2_style=copy.deepcopy(normalStyle)
    title_2_style.fontSize=11
    title_2_style.spaceBefore=10
    title_2_style.spaceAfter=10
    if not pre_play:
        para_list.append(Paragraph("<b>4."+str(index)+" Date :</b>"+day_data['date'],title_2_style))
    header=['Planned \n Plays','Number of \n Screens','Total Planned \n Plays','Completed \n plays',
        'Missed \n plays*','Partial \n plays*']
    data = [str(day_data['planned_plays']),str(day_data['screens']),
        str(day_data['total_planned_plays']),str(day_data['completed_plays']),
        str(day_data['missed_plays']),str(day_data['partial_plays'])]
    table_data = [header,data]
    summaryTable = Table(table_data)
    summaryTable.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
        ('BOX', (0,0), (-1,-1), 0.25, colors.black),('BACKGROUND',(0,0),(-1,-2),colors.cyan),
        ('ALIGN',(0,1),(-2,-2),'CENTER')]))
    summaryTable.spaceAfter = 10
    para_list.append(summaryTable)
    i=1
    for screen_data in day_data['screen_data']:
       add_one_screen_report(screen_data, index, i, para_list,pre_play)
       i=i+1     
    return para_list
    
def add_preplay_days_report(days_data):
    para_list=[]
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    title_2_style=copy.deepcopy(normalStyle)
    title_2_style.fontSize=12
    title_2_style.spaceBefore=10
    title_2_style.spaceAfter=10
    #para_list.append(Paragraph("<b>4. INDIVIDUAL DAY(S) REPORT:</b>",title_2_style))
    i=1
    for day_data in days_data:
        add_one_day_report(day_data,i,para_list,pre_play=True)
        i=i+1
    return para_list
    

def add_days_report(days_data):
    para_list=[]
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    title_2_style=copy.deepcopy(normalStyle)
    title_2_style.fontSize=12
    title_2_style.spaceBefore=10
    title_2_style.spaceAfter=10
    para_list.append(Paragraph("<b>4. INDIVIDUAL DAY(S) REPORT:</b>",title_2_style))
    i=1
    for day_data in days_data:
        add_one_day_report(day_data,i,para_list)
        i=i+1
    return para_list

def add_credit_report(credit_data):
    para_list=[]
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    missed_time = "<b>Total Missed Playtime : </b>" + credit_data['missed_time']
    missed_units = "<b>Equivalent slots(30 seconds) : </b>" + str(credit_data['slots'])
    effective_price = "<b> Effective price / slot :</b> Rs."+ str(credit_data['effective_price'])
    credited_amount = "<b> Amount credited so far:</b> Rs."+ str(credit_data['credited_amount'])
    title_2_style=copy.deepcopy(normalStyle)
    title_2_style.fontSize=12
    title_2_style.spaceBefore=10
    title_2_style.spaceAfter=10
    para_list.append(Paragraph("<b>2. CREDIT REPORT:</b>",title_2_style))
    desc = "The credit report captures the amount, if any, credited back to your account, for any missed plays. If the campaign is still running, this section captures the no play credit for the completed days so far."
    normalStyle.spaceAfter=5
    para_list.append(Paragraph(desc,normalStyle))
    para_list.append(Paragraph(missed_time,normalStyle))
    para_list.append(Paragraph(missed_units,normalStyle))
    para_list.append(Paragraph(effective_price,normalStyle))
    para_list.append(Paragraph(credited_amount,normalStyle))
    para_list.append(PageBreak())
    if len(credit_data['transactions']) > 0:
        para_list.append(Paragraph("<b> Credit transaction details:</b>",normalStyle))
        normalStyle.spaceAfter=5
        header=['No.','Transaction Number','Date','Description','Amount']
        data=[]
        data.append(header)
        i=1
        for transaction in credit_data['transactions']:
            row = [i,transaction['number'],transaction['transaction_date'],transaction['transaction_description'],
                str(transaction['amount'])]
            data.append(row)
            i=i+1
        data.append(['','','','TOTAL',credit_data['credited_amount']])
        summaryTable = Table(data)
        summaryTable.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
            ('BOX', (0,0), (-1,-1), 0.25, colors.black),('BACKGROUND',(0,0),(4,0),colors.cyan),
            ('ALIGN',(0,1),(-2,-2),'CENTER')]))
        summaryTable.spaceAfter = 10
        para_list.append(summaryTable)
    return para_list

def add_summary_play_report(summary_data):
    para_list=[]
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    style=copy.deepcopy(normalStyle)
    style.alignment=1
    style.fontSize=18
    style.spaceBefore=10
    style.spaceAfter=10
    para_list.append(Paragraph("<b>REPORTS</b>",style))
    title_2_style=copy.deepcopy(normalStyle)
    title_2_style.fontSize=12
    title_2_style.spaceBefore=10
    title_2_style.spaceAfter=10
    para_list.append(Paragraph("<b>1. SUMMARY PLAY REPORT:</b>",title_2_style))
    desc = "The summary play report captures the play details at the time report generation. This summary is only available for completed days. "
    normalStyle.spaceAfter=5
    para_list.append(Paragraph(desc,normalStyle)) 
    header = ['Completed \n Days','Planned Plays \n per Screen \n Per day','Total \n Screens','Total Planned \n Plays', 
        'Completed \n Plays', 'Missed \n Plays*','Partial \n Plays*']
    data = [str(summary_data['completed_days']),str(summary_data['planned_plays']),str(summary_data['screens']),
        str(summary_data['total_planned_plays']),str(summary_data['completed_plays']),
        str(summary_data['missed_plays']),str(summary_data['partial_plays'])]
    table_data = [header,data]
    summaryTable = Table(table_data)
    summaryTable.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
        ('BOX', (0,0), (-1,-1), 0.25, colors.black),('BACKGROUND',(0,0),(-1,-2),colors.cyan),
        ('ALIGN',(0,1),(-2,-2),'Helvetica-Bold')]))
    summaryTable.spaceAfter = 10
    para_list.append(summaryTable)    
    return para_list
    
def create_order_details(report_data):
    para_list=[]
    order = "<b>Order Number : </b>" + report_data['order_data']['number']
    quoted_amout = "<b>Quoted Amount : </b> Rs."+ str(report_data['order_data']['quoted_amount'])
    discount_coupon = "<b>Discount Coupon Applied : </b>"+ str(report_data['order_data']['coupon_applied'])
    discounted_amout = "<b>Discounted Amount : </b> Rs."+ str(report_data['order_data']['discounted_amount'])
    credit_amout = "<b>Amount from Credits : </b> Rs."+ str(report_data['order_data']['credited_amount'])
    paid_amout = "<b>Paid Amount : </b> Rs."+ str(report_data['order_data']['paid_amount'])
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    para_list.append(Paragraph(order,normalStyle))
    normalStyle.spaceAfter=5
    para_list.append(Paragraph(quoted_amout,normalStyle))
    para_list.append(Paragraph(discount_coupon,normalStyle))
    para_list.append(Paragraph(discounted_amout,normalStyle))
    para_list.append(Paragraph(credit_amout,normalStyle))
    para_list.append(Paragraph(paid_amout,normalStyle))
    para_list.append(MCLine(450))
    return para_list

def create_pack_details(report_data):
    para_list=[]
    pack = "<b>Day Pack : </b>" + report_data['pack_data']['name']
    size = "<b>Playlist size (number of 30 sec slots) : </b>"+ str(report_data['pack_data']['units'])
    num_repitions = "<b>Number of repititions per day : </b>"+ str(report_data['pack_data']['num_applied'])
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    para_list.append(Paragraph(pack,normalStyle))
    normalStyle.spaceAfter=5
    para_list.append(Paragraph(size,normalStyle))
    para_list.append(Paragraph(num_repitions,normalStyle))
    para_list.append(MCLine(450))
    return para_list
def create_campaign_details(report_data):
    para_list=[]
    campaign = "<b>Campaign : </b>" + report_data['campaign_data']['name']
    booked_date = "<b>Booked Date : </b>"+ report_data['campaign_data']['booked_date']
    planned_days = "<b>Planned days : </b>" + report_data['campaign_data']['planned_dates']
    completed_days1 = "<b>Completed days : </b>"+ str(report_data['campaign_data']['completed_days']) + " of " + str(report_data['campaign_data']['total_days'])
    completed_days2 = "<b>Completed dates : </b>"+report_data['campaign_data']['completed_dates']
    inplan_days1 = "<b>In Plan days : </b>"+ str(report_data['campaign_data']['inplan_days']) +" of " + str(report_data['campaign_data']['total_days'])
    inplan_days2 = "<b>In Plan dates : </b>"+report_data['campaign_data']['inplan_dates']
    channel ="<b>Channel : </b>"+ report_data["campaign_data"]["channel"]
    screens ="<b>Total Screens : </b>"+str(report_data["campaign_data"]["num_screens"])
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    para_list.append(Paragraph(campaign,normalStyle))
    normalStyle.spaceAfter=5
    para_list.append(Paragraph(booked_date,normalStyle))
    para_list.append(Paragraph(planned_days,normalStyle))
    para_list.append(Paragraph(completed_days1,normalStyle))
    para_list.append(Paragraph(completed_days2,normalStyle))
    para_list.append(Paragraph(inplan_days1,normalStyle))
    para_list.append(Paragraph(inplan_days2,normalStyle))
    para_list.append(Paragraph(channel,normalStyle))
    para_list.append(Paragraph(screens,normalStyle))
    para_list.append(MCLine(450))
    return para_list

def create_price_table(report_data):
    para_list=[]
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    style=copy.deepcopy(normalStyle)
    style.alignment=2
    header = ['NO.','PACK NAME','    ','    ','   ','PRICE','REPS\nPER\nDAY','DAYS','SCREENS','ITEM\nTOTAL']
    data = ['1.',Paragraph(report_data['pack_data']['name'],normalStyle),' ','','',str(report_data['pack_data']['price']),
        str(report_data['pack_data']['num_applied']),str(report_data['campaign_data']['total_days']),
        str(report_data["campaign_data"]["num_screens"]),Paragraph(report_data['order_data']['quoted_amount'],style)]
    blank_row = ['','','','','','','','','','']
    discount_data=[' ',Paragraph('Discounted Amount from coupon '+report_data["order_data"]['coupon_applied'],normalStyle),
        '','','','','','','',Paragraph(str(report_data['order_data']['discounted_amount']),style)]
    credit_data=[' ',Paragraph('Amount used from credits ',normalStyle),
        '','','','','','','',report_data['order_data']['credited_amount']]
    paid_data=[' ',Paragraph('<b>TOTAL AMOUNT PAID </b>',normalStyle),
        '','','','','','','',Paragraph('<b> Rs.'+report_data['order_data']['paid_amount']+'</b>',style)]
    table_data = [header,data,blank_row,discount_data,blank_row,credit_data,blank_row,paid_data]
    summaryTable = Table(table_data)
    summaryTable.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(9,0),colors.palegreen),
        ('VALIGN',(0,0),(9,0),'MIDDLE'),
        ('SPAN',(1,0),(4,0)),
        ('ALIGN',(9,1),(9,1),'RIGHT'),
        ('ALIGN',(5,1),(8,1),'CENTER'),
        ('SPAN',(1,1),(4,1)),
        ('SPAN',(1,3),(8,3)),
        ('ALIGN',(9,3),(9,3),'RIGHT'),
        ('SPAN',(1,5),(8,5)),
        ('ALIGN',(9,5),(9,5),'RIGHT'),
        ('SPAN',(1,7),(8,7)),
        ('ALIGN',(9,7),(9,7),'RIGHT'),
        ('LINEABOVE',(1,3),(9,3),1,colors.black),
        ('LINEABOVE',(0,7),(9,7),1,colors.black),
        ('LINEBELOW',(0,7),(9,7),2,colors.black),
        
        #('SPAN',(0,2),(8,2)),
        ]))
    para_list.append(summaryTable)
    return para_list
    
def create_campaign_details_for_invoice(report_data):
    para_list=[]
    campaign = "<b>Campaign : </b>" + report_data['campaign_data']['name']
    booked_date = "<b>Booked Date : </b>"+ report_data['campaign_data']['booked_date']
    planned_days = "<b>Planned days : </b>" + report_data['campaign_data']['planned_dates']
    channel ="<b>Channel : </b>"+ report_data["campaign_data"]["channel"]
    screens ="<b>Total Screens : </b>"+str(report_data["campaign_data"]["num_screens"])
    order="<b> Order No: </b>"+str(report_data['order_data']['number']).upper()
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    para_list.append(Paragraph(campaign,normalStyle))
    normalStyle.spaceAfter=5
    para_list.append(Paragraph(booked_date,normalStyle))
    para_list.append(Paragraph(planned_days,normalStyle))
    para_list.append(Paragraph(channel,normalStyle))
    para_list.append(Paragraph(screens,normalStyle))
    para_list.append(Spacer(1,0.2*inch))
    para_list.append(Paragraph(order,normalStyle))
    return para_list

    
def create_firm_details_for_invoice(report_data):
    para_list=[]
    account = "<b>To </b>" 
    firm = "<b> "+ report_data['firm_data']['firm_name'].upper() +"</b>"
    address = "<b> "+ report_data['firm_data']['address'].upper() +"</b>"
    invoice_date = "<b>Date : </b>"+ (datetime.now().strftime("%d-%m-%Y"))
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    style=copy.deepcopy(normalStyle)
    style.alignment=2
    firmstyle=copy.deepcopy(normalStyle)
    firmstyle.fontSize=12
    para_list.append(Paragraph(invoice_date,style))
    para_list.append(Spacer(1,0.2*inch))
    para_list.append(Paragraph(account,firmstyle))
    firmstyle.spaceAfter=5
    para_list.append(Paragraph(firm,firmstyle))
    para_list.append(Paragraph(address,firmstyle))
    #para_list.append(Paragraph("fdsfdsfds ",normalStyle))
    #para_list.append(MCLine(450))
    return para_list


def create_firm_details(report_data):
    para_list=[]
    account = "<b>Account : </b>" + report_data['firm_data']['account_name']
    firm = "<b>Firm : </b>"+ report_data['firm_data']['firm_name']
    generated = "<b>Report Generated on : </b>"+ (datetime.now().strftime("%d-%m-%Y %I:%M:%S %p"))
    stylesheet=getSampleStyleSheet()
    normalStyle = stylesheet['Normal']
    para_list.append(Paragraph(account,normalStyle))
    normalStyle.spaceAfter=5
    para_list.append(Paragraph(firm,normalStyle))
    para_list.append(Paragraph(generated,normalStyle))
    #para_list.append(Paragraph("fdsfdsfds ",normalStyle))
    para_list.append(MCLine(450))
    return para_list

def generate_preplay_report(report_data,play_path):
    doc = SimpleDocTemplate(play_path)
    Story = [Spacer(1,0.6*inch)]
    style = styles["Normal"]
    paragraphs = create_firm_details(report_data)
    camp_paras = create_campaign_details(report_data)
    preplay_header = add_preplay_header(report_data['preplay_data'])
    preplay_data = add_preplay_days_report(report_data['days_data'])
    for p in paragraphs:
        Story.append(p)
    for p in camp_paras:
        Story.append(p)
    for p in preplay_header:
        Story.append(p)
    for p in preplay_data:
        Story.append(p)
    Story.append(Spacer(1,0.2*inch))
    doc.build(Story, onFirstPage=preplay_first_Page, onLaterPages=preplay_footer)
    
def generate_invoice(report_data,path):
    doc = SimpleDocTemplate(path)
    Story = [Spacer(1,0.6*inch)]
    style = styles["Normal"]
    firm_paras=create_firm_details_for_invoice(report_data)
    campaign_paras=create_campaign_details_for_invoice(report_data)
    price_paras=create_price_table(report_data)
    for p in firm_paras:
        Story.append(p)
    Story.append(Spacer(1,0.2*inch))
    for p in campaign_paras:
        Story.append(p)
    Story.append(Spacer(1,0.2*inch))
    for p in price_paras:
        Story.append(p)
    Story.append(Spacer(1,0.2*inch))
    doc.build(Story, onFirstPage=invoice_first_page, onLaterPages=invoice_footer)
    
def generate_play_report(report_data,play_path):
    doc = SimpleDocTemplate(play_path)
    Story = [Spacer(1,0.6*inch)]
    style = styles["Normal"]
    paragraphs = create_firm_details(report_data)
    camp_paras = create_campaign_details(report_data)
    pack_paras = create_pack_details(report_data)
    pack_order = create_order_details(report_data)
    summary_paras = add_summary_play_report(report_data['summary_data'])
    credit_paras = add_credit_report(report_data['credit_data'])
    days_paras = add_days_report(report_data['days_data'])
    reach_paras = add_wifi_reach_report(report_data['reach_data'])
    for p in paragraphs:
        Story.append(p)
    for p in camp_paras:
        Story.append(p)
    for p in pack_paras:
        Story.append(p)
    for p in pack_order:
        Story.append(p)
    for p in summary_paras:
        Story.append(p)
    for p in credit_paras:
        Story.append(p)
    for p in reach_paras:
        Story.append(p)
    for p in days_paras:
        Story.append(p)
    Story.append(Spacer(1,0.2*inch))
    doc.build(Story, onFirstPage=myFirstPage, onLaterPages=myLaterPages)
    

if __name__ =='__main__':
    report_data = {'firm_data':{'account_name': 'naturals_hsr','firm_name':'Naturals Spa and Salon','address':'32, 27th Main, HSR Layout, Bengaluru-560068'},
        "campaign_data": {'name': 'Test Campaign','booked_date':'15-02-2017','planned_dates':
        '15-02-2017,16-02-2017,17-02-2017','completed_days':2,'total_days':3,'inplan_days':1,
        'completed_dates':'15-02-2017,16-02-2017','inplan_dates':'17-02-2017','channel':'Purva Skywood',
        'num_screens':4},'pack_data':{'name':'One Day Stand (12 plays of Premium, 12 plays of OffPeak, 12 plays of Average)',
        'units':1,'num_applied':3,'price':'300.00'},'order_data':{'number':'DE917483748757345','quoted_amount':'5700.00','coupon_applied':'DE100OFF',
        'discounted_amount':300.00,'credited_amount':'150.00','paid_amount':'150.00'}}
    report_data['summary_data']={'completed_days':2,'planned_plays':36,'screens':4,'total_planned_plays':288,
        'completed_plays':244,'missed_plays':44}
    report_data['credit_data']={'missed_time':'12 mins 15 secs','slots':24.5,'effective_price':1.2,'credited_amount':53.0,
        'transactions':[{'number':'4345345','transaction_date':'15-02-2017','transaction_description':'Refund','amount':21.0},
        {'number':'4345385','transaction_date':'16-02-2017','transaction_description':'Refund','amount':22.0}]}
    report_data['days_data']=[{'date':'15-02-2017','planned_plays':36,'screens':4,'total_planned_plays':144,
        'completed_plays':120,'missed_plays':18,'screen_data':[
        {'name':'Purva-Screen-1','total_planned_plays':144,'completed_plays':110,'missed_plays':26,'play_data':
         [{'content':'afdfdsf','planned':'15-02-2017 14:50:51','played':'15-02-2017 14:52:50'}]}]},
        {'date':'16-02-2017','planned_plays':36,'screens':4,'total_planned_plays':144,
        'completed_plays':110,'missed_plays':26,'screen_data':[{'name':'Purva-Screen-1',
        'total_planned_plays':144,'completed_plays':110,'missed_plays':26,'play_data':
         [{'content':'afdfdsf','planned':'16-02-2017 14:50:51','played':'16-02-2017 14:52:50'}]}]}]
    report_data['reach_data']={'total':255,'days':[{'date':'15-02-2017','count':123},{'date':'16-02-2017','count':134}]}
    report_data['preplay_data']={'date':'21-02-2017','daypart_name':'Afternoon','daypart_from_time':'02:00 PM','daypart_to_time':'04:00 PM'}
    #generate_play_report(report_data,'/tmp/report.pdf')
    #generate_preplay_report(report_data,'/tmp/report.pdf')
    generate_invoice(report_data, "/tmp/invoice.pdf")