'''
Created on 03-Aug-2017

@author: saba
'''
from PIL import Image
import os


def find_scale_dimensions(image_size):
    img_width=image_size[0]
    img_height=image_size[1]
    aspect_ratio = img_width / (1.0 * img_height)
    if aspect_ratio > 1.0:
        # width needs to be Fixed
        scaled_width=150
        scaled_height=scaled_width / aspect_ratio
    else:
        #height needs to be Fixed
        scaled_height=150
        scaled_width=scaled_height * aspect_ratio
    return (scaled_width,scaled_height)

def scale_target_image(imageFile):
    image = Image.open(imageFile)
    scale_dims = find_scale_dimensions(image.size)
    new_width = scale_dims[0]
    new_height = scale_dims[1]
    scaled_image = image.resize((int(new_width),int(new_height)),Image.ANTIALIAS)
    file_name=os.path.basename(imageFile)
    filename_without_extn=file_name.split('.')[0]
    folder=os.path.dirname(imageFile)
    scaled_img_name = filename_without_extn+"_scaled"+str(int(new_width))+"x"+str(int(new_height))+".jpg"
    file_with_folder = os.path.join(folder,scaled_img_name)
    scaled_image.save(file_with_folder)
    return file_with_folder