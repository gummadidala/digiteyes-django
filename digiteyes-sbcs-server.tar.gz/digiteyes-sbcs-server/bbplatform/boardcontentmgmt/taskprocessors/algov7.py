from __future__ import division
from datetime import datetime,timedelta
import time,math
from boardcontentmgmt.models import BookedAdPack,BookedSlot,DayPart,CampaignState,ContentQueue,BookingState,Board,Account, AccountUser,AdvtCampaign
from boardcontentmgmt.models import AffiliateContent,AttributeTagGroup,ShowSpotAsset,TrackBookingAlgo,CampaignType,AdvtCampaignDate
from boardcontentmgmt.models import ContentState,ScreenStatus
import logging
from boardcontentmgmt.utilities.algo_utilities import get_daypart
from __builtin__ import str
from . import bidallocator
logger = logging.getLogger("boardcontentmgmt.tasks")
def get_affiliate_contents_for_board(brd,date):
    logger.info('Inside get_affiliate_contents_for_board')
    affiliate_contents_list = []
    if brd.show_spot is not None:
        spot = ShowSpotAsset.objects.filter(key = brd.show_spot.key)
        if spot is not None and len(spot)> 0:
            logger.debug('assigned spot for board :'+str(brd.board_name)+' is : '+str(spot[0].name))
            key_list = []
            attrib_grps = spot[0].attached_attribute_tag.all()
            for g in attrib_grps:
                key_list.append(g.key)
                grp = AttributeTagGroup.objects.filter(key__in = key_list)
                if grp is not None and len(grp) >0:
                    logger.debug('board :'+str(brd.board_name)+' is part of group : '+str(grp[0].name))
                    affiliate_contents = AffiliateContent.objects.filter(planned_date = date,screen_group__key__in=[grp[0].key]).order_by('play_order')
                else:
                    logger.debug('Group not found for board:'+str(brd.board_name))
                if affiliate_contents is not None and len(affiliate_contents) >0:
                    for aff_cntnt in affiliate_contents:
                        approved = False
                        play_list = ContentQueue.objects.filter(key = aff_cntnt.play_list.key)
                        if play_list is not None and len(play_list)>0:
                            content_schedules = play_list[0].content_list.all()
                            if content_schedules is not None and len(content_schedules)>0:
                                for cs in content_schedules:
                                    if cs.content.content_state == ContentState.objects.filter(state_name='APPROVED')[0]:
                                        approved = True
                        if approved:
                            affiliate_contents_list.append(aff_cntnt)
                        #affiliate_contents_list.append(aff_cntnt)
    else:
        logger.info(brd.board_name+' is not assigned to any showspot')
    return affiliate_contents_list
def fill_all_child_tags(grpTag,all_tags):
    if grpTag not in all_tags:
        descendents = AttributeTagGroup.get_tree(grpTag)
        for tag in descendents:
            all_tags.append(tag.name)

def get_screens_for_tags(group_list):
    grp_tag_list_incl_children = []
    for grpTag in group_list:
        grp_tag_list_incl_children.append(grpTag.name)
        logger.debug( grpTag.name)
        fill_all_child_tags(grpTag, grp_tag_list_incl_children)
        logger.debug(str(grp_tag_list_incl_children))
    spots = ShowSpotAsset.objects.filter(
        attached_attribute_tag__name__in = grp_tag_list_incl_children)
    keyList = []
    for spot in spots:
        keyList.append(spot.key)
    related_boards = Board.objects.filter(show_spot__key__in=keyList)
    return related_boards

def create_booked_slot(date,pack,time_tillbooked,numplays=1):
    state = BookingState.objects.filter(name="SUCCESS")
    slots_booked=pack.slots_booked
    needed_time=pack.units_per_play*pack.unit_size*numplays
    bt = BookedSlot()
    bt.start_time = time_tillbooked
    bt.num_units = pack.units_per_play*numplays
    bt.unit_size = pack.unit_size
    bt.booking_state = state[0]
    bt.save()
    slots_booked.add(bt)
    pack.save()
    dt= datetime.combine(date,time_tillbooked)
    dt = dt  + timedelta(seconds=needed_time)
    time_tillbooked = dt.time()
    logger.info( 'Booked slot for:'+pack.applied_to.name +" time:"+bt.start_time.isoformat()+" units booked:"+str(bt.num_units)+
        ' Board:'+pack.booked_screen.board_name)
    return time_tillbooked

def GetNumOfUnits_DayPart(day_part):
    st = datetime.now()
    st1 = st.replace(hour=day_part.from_time.hour,minute=day_part.from_time.minute,second=day_part.from_time.second)
    et1 = st.replace(hour=day_part.to_time.hour,minute=day_part.to_time.minute,second=day_part.to_time.second)
    td = et1 - st1
    td_seconds = td.total_seconds()
    total_slots = int(td_seconds / 30)
    return total_slots

def auto_booking(slotsRemaining,date,brd,day_part,cntnt,booking_type,acct,flag,camp_type):
    logger.info('Inside auto_booking')
    existing = False
    existing_bookings = BookedAdPack.objects.filter(date_booked_for=date,
        day_part_booked_for__name=day_part,booked_screen__key=brd.key)
    if existing_bookings is not None and len(existing_bookings) > 0:
        existing = True
        bap = existing_bookings[0]
    else :
        bap = BookedAdPack()
    bap.booked_screen = Board.objects.filter(key = brd.key)[0]
    bap.date_booked_for = date
    success = BookingState.objects.filter(name = 'SUCCESS')[0]
    bap.booking_state = success 
    bap.when_booked = datetime.now().date()
    bap.num_plays = slotsRemaining
    bap.units_per_play = cntnt.num_units
    bap.day_part_booked_for = DayPart.objects.filter(name = day_part.name)[0]
    bap.price = 0
    #acct = Account.objects.filter(account_name='DE Production')
    bap.account = acct
    bap.unit_size = cntnt.unit_size
    bap.booking_type = booking_type
    bap.play_list = cntnt
    
    if not existing:
        campaign = AdvtCampaign()
    else :
        campaign = bap.applied_to
    campaign.name = 'camp_'+acct.account_name+'_'+str(flag)+'_'+day_part.name
    usr = AccountUser.objects.all().filter(account = acct)
    campaign.owner = usr[0]
    campaign.created_date = datetime.now().date()
    #campaign.planned_end_date = datetime.now().date()
    campaign.state = CampaignState.objects.filter(state_name = 'PLANNED')[0]
    campaign.selected_plays_per_day = slotsRemaining
    campaign.total_screens_selected = 1
    campaign.dayPart_selected = DayPart.objects.filter(name = day_part.name)[0] 
    campaign.account = acct
    campaign.play_list = cntnt
    campaign.type = CampaignType.objects.filter(name = camp_type)[0]
    campaign.units_per_play = cntnt.num_units
    campaign.save()
    obj = AdvtCampaignDate()
    obj.date = datetime.now().today().strftime("%Y-%m-%d")
    obj.save()
    campaign.planned_dates = [obj]
    campaign.save()
    campaign.screen_selection_tags = []
    campaign.save()
    logger.info(booking_type +' campaign created for num_plays:'+str(slotsRemaining)+' Daypart:'+str(day_part.name)+
                ' Board:'+str(brd.board_name)+' date:'+str(date)+' type: '+str(camp_type))
    bap.applied_to = campaign
    bap.save()
        
def Allocate_Free_slots(date,brd,day_part,totalslotsbooked,totalPlays,camp_type):
    logger.info('Allocate_Free_slots date:'+str(date)+' board:'+str(brd.board_name)+' day_part:'+str(day_part.name))
    totalSlots = GetNumOfUnits_DayPart(day_part)
    slotsRemaining = 0.000
    slotsRemaining = totalSlots - totalslotsbooked
    #######################
    #   Trigger the Bidding Engine
    ###############################
    logger.info("ALLOCATION_ALGO_SCREEN_STATS: Total :Before Bid Allocation "+str(totalSlots)+ 
                " Booked : "+str(totalslotsbooked)+
                " Empty : "+str(slotsRemaining))        
    slotsRemaining = bidallocator.book_adpacks_for_bids(brd,day_part,slotsRemaining)
    logger.info("ALLOCATION_ALGO_SCREEN_STATS: Total : After Bid Allocation "+str(totalSlots)+ 
                " Empty : "+str(slotsRemaining))        
    production_acct = Account.objects.filter(account_name='DE Production')
    production_normal_cntnt = ContentQueue.objects.filter(content_queue_name = 'nearby_android_playlist')
    production_ticker_content = ContentQueue.objects.filter(content_queue_name = 'production-ticker')
    if camp_type == 'TICKER':
        de_per_slots = 0.2 #20%
        empty_per_slots = 0.0 #0%
        prod_cntnt = production_ticker_content
        auto_booking_type = 'auto_booking'
        empty_booking_type = 'empty_booking'
    else:
        de_per_slots = 0.1 #10%
        empty_per_slots = 0.05 #5%
        prod_cntnt = production_normal_cntnt
        auto_booking_type = 'auto_booking'
        empty_booking_type = 'empty_booking'
    de_slots = 0
    empty_slots = 0
    affiliate_slots = 0
    if prod_cntnt is not None and len(prod_cntnt)>0:
        logger.info('production play list is configured in the system with unit size:'+str(prod_cntnt[0].unit_size))
        if slotsRemaining>0:
            slots_reserved = de_per_slots*totalSlots # check for 10% of total daypart slots
            if slotsRemaining >= slots_reserved:  
                slots_reserved = de_per_slots*totalSlots
            else:
                slots_reserved=slotsRemaining
            auto_booking_plays=math.floor(slots_reserved*30/prod_cntnt[0].unit_size)
            logger.info('calling auto_booking for plays:'+str(auto_booking_plays)+' slots:'+str(slots_reserved)+'unit_size:'+str(prod_cntnt[0].unit_size))
            auto_booking(auto_booking_plays,date,brd,day_part,prod_cntnt[0],auto_booking_type,production_acct[0],1,camp_type)        
            slotsRemaining -= slots_reserved
            de_slots= slots_reserved
            logger.info('slots_remaining after auto_booking: '+str(slotsRemaining))
        if slotsRemaining>0:
            slots_reserved = empty_per_slots*totalSlots # check for 5% of total daypart slots
            if slotsRemaining >= slots_reserved:  
                slots_reserved = empty_per_slots*totalSlots
            else:
                slots_reserved=slotsRemaining
            empty_slots = slots_reserved
            traffic_booking_plays=math.floor(slots_reserved*30/prod_cntnt[0].unit_size)
            logger.info('calling auto_booking for plays:'+str(traffic_booking_plays)+' slots:'+str(slots_reserved)+'unit_size:'+str(10))
            auto_booking(traffic_booking_plays,date,brd,day_part,prod_cntnt[0],empty_booking_type,production_acct[0],1,camp_type)        
            slotsRemaining -= slots_reserved
            logger.info('slots_remaining after empty_booking: '+str(slotsRemaining))
    else:
        logger.info('production play list is not created')
    affiliate_slots = slotsRemaining
    logger.info("ALLOCATION_ALGO_SCREEN_STATS: SCREEN : "+str(brd.board_name)+
                "BOOKED_AFFILIATE_SLOTS : "+str(affiliate_slots)+
                "DE_"+str(camp_type)+"_SLOTS : "+str(de_slots)+
                "EMPTY_"+str(camp_type)+"_SLOTS :"+str(empty_slots))
    if slotsRemaining > 0 and camp_type != 'TICKER':
        slotsRemaining = math.floor(slotsRemaining)
        affiliate_cntnts = get_affiliate_contents_for_board(brd,date)
        logger.info('affiliate contents length:'+str(len(affiliate_cntnts)))
        if affiliate_cntnts is not None and len(affiliate_cntnts) > 0:
            i=0
            j=1
            while slotsRemaining > 0 :
                cntnt = affiliate_cntnts[i]
                cntnt_plays = cntnt.num_plays
                cntnt_acct = cntnt.submitted_account
                cntnt_space = cntnt.num_plays*cntnt.play_list.num_units*cntnt.play_list.unit_size/30
                if slotsRemaining >= cntnt_space:
                    cntnt_plays = cntnt.num_plays
                    slotsRemaining -= cntnt_space
                else:
                    cntnt_plays = math.floor(slotsRemaining*30/cntnt.play_list.unit_size)
                    slotsRemaining -= slotsRemaining
                    cntnt_space = slotsRemaining
                
                auto_booking(cntnt_plays,date,brd,day_part,cntnt.play_list,'affiliate_booking',cntnt_acct,j,camp_type)
                i = (i+1)%len(affiliate_cntnts)
                j=j+1 
    else:
        logger.info('Free_slots not available!')

def call_with_campaignType(state,date,brd,dp,camp_type):
    print 'In call_with_campaign_params'
     
    time_tillbooked =dp.from_time
    mymap = {}
    mylist= []
    bookedadpack=BookedAdPack.objects.filter(booking_state = state,date_booked_for=date,
                                             day_part_booked_for=dp,booked_screen__key=brd.key,
                                             applied_to__type__name=camp_type)
    logger.info('booked ad pack total length in allocation algorithm:'+str(len(bookedadpack))+'DayPart:'+str(dp.name)+
                ' Board:'+brd.board_name+' date:'+str(date))
    if not bookedadpack:
        logger.info('no booked ad packs available!' +'DayPart:'+str(dp.name)+
                ' Board:'+brd.board_name+' date:'+str(date))   
    plys = 0
    units = 0
    for bpck in bookedadpack:
        plys += bpck.num_plays
        units += bpck.num_plays*bpck.units_per_play*bpck.unit_size/30
    Allocate_Free_slots(date, brd, dp,units,plys,camp_type)
    bookedadpack=BookedAdPack.objects.filter(booking_state = state,date_booked_for=date,
                                             day_part_booked_for=dp,booked_screen__key=brd.key,
                                             applied_to__type__name=camp_type).exclude(booking_type ='auto_booking').exclude(booking_type = 'test')
    logger.info('booked ad pack total length in allocation algorithm:'+str(len(bookedadpack))+'DayPart:'+str(dp.name)+
                            ' Board:'+brd.board_name+' date:'+str(date))
    if not bookedadpack:
        logger.info('no booked ad packs available!' +'DayPart:'+str(dp.name)+
                            ' Board:'+brd.board_name+' date:'+str(date))
        #continue
        return None
    for k in bookedadpack:
        if  k.applied_to.key in mymap.keys():
            mymap[k.applied_to.key].append(k)
        else:
            mymap[k.applied_to.key]=[k]    
        if k.applied_to.state.state_name=='PLANNED':
            k.applied_to.state = CampaignState.objects.filter(state_name = 'RUNNING')[0]
            k.applied_to.save()
            k.save()
    for key in mymap.keys():
        value = mymap[key]
        mylist.append(value)
    l = len(mylist)  
    cmpgnLength = []
    for i in range(l):
        cmpgnLength.append(len(mylist[i]))
                
    #initializing bookingCampaigns
    w = len(cmpgnLength)
    hgh = 0
    for k in range(len(cmpgnLength)):
        for m in range(cmpgnLength[k]):
                if(m > hgh):
                    hgh = m
    bookingsInCampaigns = [[0 for x in range(hgh+1)] for y in range(w)] 
    totalPlaysBooked = 0
    totalUnits = 0
    #inserting total plays according to the bookings in to  campaigns
    for k in range(len(cmpgnLength)):
        for m in range(cmpgnLength[k]):
            bookingsInCampaigns[k][m] = mylist[k][m].num_plays
            totalPlaysBooked += bookingsInCampaigns[k][m]
            totalUnits += bookingsInCampaigns[k][m]*mylist[k][m].units_per_play
    #get auto booked packs from BokkedAdPack
    auto_bookedPack = BookedAdPack.objects.filter(date_booked_for=date,day_part_booked_for=dp,
                                                  booked_screen__key=brd.key,
                                                  booking_type ='auto_booking',
                                                  applied_to__type__name=camp_type)
    logger.info('length of Auto booked ad packs:'+str(len(auto_bookedPack))+'DayPart:'+str(dp.name)+
                ' Board:'+brd.board_name+' date:'+str(date))
    autoBookingSlots = 0
    frequency = 1
    if auto_bookedPack is not None and len(auto_bookedPack) > 0:
        for abp in auto_bookedPack:
            autoBookingSlots += abp.num_plays
        try:
            frequency = math.floor(totalPlaysBooked/autoBookingSlots)
        except:
            logger.error("Error: Mostly Divide by Zero error!")
    else:
        logger.info( 'no auto booking is available')
        logger.info('Number of Auto booked plays: '+str(autoBookingSlots)+' DayPart:'+str(dp.name)+
                    ' Board:'+str(brd.board_name)+' date:'+str(date))
        logger.info('num of normal booked plays: '+str(totalPlaysBooked))
        logger.info('frequency of prroduction playlist: '+str(frequency))
    k = 0
    m = 0
    playCount = 0
    logger.info('Total remaining plays at campaigns:'+ str(bookingsInCampaigns)+' DayPart:'+str(dp.name)+
                ' Board:'+brd.board_name+' date:'+str(date))
    while k < len(cmpgnLength) and m <= hgh  and playCount < totalPlaysBooked:
        if(bookingsInCampaigns[k][m] <= 0):
            flag = True
            for h in range(hgh):
                if bookingsInCampaigns[k][h] > 0 and flag == True:
                    flag = False
                    time_tillbooked = create_booked_slot(date, mylist[k][h], time_tillbooked)
                    playCount += 1
                    bookingsInCampaigns[k][h] -= 1 
                    logger.info( 'Booked from campaign:'+ str((k+1)) +'B:'+str((h+1)) + str(bookingsInCampaigns))
                    if(autoBookingSlots > 0 and playCount%frequency==0):
                        time_tillbooked = create_booked_slot(date, auto_bookedPack[0], time_tillbooked)
                        autoBookingSlots -= 1
                        logger.info( 'Booked from AUTO BOOKING') 
            k = k + 1
            if(k > len(cmpgnLength)-1):
                k = 0
                if m + 1 <= hgh :
                    m = m + 1
                else:
                    m = 0
                continue      
        if(bookingsInCampaigns[k][m] > 0):
            time_tillbooked = create_booked_slot(date, mylist[k][m], time_tillbooked)
            playCount += 1
            bookingsInCampaigns[k][m] -= 1 
            logger.info( 'Booked from campaign:'+str((k+1))+'B:'+str((m+1)) +str(bookingsInCampaigns))
            if(autoBookingSlots > 0 and playCount%frequency==0):
                time_tillbooked = create_booked_slot(date, auto_bookedPack[0], time_tillbooked)
                autoBookingSlots -= 1
                logger.info( 'Booked from AUTO BOOKING')
            k = k + 1
            if(k > len(cmpgnLength)-1):
                k = 0
                if m + 1 <= hgh :
                    m = m + 1
                else:
                    m = 0    
    
    
def allocation_algorithm(screen_keys,date,track_key,validator,dp_list,camp_types):
    state = BookingState.objects.filter(name="SUCCESS")[0]
    cancelled_state = BookingState.objects.filter(name="CANCELLED")[0]
    board = []
    for key in screen_keys:
        brd_obj = Board.objects.filter(key=key)
        if brd_obj is not None and len(brd_obj) > 0:
            board.append(brd_obj[0])
    #day_part=DayPart.objects.all()
    day_part = []
    live_state = ScreenStatus.objects.filter(name='LIVE')[0]
    if len(dp_list) > 0:
        for d in dp_list:
            dp_obj = DayPart.objects.filter(name=d)
            if dp_obj is not None and len(dp_obj)>0:
                day_part.append(dp_obj[0])
    else:
        day_part = get_daypart()
    if len(camp_types) ==0:
       camp_types = ['NORMAL','TICKER']
    for brd in board:
        if brd.board_state == live_state:
            logger.info("Board: "+str(brd.board_name)+" is LIVE")
            for  dp in day_part:
                logger.info("ALLOCATION_ALGO_SCREEN_START SCREEN : "+str(brd.board_name)+
                " DATE : "+str(date)+" DAYPART : "+str(dp.name))
                #clearing the bookedslots if already present
                bookedadpack=BookedAdPack.objects.filter(booking_state = state,date_booked_for=date,booked_screen__key=brd.key,day_part_booked_for=dp)
                if bookedadpack is not None and len(bookedadpack) > 0:
                    for bpck in bookedadpack:
                        if bpck.applied_to.play_list is None:
                            logger.info('No playlist for the campaign : '+str(bpck.applied_to.name))
                            bpck.booking_state = cancelled_state
                            bpck.save()
                        bpck.slots_booked = []
                        bpck.save()
                        bpck.refresh_from_db()
                        if bpck.booking_type == "auto_booking" or bpck.booking_type == "empty_booking":
                           bpck.delete()
                for camp_type in camp_types:
                    logger.info("RUNNING FOR CAMPAIGN_TYPE : "+str(camp_type))
                    call_with_campaignType(state,date,brd,dp,camp_type)
                
                validator(str(date),str(dp.name),str(brd.key))
        else:
            logger.error("Board: "+str(brd.board_name)+" is not LIVE")
    logger.info("ALLOCATION_ALGO_SCREEN_END SCREEN : "+str(board[0].board_name)+
                " DATE : "+str(date)+" DAYPART : "+str(day_part[0].name))
    obj = TrackBookingAlgo.objects.filter(key = track_key)
    if obj is not None and len(obj)> 0 :
        algo_obj = obj[0]
        algo_obj.end_time = datetime.now()
        algo_obj.save()                            
                
                
                                      
              
                
                
                
           




            
            
                
                
#allocation_algorithm(datetime.now().date())
#allocation_algorithm(datetime.now().date()+timedelta(days=-1))               
                    
                     
            
            
        
    