'''
Created on 17-Feb-2017

@author: saba
'''
import datetime
from boardcontentmgmt.models import Content,BookedAdPack,BookingState,BoardPlayHistory
from boardcontentmgmt.models import BookedSlot,Board
from django.db.models import Sum
import logging
logger = logging.getLogger("boardcontentmgmt.tasks")

def get_playlist_contetent_and_time(play_list):
    campaign_contents = []
    if play_list is None:
        logger.warn("No Play list available -- May be not assigned!")
        return campaign_contents
    for cs in play_list.content_list.all():
        content={}
        content['key']=str(cs.content.key)
        content['name']=str(cs.content.content_name)
        content['type']=str(cs.content.content_type.type_name)
        if cs.filler_time > datetime.timedelta(seconds=0):
            cntnt_time = int(cs.filler_time.total_seconds())
        else:
            cntnt_time= int(cs.content.content_play_time.total_seconds())
        if cntnt_time == 0:
            cntnt_time=30
        content['play_time']=str(cntnt_time)
        campaign_contents.append(content)
    return campaign_contents

def generate_report_for_schedule(booked_slot,content_list,play_reports,play_stats,pre_play):
    missed_time=0
    play_stats['completed_plays']=0
    play_stats['missed_plays']=0
    play_stats['partial_plays']=0
    missed=True
    completed=True
    play_report={}
    logger.info("generate_report_for_schedule "+str(pre_play))
    index=0
    for content in content_list:
        play_report={}
        play_report['content']=content['name']
        play_report['type']=content['type']
        play_report['play_time']=content['play_time']
        if index == 0:
            play_report['planned']=booked_slot.start_time.strftime("%I:%M:%S %p")
            play_report['planned_time']=booked_slot.start_time
        else:
            play_report['planned']=" "
            play_report['planned_time']=(datetime.datetime.combine(datetime.date.today(), 
                booked_slot.start_time) + datetime.timedelta(seconds=index)).time()
        index=index+1
        if pre_play:
            play_report['played']=" "
            play_reports.append(play_report)
            continue
        hist_objs = BoardPlayHistory.objects.filter(schedule_key = booked_slot.key,
            content_played__key=content['key'])
        play_report['played']="Not Completed"
        if len(hist_objs) > 0:
            missed=False
            ob=hist_objs[0]
            start_time = ob.content_from_time
            end_time = ob.content_to_time
            td = end_time-start_time
            if td.total_seconds() >= int(content['play_time']):
                play_report['played']=start_time.strftime("%I:%M:%S %p")
            else:
                completed=False
                missed_time=missed_time+int(content['play_time'])
        else:
            completed=False
            missed_time=missed_time+int(content['play_time'])
        play_reports.append(play_report)
    if pre_play:
        return missed_time
    if missed:
        play_stats['missed_plays']=1
    if completed and not missed:
        play_stats['completed_plays']=1
    if not missed and not completed:
        play_stats['partial_plays']=1
    return missed_time
        
def generate_play_report(screen,day,campaign,screen_stats,dayPart,pre_play):
    success=BookingState.objects.filter(name='SUCCESS')[0]
    if dayPart is None:
        baps = BookedAdPack.objects.filter(date_booked_for = day,
            applied_to__key = campaign.key,booked_screen__key=screen.key,booking_state=success)
        planned_plays=BookedAdPack.objects.filter(date_booked_for = day,
            applied_to__key = campaign.key,booked_screen__key=screen.key,booking_state=success).aggregate(Sum('num_plays'))
    else :
        baps = BookedAdPack.objects.filter(date_booked_for = day,
            applied_to__key = campaign.key,booked_screen__key=screen.key,
            day_part_booked_for__key=dayPart.key,booking_state=success)
        planned_plays=BookedAdPack.objects.filter(date_booked_for = day,
            applied_to__key = campaign.key,day_part_booked_for__key=dayPart.key,
            booked_screen__key=screen.key,booking_state=success).aggregate(Sum('num_plays'))
    missed_time=0
    screen_stats['name']=screen.board_name
    logger.info("Total plays for Screen: "+unicode(planned_plays))
    screen_stats['total_planned_plays']=planned_plays['num_plays__sum']
    screen_stats['completed_plays']=0
    screen_stats['missed_plays']=0
    screen_stats['partial_plays']=0
    screen_stats['missed_time']=0
    play_reports=[]
    for bap in baps:
        contents = get_playlist_contetent_and_time(bap.play_list)
        for bs in bap.slots_booked.all():
            play_stats={}
            missed_time=missed_time+generate_report_for_schedule(bs, contents, 
                play_reports,play_stats,pre_play)
            screen_stats['completed_plays']=screen_stats['completed_plays']+ play_stats['completed_plays']
            screen_stats['missed_plays']=screen_stats['missed_plays']+ play_stats['missed_plays']
            screen_stats['partial_plays']=screen_stats['partial_plays']+ play_stats['partial_plays']
    screen_stats['missed_time']=missed_time
    ordered_play_reports = sorted(play_reports, key=lambda k: k['planned_time'])
    screen_stats['play_data']=ordered_play_reports
    return missed_time

def find_campaign_stats_for_day(day,campaign,dayPart=None,pre_play=False):
    if dayPart is not None:
        logger.info("find_campaign_stats_for_day : "+dayPart.name+" Pre-play "+str(pre_play))
    success=BookingState.objects.filter(name='SUCCESS')[0]
    screen_keys = BookedAdPack.objects.filter(date_booked_for = day,
        applied_to__key = campaign.key,booking_state=success).values('booked_screen__key').distinct()
    print unicode(screen_keys)
    screens=[]
    for skey in screen_keys:
        screen=Board.objects.get(key=skey['booked_screen__key'])
        screens.append(screen)
    missed_time=0;
    campaign_stats={}
    campaign_stats['date']=day.strftime("%d-%m-%Y")
    campaign_stats['screens']=len(screens)
    if dayPart is None:
        total_plays_for_day=BookedAdPack.objects.filter(date_booked_for = day,
            applied_to__key = campaign.key,booking_state=success).aggregate(Sum('num_plays'))
    else:
        total_plays_for_day=BookedAdPack.objects.filter(date_booked_for = day,
            applied_to__key = campaign.key,day_part_booked_for__key=dayPart.key,booking_state=success).aggregate(Sum('num_plays'))
    logger.info("Total plays for day: "+unicode(total_plays_for_day))
    campaign_stats['total_planned_plays']=total_plays_for_day['num_plays__sum']
    campaign_stats['planned_plays']=total_plays_for_day['num_plays__sum']
    campaign_stats['completed_plays']=0
    campaign_stats['missed_plays']=0
    campaign_stats['partial_plays']=0
    campaign_stats['missed_time']=0
    campaign_stats['screen_data']=[]
    for screen in screens:
        screen_stats={}
        missed_time=missed_time+generate_play_report(screen,day,campaign,screen_stats,dayPart,pre_play)
        campaign_stats['completed_plays']=campaign_stats['completed_plays']+screen_stats['completed_plays']
        campaign_stats['missed_plays']=campaign_stats['missed_plays']+screen_stats['missed_plays']
        campaign_stats['missed_time']=campaign_stats['missed_time']+screen_stats['missed_time']
        campaign_stats['partial_plays']=campaign_stats['partial_plays']+screen_stats['partial_plays']
        campaign_stats['screen_data'].append(screen_stats)
    return campaign_stats

def find_campaign_stats(campaign):
    planned_dates= campaign.planned_dates
    summary_data={}
    full_campaign_stats={}
    completed_days=[]
    today=datetime.date.today()
    for day in planned_dates.all():
        if day.date < today:
            completed_days.append(day.date)
    success=BookingState.objects.filter(name='SUCCESS')[0]
    screens = BookedAdPack.objects.filter(applied_to__key = campaign.key,
        booking_state=success).values('booked_screen').distinct()
    summary_data['screens']=len(screens)
    total_plays=BookedAdPack.objects.filter(applied_to__key = campaign.key,
        booking_state=success,date_booked_for__in=completed_days).aggregate(Sum('num_plays'))
    summary_data['total_planned_plays']=total_plays['num_plays__sum']
    if len(completed_days) == 0:
        summary_data['planned_plays']=0
    else:
        summary_data['planned_plays']=total_plays['num_plays__sum']/summary_data['screens']/len(completed_days)
    summary_data['completed_plays']=0
    summary_data['missed_plays']=0
    summary_data['partial_plays']=0
    summary_data['missed_time']=0
    full_campaign_stats['days_data']=[]
    today = datetime.date.today()
    count=0
    for day in planned_dates.all():
        if day.date < today:
            count=count+1
            day_stats=find_campaign_stats_for_day(day.date,campaign)
            summary_data['completed_plays']=summary_data['completed_plays']+day_stats['completed_plays']
            summary_data['missed_plays']=summary_data['missed_plays']+day_stats['missed_plays']
            summary_data['partial_plays']=summary_data['partial_plays']+day_stats['partial_plays']
            summary_data['missed_time']=summary_data['missed_time']+day_stats['missed_time']
            full_campaign_stats['days_data'].append(day_stats)
    summary_data['completed_days']=count
    full_campaign_stats['summary_data']=summary_data
    return full_campaign_stats
        