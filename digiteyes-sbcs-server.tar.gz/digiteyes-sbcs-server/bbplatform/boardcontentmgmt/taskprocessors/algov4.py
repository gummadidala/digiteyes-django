from datetime import datetime,timedelta
from boardcontentmgmt.models import BookedAdPack,BookedSlot,DayPart,BookingState,Board

def create_booked_slot(date,pack,time_tillbooked,numplays=1):
    state = BookingState.objects.filter(name="SUCCESS")
    slots_booked=pack.slots_booked
    needed_time=pack.units_per_play*30*numplays
    #needed_time=pack.reference_master_pack.units_per_play*30*numplays
    bt = BookedSlot()
    bt.start_time = time_tillbooked
    bt.num_units = pack.units_per_play*numplays
    #bt.num_units = pack.reference_master_pack.units_per_play*numplays
    bt.unit_size = 30
    bt.booking_state = state[0]
    bt.save()
    slots_booked.add(bt)
    pack.save()
    dt= datetime.combine(date,time_tillbooked)
    dt = dt  + timedelta(seconds=needed_time)
    time_tillbooked = dt.time()
    print pack.applied_to.name ,": ",bt.start_time," - ",bt.num_units,pack.booked_screen.board_name
    return time_tillbooked

def ValidateAlgorithm(units_asked_tobook,cmpgnLength,mylist):
    units_booked =0
    for k in range(len(cmpgnLength)):
        for m in range(cmpgnLength[k]):
            slotsbooked = mylist[k][m].slots_booked.all()
            for s in slotsbooked:
                units_booked += s.num_units
    #print'units_booked',units_booked
    #print'units_asked_tobook',units_asked_tobook
    if(units_booked == units_asked_tobook):
        print 'Booking done successfully! :)'
    else:
        print 'Booking unsuccessfull :('

def GetNumOfUnits_DayPart(day_part):
    st = datetime.now()
    st1 = st.replace(hour=day_part.from_time.hour,minute=day_part.from_time.minute,second=day_part.from_time.second)
    et1 = st.replace(hour=day_part.to_time.hour,minute=day_part.to_time.minute,second=day_part.to_time.second)
    td = et1 - st1
    td_seconds = td.total_seconds()
    total_slots = int(td_seconds / 30)
    return total_slots

def allocation_algorithm(date):
    day_part=DayPart.objects.all()
    state = BookingState.objects.filter(name="SUCCESS")
    board = Board.objects.all()
    
    for brd in board:
        for  i in day_part:
            units_asked_tobook = 0
            time_tillbooked =i.from_time
            mymap = {}
            mylist= []
            
            bookedadpack=BookedAdPack.objects.all().filter(date_booked_for=date,day_part_booked_for=i,booked_screen__key=brd.key)
            if not bookedadpack:
                continue
            for pack in bookedadpack:
                pack.slots_booked = []
                pack.save()
            print 'Day Part:',i.name
            totalUnitsAvailable = GetNumOfUnits_DayPart(i)
            #print 'total units available:',totalUnitsAvailable
            #print len(bookedadpack)
            for k in bookedadpack:
                if  k.applied_to.key in mymap.keys():
                    mymap[k.applied_to.key].append(k)
                else:
                    mymap[k.applied_to.key]=[k]
            for key in mymap.keys():
                value = mymap[key]
                mylist.append(value)
    
            l = len(mylist)
            #print 'length of myList',l
            
            cmpgnLength = []
            for i in range(l):
                cmpgnLength.append(len(mylist[i]))
            #print 'total campaigns:',len(cmpgnLength)
            
            totalBookings = 0
            for j in range(len(cmpgnLength)):
                totalBookings = totalBookings + cmpgnLength[j]
            #print 'totalBookings available:',totalBookings
            
            #initializing bookingCampaigns
            w = len(cmpgnLength)
            hgh = 0
            for k in range(len(cmpgnLength)):
                for m in range(cmpgnLength[k]):
                    if(m > hgh):
                        hgh = m
            bookingsInCampaigns = [[0 for x in range(hgh+1)] for y in range(w)] 
            #print w, hgh
            totalPlays = 0
            totalUnits = 0
            #inserting total plays according to the bookings in to  campaigns
            for k in range(len(cmpgnLength)):
                #print 'k:',k
                for m in range(cmpgnLength[k]):
                    #print 'm:',m
                    #bookingsInCampaigns[k][m] = mylist[k][m].reference_master_pack.num_plays
                    bookingsInCampaigns[k][m] = mylist[k][m].num_plays
                    totalPlays += bookingsInCampaigns[k][m]
                    totalUnits += bookingsInCampaigns[k][m]*mylist[k][m].units_per_play
                    #totalUnits += bookingsInCampaigns[k][m]*mylist[k][m].reference_master_pack.units_per_play
            #print bookingsInCampaigns
            #print 'totalPlays available:',totalPlays
            #print 'totalUnits available for play:', totalUnits
            units_asked_tobook = totalUnits
            k = 0
            m = 0
            playCount = 0
            print 'Total remaining plays at campaigns:', bookingsInCampaigns
            while k < len(cmpgnLength) and m <= hgh  and playCount < totalPlays:
                if(bookingsInCampaigns[k][m] <= 0):
                    flag = True
                    for h in range(hgh):
                        if bookingsInCampaigns[k][h] > 0 and flag == True:
                            flag = False
                            time_tillbooked = create_booked_slot(date, mylist[k][h], time_tillbooked)
                            playCount += 1
                            bookingsInCampaigns[k][h] -= 1 
                            print 'Booked from campaign:',k+1 ,'B:',h+1 ,bookingsInCampaigns
                    k = k + 1
                    if(k > len(cmpgnLength)-1):
                        k = 0
                        if m + 1 <= hgh :
                            m = m + 1
                        else:
                            m = 0
                    continue      
                if(bookingsInCampaigns[k][m] > 0):
                    #print bookingsInCampaigns[k][m]
                    time_tillbooked = create_booked_slot(date, mylist[k][m], time_tillbooked)
                    playCount += 1
                    bookingsInCampaigns[k][m] -= 1 
                    print 'Booked from campaign:',k+1,'B:',m+1,bookingsInCampaigns
                    k = k + 1
                    if(k > len(cmpgnLength)-1):
                        k = 0
                        if m + 1 <= hgh :
                            m = m + 1
                        else:
                            m = 0
            ValidateAlgorithm(units_asked_tobook, cmpgnLength, mylist)
                                    
                
    
                            
              
                
                
                
           




            
            
                
                
#allocation_algorithm(datetime.now().date())
#allocation_algorithm(datetime.now().date()+timedelta(days=-8))               
                    
                     
            
            
        
    