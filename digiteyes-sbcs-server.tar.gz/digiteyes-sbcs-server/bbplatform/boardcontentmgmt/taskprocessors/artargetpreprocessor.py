'''
Created on 04-Jul-2017

@author: saba
'''
from PIL import Image
import sys
import os

FILE_SIZE_MAX_MB = 2.0
def pixel_size_40_inch():
    tv_horizontal_size_inch = 34.8
    tv_horizontal_size_mm = tv_horizontal_size_inch * 25.4
    full_hd_horizontal_res = 1920
    pixel_size = tv_horizontal_size_mm / full_hd_horizontal_res
    return pixel_size

def pixel_size_20_inch():
    tv_horizontal_size_inch = 17.4
    tv_horizontal_size_mm = tv_horizontal_size_inch * 25.4
    full_hd_horizontal_res = 1920
    pixel_size = tv_horizontal_size_mm / full_hd_horizontal_res
    return pixel_size

def max_width_20_inch():
    tv_horizontal_size_inch = 17.4
    display_size = tv_horizontal_size_inch - 1.0
    return display_size * 25.4

def max_width_40_inch():
    tv_horizontal_size_inch = 34.8
    display_size = tv_horizontal_size_inch - 1.2
    return display_size * 25.4

#################################################################################
# Calculates the image width based on image size and pixel size
#################################################################################      
def calculate_width(imageFile, tv_size):
    im = Image.open(imageFile)
    pixel_size = pixel_size_20_inch()
    if tv_size == 40:
        pixel_size = pixel_size_40_inch()
    image_size_pixels = im.size
    image_width = image_size_pixels[0] * pixel_size
    return image_width

def get_image_size(imageFile):
    im = Image.open(imageFile)
    return im.size

#################################################################################
# Returns the File Size
#################################################################################
def calculate_file_size(imageFile):
    bytes = os.path.getsize(imageFile)
    mb_size = bytes / (1024.0 * 1024.0)
    return mb_size
#################################################################################
# Ceils the image width to what is displayable.
#################################################################################
def ceil_image_width(calc_width, tv_size):
    max_width = max_width_20_inch()
    if tv_size == 40:
        max_width = max_width_40_inch()
    if calc_width > max_width:
        return max_width / 1000.0 # Conversion to Meters
    return calc_width / 1000.0 # conversion to Meters
#################################################################################
# Scales the image if the size exceeds Max Size
#################################################################################
def scale_image_if_it_exceeds_limit(imageFile,orig=True):
    img_size = calculate_file_size(imageFile)
    if img_size > FILE_SIZE_MAX_MB:
        percent_more = (img_size / FILE_SIZE_MAX_MB) -1.0
	if percent_more > 0.5 :
		percent_more = 0.5
        image = Image.open(imageFile)
        img_size = image.size
	print str(img_size)
        aspect_ratio = img_size[0] / (1.0 * img_size[1])
        new_height = (1.0 -percent_more) * img_size[1]
        new_width = aspect_ratio * new_height
	print new_height, new_width
        scaled_image = image.resize((int(new_width),int(new_height)),Image.ANTIALIAS)
        file_name=os.path.basename(imageFile)
        filename_without_extn=file_name.split('.')[0]
        folder=os.path.dirname(imageFile)
        scaled_img_name = filename_without_extn+"_scaled"+str(int(new_width))+"x"+str(int(new_height))+".jpg"
        file_with_folder = os.path.join(folder,scaled_img_name)
        scaled_image.save(file_with_folder)
        if not orig:
            os.remove(imageFile)
        return scale_image_if_it_exceeds_limit(file_with_folder,False)
    else :
        return imageFile
        

if __name__ == '__main__':
    scaled_file = scale_image_if_it_exceeds_limit(sys.argv[1])
    print scaled_file
    image_width = ceil_image_width(calculate_width(scaled_file,20),20)
    print str(image_width) +"mm"
    
