'''
Created on 13-Jun-2017

@author: saba
'''

from boardcontentmgmt.utilities.freeslotutilities import get_screens_for_tags
from treebeard.mp_tree import MP_Node
from boardcontentmgmt.models import BidsForPlay, BookedAdPack, BookingState
from datetime import date
from datetime import datetime
#################################################################################
# Finds all the channel the given show spot belongs to.
#################################################################################
def find_channels_for_showspot(show_spot_attributes):
    channels = []
    for attribute in show_spot_attributes:
        channels.append(attribute)
        parents = attribute.get_ancestors()
        if len(parents) > 0:
            parent_channels = find_channels_for_showspot(parents)
            channels = channels + parent_channels
    return channels
#################################################################################
# Returns the bids for the given channel, for today and given day part
#################################################################################
def get_bids_for_channel(day_part,channel):
    today = date.today()
    bids = BidsForPlay.objects.filter(campaign__planned_dates__date=
        today,channel__key=channel.key)
    flattened_bids = []
    #print len(bids)
    for bid in bids:
        print bid.key
        fbid = {}
        fbid['campaign']=bid.campaign
        fbid['key']=bid.key
        fbid['bid_time']=bid.bid_time
        todays_bid = bid.day_part_bids.filter(date=today,dayPart__name=day_part.name)
	if len(todays_bid) > 0:
        	fbid['bid']=todays_bid[0]
        	flattened_bids.append(fbid)
    return flattened_bids
#################################################################################
# Returns a sorted bid based on price.
#################################################################################
def get_sorted_bids_by_price(bids):
    sorted_bids = sorted(sorted(bids, key=lambda k: k['bid_time']),
        key=lambda k: k['bid'].bid_amount_per_play/k['bid'].units,reverse=True)
    return sorted_bids 
#################################################################################
# Allocate for the given bid the number of slots
#################################################################################
def allocate_slot_for_bid(board,bid,dayPart,number_of_slots):
    # In case any previous allocation done for the same date, day part, remove them.
    bid_for_play = BidsForPlay.objects.filter(key=bid['key'])[0]
    already_booked_packs = bid_for_play.booked_adpacks.filter(date_booked_for=date.today(),
        day_part_booked_for=dayPart)
    if len(already_booked_packs) > 0:
        print unicode(already_booked_packs)
        for pack in already_booked_packs:
            pack.delete()
        already_booked_packs.delete()
        bid_for_play.save()
    # Create a Booked ad pack for the bid
    bap = BookedAdPack()
    bap.booked_screen = board
    bap.date_booked_for = date.today()
    success = BookingState.objects.filter(name = 'SUCCESS')[0]
    bap.booking_state = success 
    bap.when_booked = datetime.now()
    bap.num_plays = number_of_slots / bid['bid'].units
    bap.units_per_play = bid['bid'].units
    bap.day_part_booked_for = dayPart
    bap.price = bid['bid'].bid_amount_per_play * bap.num_plays
    bap.account = bid['campaign'].account
    bap.unit_size = 30
    bap.booking_type = "Bid"
    bap.play_list = bid['campaign'].play_list
    bap.applied_to = bid['campaign']
    bap.save()
    # Now add the booked adpack to Bid
    bid_for_play = BidsForPlay.objects.filter(key=bid['key'])[0]
    bid_for_play.booked_adpacks.add(bap)
    bid_for_play.save()

def print_all_bids(bids):
    for bid in bids:
        #print unicode(bid['campaign'].__dict__)
        print str(bid['bid_time'])+" "+unicode(bid['bid'].__dict__)
#################################################################################
# Book ad packs for Bids
#################################################################################
def book_adpacks_for_bids(board,day_part,slots_available):
    show_spot = board.show_spot
    channels = find_channels_for_showspot(show_spot.attached_attribute_tag.all())
    print unicode(channels)
    all_bids = []
    for channel in channels:
        bids = get_bids_for_channel(day_part, channel)
        all_bids = all_bids + bids
    #print_all_bids(all_bids)
    sorted_bids = get_sorted_bids_by_price(all_bids)
    print_all_bids(sorted_bids)
    for bid in sorted_bids:
        if slots_available == 0:
            print slots_available
            return 0
        required_slots = bid['bid'].plays * bid['bid'].units 
        if required_slots <=slots_available:
            allocate_slot_for_bid(board,bid,day_part, required_slots)
            slots_available = slots_available - required_slots
        else:
            allocate_slot_for_bid(board,bid,day_part, slots_available)
            slots_available = 0
    print slots_available
    return slots_available    
