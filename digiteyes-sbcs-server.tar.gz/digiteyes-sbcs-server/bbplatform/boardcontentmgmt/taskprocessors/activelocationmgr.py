from boardcontentmgmt.models import ActiveConsumerLocation,\
    ConsumerCuratedPlaylists, DynamicSchedule, Account, Board
from boardcontentmgmt.models import ShowSpotAsset
from boardcontentmgmt.models import ConsumerContentTargets

import logging
import datetime
logger = logging.getLogger(__name__)
#################################################################################
# Creates a dynamic schedule for the user
#################################################################################
def create_dynamic_schedule(consumer,show_spot):
    consumer_playlists = ConsumerCuratedPlaylists.objects.filter(
        consumer_account__key = consumer)
    if consumer_playlists and len(consumer_playlists) > 0:
        schedule = DynamicSchedule()
        schedule.consumer_account = Account.objects.get(key=consumer)
        schedule.play_list = consumer_playlists[0].play_list
        schedule.valid = True
        schedule.created_time = datetime.datetime.now()
        schedule.invalidated_time = datetime.datetime.now()
        boards = Board.objects.filter(show_spot__key = show_spot.key)
        if boards and len(boards)>0 :
            schedule.board = boards[0] 
        schedule.save()
#################################################################################
# Invalidates dynamic schedules for the user
#################################################################################
def invalidate_dynamic_schedule(consumer,show_spot):
    boards = Board.objects.filter(show_spot__key = show_spot.key)
    logger.debug("Invalidate Dynamic Schedule : "+show_spot.name)
    if boards and len(boards)>0 :
        logger.debug("Board :"+str(boards[0].key))
        logger.debug("Consumer :"+str(consumer))
        schedules = DynamicSchedule.objects.filter(board__key = boards[0].key,
            consumer_account__key=consumer,valid = True)
        logger.debug("Schedules :" +str(len(schedules)))
        for schedule in schedules:
            logger.debug("Invalidate Dynamic Schedule : "+str(schedule.key))
            schedule.valid = False
            schedule.invalidated_time = datetime.datetime.now()
            schedule.save() 
##################################################################################
#   ACTIVE LOCATION MANAGER
#   Managers Consumers active locations with respect to show spots
##################################################################################
#################################################################################
# Handles User exit events from a show spot.
# If the user had an active entry against the show spot, it is marked as False
#################################################################################
def handle_exit(user_event,show_spot):
    logger.debug("Handle Exit : "+show_spot.name)
    active_items = ActiveConsumerLocation.objects.filter(event_location__key = 
        show_spot.key,consumer_account__key = user_event.consumer_account.key,
        is_active = True)
    if active_items and len(active_items) > 0 :
        for item in active_items:
            logger.debug("Active Entry"+ str(item.entry_time_stamp))
            item.is_active = False
            item.exit_time_stamp = user_event.event_time_stamp
            item.save()
    invalidate_dynamic_schedule(user_event.consumer_account.key, show_spot)
#################################################################################
# Handles User entry events for a show spot.
# If the user had any active entry against any show spot, it is marked as False
# and a new active entry against the given show spot is created.
#################################################################################            
def handle_entry(user_event,show_spot):
    logger.debug("Handle Entry : "+show_spot.name)
    active_items = ActiveConsumerLocation.objects.filter(consumer_account__key = 
        user_event.consumer_account.key,is_active = True)
    if active_items and len(active_items) > 0 :
        for item in active_items:
            item.is_active = False
            item.exit_time_stamp = user_event.event_time_stamp
            item.save()
    consumer_entry = ActiveConsumerLocation()
    consumer_entry.event_location = show_spot
    consumer_entry.consumer_account = user_event.consumer_account
    consumer_entry.entry_time_stamp = user_event.event_time_stamp
    consumer_entry.is_active = True
    consumer_entry.save()
    create_dynamic_schedule(user_event.consumer_account.key, show_spot)
#################################################################################
# Router to Entry / Exit handlers
#################################################################################
def process_user_event(user_event):
    beacons = [user_event.event_location]
    show_spot = ShowSpotAsset.objects.filter(attached_beacons__in=beacons)
    if show_spot is not None and len(show_spot)>0:
        if user_event.event_type == 'EXIT' :
            handle_exit(user_event,show_spot[0])
        else :
            handle_entry(user_event,show_spot[0])
#################################################################################
# Creates Consumer Content Targets for Play history.
# Works based on active consumers for the given show spot.
#################################################################################
def create_consumer_targets_for_play_history(play_history):
    board = play_history.board
    show_spot = board.show_spot
    logger.debug("create_consumer_targets_for_play_history") 
    active_consumers = ActiveConsumerLocation.objects.filter(event_location__key = 
        show_spot.key,is_active = True)
    if active_consumers:
	logger.debug("Create_consumer_targets_for_play_history = active consumers :"+str(len(active_consumers)))
    for consumer in active_consumers:
        if consumer.entry_time_stamp <= play_history.content_from_time and consumer.entry_time_stamp <= play_history.content_to_time :
            consumer_target = ConsumerContentTargets()
            consumer_target.show_spot_location_lat = show_spot.spot_location_lat
            consumer_target.show_spot_location_long = show_spot.spot_location_long
            consumer_target.show_spot_location_key = show_spot.key
            consumer_target.show_spot_beacon_touched = show_spot.attached_beacons.all()[0].mac_address
            consumer_target.show_spot_location_image_url = show_spot.spot_location_image_url
            consumer_target.content_target = play_history.content_played.content_target
            consumer_target.time = play_history.content_to_time
            consumer_target.campaign = play_history.campaign.key
            consumer_target.content = play_history.content_played
            consumer_target.account = consumer.consumer_account
            consumer_target.save()
