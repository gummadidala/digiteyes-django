'''
Created on 17-Feb-2017

@author: saba
'''
from __future__ import absolute_import, division
from boardcontentmgmt.taskprocessors.campaignreportgenerator import generate_play_report,generate_preplay_report
from boardcontentmgmt.taskprocessors.campaignreportgenerator import generate_invoice
from boardcontentmgmt.taskprocessors.playreport import find_campaign_stats,find_campaign_stats_for_day
from boardcontentmgmt.models import Advertiser, AdvtCampaign,BookingState, MyOrder
from boardcontentmgmt.models import BookedAdPack, BookedDayPack, DayPart
from boardcontentmgmt.utilities.wifireachutility import generate_wifi_reach_report
from datetime import date, timedelta
from django.db.models import Sum
import logging
logger = logging.getLogger("boardcontentmgmt.tasks")

def fill_campaign_details(campaign,report_data):
    camp_data = {}
    summary_data={}
    camp_data['name']=campaign.name
    camp_data['booked_date']=campaign.created_date.strftime("%d-%m-%Y %I:%M:%S %p")
    camp_data['total_days']=campaign.planned_dates.all().count()
    planned_days="";
    completed_days=""
    completed_count=0
    inplan_days=""
    inplan_count=0
    today=date.today()
    for day in campaign.planned_dates.all():
        if planned_days == "" :
            planned_days=day.date.strftime("%d-%m-%Y")
        else :
            planned_days=planned_days+","+day.date.strftime("%d-%m-%Y")
        if today > day.date:
            if completed_days == "":
                completed_days = day.date.strftime("%d-%m-%Y")
            else:
                completed_days=completed_days+","+day.date.strftime("%d-%m-%Y")
            completed_count=completed_count+1
        else:
            if inplan_days == "":
                inplan_days=day.date.strftime("%d-%m-%Y")
            else:
                inplan_days=inplan_days+","+day.date.strftime("%d-%m-%Y")
            inplan_count=inplan_count+1
        
    camp_data['planned_dates']=planned_days
    camp_data['completed_days']=completed_count
    camp_data['inplan_days']=inplan_count
    if completed_count == 0:
        completed_days='None'
    if inplan_count == 0:
        inplan_days='None'
    camp_data['completed_dates']=completed_days
    camp_data['inplan_dates']=inplan_days
    channel_str=""
    for channel in campaign.screen_selection_tags.all():
        if channel_str == "":
            channel_str=channel.name
        else:
            channel_str=channel_str+","+channel.name
    summary_data['completed_days']=completed_count
    camp_data['channel']=channel_str
    camp_data['num_screens']=campaign.total_screens_selected
    summary_data['screens']=completed_count
    #summary_data['completed_days']=completed_count
    report_data['campaign_data']=camp_data
    report_data['summary_data']=summary_data

def fill_summary_play(campaign,report_data):
    campaign_stats = find_campaign_stats(campaign)
    report_data['summary_data']=campaign_stats['summary_data']
    report_data['days_data']=campaign_stats['days_data']
    
def fill_account_details(campaign,report_data):
    firm_data={}
    firm_data['account_name']=campaign.account.account_name
    advertiser = Advertiser.objects.filter(account=campaign.account)
    if len(advertiser) > 0:
        firm_data['firm_name']=advertiser[0].firm_name
        firm_data['address']=advertiser[0].address
        if advertiser[0].city is not None: 
            firm_data['address']=firm_data['address']+'\n'+advertiser[0].city.city_name
        report_data['firm_data']=firm_data
    else :
        # May be association / system campaign
        firm_data['firm_name']="N/A"
        report_data['firm_data']=firm_data
        

def fill_order_details(campaign,report_data):
    order={}
    success=BookingState.objects.filter(name='SUCCESS')[0]
    orders = MyOrder.objects.filter(campaign=campaign,status=success)
    if len(orders) > 0:
        oder = orders[0]
        order['number']=oder.txnid
        order['quoted_amount']="{:.2f}".format(oder.actual_amount)
        order['coupon_applied']="N/A"
        if oder.applied_coupon is not None:
            order['coupon_applied']=oder.applied_coupon.coupon_code
        order['discounted_amount']="{:.2f}".format(oder.discounted_amount)
        order['credited_amount']="{:.2f}".format(oder.credit_amount)
        order['paid_amount']="{:.2f}".format(oder.paid_amount)
        report_data['order_data'] = order
    else :
        order['number']="N/A"
        order['quoted_amount']="N/A"
        order['coupon_applied']="N/A"
        order['discounted_amount']="N/A"
        order['credited_amount']="N/A"
        order['paid_amount']="N/A"
        report_data['order_data'] = order
def fill_pack_details(campaign,report_data):
    success=BookingState.objects.filter(name='SUCCESS')[0]
    pack_data={}
    bdps = BookedDayPack.objects.filter(applied_to__key=campaign.key,booking_state=success)
    pack_data['units']="N/A"
    pack_data['num_applied']="N/A"
    pack_data['name']="N/A"
    if len(bdps) > 0:
        day_pack=bdps[0].day_pack
        
        pack_data['units']=day_pack.units_per_play
        pack_data['price']="{:.2f}".format(day_pack.price)
        pack_data['num_applied']=len(bdps)/report_data['campaign_data']['total_days']
        bp_str=" ("
        name_str=""
        for bp in day_pack.base_pack.all():
            if name_str == "":
                name_str=str(bp.count)+"x"+bp.pack.name+"-"+str(bp.pack.num_plays)+" plays "
            else:
                name_str=name_str+", "+str(bp.count)+"x"+bp.pack.name+"-"+str(bp.pack.num_plays)+" plays "
        bp_str=bp_str+name_str+")"
        pack_data['name']=day_pack.name+bp_str
    report_data['pack_data']=pack_data

def fill_credit_details(campaign,report_data):
    credit_data={}
    missed_time=report_data['summary_data']['missed_time']
    td = timedelta(seconds=missed_time) 
    credit_data['missed_time']=str(td)
    slots=missed_time/30
    credit_data['slots']="{:.2f}".format(slots)
    odrs = MyOrder.objects.filter(campaign__key = campaign.key)
    if len(odrs) == 0:
        credit_data['effective_price']='NA'
        credit_data['credited_amout']='NA'
        credit_data['transactions']=[]
        report_data['credit_data']=credit_data
        return
    odr=odrs[0]
    total_amount_paid = odr.paid_amount + odr.credit_amount
    success=BookingState.objects.filter(name='SUCCESS')[0]
    bps = BookedAdPack.objects.filter(applied_to__key = campaign.key, booking_state=success)
    total_units=0
    for bp in bps:    
        total_units = total_units+bp.num_plays*bp.units_per_play*bp.unit_size/30
    price_per_unit=0
    logger.info(" Total Units "+unicode(total_units))
    logger.info(" Total amount paid "+unicode(total_amount_paid))
    if total_units != 0:
        price_per_unit = total_amount_paid/total_units
    credit_data['effective_price']="{:.2f}".format(price_per_unit)
    credit_data['transactions']=[]
    credits=odr.applied_credit_trasaction.filter(is_credit=True)
    sum=0;
    for record in credits:
        credit_data['transactions'].append({'number':'','transaction_date':record.transaction_date,
            'amount':record.amount,'transaction_date':record.amount,
            'transaction_description':record.transaction_description})
        sum=sum+record.amount
    credit_data['credited_amount']=str(sum)
    report_data['credit_data']=credit_data
def fill_reach_details(campaign,report_data):
    data=generate_wifi_reach_report(campaign.key)
    if data is not None:
        report_data['reach_data']=data

def generate_campaign_invoice(campaign,path):
    report_data={}
    fill_account_details(campaign, report_data)
    fill_campaign_details(campaign, report_data)
    fill_order_details(campaign, report_data)
    fill_pack_details(campaign, report_data)
    print unicode(report_data)
    generate_invoice(report_data,path)
    
def generate_campaign_preplay_report(campaign,report_path,dayPart_key):
    report_data={}
    fill_account_details(campaign, report_data)
    fill_campaign_details(campaign, report_data)
    dps = DayPart.objects.filter(key=dayPart_key)
    if len(dps) > 0:
        stats=find_campaign_stats_for_day(date.today(),campaign,dps[0],True)
        report_data['preplay_data']={'date':date.today().strftime("%d-%m-%Y"),
            'daypart_name':dps[0].name,'daypart_from_time':dps[0].from_time.strftime("%I:%M %p"),
            'daypart_to_time':dps[0].to_time.strftime("%I:%M %p"),}
        report_data['days_data']=[stats]
    generate_preplay_report(report_data,report_path)
def generate_campaign_play_report(campaign,report_path,pre_play=False,dayPart_key=None):
    if pre_play:
        generate_campaign_preplay_report(campaign,report_path,dayPart_key)
        return
    report_data={}
    fill_account_details(campaign, report_data)
    fill_campaign_details(campaign, report_data)
    fill_order_details(campaign, report_data)
    fill_summary_play(campaign, report_data)
    fill_pack_details(campaign,report_data)
    fill_credit_details(campaign,report_data)
    fill_reach_details(campaign, report_data)
    print unicode(report_data) 
    generate_play_report(report_data,report_path)

if __name__ == '__main__':
    campaign = AdvtCampaign.objects.get(pk=109)
    generate_campaign_play_report(campaign)