from datetime import datetime,date,time,timedelta
from boardcontentmgmt.models import BookedAdPack,BookedSlot,DayPart,BookingState,Board


def allocation_algorithm(date):
    day_part=DayPart.objects.all()
    state = BookingState.objects.filter(name="SUCCESS")
    board = Board.objects.all()
    
    for brd in board:
        for  i in day_part:
            time_tillbooked =i.from_time
            print brd.key
            print i.name
            bookedadpack=BookedAdPack.objects.all().filter(date_booked_for=date,day_part_booked_for=i,booked_screen__key=brd.key)
            myodds = list(bookedadpack)[1::2]
            myevens = list(bookedadpack)[0::2]
            
            for j,k in zip(myevens,myodds):
                evenplays=j.reference_master_pack.num_plays
                oddplays=k.reference_master_pack.num_plays
                print evenplays+oddplays
                while evenplays != 0 or oddplays != 0:
                    if evenplays is not 0 :
                        needed_time=j.reference_master_pack.units_per_play*30 #needed_time in sec
                        listr=[]
                        bt = BookedSlot()
                        bt.start_time = time_tillbooked
                        bt.num_units = j.reference_master_pack.units_per_play
                        bt.unit_size = 30
                        bt.booking_state = state[0]
                        bt.save()
                        listr.append(bt)
                        j.slots_booked = listr
                        j.save()
                        dt= datetime.combine(date,time_tillbooked)
                        dt = dt  + timedelta(seconds=needed_time)
                        time_tillbooked = dt.time()
                        evenplays = evenplays - 1
                        
                             
                    if oddplays is not 0 :
                        needed_time=k.reference_master_pack.units_per_play*30 #needed_time in sec
                        listr=[]
                        bt = BookedSlot()
                        bt.start_time = time_tillbooked
                        bt.num_units = k.reference_master_pack.units_per_play
                        bt.unit_size = 30
                        bt.booking_state = state[0]
                        bt.save()
                        listr.append(bt)
                        k.slots_booked = listr
                        k.save()
                        dt= datetime.combine(date,time_tillbooked)
                        dt = dt  + timedelta(seconds=needed_time)
                        time_tillbooked = dt.time()
                        oddplays = oddplays - 1     
                        
                        
                
                
         
         
    
    

 











allocation_algorithm (datetime.now().date())
#allocation_algorithm(datetime.now().date()+timedelta(days=2))

