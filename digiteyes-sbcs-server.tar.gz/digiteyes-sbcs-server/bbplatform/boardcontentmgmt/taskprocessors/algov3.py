from datetime import datetime,date,time,timedelta
from boardcontentmgmt.models import BookedAdPack,BookedSlot,DayPart,BookingState,Board,AdvtCampaign
def get_next_free(statuslist,index):
    for x in range(index,len(statuslist)):
        if statuslist[x] ==  'Not Started':
            return x
        
    return len(statuslist)
    


        
def allocate_remaining(date,packlist,currentpack,time_tillbooked):
    for x in range(currentpack,len(packlist)):
        pack = packlist[x]
        time_tillbooked=create_booked_slot(date,pack, time_tillbooked, pack.reference_master_pack.num_plays)
    
    


               
def create_booked_slot(date,pack,time_tillbooked,numplays=1):
    state = BookingState.objects.filter(name="SUCCESS")
    slots_booked=pack.slots_booked
    needed_time=pack.reference_master_pack.units_per_play*30*numplays
    bt = BookedSlot()
    bt.start_time = time_tillbooked
    bt.num_units = pack.reference_master_pack.units_per_play*numplays
    bt.unit_size = 30
    bt.booking_state = state[0]
    bt.save()
    slots_booked.add(bt)
    pack.save()
    dt= datetime.combine(date,time_tillbooked)
    dt = dt  + timedelta(seconds=needed_time)
    time_tillbooked = dt.time()
    print pack.applied_to.name ,": ",bt.start_time," - ",bt.num_units,pack.booked_screen.board_name
    return time_tillbooked

def allocation_algorithm(date):
    day_part=DayPart.objects.all()
    state = BookingState.objects.filter(name="SUCCESS")
    board = Board.objects.all()
    
    for brd in board:
        for  i in day_part:
            time_tillbooked =i.from_time
            mymap = {}
            mylist= []
            bookedadpack=BookedAdPack.objects.all().filter(date_booked_for=date,day_part_booked_for=i,booked_screen__key=brd.key)
            if not bookedadpack:
                continue
            print i.name
            print len(bookedadpack)
            for k in bookedadpack:
                if  k.applied_to.key in mymap.keys():
                    mymap[k.applied_to.key].append(k)
                else:
                    mymap[k.applied_to.key]=[k]
            for key in mymap.keys():
                value = mymap[key]
                mylist.append(value)
            first = 0
            second = 1
            currentfirst =0
            currentsecond = 0
            firstremaining = 0
            secondremaining = 0
            l = len(mylist)
            statuslist=[]
            for x in range(len(mylist)):
                statuslist.append("Not Started")
            statuslist[first]='Started'
            if l > 1 :
                statuslist[second]='Started'    
            firstpack = mylist[first][currentfirst]
            firstremaining = firstpack.reference_master_pack.num_plays  
            secondpack = mylist[second][currentsecond]  
            secondremaining = secondpack.reference_master_pack.num_plays  
            while first< l and second < l:
                print firstremaining
                print secondremaining
                while currentfirst < len(mylist[first]) and currentsecond < len(mylist[second]):
                    flag= False
                    if firstremaining == 0 : 
                        currentfirst += 1
                        if currentfirst < len(mylist[first]):
                            firstpack = mylist[first][currentfirst] 
                            firstremaining = firstpack.reference_master_pack.num_plays
                        flag = True         
                    if secondremaining == 0 :
                        currentsecond += 1
                        if currentsecond < len(mylist[second]):
                            secondpack = mylist[second][currentsecond] 
                            secondremaining = secondpack.reference_master_pack.num_plays    
                        flag = True
                    
                    if flag:
                        continue   
                    time_tillbooked = create_booked_slot(date,firstpack,time_tillbooked)
                    time_tillbooked = create_booked_slot(date,secondpack,time_tillbooked)
                    firstremaining -= 1
                    secondremaining -= 1   
                    print 'after decrementing'
                    print firstremaining
                    print secondremaining        
                if currentfirst >= len(mylist[first]):
                    statuslist[first]='Completed'
                    print 'FIRST COMPLETED :D',firstpack.applied_to.name
                    first = get_next_free(statuslist, first)
                    if first < l:
                        statuslist[first]='Started'
                        currentfirst = 0
                        firstpack = mylist[first][currentfirst]
                        firstremaining = firstpack.reference_master_pack.num_plays
                        
                if currentsecond >= len(mylist[second]):
                    statuslist[second]='Completed'
                    print 'SECOND COMPLETED :D',secondpack.applied_to.name
                    second =get_next_free(statuslist, second)
                    if second < l :
                        statuslist[second]='Started'
                        currentsecond = 0
                        secondpack = mylist[second][currentsecond]  
                        secondremaining = secondpack.reference_master_pack.num_plays
                        
            if first < l:
                allocate_remaining(date,mylist[first], currentfirst, time_tillbooked)
            if second < l:
                allocate_remaining(date,mylist[second], currentsecond, time_tillbooked)
                       

                

    
    
                







            
            
                
                
allocation_algorithm(datetime.now().date()+timedelta(days=-1))                
                    
                     
            
            
            
    