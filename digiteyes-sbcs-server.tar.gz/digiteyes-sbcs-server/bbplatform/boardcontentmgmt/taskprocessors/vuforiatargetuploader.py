'''
Created on 03-Jul-2017

@author: saba
'''

import requests
import sys
from time import strftime
server_access_key="abd7b7c96a0a88d23d9007edce2f83739e0dfff2"
server_secret_key="50e829931de6e12f5ec3918347926e818d2f12a7"
import datetime
import base64
import md5
import hmac, hashlib
import pytz
from email.utils import formatdate
import httplib
import mimetypes
import json
import artargetpreprocessor
#from .artargetpreprocessor import scale_image_if_it_exceeds_limit, ceil_image_width, calculate_width


CLOUD_RECO_API_ENDPOINT = 'vws.vuforia.com'



def compute_md5_hex(data):
    """Return the hex MD5 of the data"""
    h = hashlib.md5()
    h.update(data)
    return h.hexdigest()

def compute_hmac_base64(key, data):
    """Return the Base64 encoded HMAC-SHA1 using the provide key"""
    h = hmac.new(key, None, hashlib.sha1)
    h.update(data)
    return base64.b64encode(h.digest())

def read_contents_as_base_64(fileName):
    with open(fileName, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read())
        return encoded_string
def encode_metadata(metadata):
    return base64.b64encode(metadata)
##################################################################################
# Forms the signed auth header
##################################################################################
def authorization_header_for_request(access_key, secret_key, method, content, 
        content_type, date, request_path):
    """Return the value of the Authorization header for the request parameters"""
    components_to_sign = list()
    components_to_sign.append(method)
    components_to_sign.append(str(compute_md5_hex(content)))
    components_to_sign.append(str(content_type))
    components_to_sign.append(str(date))
    components_to_sign.append(str(request_path))
    string_to_sign = "\n".join(components_to_sign)
    signature = compute_hmac_base64(secret_key, string_to_sign)
    auth_header = "VWS %s:%s" % (access_key, signature)
    return auth_header
#################################################################################
# Uploads the given file to vuforia cloud, with the given meta data.
#################################################################################
def upload_cloud_target_from_file(fileName,name,meta_data_obj,for_tv_size):
    scaled_file = artargetpreprocessor.scale_image_if_it_exceeds_limit(fileName)
    loaded_binary=read_contents_as_base_64(scaled_file)
    
    data = {}
    data['name']=name
    data['width']=artargetpreprocessor.ceil_image_width(
        artargetpreprocessor.calculate_width(scaled_file,for_tv_size),for_tv_size)
    data['image']=loaded_binary
    data['application_metadata']=encode_metadata(json.dumps(meta_data_obj))
    http_method = 'POST'
    date = formatdate(None, localtime=False, usegmt=True)
    path = "/targets"
    request_body = json.dumps(data)
    
    content_type_bare='application/json'
    auth_header = authorization_header_for_request(server_access_key, server_secret_key, 
        http_method,request_body, content_type_bare, date, path)
    
    request_headers = {
        'Accept': 'application/json',
        'Authorization': auth_header,
        'Content-Type': content_type_bare,
        'Date': date
    }
    # Make the request over HTTPS on port 443
    http = httplib.HTTPSConnection(CLOUD_RECO_API_ENDPOINT, 443)
    http.request(http_method, path, request_body, request_headers)

    response = http.getresponse()
    response_body = response.read()
    return response.status, response_body
            
    
if __name__ == '__main__':
    fileName=sys.argv[1]
    name=sys.argv[2]
    metadata = {}
    metadata['title']='Amazon'
    metadata['desc']='Worlds Leading e-commerce Portal'
    status, response = upload_cloud_target_from_file(fileName, name,metadata),20
    print status
    print response