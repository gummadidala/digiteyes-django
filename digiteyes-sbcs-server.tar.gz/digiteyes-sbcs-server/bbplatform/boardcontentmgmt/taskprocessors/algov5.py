from datetime import datetime,timedelta
import time
from boardcontentmgmt.models import BookedAdPack,BookedSlot,DayPart,CampaignState,ContentQueue,BookingState,Board,Account, AccountUser,AdvtCampaign

import logging
logger = logging.getLogger("boardcontentmgmt.tasks")

def create_booked_slot(date,pack,time_tillbooked,numplays=1):
    state = BookingState.objects.filter(name="SUCCESS")
    slots_booked=pack.slots_booked
    needed_time=pack.units_per_play*pack.unit_size*numplays
    bt = BookedSlot()
    bt.start_time = time_tillbooked
    bt.num_units = pack.units_per_play*numplays
    bt.unit_size = pack.unit_size
    bt.booking_state = state[0]
    bt.save()
    slots_booked.add(bt)
    pack.save()
    dt= datetime.combine(date,time_tillbooked)
    dt = dt  + timedelta(seconds=needed_time)
    time_tillbooked = dt.time()
    logger.info( 'Booked slot for:'+pack.applied_to.name +" time:"+bt.start_time.isoformat()+" units booked:"+str(bt.num_units)+
        ' Board:'+pack.booked_screen.board_name)
    return time_tillbooked

def ValidateAlgorithm(units_asked_tobook,cmpgnLength,mylist):
    units_booked =0
    for k in range(len(cmpgnLength)):
        for m in range(cmpgnLength[k]):
            slotsbooked = mylist[k][m].slots_booked.all()
            for s in slotsbooked:
                units_booked += s.num_units
    if(units_booked == units_asked_tobook):
        logger.info( 'Booking done successfully! :)')
    else:
        logger.info('Booking unsuccessfull :(')

def GetNumOfUnits_DayPart(day_part):
    st = datetime.now()
    st1 = st.replace(hour=day_part.from_time.hour,minute=day_part.from_time.minute,second=day_part.from_time.second)
    et1 = st.replace(hour=day_part.to_time.hour,minute=day_part.to_time.minute,second=day_part.to_time.second)
    td = et1 - st1
    td_seconds = td.total_seconds()
    total_slots = int(td_seconds / 30)
    return total_slots

def auto_booking(slotsRemaining,date,brd,day_part):
    logger.info('Inside auto_booking')
    existing = False
    existing_bookings = BookedAdPack.objects.filter(date_booked_for=date,
        day_part_booked_for__name=day_part,booked_screen__key=brd.key)
    if existing_bookings is not None and len(existing_bookings) > 0:
        existing = True
        bap = existing_bookings[0]
    else :
        bap = BookedAdPack()
    bap.booked_screen = Board.objects.all().filter(key = brd.key)[0]
    bap.date_booked_for = date
    success = BookingState.objects.all().filter(name = 'SUCCESS')[0]
    bap.booking_state = success 
    bap.when_booked = datetime.now().date()
    bap.num_plays = slotsRemaining
    bap.units_per_play = 1
    bap.day_part_booked_for = DayPart.objects.all().filter(name = day_part.name)[0]
    bap.price = 0
    acct = Account.objects.filter(account_name='DE Production')
    bap.account = acct[0]
    bap.unit_size = 10
    bap.booking_type = 'auto_booking'
    
    if not existing:
        campaign = AdvtCampaign()
    else :
        campaign = bap.applied_to
    campaign.name = 'auto_booking'
    usr = AccountUser.objects.all().filter(account = acct[0])
    campaign.owner = usr[0]
    campaign.created_date = datetime.now().date()
    campaign.planned_start_date = datetime.now().date()
    campaign.planned_end_date = datetime.now().date()
    campaign.state = CampaignState.objects.all().filter(state_name = 'PLANNED')[0]
    campaign.selected_plays_per_day = slotsRemaining
    campaign.screen_selection_tags = ""
    campaign.total_screens_selected = 1
    campaign.dayPart_selected = DayPart.objects.all().filter(name = day_part.name)[0] 
    campaign.account = acct[0]
    campaign.play_list = ContentQueue.objects.all().filter(content_queue_name = 'production_playlist')[0]
    campaign.save()
    logger.info('Auto booking campaign created for num_plays:'+str(slotsRemaining)+' Daypart:'+str(day_part.name)+
                ' Board:'+str(brd.board_name)+' date:'+str(date))
    bap.applied_to = campaign
    bap.save()

def Allocate_Free_slots(date,brd,day_part,totalslotsbooked,totalPlays):
    logger.info('Allocate_Free_slots date:'+str(date)+' board:'+str(brd.board_name)+' day_part:'+str(day_part.name))
    logger.info( 'total slots booked:'+ str(totalslotsbooked))
    logger.info( 'total plays booked:'+ str(totalPlays))
    totalSlots = GetNumOfUnits_DayPart(day_part)
    logger.info( 'total slots in Day_part:'+ str(totalSlots))
    slotsRemaining = totalSlots - totalslotsbooked
    logger.info( 'slots remaining:'+ str(slotsRemaining))
    if(slotsRemaining > 0):
        insertsfor_sb = totalPlays
        if(insertsfor_sb <= slotsRemaining):
            logger.info('inserts for slots booked:'+str(insertsfor_sb))
            logger.info('calling auto_booking')
            auto_booking(insertsfor_sb,date,brd,day_part) 
        else :
            logger.info('inserts for slots booked:'+str(slotsRemaining))
            logger.info('calling auto_booking')
            auto_booking(slotsRemaining,date,brd,day_part)
        logger.info('Back to Allocate_Free_slots !') 
    
def allocation_algorithm(date):
    logger.info('In allocation_algorithm')
    state = BookingState.objects.filter(name="SUCCESS")[0]
    day_part=DayPart.objects.all()
    board = Board.objects.all()
    for brd in board:
        for  dp in day_part:
            #Allocate_Free_slots(date,brd,dp)
            units_asked_tobook = 0
            time_tillbooked =dp.from_time
            mymap = {}
            mylist= []
            bookedadpack=BookedAdPack.objects.filter(booking_state = state,date_booked_for=date,day_part_booked_for=dp,booked_screen__key=brd.key).exclude(booking_type ='auto_booking')
            logger.info('booked ad pack total length in allocation algorithm:'+str(len(bookedadpack))+'DayPart:'+str(dp.name)+
                        ' Board:'+brd.board_name+' date:'+str(date))
            if not bookedadpack:
                logger.info('no booked ad packs available!' +'DayPart:'+str(dp.name)+
                        ' Board:'+brd.board_name+' date:'+str(date))
                continue
            for pack in bookedadpack:
                pack.slots_booked = []
                pack.save()
            for k in bookedadpack:
                if  k.applied_to.key in mymap.keys():
                    mymap[k.applied_to.key].append(k)
                else:
                    mymap[k.applied_to.key]=[k]
            for key in mymap.keys():
                value = mymap[key]
                mylist.append(value)
    
            l = len(mylist)
            
            cmpgnLength = []
            for i in range(l):
                cmpgnLength.append(len(mylist[i]))
            
            totalBookings = 0
            for j in range(len(cmpgnLength)):
                totalBookings = totalBookings + cmpgnLength[j]
            
            #initializing bookingCampaigns
            w = len(cmpgnLength)
            hgh = 0
            for k in range(len(cmpgnLength)):
                for m in range(cmpgnLength[k]):
                    if(m > hgh):
                        hgh = m
            bookingsInCampaigns = [[0 for x in range(hgh+1)] for y in range(w)] 
            totalPlaysBooked = 0
            totalUnits = 0
            #inserting total plays according to the bookings in to  campaigns
            for k in range(len(cmpgnLength)):
                for m in range(cmpgnLength[k]):
                    bookingsInCampaigns[k][m] = mylist[k][m].num_plays
                    totalPlaysBooked += bookingsInCampaigns[k][m]
                    totalUnits += bookingsInCampaigns[k][m]*mylist[k][m].units_per_play
            logger.info('calling Allocate_Free_slots!')
            Allocate_Free_slots(date, brd, dp,totalUnits,totalPlaysBooked)
            logger.info('Back to allocation_algorithm!')
            #get auto booked packs from BokkedAdPack
            auto_bookedPack = BookedAdPack.objects.filter(date_booked_for=date,day_part_booked_for=dp,booked_screen__key=brd.key,booking_type ='auto_booking')
            logger.info('length of Auto booked ad packs:'+str(len(auto_bookedPack))+'DayPart:'+str(dp.name)+
                        ' Board:'+brd.board_name+' date:'+str(date))
            if auto_bookedPack is not None and len(auto_bookedPack) > 0:
                autoBookingSlots = auto_bookedPack[0].num_plays
            else:
                logger.info( 'no auto booking is available')
                autoBookingSlots = 0
            logger.info('Number of Auto booked plays:'+str(autoBookingSlots)+' DayPart:'+str(dp.name)+
                        ' Board:'+str(brd.board_name)+' date:'+str(date))
            units_asked_tobook = totalUnits
            k = 0
            m = 0
            playCount = 0
            logger.info('Total remaining plays at campaigns:'+ str(bookingsInCampaigns)+' DayPart:'+str(dp.name)+
                        ' Board:'+brd.board_name+' date:'+str(date))
            while k < len(cmpgnLength) and m <= hgh  and playCount < totalPlaysBooked:
                if(bookingsInCampaigns[k][m] <= 0):
                    flag = True
                    for h in range(hgh):
                        if bookingsInCampaigns[k][h] > 0 and flag == True:
                            flag = False
                            time_tillbooked = create_booked_slot(date, mylist[k][h], time_tillbooked)
                            playCount += 1
                            bookingsInCampaigns[k][h] -= 1 
                            logger.info( 'Booked from campaign:'+ str((k+1)) +'B:'+str((h+1)) + str(bookingsInCampaigns))
                            if(autoBookingSlots > 0):
                                time_tillbooked = create_booked_slot(date, auto_bookedPack[0], time_tillbooked)
                                autoBookingSlots -= 1
                                logger.info( 'Booked from AUTO BOOKING') 
                    k = k + 1
                    if(k > len(cmpgnLength)-1):
                        k = 0
                        if m + 1 <= hgh :
                            m = m + 1
                        else:
                            m = 0
                    continue      
                if(bookingsInCampaigns[k][m] > 0):
                    time_tillbooked = create_booked_slot(date, mylist[k][m], time_tillbooked)
                    playCount += 1
                    bookingsInCampaigns[k][m] -= 1 
                    logger.info( 'Booked from campaign:'+str((k+1))+'B:'+str((m+1)) +str(bookingsInCampaigns))
                    if(autoBookingSlots > 0):
                        time_tillbooked = create_booked_slot(date, auto_bookedPack[0], time_tillbooked)
                        autoBookingSlots -= 1
                        logger.info( 'Booked from AUTO BOOKING')
                    k = k + 1
                    if(k > len(cmpgnLength)-1):
                        k = 0
                        if m + 1 <= hgh :
                            m = m + 1
                        else:
                            m = 0
            ValidateAlgorithm(units_asked_tobook, cmpgnLength, mylist)                                   
                
    
                            
              
                
                
                
           




            
            
                
                
#allocation_algorithm(datetime.now().date())
#allocation_algorithm(datetime.now().date()+timedelta(days=-1))               
                    
                     
            
            
        
    