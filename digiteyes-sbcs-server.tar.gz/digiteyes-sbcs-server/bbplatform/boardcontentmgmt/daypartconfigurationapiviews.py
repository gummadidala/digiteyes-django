from rest_framework import generics
from rest_framework.response import Response
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters
import django_filters
from boardcontentmgmt.models import DayPart,AccountUser
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from rest_framework import serializers
from dateutil.parser import parse
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from boardcontentmgmt.campaignmgmt.apartmentadvertisingapiviews import get_available_day_parts

class DayPartSerializer(serializers.ModelSerializer):
    class Meta:
        model = DayPart
        fields = ('name','key','from_time','to_time')

class DayPartFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(name='name',lookup_type='exact')
    class Meta:
        model = DayPart
	fields = ('name',)
#################################################################################
# DeviceAppConfigurationListView
#################################################################################
class DayPartListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = DayPartSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name', )
    filter_class = DayPartFilter
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return DayPart.objects.all().order_by('from_time')
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return DayPartSerializer
        return DayPartSerializer
#################################################################################
# DeviceAppConfigurationUpdateView
#################################################################################
class DayPartUpdateView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = DayPartSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name', )
    filter_class = DayPartFilter
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return DayPart.objects.all().order_by('from_time')
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return DayPartSerializer
        return DayPartSerializer

class GetAvilableDayParts(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    def get(self,request):
        date = parse(request.query_params.get('date', None)).date()
        if date is not None:
            res = []
            day_parts = get_available_day_parts(date)
            if len(day_parts)>0:
                for dp in day_parts:
                    res.append(DayPartSerializer(dp).data)
            return Response(res)
        else:
            error = {'error':'Date is required'}
            return Response(error,status=HTTP_400_BAD_REQUEST)
        
        
