

from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated

from rest_framework import filters
import django_filters

from boardcontentmgmt.models import BookedAdPack, BookedSlot,AdvtCampaign,Layout,BookingState,Account,Board
from rest_framework.views import APIView
from boardcontentmgmt.contentmgmt.adcontentserializers import ContentQueueShortSerializer
import datetime
from datetime import timedelta
from dateutil.parser import parse
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions    
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.utilities.algo_utilities import get_daypart
from affiliateads.scraper import hopcoms_price_list
import random,string
import logging
logger = logging.getLogger(__name__)

def addSecs(tm, secs):
    fulldate = datetime.datetime(100, 1, 1, tm.hour, tm.minute, tm.second)
    fulldate = fulldate + datetime.timedelta(seconds=secs)
    return fulldate.time()

def get_store_menu():
    logger.info("In get_store_menu")
    store_menu = ["Amla : 60.00", "Avarekai (Field Beans ) : 76.00", "Baby corn : 28.00",
                  "Baby corn cleaned : 98.00", "Basale Greens : 32.00", "Beans : 75.00",
                  "Beet Root : 40.00","Bitter Gourd : 56.00","Capsicum Red/Yellow : 80.00",
                  "Chillies Green : 65.00","Corriander Leave : 160.00","Drumstik : 44.00",
                  "Eggs : 4.5","Greens Sabbakki : 128.00","Ladys finger : 37.00",
                  "Mangalore cucumber : 21.00","Palak Greens : 44.00","Potato(M) : 23.00",
                  "Snake Gourd : 38.00", "Sweet corn : 36.00","Tender Coconut : 23.00",
                  "Tomoto : 20.00", "Apple Delicious : 136.00","Banana Nendra : 60.00",
                  "Chicco(Sapota) : 49.00","Grapes Red globe : 430","Guava : 65.00",
                  "Mango malagova : 80.00","Mango Raspuri : 56.00","Mosambi : 58.00",
                  "Pineapple : 52.00","Watermellon : 23.00" ]
    
    return store_menu

##################################################################################
# Generates Content advices from start date, end date 
#################################################################################
def generate_content_advices(start_date_time, end_date_time, board_key,camp_type):
        booked_packs = BookedAdPack.objects.filter(
            applied_to__type__name = camp_type,
            booked_screen__key = board_key).exclude(
            date_booked_for__lt = start_date_time).exclude(
            date_booked_for__gt = end_date_time).filter(
            booking_state__name = 'SUCCESS').order_by('day_part_booked_for__from_time').exclude(
                booking_type = 'test')
        adviceList = []
        queue_map = {}
        queue_list = []
        
        rand_num = ''.join(random.choice(string.ascii_lowercase + 
                                         string.ascii_uppercase + string.digits) for i in range(8))
        time1=datetime.datetime.now()
        for pack in booked_packs :
            for bookedslot in pack.slots_booked.all():
                advice = {}
                advice['campaign'] = pack.applied_to.key
                advice['campaign_type'] = pack.applied_to.type.name
                #advice['play_queue'] = pack.applied_to.play_list.key
                if pack.play_list is not None:
                    advice['play_queue'] = pack.play_list.key
                else:
                    advice['play_queue'] = pack.applied_to.play_list.key
                if str(pack.applied_to.play_list.key) not in queue_map:
                    queue_map[str(pack.applied_to.play_list.key)] = True
                    qser = ContentQueueShortSerializer(pack.applied_to.play_list)
                    queue_list.append(qser.data)
                #advice['validity_from_time'] = pack.date_booked_for
                #advice['validity_to_time'] = pack.date_booked_for
                advice['play_from_time_of_day'] = bookedslot.start_time
                play_secs = bookedslot.num_units * bookedslot.unit_size
                advice['play_to_time_of_day'] = addSecs(bookedslot.start_time,play_secs)
                advice['schedule_key']=bookedslot.key
                advice['skip']="false"
                advice['empty']="false"
                if pack.booking_type=='auto_booking' or pack.booking_type=='affiliate_booking':
                    advice['skip']="true"
                if pack.booking_type=='empty_booking':
                    advice['empty']="true"
                adviceList.append(advice)
        time2=datetime.datetime.now()
        diff_time = time2-time1
        logger.debug(rand_num+" time1:"+str(time1))
        logger.debug(rand_num+" time2:"+str(time2))
        logger.debug(rand_num+" diff_time:"+str(diff_time))
        result = {}
        result['content_advices'] = adviceList
        result['play_lists'] = queue_list
        #result['store_menu'] = hopcoms_price_list("http://www.hopcoms.kar.nic.in/")
        result['store_menu'] = get_store_menu()
        return result

def create_bookedslot(time_tillbooked):
    bt = BookedSlot()
    bt.start_time = time_tillbooked
    bt.num_units = 1
    bt.unit_size = 30
    bt.booking_state = BookingState.objects.filter(name="SUCCESS")[0]
    bt.save()
    return bt

def create_bookedadpack(campaign,dp,brd):
    bap = BookedAdPack()
    bap.booked_screen = Board.objects.filter(key=brd)[0]
    bap.date_booked_for = datetime.datetime.now().date()
    booking_state = BookingState.objects.filter(name = "SUCCESS")[0]
    bap.booking_state = booking_state 
    bap.when_booked = datetime.datetime.now().date()
    bap.num_plays = 12
    bap.booking_type = 'test'
    bap.units_per_play = campaign.play_list.num_units
    bap.day_part_booked_for = dp[0]
    bap.price = 0
    bap.account = Account.objects.filter(account_name='DE Production')[0]
    bap.unit_size = campaign.play_list.unit_size
    bap.applied_to = campaign
    bap.save()
    return bap

def generate_test_content_advices(board):
    adviceList=[]
    queue_list = []
    layout_list = Layout.objects.all()
    test_campaingn_list = []
    dp = get_daypart()
    for layout in layout_list:
        for i in range(3):
            camp = AdvtCampaign.objects.filter(name='device-test_'+layout.name+str(i+1),
                                               dayPart_selected__name = dp[0].name)
            if camp is not None and len(camp)>0:
                camp[0].planned_start_date= datetime.datetime.now().date()
                camp[0].planned_end_date = datetime.datetime.now().date()
                #camp[0].planned_dates = [datetime.datetime.now().date()]
                camp[0].save()
                test_campaingn_list.append(camp[0])
            else:
                logger.error('Campaign with name:'+str('device-test_'+layout.name+str(i+1)+' is not found'))
    current_time=datetime.datetime.strptime(str(datetime.datetime.now().time()).split('.')[0], '%H:%M:%S').time()
    for campaign in test_campaingn_list:
        create_bookedadpack(campaign,dp,board)
    for j in range(4):
        for campaign in test_campaingn_list:
            bookedslot = create_bookedslot(current_time)
            bookedaddpack = BookedAdPack.objects.filter(applied_to__key=campaign.key)
            if bookedaddpack is not None and len(bookedaddpack)>0:
                bookedaddpack[0].slots_booked.add(bookedslot)
                bookedaddpack[0].save()
            advice = {}
            advice['campaign'] = campaign.key
            advice['play_queue'] = campaign.play_list.key
            advice['play_from_time_of_day'] = bookedslot.start_time
            play_secs = bookedslot.num_units * bookedslot.unit_size
            end_time = addSecs(bookedslot.start_time,play_secs)
            current_time = end_time
            advice['play_to_time_of_day'] = end_time
            advice['schedule_key']=bookedslot.key
            advice['skip']="false"
            qser = ContentQueueShortSerializer(campaign.play_list)
            queue_list.append(qser.data)
            adviceList.append(advice)
        
    result = {}
    result['content_advices'] = adviceList
    result['play_lists'] = queue_list
    return result
#################################################################################
# Board List API List View
#################################################################################
class ContentAdviceListAPIView(APIView):
    """
    Screen List
    ==========
    ##GET:
    List of Screens. If no filters passed, then it returns the list of screens in the account.
    ### Filter Fields:
        1. account__account_name (For Un accounted )
        2. board_state__name (For UnRegisterd)
                         
    ###Search Fileds:
        1. screen name (board_name) 
    ##POST:
    
    Create a Screen Instance. 
    ###Required fields are
        1. board Name (board_name)
        2. board serial number (board_serial_number)
    
    Screen Instance creation happens from Production account. So they are not put into any account. Screens
    are assigned to an account during Assign screen workflow, which happens after the screen is registered.
    """
    
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated, )
    #permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    
    def get(self,request,format = None):
        from_date = request.query_params.get('from_date', None)
        to_date = request.query_params.get('to_date', None)
        board = request.query_params.get('board', None)
        test_mode = request.query_params.get('test_mode', None)
        camp_type = request.query_params.get('camp_type', 'NORMAL')
        logger.info("From Date: " + from_date + " To Date: "+to_date +" Board : " +board)
        if test_mode=="true":
            advices = generate_test_content_advices(board)
            return Response(advices)
        else:
            if from_date and to_date and board :
                from_date_dd = parse(from_date)
                to_date_dd = parse(to_date)
                advices = generate_content_advices(from_date_dd,to_date_dd,board,camp_type)
                return Response(advices)
            else :
                error = {"error" : "from_date, to_date, board params required"}
                return Response(error, status=HTTP_400_BAD_REQUEST)
    
                
            
        
        
