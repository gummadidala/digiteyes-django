from rest_framework import generics

from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters
import django_filters
from boardcontentmgmt.models import DeviceAppVersion, DeviceConfiguration,AccountUser
from .deviceconfigurationserializers import DeviceConfigurationSerializer
from .deviceconfigurationserializers import DeviceAppVersionSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from boardcontentmgmt.tasks import calculate_hash_apk
import django_filters
import logging
logger = logging.getLogger(__name__)
import sys,traceback
#################################################################################
# Board List API List View
#################################################################################
class DeviceConfigurationListView(generics.ListCreateAPIView):
    """
    Device Configuration
    ==========
    ##GET:
    List of Device Configuration. 
    ### Filter Fields:
        1. applicable_app_version 
        
    ###Search Fileds:
        1. applicable_app_version 
    ##POST:
    
    Creates a Device Configuration.
    ###Required fields are
        1. applicable_app_version
        2. upgrade_url 
        3. log_upload_url
    """
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = DeviceConfigurationSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('applicable_app_version', )
    search_fields = ('applicable_app_version',)
    lookup_field = 'key'
    def get_queryset(self):
        return DeviceConfiguration.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return DeviceConfigurationSerializer
        return DeviceConfigurationSerializer
#################################################################################
# Board List API List View
#################################################################################
class DeviceConfigurationUpdateView(generics.RetrieveUpdateDestroyAPIView):
    """
    Device Configuration
    ==========
    ##GET:
    Gets the  Device Configuration object as specified by the key.
    ##PUT:
    
    Updates the Device configuration. 
    ###Required fields are
        1. applicable_app_version
        2. upgrade_url 
        3. log_upload_url
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = DeviceConfigurationSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('applicable_app_version', )
    search_fields = ('applicable_app_version',)
    lookup_field = 'key'
    def get_queryset(self):
        return DeviceConfiguration.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return DeviceConfigurationSerializer
        return DeviceConfigurationSerializer
#################################################################################
# Board List API List View
#################################################################################
class DeviceAppVersionFilter(django_filters.FilterSet):
    type = django_filters.CharFilter(name='app_type__type',lookup_type='exact')
    class Meta:
        model = DeviceAppVersion
	fields = ('type',)
class DeviceAppVersionListView(generics.ListCreateAPIView):
    """
    DeviceAppVersion
    ==========
    ##GET:
    List of Device App Version objects.
    ### Filter Fields:
        1. app_version
        
    ###Search Fileds:
        1. app_version
    ##POST:
    
    Creates a Device Configuration.
    ###Required fields are
        1. app_version
        2. released_date 
        3. apk_location
    """
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = DeviceAppVersionSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_class = DeviceAppVersionFilter
    filter_fields = ('app_version','app_type__type')
    search_fields = ('app_version','app_type__type')
    lookup_field = 'key'
    def get_queryset(self):
        return DeviceAppVersion.objects.all().order_by('-release_date')
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return DeviceAppVersionSerializer
        return DeviceAppVersionSerializer
    def perform_create(self, serializer):
        try:
            generics.ListCreateAPIView.perform_create(self, serializer)
            logger.info("CREATED "+str(serializer.instance))
            calculate_hash_apk.delay(str(serializer.instance.key))
        except:
            logger.error ("CREATION_ERROR "+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("CREATION_ERROR "+str(tb))
#################################################################################
# Board List API List View
#################################################################################
class DeviceAppVersionUpdateView(generics.RetrieveUpdateDestroyAPIView):
    """
    DeviceAppVersion
    ==========
    ##GET:
    Gets the  Device App version object as specified by the key.
    ##PUT:
    
    Updates the DeviceApp Version
    ###Required fields are
        1. app_version
        2. released_date
        3. apk_location
    """
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = DeviceAppVersionSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_class = DeviceAppVersionFilter
    filter_fields = ('app_version', 'app_type__type')
    search_fields = ('app_version','app_type__type')
    lookup_field = 'key'
    def get_queryset(self):
        return DeviceAppVersion.objects.all().order_by('-release_date')
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return DeviceAppVersionSerializer
        return DeviceAppVersionSerializer
    def perform_update(self, serializer):
        try:
            generics.RetrieveUpdateDestroyAPIView.perform_update(self, serializer)
            logger.info("UPDATED "+str(serializer.instance))
            calculate_hash_apk.delay(str(serializer.instance.key))
        except:
            logger.error ("UPDATION_ERROR "+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("UPDATION_ERROR "+str(tb))
