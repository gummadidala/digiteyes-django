from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework.pagination import PageNumberPagination
from rest_framework import filters
from boardcontentmgmt.models import DeviceLastContact,AccountUser,Board
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from boardcontentmgmt.tasks import check_devicecontrol_status
import datetime
from rest_framework import serializers
from boardcontentmgmt.screenmgmt.boardserializers import BoardBasicSerializer
##################################################################################
#Serializer for DeviceLastContact
#################################################################################
class DeviceLastContactSerializer(serializers.ModelSerializer):
    board = BoardBasicSerializer()
    class Meta:
        model = DeviceLastContact
        fields = ['key','last_contact_time','board','status']
class DeviceLastContactWriteSerializer(serializers.ModelSerializer):
    board = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='key')
    class Meta:
        model = DeviceLastContact
        fields = ['key','last_contact_time','board','status']
#################################################################################
#DeviceLastContact API List View - Supports Listing and Create
#################################################################################
class CustomPagination(PageNumberPagination):
    page_size_query_param = 'page_size'
class DeviceLastContactFilter(django_filters.FilterSet):
    board = django_filters.CharFilter(name='board__key',lookup_type='exact')
    board_serial_number  = django_filters.CharFilter(name='board__board_serial_number',lookup_type='exact')
    start_time = django_filters.CharFilter(name='last_contact_time', lookup_type="gte")
    end_time = django_filters.CharFilter(name='last_contact_time',lookup_type="lte")
    class Meta:
        model = DeviceLastContact
	fields = ('board','board_serial_number','start_time','end_time',)
class DeviceLastContactListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,DjangoModelPermissions)#,DjangoObjectPermissions,)
    serializer_class  = DeviceLastContactSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('last_contact_time','board__key')
    filter_class = DeviceLastContactFilter
    pagination_class = CustomPagination
    lookup_field = 'key'
    def get_queryset(self):
        return DeviceLastContact.objects.all().order_by('-last_contact_time')
    def post(self,request, format=None):
        request.data['last_contact_time'] = datetime.datetime.now()
        serializer = DeviceLastContactWriteSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)

    
    
    
    
