from rest_framework import serializers
from boardcontentmgmt.models import Board, RequestState, DeviceControlCommand,DeviceController
from boardcontentmgmt.screenmgmt.boardserializers import BoardSerializer

##################################################################################
#Serializer for Device controller
#################################################################################
class DeviceControllerSerializer(serializers.ModelSerializer):
    board = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='key')
    command = serializers.SlugRelatedField(
        queryset=DeviceControlCommand.objects.all(),
        slug_field='name')
    request_state = serializers.SlugRelatedField(
        queryset=RequestState.objects.all(),
        slug_field='name')
    class Meta:
        model = DeviceController
        fields = ['key','board','command','request_start_time','request_end_time','request_state','parameter']
        
#################################################################################
##Serializer for Device controller
#################################################################################
class DeviceControllerWriteSerializer(serializers.ModelSerializer):
    board = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='key')
    command = serializers.SlugRelatedField(
        queryset=DeviceControlCommand.objects.all(),
        slug_field='name')
    request_state = serializers.SlugRelatedField(
        queryset=RequestState.objects.all(),
        slug_field='name')
    class Meta:
        model = DeviceController
        fields = ['key','board','command','request_start_time','request_end_time','request_state','parameter']
    