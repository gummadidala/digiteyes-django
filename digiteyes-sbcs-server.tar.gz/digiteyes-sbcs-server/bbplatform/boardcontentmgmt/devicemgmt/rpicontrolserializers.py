from rest_framework import serializers
from boardcontentmgmt.models import Board, RequestState,RpiControlCommand,RpiController
from boardcontentmgmt.screenmgmt.boardserializers import BoardSerializer

##################################################################################
#Serializer for Rpi controller
#################################################################################
class RpiControllerSerializer(serializers.ModelSerializer):
    board = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='key')
    command = serializers.SlugRelatedField(
        queryset=RpiControlCommand.objects.all(),
        slug_field='name')
    request_state = serializers.SlugRelatedField(
        queryset=RequestState.objects.all(),
        slug_field='name')
    class Meta:
        model = RpiController
        fields = ['key','board','command','request_start_time','request_end_time','request_state']
        
#################################################################################
##Serializer for Rpi controller
#################################################################################
class RpiControllerWriteSerializer(serializers.ModelSerializer):
    board = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='key')
    command = serializers.SlugRelatedField(
        queryset=RpiControlCommand.objects.all(),
        slug_field='name')
    request_state = serializers.SlugRelatedField(
        queryset=RequestState.objects.all(),
        slug_field='name')
    class Meta:
        model = RpiController
        fields = ['key','board','command','request_start_time','request_end_time','request_state']
    