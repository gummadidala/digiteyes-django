from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework import filters
from boardcontentmgmt.models import DeviceController,AccountUser
from .devicecontrolserializers import DeviceControllerSerializer,DeviceControllerWriteSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from boardcontentmgmt.tasks import check_devicecontrol_status
import datetime
#################################################################################
#Device Control API List View - Supports Listing and Create
#################################################################################
class DevicecontrolFilter(django_filters.FilterSet):
    board = django_filters.CharFilter(name='board__key')
    request_state = django_filters.CharFilter(name='request_state__name')
    command = django_filters.CharFilter(name='command__name')
    class Meta:
        model = DeviceController
        fields = []
class DevicecontrolListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,DjangoModelPermissions)#,DjangoObjectPermissions,)
    serializer_class  = DeviceControllerSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_class = DevicecontrolFilter
    search_fields = ('board__board_name','command__name','request_state__name')
    lookup_field = 'key'
    def get_queryset(self):
        return DeviceController.objects.all().order_by('-request_start_time')
    def post(self,request, format=None):
        request.data['request_state'] = 'SUBMITTED'
        serializer = DeviceControllerWriteSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            key = str(serializer.data['key'])
            check_devicecontrol_status.apply_async((key,), countdown=1800)
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)
#################################################################################
# Devicecontrol  API Detail View - Supports Update/Patch and Deletion
#################################################################################
class DevicecontrolUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions)#,DjangoObjectPermissions)
    serializer_class  = DeviceControllerSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('board__board_name','command__name','request_state__name')
    filter_class = DevicecontrolFilter
    lookup_field = 'key'
    def get_queryset(self):
        return DeviceController.objects.all().order_by('-request_start_time')
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return DeviceControllerSerializer
        return DeviceControllerWriteSerializer
    
    
    
    