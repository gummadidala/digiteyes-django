from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework import filters
from boardcontentmgmt.models import RpiController,AccountUser,WifiCounter,Board
from .rpicontrolserializers import RpiControllerSerializer,RpiControllerWriteSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from boardcontentmgmt.tasks import check_rpicontrol_status
from boardcontentmgmt.tasks import check_devicecontrol_status
import datetime
import logging
logger = logging.getLogger(__name__)
#################################################################################
#Rpi Control API List View - Supports Listing and Create
#################################################################################

def filter_mac_address(queryset,value):
    if value is not None:
        print value
        wifi_counters=WifiCounter.objects.filter(mac_address=value)
        print str(wifi_counters)
        if len(wifi_counters)==0:
           return queryset.none()
        boards=Board.objects.filter(attached_wificounters=wifi_counters)
        print str(boards)
        if len(boards) > 0 and boards is not None:
            queryset = queryset.filter(board__key=boards[0].key)
        logger.debug(queryset)
    return queryset
    
class RpicontrolFilter(django_filters.FilterSet):
    board = django_filters.CharFilter(name='board__key')
    request_state = django_filters.CharFilter(name='request_state__name')
    command = django_filters.CharFilter(name='command__name')
    #mac_address = django_filters.CharFilter(action=filter_mac_address)
    class Meta:
        model = RpiController
        #fields = ['key','board','command','request_start_time','request_end_time','request_state']
class RpicontrolListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)#DjangoModelPermissions)#,DjangoObjectPermissions,)
    serializer_class  = RpiControllerSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_class = RpicontrolFilter
    search_fields = ('board__board_name','command__name','request_state__name')
    lookup_field = 'key'
    def get_queryset(self):
        return RpiController.objects.all().order_by('-request_start_time')
    def post(self,request, format=None):
        request.data['request_state'] = 'SUBMITTED'
        serializer = RpiControllerWriteSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            key = str(serializer.data['key'])
            check_rpicontrol_status.apply_async((key,), countdown=1800)
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)
#################################################################################
# Rpicontrol  API Detail View - Supports Update/Patch and Deletion
#################################################################################
class RpicontrolUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions)#,DjangoObjectPermissions)
    serializer_class  = RpiControllerSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('board__board_name','command__name','request_state__name')
    filter_class = RpicontrolFilter
    lookup_field = 'key'
    def get_queryset(self):
        return RpiController.objects.all().order_by('-request_start_time')
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return RpiControllerWriteSerializer
        return RpiControllerSerializer
    
    
    
    
