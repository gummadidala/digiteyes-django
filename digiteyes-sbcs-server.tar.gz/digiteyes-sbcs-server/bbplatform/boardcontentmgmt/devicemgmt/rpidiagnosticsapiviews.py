from rest_framework import generics
from rest_framework import serializers
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters
import django_filters
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from django.http.response import Http404
from rest_framework.response import Response
from rest_framework.views import APIView
from boardcontentmgmt.models import RpiVersion, RpiDiagnostics,AccountUser,Board
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from boardcontentmgmt.tasks import calculate_hash_apk
import django_filters
import logging
logger = logging.getLogger(__name__)
import sys,traceback

class RpiVersionSerializer(serializers.ModelSerializer):
    class Meta:
        model = RpiVersion
        fields = ('application_version','release_date','code_location','key','hash')

class RpiDiagnosticsSerializer(serializers.ModelSerializer):
    board = serializers.SlugRelatedField(
        queryset=Board.objects.all(),
        slug_field='board_serial_number')
    class Meta:
        model = RpiDiagnostics
        fields = ('application_version','key','board')
class RpiDiagnosticsFilter(django_filters.FilterSet):
    board = django_filters.CharFilter(name='board__key',lookup_type='exact')
    class Meta:
        model = RpiDiagnostics

class RpiVersionListView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)# DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = RpiVersionSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('application_version',)
    search_fields = ('application_version',)
    lookup_field = 'key'
    def get_queryset(self):
        return RpiVersion.objects.all().order_by('-release_date')
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return RpiVersionSerializer
        return RpiVersionSerializer
    def perform_create(self, serializer):
        try:
            generics.ListCreateAPIView.perform_create(self, serializer)
            logger.info("CREATED "+str(serializer.instance))
            calculate_hash_apk.delay(str(serializer.instance.key),"RPI")
        except:
            logger.error ("CREATION_ERROR "+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("CREATION_ERROR "+str(tb))
#################################################################################
# Board List API List View
#################################################################################
class RpiVersionUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)# DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = RpiVersionSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('application_version',)
    search_fields = ('application_version',)
    lookup_field = 'key'
    def get_queryset(self):
        return RpiVersion.objects.all().order_by('-release_date')
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return RpiVersionSerializer
        return RpiVersionSerializer
    def perform_update(self, serializer):
        try:
            generics.RetrieveUpdateDestroyAPIView.perform_update(self, serializer)
            logger.info("UPDATED "+str(serializer.instance))
            calculate_hash_apk.delay(str(serializer.instance.key),"RPI")
        except:
            logger.error ("UPDATION_ERROR "+ str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("UPDATION_ERROR "+str(tb))

class RpiDiagnosticsListView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)# DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class = RpiDiagnosticsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('board__key',)
    search_fields = ('board__key',)
    lookup_field = 'key'
    def get_queryset(self):
        return RpiDiagnostics.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return RpiDiagnosticsSerializer
        return RpiDiagnosticsSerializer

class RpiDiagnosticsUpdateView(APIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)# DjangoModelPermissions,DjangoObjectPermissions)
    def get(self,request,format = None):
        brd_serial_number = self.request.query_params.get('board_serial_number', None)
        new_version = self.request.query_params.get('version', None)
        diag_obj = RpiDiagnostics.objects.filter(board__board_serial_number=brd_serial_number)
        if diag_obj is not None and len(diag_obj)>0:
            diag_obj[0].application_version = new_version
            diag_obj[0].save()
        else:
            obj = RpiDiagnostics()
            obj.application_version = new_version
            obj.board = Board.objects.filter(board_serial_number=brd_serial_number)[0]
            obj.save()
        return Response(status=HTTP_201_CREATED)
