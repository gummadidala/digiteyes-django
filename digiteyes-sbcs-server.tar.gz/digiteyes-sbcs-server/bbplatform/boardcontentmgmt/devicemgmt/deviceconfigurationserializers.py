from rest_framework import serializers
from boardcontentmgmt.models import DeviceAppVersion, DeviceConfiguration, AppType

class DeviceConfigurationSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceConfiguration
        fields = ('applicable_app_version','upgrade_url','log_upload_url',
                  'log_upload_user','log_upload_password','key')

class DeviceAppVersionSerializer(serializers.ModelSerializer):
    app_type = serializers.SlugRelatedField(
        queryset=AppType.objects.all(),
        slug_field='type')
    class Meta:
        model = DeviceAppVersion
        fields = ('app_version','release_date','apk_location','key','hash','app_type')