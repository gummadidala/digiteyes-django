from django.test import TestCase

# Create your tests here.

from boardcontentmgmt.models import AdvtCampaign, AdvtCampaignDate
from boardcontentmgmt.taskprocessors import reportgen
from datetime import date

def test_report_data():
    campaign=AdvtCampaign.objects.get(pk=109)
    dates=[]
    day1 = AdvtCampaignDate()
    day1.date = '2017-02-16'
    day1.save()
    day2 = AdvtCampaignDate()
    day2.date = '2017-02-17'
    day2.save()
    day3 = AdvtCampaignDate()
    day3.date = '2017-02-18'
    day3.save()
    campaign.planned_dates=[day1,day2,day3]
    bdp=BookedDayPack()
    
    campaign.save()
    
    reportgen.generate_campaign_play_report(campaign)