from rest_framework import serializers
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from boardcontentmgmt.models import Account, DayPart, MasterEntitlement

##################################################################################
#Serializer for Master Entitlement
#################################################################################
class MasterEntitlementSerializer(serializers.ModelSerializer):
    account = AccountSerializer()
    day_part_entitled = serializers.SlugRelatedField(
        queryset=DayPart.objects.all(),
        slug_field='name')
    class Meta:
        model = MasterEntitlement
        fields = ['key','account','day_part_entitled','percent_slots_entitled_association',
                  'percent_slots_entitled_consumer','ticker_slots_entitled']
        
#################################################################################
##Serializer for Master Entitlement
#################################################################################
class MasterEntitlementWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key')
    day_part_entitled = serializers.SlugRelatedField(
        queryset=DayPart.objects.all(),
        slug_field='name')
    class Meta:
        model= MasterEntitlement
        fields = ['key','account','day_part_entitled','percent_slots_entitled_association',
                  'percent_slots_entitled_consumer','ticker_slots_entitled']
    