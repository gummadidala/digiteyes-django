from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.request import Request
from django.contrib.auth.models import User
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST
import django_filters
from rest_framework import filters
from boardcontentmgmt.models import MasterEntitlement,AccountUser
from .masterentitlementserializers import MasterEntitlementWriteSerializer,MasterEntitlementSerializer
from rest_framework.permissions import DjangoModelPermissions
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from boardcontentmgmt.permissionsmgmt.checkobjectfieldpermission import PermissionCheck
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
#################################################################################
#MasterEntitlement API List View - Supports Listing and Create
#################################################################################
class EntitlementsFilter(django_filters.FilterSet):
    account = django_filters.CharFilter(name='account__account_name')
    class Meta:
        model = MasterEntitlement
        fields = []
class MasterEntitlementListView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,DjangoModelPermissions,DjangoObjectPermissions,)
    serializer_class  = MasterEntitlementSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_class = EntitlementsFilter
    search_fields = ('account__account_name','day_part__name')
    lookup_field = 'key'
    #queryset = MasterEntitlement.objects.all()
    def get_queryset(self):
        username = self.request.user.username
        usr = self.request.user
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(usr,'masterentitlement') == True):
            return MasterEntitlement.objects.all()
        else:
            return MasterEntitlement.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return MasterEntitlementWriteSerializer
        return MasterEntitlementSerializer
    
#################################################################################
# MasterEntitlement  API Detail View - Supports Update/Patch and Deletion
#################################################################################
class MasterEntitlementUpdateView(generics.RetrieveUpdateDestroyAPIView):
    #authentication_classes = (TokenAuthentication,)
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    serializer_class  = MasterEntitlementSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    search_fields = ('account__account_name','day_part__name')
    filter_class = EntitlementsFilter
    lookup_field = 'key'
    #queryset = MasterEntitlement.objects.all()
    def modify(self):
        field_permissions = [{'permission':'modify_all_masterentitlement',
                              'model_name' : 'masterentitlement'}]
        return field_permissions
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'masterentitlement') == True):
            return MasterEntitlement.objects.all()
        else:
            return MasterEntitlement.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return MasterEntitlementWriteSerializer
        return MasterEntitlementSerializer
    
    
    
    