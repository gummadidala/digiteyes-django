import requests
import random
import string
import logging
from datetime import date
from selenium import webdriver
import traceback,sys
import time
import re

from createaffiliatecontent import create_affiliate_account, create_affiliate_playlists
from affiliateprefsprovider import get_affiliate_prefs
logger = logging.getLogger("affiliateads.tasks")

#################################################################################
#  Returns HD url for a given url
#################################################################################
def get_hd_url(img_url):
    p= re.compile(r"(\d+)/(\d+)")
    new_path = p.sub("1024/1024",img_url)
    return new_path

def flipkart_scrap_provide_contents(offer_url,offer_title,number_of_products):
    #logger.info('In flipkart_scrap_provide_contents')
    try :
        driver = webdriver.PhantomJS(service_args=['--ignore-ssl-errors=true', 
            '--ssl-protocol=TLSv1'])
        driver.set_window_size(1024, 768) # optional
        driver.get(offer_url)
        time.sleep(10)
        if driver.current_url != offer_url :
            time.sleep(5)
        
        elems = driver.find_elements_by_class_name("Zhf2z-")
        title_divs = driver.find_elements_by_class_name("_2Wy-am")
        product_info_list = []
        
        title=""
        for div in title_divs:
            title = div.text
            #logger.info("Production Title:"+str(div.text))
        count=0
        for elem in elems:
            if count >= number_of_products:
                break
            img = elem.find_element_by_tag_name("img")
            if img is not None:
                product_info = {}
                product_info['title'] = offer_title+ " - "+title
                img_url = img.get_attribute("src")
                parent=elem.find_element_by_xpath("..")
                descs = parent.find_elements_by_class_name("_2cLu-l")
                for desc in descs:
                    #print desc.text
                    product_info['description'] = desc.text
                    product_info['url'] = desc.get_attribute('href')+"&affid=digiteyes1"
                    #print product_info['url']
                sale_prices = parent.find_elements_by_class_name("_1vC4OE")
                sale_price=""
                for price in sale_prices:
                    #print price.text
                    sale_price=price.text
                orig_prices = parent.find_elements_by_class_name("_3auQ3N")
                listed_price=""
                for price in orig_prices:
                    #print price.text
                    listed_price=price.text
                product_info['additional_info']=[{"Listed":listed_price,"Sale":sale_price,
                    "title":product_info['description']}]
                if img_url is not None:
                    new_url = get_hd_url(img_url)
                    product_info["images"]=[]
                    product_info["images"].append(new_url)
                    #logger.debug("Image URL:"+str(new_url))
                    product_info['imageUrls']=[{'resolutionType':'mid','url':img_url}]
                count+=1
                product_info_list.append(product_info)
        driver.close()
        return product_info_list
    except:
        logger.error ("FLIPKART_AFFILIATE_CONTENT_PULL_EEEOR"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("FLIPKART_AFFILIATE_CONTENT_PULL_EEEOR "+str(tb))
        if driver is not None:
            driver.close()
        return None
    
def filter_offers(offer_list, category):
    filter_categories = [category]
    filtered_offers = []
    for offer in offer_list:
        if offer['availability'] != 'LIVE':
            continue
        if offer['category'].lower() in (category.lower() for category in filter_categories) :
            if offer['title'].find('Off') >=0 or offer['description'].find('Off') >= 0:
                filtered_offers.append(offer)
    return filtered_offers
def pick_random_offers(num,offer_list):
    random_picked = []
    random_picked_indexes = []
    count = 0
    if len(offer_list) <= num :
	return offer_list
    while count < num:
        rand_ind = random.randint(0, len(offer_list)-1)
        while rand_ind in random_picked_indexes:
            rand_ind = random.randint(0, len(offer_list)-1)
        random_picked_indexes.append(rand_ind)
        random_picked.append(offer_list[rand_ind])
        count +=1
    return random_picked

def get_flipkart_offers(planned_date):
    #logger.info("get_flipkart_offers")
    url='https://affiliate-api.flipkart.net/affiliate/offers/v1/all/json'
    id='digiteyes1'
    token='e84eabb6db59476e8a16bbcce36e5571'
    headers= {"Fk-Affiliate-Id": id,"Fk-Affiliate-Token":token}
    resp = requests.get(url,headers=headers)
    offers = resp.json()
    offer_list = offers['allOffersList']
    #logger.info("Number of Offers" + unicode(len(offer_list)))
    prefs = get_affiliate_prefs("flipkart",planned_date)
    for pref in prefs:
        #logger.debug( "Processing Flipkart Affiliate Prefs============="+
            #unicode(pref.category)+" "+unicode(pref.number_of_ads))
        filtered = filter_offers(offer_list,pref.category)
        if filtered is None or len(filtered) <=0 :
            #logger.warn("No offers after filtering")
            continue 
        #logger.info("Filtered Offers: "+ unicode(len(filtered)))
        '''
        for offer in filtered:
            logger.debug(offer['title'])
            logger.debug(offer['description'])
        '''
        picked = pick_random_offers(pref.number_of_ads,filtered)
        #logger.debug( "Random picked =============")
        create_affiliate_account('flipkart')
        for offer in picked:
            #logger.debug(""+unicode(offer['title'])+","+offer['description'])
            product_info_list = flipkart_scrap_provide_contents(offer['url'],
                offer['title'],pref.number_of_ads)
            logger.info("url : "+unicode(offer['url']) +" title : "+unicode(offer['title']))
            logger.info("FLIPLART_AFFILIATE_CONTENT_PULL_STATS : Category : "+str(pref.category)+
                        " Number of Ads pulled :"+str(len(product_info_list))+
                        " Channels : "+str(len(pref.channels)))
            for product in product_info_list:
                #logger.debug(""+ unicode(product))
                create_affiliate_playlists([product],"flipkart", False,pref.channels,
                    pref.priority,planned_date)
def get_flipkart_offers_today():
        get_flipkart_offers(date.today())
def get_deal_of_the_day():
    logger.info("get_deals")
    url='https://affiliate-api.flipkart.net/affiliate/offers/v1/dotd/json'
    id='digiteyes1'
    token='e84eabb6db59476e8a16bbcce36e5571'
    headers= {"Fk-Affiliate-Id": id,"Fk-Affiliate-Token":token}
    resp = requests.get(url,headers=headers)
    deals = resp.json()
    offer_list = deals['dotdList']
    picked = pick_random_offers(5,offer_list)
    '''
    for offer in picked:
        logger.debug(""+unicode(offer['title'])+","+offer['description'])
        '''
    #create_affiliate_account('flipkart')
    #create_affiliate_playlists(picked)
if __name__ == '__main__':
    get_flipkart_offers("planned_date")
