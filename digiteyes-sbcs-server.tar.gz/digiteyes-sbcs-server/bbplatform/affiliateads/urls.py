
from affiliateads import affiliateadviews
from affiliateads import dynamicscheduleapiviews
from affiliateads import affiliateprefsapiviews
from django.conf.urls import url

urlpatterns = [
    url(r'^api/affiliateads/',
        affiliateadviews.CreateAffiliateAds.as_view()),
    url(r'^api/dynamicschedules/',
        dynamicscheduleapiviews.DynamicScheduleAPIView.as_view()),
    url(r'^api/consumerplaylists/',
        dynamicscheduleapiviews.CreateCuratedPlaylists.as_view()),
    url(r'^api/affiliateprefs/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
        affiliateprefsapiviews.AffiliatePrefsUpdateView.as_view()),
    url(r'^api/affiliateprefs/',
        affiliateprefsapiviews.AffiliatePrefsListView.as_view()),
    ]