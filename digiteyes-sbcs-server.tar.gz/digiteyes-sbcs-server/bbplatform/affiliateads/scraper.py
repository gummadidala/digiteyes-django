'''
Created on 29-Sep-2016

@author: saba
'''

from selenium import webdriver
import time
import re
import logging
import traceback,sys
logger = logging.getLogger("affiliateads.tasks")

#################################################################################
#  Returns HD url for a given url
#################################################################################
def get_hd_url(img_url):
    p= re.compile(r"(\d+)/(\d+)")
    new_path = p.sub("1024/1024",img_url)
    return new_path

def jabong_scrap_provide_contentsold(offer_url):
    try :
        #logger.info('In jabong_scrap_provide_contents')
        img_cls = "catalog-img"
        title_cls = "catalog-product-info"
        driver = webdriver.PhantomJS(service_args=['--ignore-ssl-errors=true', 
            '--ssl-protocol=TLSv1'])
        driver.set_window_size(1024, 768) # optional
        driver.get(offer_url)
        time.sleep(10)
        if driver.current_url != offer_url :
            time.sleep(5)
        elems = driver.find_elements_by_class_name(img_cls)
        title_divs = driver.find_elements_by_class_name(title_cls)
        product_info = {"title":"","images":[]}
        for div in title_divs:
            h1 = div.find_element_by_tag_name("h1")
            product_info["title"] = h1.text
            #logger.info("Production Title:"+str(div.text))
        for elem in elems:
            img_url = elem.get_attribute("src")
            img = elem.find_element_by_tag_name("img")
            if img is not None:
                img_url = img.get_attribute("src")
                if img_url is not None:
                    if 'product.gif' not in img_url:
                        product_info["images"].append(img_url)
                        #logger.debug("Image URL:"+str(img_url))
        driver.close()
        return product_info
    except:
        logger.warn("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        if driver is not None:
            driver.close()
        return None
def paytm_scrap_provide_contentsold(offer_url):
    try :
        #logger.info('In paytm_scrap_provide_contents')
        img_cls = "_3nWP"
        main_class = "_2i1r"
        driver = webdriver.PhantomJS(service_args=['--ignore-ssl-errors=true', 
            '--ssl-protocol=TLSv1'])
        driver.set_window_size(1024, 768) # optional
        driver.get(offer_url)
        time.sleep(10)
        if driver.current_url != offer_url :
            time.sleep(5)
        main_elems = driver.find_elements_by_class_name(main_class)
        product_info_list = []
        for elem in main_elems:
            product_info = {}
            image_cls = elem.find_element_by_class_name(img_cls)
            img  = image_cls.find_element_by_tag_name("img")
            img_url = img.get_attribute("src")
            title = img.get_attribute("alt")
            product_info['image_url'] = img_url
            product_info['title'] = title
            sale_price = elem.find_element_by_class_name("_1kMS")
            listed_price = elem.find_element_by_class_name("dQm2")
            product_info['additional_info'] = {"Listed":listed_price.text,
                                               "Sale":sale_price.text,
                                               "title":title}
            product_info_list.append(product_info)
        driver.close()
        return product_info_list
    except:
        logger.warn("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        if driver is not None:
            driver.close()
        return None

def nnnow_scrap_provide_contents(offer_url):
    try :
        #logger.info('In nnnow_scrap_provide_contents')
        img_cls = "imgWrapper"
        title_cls = ""
        driver = webdriver.PhantomJS(service_args=['--ignore-ssl-errors=true', 
            '--ssl-protocol=TLSv1'])
        driver.set_window_size(1280, 1024) # optional
        driver.get(offer_url)
        time.sleep(10)
        if driver.current_url != offer_url :
            time.sleep(5)
        product_info_list = []
        img_urls = []
        titles=[]
        listed_prices = []
        sale_prices=[]
        
        img_elems = driver.find_elements_by_class_name("imgWrapper")
        for ele in img_elems:
            img = ele.find_element_by_tag_name("img")
            url = img.get_attribute("lazy-img")
            img_url=url.replace("medium","large")
            img_urls.append(img_url)
        title_elems = driver.find_elements_by_class_name("product-name")
        for ele in title_elems:
            title = ele.text
            titles.append(title)
        listprice_elems = driver.find_elements_by_class_name("strike")
        for ele in listprice_elems:
            listed = ele.text
            listed_prices.append(listed)
        saleprice_elems = driver.find_elements_by_class_name("original-price")
        for ele in saleprice_elems:
            sale = ele.text
            sale_prices.append(sale)
        
        i=0
        for i in range(6):
            product_info = {}
            product_info['image_url'] = img_urls[i]
            product_info['title'] = titles[i]
            product_info['additional_info'] = {"Listed":listed_prices[i],
                                               "Sale":sale_prices[i],
                                               "title":titles[i]}
            product_info_list.append(product_info)
            i=i+1
        driver.close()
        return product_info_list
    except:
        logger.warn("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        if driver is not None:
            driver.close()
        return None
    
def flipkart_scrap_provide_contents(offer_url):
    #logger.info('In flipkart_scrap_provide_contents')
    try :
        driver = webdriver.PhantomJS(service_args=['--ignore-ssl-errors=true', 
            '--ssl-protocol=TLSv1'])
        driver.set_window_size(1024, 768) # optional
        driver.get(offer_url)
        time.sleep(10)
        if driver.current_url != offer_url :
            time.sleep(5)
        
        elems = driver.find_elements_by_class_name("Zhf2z-")
        title_divs = driver.find_elements_by_class_name("_2Wy-am")
        product_info = {"title":"","images":[]}
        for div in title_divs:
            product_info["title"] = div.text
            logger.info("Production Title:"+str(div.text))
        for elem in elems:
            img = elem.find_element_by_tag_name("img")
            if img is not None:
                img_url = img.get_attribute("src")
                if img_url is not None:
                    new_url = get_hd_url(img_url)
                    product_info["images"].append(new_url)
                    logger.debug("Image URL:"+str(new_url))
        driver.close()
        return product_info
    except:
        logger.warn("FLIPKART_AFFILIATE_CONTENT_PULL_ERROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("FLIPKART_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        if driver is not None:
            driver.close()
        return None
def limeroad_scrap_provide_contents(offer_url):
    try :
        #print "limeroad_scrap_provide_contents"
        #logger.info('In limeroad_scrap_provide_contents')
        img_cls = "exclusive_tag_div"
        driver = webdriver.PhantomJS(service_args=['--ignore-ssl-errors=true', 
            '--ssl-protocol=TLSv1'])
        driver.set_window_size(1024, 768) # optional
        driver.get(offer_url)
        time.sleep(10)
        if driver.current_url != offer_url :
            time.sleep(5)
        elems = driver.find_elements_by_class_name("scrap-img")
        product_info_list = []
        i=0
        for i in range(len(elems)):
            if i<5: 
                product_info = {}
                img_url = elems[i].get_attribute("src")
                product_info['image_url']=img_url
                product_info['title']='offers with limeroad'
                product_info_list.append(product_info)
                i=i+1
        driver.close()
        return product_info_list
    except:
        logger.warn("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        if driver is not None:
            driver.close()
        return None
def lurap_scrap_provide_contents(offer_url):
    #logger.info('In lurap_scrap_provide_contents')
    try :
        driver = webdriver.PhantomJS(service_args=['--ignore-ssl-errors=true', 
            '--ssl-protocol=TLSv1'])
        driver.set_window_size(1024, 768) # optional
        driver.get(offer_url)
        time.sleep(10)
        if driver.current_url != offer_url :
            time.sleep(5)
        elems = driver.find_elements_by_class_name("white-panel")
        product_info_list = []
        for ele in elems:
            product_info = {}
            img = ele.find_element_by_tag_name("img")
            img_url = img.get_attribute("src")
            product_info['image_url'] = img_url
            product_info['title'] = "lurap-offers"
            product_info_list.append(product_info)
        driver.close()
        return product_info_list
    except:
        logger.warn("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        if driver is not None:
            driver.close()
        return None
def voonik_scrap_provide_contents(offer_url):
    #logger.info('In voonik_scrap_provide_contents')
    try :
        driver = webdriver.PhantomJS(service_args=['--ignore-ssl-errors=true', 
            '--ssl-protocol=TLSv1'])
        driver.set_window_size(1024, 768) # optional
        driver.get(offer_url)
        time.sleep(10)
        if driver.current_url != offer_url :
            time.sleep(5)
        product_info_list=[]
        img_classes = ['item-container-right','item-container-left']
        for cls in img_classes:
            elems = driver.find_elements_by_class_name(cls)
            for ele in elems:
                product_info = {}
                img = ele.find_element_by_tag_name("img")
                img_url = img.get_attribute("src")
                product_info['image_url'] = img_url
                product_info['title'] = "voonik-offers"
                product_info_list.append(product_info)
        driver.close()
        return product_info_list
            
    except:
        logger.warn("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        if driver is not None:
            driver.close()
        return None
def faasos_scrap_provide_contents(offer_url):
    #logger.info('In faasos_scrap_provide_contents')
    try :
        driver = webdriver.PhantomJS(service_args=['--ignore-ssl-errors=true', 
            '--ssl-protocol=TLSv1'])
        driver.set_window_size(1024, 768) # optional
        driver.get(offer_url)
        time.sleep(10)
        if driver.current_url != offer_url :
            time.sleep(5)
        product_info_list=[]
        img_classes = ['offerContainer']
        for cls in img_classes:
            elems = driver.find_elements_by_class_name(cls)
            for ele in elems:
                product_info = {}
                img = ele.find_element_by_tag_name("img")
                img_url = img.get_attribute("src")
                product_info['image_url'] = img_url
                product_info['title'] = "faasos-offers"
                product_info_list.append(product_info)
        driver.close()
        return product_info_list
    except:
        logger.warn("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        if driver is not None:
            driver.close()
        return None
def pepperfry_scrap_provide_contents(offer_url):
    #logger.info('In pepperfry_scrap_provide_contents')
    try :
        driver = webdriver.PhantomJS(service_args=['--ignore-ssl-errors=true', 
            '--ssl-protocol=TLSv1'])
        driver.set_window_size(1024, 768) # optional
        driver.get(offer_url)
        time.sleep(10)
        if driver.current_url != offer_url :
            time.sleep(5)
        product_info_list=[]
        img_classes = ['hp-card-hd']
        for cls in img_classes:
            elems = driver.find_elements_by_class_name(cls)
            for i in range(len(elems)):
                if i<5:
                    product_info = {}
                    img = elems[i].find_element_by_tag_name("img")
                    img_url = img.get_attribute("src")
                    product_info['image_url'] = img_url
                    product_info['title'] = "pepperfry-offers"
                    product_info_list.append(product_info)
                i = i+1
        driver.close()
        return product_info_list
    except:
        logger.warn("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        if driver is not None:
            driver.close()
        return None
def tatacliq_scrap_provide_contents(offer_url):
    try :
        #logger.info('In paytm_scrap_provide_contents')
        img_cls = "_3nWP"
        main_class = "_2i1r"
        driver = webdriver.PhantomJS(service_args=['--ignore-ssl-errors=true', 
            '--ssl-protocol=TLSv1'])
        driver.set_window_size(1024, 768) # optional
        driver.get(offer_url)
        time.sleep(10)
        if driver.current_url != offer_url :
            time.sleep(5)
        img_classes = ['home-best-pick-carousel-img']
        product_info_list = []
        for cls in img_classes:
            elems = driver.find_elements_by_class_name(cls)
            i=0
            for i in range(len(elems)):
                if i<5:
                    product_info = {}
                    img = elems[i].find_element_by_tag_name("img")
                    img_url = img.get_attribute("src")
                    product_info['image_url'] = img_url
                    product_info['title'] = "tatacliq-offers"
                    product_info_list.append(product_info)
                i=i+1
        driver.close()
        return product_info_list
    except:
        logger.warn("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        if driver is not None:
            driver.close()
        return None

def get_hopcoms_rate_list_url(offer_url):
    try:
        driver = webdriver.PhantomJS(service_args=['--ignore-ssl-errors=true', 
                '--ssl-protocol=TLSv1'])
        driver.set_window_size(1024, 768) # optional
        driver.get(offer_url)
        #time.sleep(10)
        #if driver.current_url != offer_url :
        #    time.sleep(5)
        ele = driver.find_element_by_id("ctl00_rates")
        rate_list_url = ele.get_attribute("href")
        driver.close()
        return rate_list_url
    except:
        logger.warn("get_hopcoms_rate_list_url_ERROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("get_hopcoms_rate_list_url_ERROR: "+str(tb))
        if driver is not None:
            driver.close()
        return None
    

def hopcoms_price_list(hopcoms_url):
    try :
        store_menu = []
        rate_list_url = get_hopcoms_rate_list_url(hopcoms_url)
        if rate_list_url is None:
            return store_menu
        driver = webdriver.PhantomJS(service_args=['--ignore-ssl-errors=true', 
            '--ssl-protocol=TLSv1'])
        driver.set_window_size(1024, 768) # optional
        driver.get(rate_list_url)
        try:
            for i in range(2,100):
                if i < 10:
                    key_id = "ctl00_LC_grid1_ctl0"+str(i)+"_Label1"
                    val_id = "ctl00_LC_grid1_ctl0"+str(i)+"_Label2"
                else:
                    key_id = "ctl00_LC_grid1_ctl"+str(i)+"_Label1"
                    val_id = "ctl00_LC_grid1_ctl"+str(i)+"_Label2"
                st = ""
                st +=driver.find_element_by_id(key_id).text + " : "
                st += driver.find_element_by_id(val_id).text
                store_menu.append(st)
        except:
            pass
        try:
            for i in range(2,100):
                if i < 10:
                    key_id = "ctl00_LC_grid1_ctl0"+str(i)+"_Label3"
                    val_id = "ctl00_LC_grid1_ctl0"+str(i)+"_Label4"
                else:
                    key_id = "ctl00_LC_grid1_ctl"+str(i)+"_Label3"
                    val_id = "ctl00_LC_grid1_ctl"+str(i)+"_Label4"
                def_str = " : "
                st = ""
                st +=driver.find_element_by_id(key_id).text + def_str
                st += driver.find_element_by_id(val_id).text
                if st != def_str:
                    store_menu.append(st)
        except:
            pass
        return store_menu
    except:
        logger.warn("hopcoms_price_list_ERROR "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("hopcoms_price_list_ERROR: "+str(tb))
        return store_menu

#################################################################################
# Scrapes the web to find more information about the offer
#################################################################################
def scrap_provide_contents(offer_url,cmpny):
    if cmpny == "jabong":
        return jabong_scrap_provide_contents(offer_url)
    elif cmpny == "tatacliq":
        return tatacliq_scrap_provide_contents(offer_url)
    elif cmpny == "limeroad":
        return limeroad_scrap_provide_contents(offer_url)
    elif cmpny == "nnnow":
        return nnnow_scrap_provide_contents(offer_url)
    elif cmpny == "flipkart":
        return flipkart_scrap_provide_contents(offer_url)
    elif cmpny == "lurap":
        return lurap_scrap_provide_contents(offer_url)
    elif cmpny == "voonik":
        return voonik_scrap_provide_contents(offer_url)
    elif cmpny == "faasos":
        return faasos_scrap_provide_contents(offer_url)
    elif cmpny == "pepperfry":
        return pepperfry_scrap_provide_contents(offer_url)

if __name__ == '__main__':
    #get_hd_url("https://rukminim1.flixcart.com/image/312/312/sari/w/g/p/1-1-2069-tus-offwt-mimosa-original-imaed32ddnswvzh5.jpeg?q=70")
    url = 'https://paytm.com/shop/g/paytm-home/sunday-bazaar-deals?utm_source=Affiliates&utm_medium=Payoom&utm_term={affiliate_id}{transaction_id}&utm_campaign=Payoom'
    #prod_info = scrap_provide_contents("http://dl.flipkart.com/dl/womens-clothing/~onam-sarees/pr?sid=2oq%2Cc1r&p%5B%5D=facets.discount_range%255B%255D%3DMore%2Bthan%2B50%2525&p%5B%5D=facets.discount_range%255B%255D%3D40%2525%2B-%2B50%2525&p%5B%5D=facets.filter_standard%255B%255D%3D1&affid=digiteyes1")
    img_scrapper_class = "_3nWP"
    title_scrapper_class = "_lqXr"
    prod_info = scrap_provide_contents(url,img_scrapper_class,title_scrapper_class)
    print str(prod_info)