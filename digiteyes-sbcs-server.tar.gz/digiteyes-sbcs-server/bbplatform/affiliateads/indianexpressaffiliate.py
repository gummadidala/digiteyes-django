'''
Created on 01-Dec-2016

@author: saba
'''
import feedparser
from selenium import webdriver
import time
import logging
import traceback
from datetime import date
from affiliateprefsprovider import get_affiliate_prefs
from createaffiliatecontent import create_affiliate_playlists_today,create_affiliate_account,create_affiliate_playlists
logger = logging.getLogger("affiliateads.tasks")


def create_offer_for_news(news_title,desc,thumbnail,img,url):
    offer = {}
    offer["description"] = desc
    offer["images"] = []
    offer["url"] = url
    offer["title"] = news_title
    offer["images"].append(img)
    offer['imageUrls'] = [{"resolutionType":'mid','url':thumbnail}]
    return offer
def scrap_provide_contents(news_url):
    #logger.info('In Indian Express Scrap provide contents')
    try :
        driver = webdriver.PhantomJS(service_args=['--ignore-ssl-errors=true', 
            '--ssl-protocol=TLSv1'])
        driver.set_window_size(1024, 768) # optional
        driver.get(news_url)
        time.sleep(10)
        if driver.current_url != news_url :
            time.sleep(5)
        
        elems = driver.find_elements_by_class_name("synopsis")
        news_text =""
        for elem in elems:
            news_text = elem.text
        driver.close()
        return news_text
    except:
        logger.error ("IE_AFFILIATE_CONTENT_PULL_EEEOR"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("IE_AFFILIATE_CONTENT_PULL_EEEOR "+str(tb))
        driver.close()
        return None

def get_feed_url_for_category(category):
    if category == 'news':
        return 'http://indianexpress.com/section/india/feed/'
    if category == 'sports':
        return 'http://indianexpress.com/section/sports/feed/'
    if category == 'health':
        return 'http://indianexpress.com/section/lifestyle/health/feed/'
    if category == 'entertainment':
        return 'http://indianexpress.com/section/entertainment/feed/'
    return None

def collect_news(number_of_items,feed_url):
    feed = feedparser.parse(feed_url)
#    print feed.title
    count = 0
    offers = []
    for item in feed.entries:
        title=item.title
        if 'media_thumbnail' not in item :
            continue
        thumbnail=item.media_thumbnail[0]['url']
        #print item.link
        news=scrap_provide_contents(item.link)
        #print news
        image=''
        for content in item.media_content:
            image=content['url']
        offer=create_offer_for_news(title,news,thumbnail,image,item.link)
        offers.append(offer)
        #print str(offer)
        count +=1
        if count >= number_of_items:
            break
    return offers
def collect_news_from_ie(planned_date):
    create_affiliate_account('indianexpress')
    prefs=get_affiliate_prefs("indianexpress",planned_date)
    for pref in prefs:
        #print pref.category
        feed_url = get_feed_url_for_category(pref.category)
        if feed_url is not None:
            offers = collect_news(pref.number_of_ads,feed_url)
            logger.info("IE_AFFILIATE_CONTENT_PULL_STATS : Category : "+str(pref.category)+
                        " Number of Ads pulled :"+str(len(offers))+
                        " Channels : "+str(len(pref.channels)))
            for offer in offers:
                create_affiliate_playlists([offer],'indianexpress',False,
                    pref.channels,pref.priority,planned_date)
def collect_news_from_ie_today():
    collect_news_from_ie(date.today())
    
if __name__ == '__main__':
    collect_news_from_ie()