'''
Created on 30-Sep-2016

@author: saba
'''
from __future__ import absolute_import
from celery import shared_task


import logging
from datetime import timedelta,datetime,date
from django.contrib.auth.models import User, Permission
from django.db.models import Q
from boardcontentmgmt.tasks import send_email,send_email_ses,send_sms_plivo
from bbplatform.settings import HOSTING_SERVER,Adiot_logo_url
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from django.template import Context
from boardcontentmgmt.models import AffiliateContent, AccountUser
from affiliateads.flipkartaffiliate import get_flipkart_offers_today,get_flipkart_offers
from affiliateads.amazonaffiliate import get_amazon_offers_today,get_amazon_offers
from affiliateads.payoomaffiliate import get_payoom_offers_today,get_payoom_offers
from affiliateads.indianexpressaffiliate import collect_news_from_ie,collect_news_from_ie_today
from affiliateads.adsfromfacebook import create_facebook_ads, create_ads_from_fb_events
from affiliateads.snapdealaffiliate import get_snapdeal_deals_today, get_snapdeal_deals
import traceback,sys
logger = logging.getLogger(__name__)

def approve_contents_email_notification():
    logger.info("CONTENTS_EMAIL_NOTIFICATION_START")
    try:
        perm = Permission.objects.get(codename='can_approve_content')
        users = User.objects.filter(Q(groups__permissions=perm) | Q(user_permissions=perm)).distinct()
        if users is not None and len(users)>0:
            logger.debug("total content approval users : "+str(len(users)))
            for usr in users:
                user_email = usr.email
                user_name = usr.first_name +" "+ usr.last_name
                logger.debug("attempting to send email to " +str(user_email))
                link = HOSTING_SERVER+'contentmgmt/contentapproval'
                htmly  = get_template('approve_contents_notification.html')
                d = Context({ 'link': link,'username':user_name,'logo_url':Adiot_logo_url})
                subject = 'Approve contents!'
                html_content = htmly.render(d)
                #send_email.delay(user_email,subject,html_content,link,"")
                send_email_ses.delay(user_email,subject,html_content,link,"")
                logger.info('content approval notification mail sent successfully to: '+str(user_email))
                txt_msg = " New contents are awaiting your approval. Your action is required"
                phone_numbers = [AccountUser.objects.filter(account_user__username=usr.username)[0].account_user_phone_no]
                send_sms_plivo(user_name, txt_msg, phone_numbers)
        else:
            logger.debug("total content approval users : "+str(len(users)))
    except:
        logger.error ("CONTENTS_EMAIL_NOTIFICATION_ERROR"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("CONTENTS_EMAIL_NOTIFICATION_ERROR: "+str(tb))
    logger.info("CONTENTS_EMAIL_NOTIFICATION_END")

@shared_task    
def load_all_affiliate_contents():
    
    logger.info("AFFILIATE_CONTENT_PULL_START")
    try:
        
        logger.info("AMAZON_AFFILIATE_CONTENT_PULL_START")
        print 'AMAZON'
        try:
            get_amazon_offers_today()
        except:
            logger.error ("AMAZON_AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("AMAZON_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        logger.info("AMAZON_AFFILIATE_CONTENT_PULL_END")
        
        logger.info("FLIPKART_AFFILIATE_CONTENT_PULL_START")
        print 'FLIPKART'
        try:
            get_flipkart_offers_today()
        except:
            logger.error ("FLIPKART_AFFILIATE_CONTENT_PULL_EEEOR"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("FLIPKART_AFFILIATE_CONTENT_PULL_EEEOR: "+str(tb))
        logger.info("FLIPKART_AFFILIATE_CONTENT_PULL_END")
        
        logger.info("PAYOOM_AFFILIATE_CONTENT_PULL_START")
        print "PAYOOM"
        try:
            get_payoom_offers_today()
        except:
            logger.error ("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        logger.info("PAYOOM_AFFILIATE_CONTENT_PULL_END")
        
        logger.info("SNAPDEAL_AFFILIATE_CONTENT_PULL_START")
        print 'SNAPDEAL'
        try:
            get_snapdeal_deals_today()
        except:
            logger.error ("SNAPDEAL_AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("SNAPDEAL_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        logger.info("SNAPDEAL_AFFILIATE_CONTENT_PULL_END")
        
        logger.info("IE_AFFILIATE_CONTENT_PULL_START")
        print 'INDIAN EXPRESS'
        try:
            collect_news_from_ie_today()
        except:
            logger.error ("IE_AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("IE_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        logger.info("IE_AFFILIATE_CONTENT_PULL_END")
    
        logger.info("FACEBOOK_ADS_AFFILIATE_CONTENT_PULL_START")
        try:
            create_facebook_ads(date.today())
        except:
            logger.error ("FACEBOOK_ADS_AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("FACEBOOK_ADS_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        logger.info("FACEBOOK_ADS_AFFILIATE_CONTENT_PULL_END")
    
        logger.info("FACEBOOK_EVENTS_AFFILIATE_CONTENT_PULL_START")
        try:
            create_ads_from_fb_events(date.today())
        except:
            logger.error ("FACEBOOK_EVENTS_AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("FACEBOOK_EVENTS_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        logger.info("FACEBOOK_EVENTS_AFFILIATE_CONTENT_PULL_END")
        
        logger.info("Calling approve_contents_email_notification()")
        approve_contents_email_notification()
        
    except:
        logger.error ("AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
    
    logger.info(" AFFILIATE_CONTENT_PULL_END")
        
@shared_task    
def load_all_affiliate_contents_automatic(play_date=None):    
    logger.info("AFFILIATE_CONTENT_PULL_START")
    try:
        if play_date is not None:
            date = datetime.strptime(play_date,"%Y-%m-%d").date()
        else:
            date=datetime.now().date()+timedelta(days=1)
        logger.info("AFFILIATE_CONTENT_PULL for date : "+str(date))
        
        logger.info("AMAZON_AFFILIATE_CONTENT_PULL_START")
        try:
            get_amazon_offers(date)
        except:
            logger.error ("AMAZON_AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("AMAZON_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        logger.info("AMAZON_AFFILIATE_CONTENT_PULL_END")
        
        logger.info("FLIPKART_AFFILIATE_CONTENT_PULL_START")
        try:
            get_flipkart_offers(date)
        except:
            logger.error ("FLIPKART_AFFILIATE_CONTENT_PULL_EEEOR"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("FLIPKART_AFFILIATE_CONTENT_PULL_EEEOR: "+str(tb))
        logger.info("FLIPKART_AFFILIATE_CONTENT_PULL_END")
        
        logger.info("PAYOOM_AFFILIATE_CONTENT_PULL_START")
        try:
            get_payoom_offers(date)
        except:
            logger.error ("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("PAYOOM_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        logger.info("PAYOOM_AFFILIATE_CONTENT_PULL_END")
        
        logger.info("SNAPDEAL_AFFILIATE_CONTENT_PULL_START")
        try:
            get_snapdeal_deals(date)
        except:
            logger.error ("SNAPDEAL_AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("SNAPDEAL_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        logger.info("SNAPDEAL_AFFILIATE_CONTENT_PULL_END")
        
        logger.info("IE_AFFILIATE_CONTENT_PULL_START")
        try:
            collect_news_from_ie(date)
        except:
            logger.error ("IE_AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("IE_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        logger.info("IE_AFFILIATE_CONTENT_PULL_END")
        
        logger.info("FACEBOOK_ADS_AFFILIATE_CONTENT_PULL_START")
        try:
            create_facebook_ads(date)
        except:
            logger.error ("FACEBOOK_ADS_AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("FACEBOOK_ADS_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        logger.info("FACEBOOK_ADS_AFFILIATE_CONTENT_PULL_END")
        
        logger.info("FACEBOOK_EVENTS_AFFILIATE_CONTENT_PULL_START")
        try:
            create_ads_from_fb_events(date)
        except:
            logger.error ("FACEBOOK_EVENTS_AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
            tb = traceback.format_exc()
            logger.error ("FACEBOOK_EVENTS_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        logger.info("FACEBOOK_EVENTS_AFFILIATE_CONTENT_PULL_END")
        
        logger.info("Calling approve_contents_email_notification()")
        approve_contents_email_notification()
    except:
        logger.error ("AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
        
    logger.info("AFFILIATE_CONTENT_PULL_END")

@shared_task    
def pull_news_latest():
    logger.info("LATEST_IE_AFFILIATE_CONTENT_PULL_START")
    try:
        all_existing_news = AffiliateContent.objects.filter(planned_date=date.today(),play_list__layout__name='NEWS')
        if all_existing_news is not None and len(all_existing_news)>0:
            for obj in all_existing_news:
                priority = obj.play_order
                obj.play_order = priority+len(all_existing_news)
                obj.save()
        logger.info("IE_AFFILIATE_CONTENT_PULL_START")
        collect_news_from_ie_today()
        logger.info("IE_AFFILIATE_CONTENT_PULL_END")
        
        logger.info("Calling approve_contents_email_notification()")
        approve_contents_email_notification()
    except:
        logger.error ("LATEST_IE_AFFILIATE_CONTENT_PULL_ERROR"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("LATEST_IE_AFFILIATE_CONTENT_PULL_ERROR: "+str(tb))
    
    logger.info("LATEST_IE_AFFILIATE_CONTENT_PULL_END")

