import requests
import random
import string
import logging
from datetime import date
from createaffiliatecontent import create_affiliate_account, create_affiliate_playlists
from affiliateads.scraper import scrap_provide_contents
logger = logging.getLogger("affiliateads.tasks")
from affiliateprefsprovider import get_affiliate_prefs
def select_one_url_from_company(res_list,companies_list):
    final_list = []
    for url in res_list:
        for cmpny in companies_list:
            if cmpny in url['offer_url']:
                final_list.append(url)
                companies_list.remove(cmpny) 
    return final_list
                
def sort_diff_companies_urls(offer_url_list,companies_list,category):
    res_list = []
    for url in offer_url_list:
        if any(cmpny in url['offer_url'] for cmpny in companies_list):# and category in url['offer_url']:
            res_list.append(url)
    return select_one_url_from_company(res_list,companies_list)

def get_offer_urls(offers,companies_list,category):
    offer_url_list = []
    for i in range(1000):
        if str(i) in offers['response']['data']:
            offer_url_list.append(offers['response']['data'][str(i)]['OfferUrl'])
        i += 2
    return sort_diff_companies_urls(offer_url_list,companies_list,category)
    
def re_create_objectforindividual(offer_url,product_info):
    image_urls = [{'resolutionType':"mid",
                   'url':product_info['image_url']}]
    obj = {'url':offer_url,
           'title':product_info['title'],
           'category':'',
           'description':product_info['title'],
           'imageUrls':image_urls,
           'images':[product_info['image_url']]
           }    
    return obj
def re_create_object_forbunch(offer_url,product_info):
    image_urls = []
    urls = []
    for each_image_url in product_info['images']:
        obj = {'url':each_image_url,
               'resolutionType':'mid'}
        urls.append(each_image_url)
        image_urls.append(obj)
    obj = {'url':offer_url,
           'title':product_info['title'],
           'category':'',
           'description':product_info['title'],
           'imageUrls':image_urls,
           'images':urls
           }    
    return obj
def get_payoom_offers_old(planned_date):
    logger.info("get_payoom_offers")
    url = 'https://api.hasoffers.com/Apiv3/json?NetworkId=payoom&Target=Affiliate_OfferUrl&Method=findAll&api_key=3dfbc4e3e86850f10cc15faa8ee1461de3e0f1014a3168350a97d15fcd0bd1be&fields%5B%5D=name&fields%5B%5D=offer_url&fields%5B%5D=status&fields%5B%5D=id'
    resp = requests.get(url)
    offers = resp.json()
    companies_list = ['jabong','paytm','limeroad','nnnow']
    category = 'clothing'
    picked_offers_companies = get_offer_urls(offers,companies_list,category)
    #companies_list = ['limeroad']
    companies_list = ['jabong','paytm','nnnow']
    for cmpny in companies_list:
        for each_offer in picked_offers_companies: 
            create_affiliate_account(cmpny)
            prefs = get_affiliate_prefs(cmpny,planned_date)
            if prefs is None or len(prefs) == 0 :
                continue
            channels = prefs[0].channels
            priority = prefs[0].priority
            if cmpny in each_offer['offer_url']:
                print 'processing for ',cmpny  
                print "offer_url",each_offer['offer_url']
                if cmpny == 'jabong':
                    product_info = scrap_provide_contents(each_offer['offer_url'],cmpny)
                    each_offer = re_create_object_forbunch(each_offer,product_info)
                    create_affiliate_playlists([each_offer],cmpny, False,channels,
                                               priority,planned_date)
                else:
                    product_info = scrap_provide_contents(each_offer['offer_url'],cmpny)
                    offer_list = []
                    for product in product_info:
                        each_product = re_create_objectforindividual(each_offer,product)
                        offer_list.append(each_product)
                    create_affiliate_playlists(offer_list,cmpny, False,channels,
                                                   priority,planned_date)
def get_payoom_offers(planned_date):
    #companies_list = ['jabong','paytm','lurap','limeroad','microsoft','voonik','tatacliq','faasos',
    #                  'makemytrip','oyo','pepperfry']
    companies_list = ['limeroad','lurap','voonik','faasos','pepperfry','tatacliq']
    #companies_list = ['tatacliq']
    payoom_urls = ["http://www.jabong.com/?utm_source=cps_payoom&utm_medium=dc-clicktracker&utm_campaign=29394",
                   "https://paytm.com/shop?utm_source=Payoom&utm_medium=affiliate&utm_term=29394102e9d85214dd098113adc7f760402&utm_campaign=Payoom",
                   "https://www.lurap.com/?utm_source=affiliate_id2017_02&utm_campaign=affiliate",
                   "https://www.limeroad.com/?utm_source=affiliates&utm_medium=payoom_paid&utm_campaign=29394",
                   "https://www.microsoftstore.com/store/msin/en_GB/home/?tduid=(d40257d7e74fae920c9e8278d70c6591)(235158)(2921315)(29394)()",
                   "https://www.voonik.com/?utm_source=affiliates&utm_medium=payoom&utm_campaign=cps-29394",
                   "https://www.tatacliq.com/?cid=af:homepage:payoom:deal:29394",
                   "https://order.faasos.io/?utm_source=PM&utm_medium=CS&utm_campaign=Website29394",
                   "https://www.makemytrip.com/flights/?cmp=disp_payoom_df_29394-",
                   "https://www.oyorooms.com/?utm_source=n11&utm_campaign=CPS&utm_medium=aff_3%2029394",
                   "https://www.pepperfry.com/?utm_source=aff&utm_medium=payoom&utm_campaign=payoom29394",
                   "https://freshmenu.com/?utm_source=Payoom&utm_medium=referral_cpv&utm_campaign=29394"]
    for cmpny in companies_list:
        for url in payoom_urls:
            if cmpny in url:  
                logger.info(cmpny)
                logger.info("url : "+str(url))
                create_affiliate_account(cmpny)
                prefs = get_affiliate_prefs(cmpny,planned_date)
                if prefs is None or len(prefs) == 0 :
                    continue
                channels = prefs[0].channels
                priority = prefs[0].priority
                product_info_list = scrap_provide_contents(url,cmpny)
                offer_list = []
                for info in product_info_list:
                    offer = re_create_objectforindividual(url,info)
                    offer_list.append(offer)
                logger.info("PAYOOM_AFFILIATE_CONTENT_PULL_STATS : "+
                        " Number of Ads pulled :"+str(len(offer_list))+
                        " Channels : "+str(len(channels)))
                create_affiliate_playlists(offer_list,cmpny, False,channels,
                                                   priority,planned_date)
                
def get_payoom_offers_today():
    get_payoom_offers(date.today())