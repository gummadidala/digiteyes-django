from rest_framework.views import APIView
from rest_framework.response import Response
import requests,datetime
from .tasks import load_all_affiliate_contents, load_all_affiliate_contents_automatic
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework.permissions import DjangoModelPermissions, IsAuthenticated


class CreateAffiliateAds(APIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, )
    def post(self,request):
        if 'play_date' not in request.data:
            play_date = datetime.datetime.now().date().strftime("%Y-%m-%d")
        else:
            play_date = request.data['play_date']
        #load_all_affiliate_contents.delay()
        load_all_affiliate_contents_automatic.delay(play_date)
        return Response({'status':'Success'})
