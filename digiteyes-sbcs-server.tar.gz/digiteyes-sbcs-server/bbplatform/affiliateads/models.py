from __future__ import unicode_literals

from django.db import models
from boardcontentmgmt.models import Account, DayPart

# Create your models here.

    
    
    
