'''
Created on 30-Sep-2016

@author: saba
'''
import os, string,random
import urllib2,urllib
from os.path import isfile, join
from os import listdir
import zipfile
import sys  
import traceback
from boto.s3.connection import S3Connection
from boto.s3.key import Key
import logging
from boardcontentmgmt.tasks import upload_file_to_remote_storage
logger = logging.getLogger("affiliateads.tasks")
#################################################################################
# Creates a random temp file
#################################################################################
def create_random_temp_file(keyword,extn):
    temppath = '/tmp/'
    fileName = keyword
    random_name = ''.join(random.choice(string.ascii_lowercase + 
        string.ascii_uppercase + string.digits) for i in range(10))
    fileName += random_name+'.'+extn  
    if os.path.exists(temppath+fileName) :
        os.remove(temppath+fileName)
    return temppath+fileName

def download_url(url,path,name):
    try:
        try:
            testfile = urllib.URLopener()
            testfile.retrieve(url, path+'/'+name)
        except:
            logger.debug("Exception happened with urlib, so trying with urllib2")
            hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                   'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
                   'Accept-Encoding': 'none',
                   'Accept-Language': 'en-US,en;q=0.8',
                   'Connection': 'keep-alive'}
            req = urllib2.Request(url, headers=hdr)
            page = urllib2.urlopen(req)
            with open(path+"/"+name,'wb') as output:
                output.write(page.read())
    except:
        logger.error ("Error happened retrieving url "+str(url)+ " "+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("Stack Trace: "+str(tb))
        return False
    return True
    
def zip_individual_images(folder,name):
    onlyfiles = [f for f in listdir(folder) if isfile(join(folder, f))]
    temp_file=create_random_temp_file(name+'_image_bunch', '.zip')
    with zipfile.ZipFile(temp_file, 'w') as bunch_zip:
        for iFile in onlyfiles:
            bunch_zip.write(join(folder, iFile),iFile)
        bunch_zip.close()
    return temp_file

def upload_file_to_s3(filePath,name_of_key):
    conn = S3Connection('AKIAIU5QBFMYBBQ4DM4Q','jl9Ac+LTgkRQfJTS6b9HJeByHwt6JjfrPTHtaPaz')
    bucket_name = 'ruga-boardcontentmgmt-uploaded-media-content'
    bucket=conn.get_bucket(bucket_name)
    k = Key(bucket)
    k.key = name_of_key
    k.set_contents_from_filename(filePath)
    k.make_public()
    thumb_url = k.generate_url(expires_in=0,query_auth=False)
    thumb_url = thumb_url.split('?', 1)[0]
    return thumb_url
    
def create_image_bunch(image_list,name,num_required):
    folder = create_random_temp_file("temp_images_folder", "for_bunch")
    os.mkdir(folder)
    i =1
    for img in image_list:
        if download_url(img, folder, "image"+str(i)):
            if i >= num_required:
                break
            i=i+1
            
    created_file = zip_individual_images(folder, name)
    #url = upload_file_to_s3(created_file, name)
    url = upload_file_to_remote_storage(created_file,name,"","image/jpeg",'MEDIA')
    if os.path.exists(created_file):
        os.remove(created_file)
    onlyfiles = [f for f in listdir(folder) if isfile(join(folder, f))]
    
    for iFile in onlyfiles:
        if os.path.exists(join(folder,iFile)):
            os.remove(join(folder,iFile))
    if os.path.exists(folder):
        os.rmdir(folder)
    return url

if __name__ == '__main__':
    print "I am in main()"
    images = ['https://rukminim1.flixcart.com/image/1024/1024/sari/w/g/p/1-1-2069-tus-offwt-mimosa-original-imaed32ddnswvzh5.jpeg?q=70',
        'https://rukminim1.flixcart.com/image/1024/1024/sari/u/e/d/1-1-ekep-e-vastram-original-imaeftgcj5n8kwrg.jpeg?q=70',
        'https://rukminim1.flixcart.com/image/1024/1024/sari/x/1024/1024/kjs-kerala-kasavau-kj-s-original-imaefaafurnbstcp.jpeg?q=70',
        'https://rukminim1.flixcart.com/image/1024/1024/sari/q/g/z/1-1-mk1631-pavechas-original-imae5hhxcjpgwqq7.jpeg?q=70', 
        'https://rukminim1.flixcart.com/image/1024/1024/sari/e/e/n/1-1-kasavu-sudha-creations-original-imae8f4ggwwhfc2y.jpeg?q=70', 
        'https://rukminim1.flixcart.com/image/1024/1024/sari/r/f/u/1-1-weave-400-alankrita-original-imaee4w3gvfbygaa.jpeg?q=70']
    create_image_bunch(images,"testing-bunch",5)