'''
Created on 07-Dec-2016

@author: saba
'''
from boardcontentmgmt.models import FacebookSettings, SystemConfiguration, CTA,\
    AdvtCampaign, CampaignState, BookedAdPack, BookingState, DayPart,\
    AttributeTagGroup
from boardcontentmgmt.models import CTAType, ContentTarget, ContentQueue, ContentSchedule,ContentLabel
from boardcontentmgmt.models import Layout, Content, ContentType, ContentState, AccountUser,SubordinateContent
from facebookaffiliate import get_facebook_posts, get_facebook_events
from datetime import datetime, timedelta, date
from affiliateprefsprovider import get_affiliate_prefs
from boardcontentmgmt.utilities.freeslotutilities import get_screens_for_tags, get_board_num_free_slots_against_order
from createaffiliatecontent import create_affiliate_account, create_affiliate_playlists
import random
import string
import logging
logger = logging.getLogger("affiliateads.tasks")


def create_subordinate_content(cntnt,i,act,type):
    sub_cnt = SubordinateContent()
    sub_cnt.name = 'SubordinateContent'+str(i)
    sub_cnt.type = ContentType.objects.get(type_name=type)
    if type == 'TEXT':
        sub_cnt.text = unicode(cntnt)
    elif type=='IMAGE':
        sub_cnt.url = cntnt
    sub_cnt.account = act
    sub_cnt.content_label = ContentLabel.objects.filter(name = "SUB"+str(i))[0]
    sub_cnt.save()
    return sub_cnt

def create_cta(offer,account):
    cta = CTA()
    cta.type = CTAType.objects.get(name='APP')
    cta.app_name = 'facebook'
    cta.app_link = offer['url']
    cta.account = account
    cta.save()
    return cta

def create_content_target(offer,account):
    ct = ContentTarget()
    ct.account = account
    ct.target_title = offer['title']
    ct.target_description = offer['description']
    for img in offer['imageUrls']:
        if img['resolutionType'] == "mid":
            ct.target_image_url = img['url']
    ct.save()
    return ct

def create_play_list(cont,qname,account,account_user):
    cq = ContentQueue()
    cq.content_queue_name = qname
    cs = ContentSchedule()
    cs.content = cont
    cs.repeat = 1
    cq.account = account
    cq.content_queue_owner = account_user
    cq.save()
    cs.save()
    cq.content_list = [cs]
    cq.queue_state = 'SEALED'
    cq.num_units = 1
    if cont.content_type.type_name == 'IMAGE':
        cq.unit_size = 10
    else:
        cq.unit_size = 30
    #layout=Layout.objects.filter(name = "LAYERED")
    layout=Layout.objects.filter(name = "AFFILIATE_ADVERTISEMENT")
    if layout is not None and len(layout) >0:   
        cq.layout = layout[0]
    cq.save()
    return cq
def create_content(offer, account,account_user):
    cont = Content()
    cont.content_name = offer['title']+''.join(
            random.choice(string.ascii_lowercase + string.ascii_uppercase + 
            string.digits) for i in range(5))
    cont.content_type = ContentType.objects.get(type_name='IMAGE')
    cont.content_source = offer['images'][0]
    cont.content_play_time = timedelta(seconds=10)
        
    cont.account = account 
    cont.content_owner = account_user
    cont.content_state = ContentState.objects.get(state_name='SUBMITTED')
    cont.save()
    subordinate_content_list = []
    subordinate_content_list.append(create_subordinate_content("",1,account,"TEXT"))
    subordinate_content_list.append(create_subordinate_content(offer['title'],2,account,"TEXT"))
    subordinate_content_list.append(create_subordinate_content("",3,account,"TEXT"))
    cont.subordinate_content = subordinate_content_list
    cont.save()
    return cont

def get_fb_access_token():
    fb_access_token=''
    long_token_config = SystemConfiguration.objects.filter(name='FB_LONG_TOKEN')
    if long_token_config is not None and len(long_token_config) >0:
        fb_access_token=long_token_config[0].value
    long_token_config_gen = SystemConfiguration.objects.filter(name='FB_LONG_TOKEN_GENERATED_TIME')
    if long_token_config_gen is not None and len(long_token_config_gen) >0:
        gen_time=long_token_config_gen.value
    return fb_access_token

def book_adpacks(dayPart,booking_date,screen,plays,campaign,account):
    bap = BookedAdPack()
    bap.booked_screen = screen
    bap.applied_to = campaign
    bap.date_booked_for = booking_date
    bap.day_part_booked_for = dayPart
    bap.account = account
    bap.units_per_play = 1
    bap.unit_size = 10
    bap.num_plays = plays
    bap.price = 0.0
    bap.when_booked = datetime.now()
    bap.booking_state = BookingState.objects.get(name='SUCCESS')
    bap.save()

def create_campaign_booking(cq,channels,pack_name,account,user,planned_date):
    #planned_date = date.today()
    campaign = AdvtCampaign()
    campaign.name = cq.content_queue_name
    campaign.account = account
    campaign.owner = user
    campaign.state = CampaignState.objects.get(state_name='PLANNED')
    campaign.play_list = cq
    campaign.planned_start_date = planned_date
    campaign.planned_end_date = planned_date
    campaign.save()
    min_plays_to_book=12
    dayParts = DayPart.objects.all()
    channels_to_promote = channels.split(',')
    group_tags = AttributeTagGroup.objects.filter(name__in=channels_to_promote)
    screens = get_screens_for_tags([],group_tags.all())
    for part in dayParts.all():
        for screen in screens:
            free_slots = get_board_num_free_slots_against_order(screen,planned_date,
                part.from_time,part.to_time,part)
            if (min_plays_to_book *10) < free_slots * 30 :
                book_adpacks(part,planned_date,screen,min_plays_to_book,campaign,account)
##################################################################################
# Reads Facebook settings of all Accounts and loads content from Facebook pages. 
##################################################################################
def create_facebook_ads(planned_date):
    all_fbs = FacebookSettings.objects.filter(enable=True)
    fb_access_token=get_fb_access_token()
    for fb_settings in all_fbs:
        from_date = datetime.now() - timedelta(days=fb_settings.posts_from_days_in_past)
        ad_lists = get_facebook_posts(from_date, fb_settings.fb_page_id, 
            fb_settings.page_owner_id, fb_access_token)
        '''
        logger.info("FB_ADS_CONTENT_PULL_STATS : Category : "+str(pref.category)+
                        " Number of Ads pulled :"+str(len(ad_lists))+
                        " Channels : "+str(len(pref.channels)))
                        '''
        for ad in ad_lists:
            account = fb_settings.account
            cta = create_cta(ad, account)
            ct = create_content_target(ad, account)
            user = AccountUser.objects.all()[0]
            cont = create_content(ad, account, user)
            ct.target_cta = [cta]
            ct.save()
            cont.content_target = ct
            cont.save()
            qname=ad['title']+''.join(
            random.choice(string.ascii_lowercase + string.ascii_uppercase + 
            string.digits) for i in range(5))
            cq = create_play_list(cont, qname, account, user)
            create_campaign_booking(cq,fb_settings.channels_to_promote,"",
                account,user,planned_date)
            
def create_ads_from_fb_events(planned_date):
    fb_access_token=get_fb_access_token()
    create_affiliate_account("fbevents")
    prefs = get_affiliate_prefs('fbevents',planned_date)
    events = get_facebook_events(fb_access_token,prefs[0].number_of_ads)
    logger.info("FB_EVENTS_CONTENT_PULL_STATS : Category : "+str(prefs[0].category)+
                        " Number of Ads pulled :"+str(len(events))+
                        " Channels : "+str(len(prefs[0].channels)))
    for event in events:
        create_affiliate_playlists([event],"fbevents",False,prefs[0].channels,
            prefs[0].priority,planned_date)
    
    
        