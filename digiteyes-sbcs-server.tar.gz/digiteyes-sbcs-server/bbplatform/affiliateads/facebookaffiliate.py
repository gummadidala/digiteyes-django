'''
Created on 02-Dec-2016

@author: saba
'''
import facebook
from datetime import datetime

def get_high_def_image(images):
    max_width=0
    index = -1
    i=0
    for image in images:
        if int(image['width']) > max_width:
            max_width = int(image['width'])
            index = i
        i+=1
    if index >=0 :
        return images[index]
def get_small_image(images):
    min_width=99999
    index = -1
    i=0
    for image in images:
        if int(image['width']) < min_width:
            min_width = int(image['width'])
            index = i
        i+=1
    if index >=0 :
        return images[index]

def get_post_details(post_id,fb_access_token,from_id):
    #print str(post_id)
    graph = facebook.GraphAPI(access_token=fb_access_token, version='2.5')
    data = graph.get_object(id=post_id,fields="images,from")
    #print "from...."+str(data['from'])
    if from_id == str(data['from']['id']) :
        #for image in data['images']:
            #print str(image)
        hd_image = get_high_def_image(data['images'])
        #print str(hd_image)
        small_img = get_small_image(data['images'])
        #print str(small_img)
        return {'hd':hd_image,'small':small_img}
    return None

###################################################################################
# Gets all the facebook posts (photos) for the given page, posted by given id from
# the given date.
####################################################################################
def get_facebook_posts(from_date,fb_page_id,from_id,fb_access_token):
    graph = facebook.GraphAPI(access_token=fb_access_token, version='2.5')
    posts = graph.get_connections(id=fb_page_id, connection_name='feed', fields='type,created_time,message,id,link,object_id')
    from_dt = from_date 
    ad_info_list=[]
    #print str(from_dt)
    for post in posts['data']:
        ad_info={}
        posted_date = datetime.strptime(post['created_time'],'%Y-%m-%dT%H:%M:%S+0000')
        #print str(posted_date)
        if posted_date >= from_dt and 'message' in post:
            #print str(post)
            #print str(post['message'])
            #print str(post['type'])
            #print str(post['link'])
            if post['type'] == 'photo' :
                img = get_post_details(post['object_id'],fb_access_token,from_id)
                if img is not None:
                    ad_info['title']=post['message']
                    ad_info['description']=post['message']
                    ad_info['url']=post['link']
                    ad_info['images'] = [img['hd']['source']]
                    ad_info['imageUrls']=[{'resolutionType':'mid','url':img['small']['source']}]
                    ad_info_list.append(ad_info)
    return ad_info_list

def get_facebook_events(fb_access_token,number_of_events):
    graph = facebook.GraphAPI(access_token=fb_access_token, version='2.5')
    currentTime = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    t=graph.request("search",{ 'q' : 'Bengaluru', 'type' : 'event', 'limit' : number_of_events, 
        'since_date'  :   currentTime})
    ad_info_list = []
    for event in t['data']:
        print str(event)
        event_obj = graph.get_object(id=event['id'], fields='cover,owner,place,description')
        #print unicode(event_obj['cover'])
        #print unicode(event_obj['owner'])
        #print unicode(event_obj['place'])
        #print unicode(event_obj['description'])
        ad_info = {}
        ad_info['title']=event['name']
	if 'description' in event_obj:
        	ad_info['description']=event_obj['description']
        	if len(ad_info['description']) > 1000 :
            		ad_info['description'] = ad_info['description'][:997]+"..."
        ad_info['url']="https://www.facebook.com/events/"+event['id']
	if 'cover' in event_obj:
        	ad_info['images'] = [event_obj['cover']['source']]
        	ad_info['imageUrls']=[{'resolutionType':'mid','url':event_obj['cover']['source']}]
        evt_location = {}
        if 'place' in event_obj and 'location' in event_obj['place']:
            evt_location = event_obj['place']['location']
        ad_info["additional_info"] = [{'title':event['name'],
            'Start':event['start_time'],'End':event['end_time'],'location':evt_location}]
        print unicode(ad_info)
        ad_info_list.append(ad_info)
    return ad_info_list
        #roles = graph.get_connections(id=event_obj['id'],connection_name='admins',fields='')
        #for role in roles['data']:
            #print "####",unicode(role)
        #feed = graph.get_connections(id=event_obj['id'],connection_name='feed',fields='link')
       
            #user = graph.get_object(id=role['id'],fields='first_name,last_name,email')
            #print "-----",str(user)

if __name__ == '__main__':
    #ad_infos = get_facebook_posts(datetime.strptime("2016-12-01",'%Y-%m-%d'), "242583605801301","242583605801301", "EAACEdEose0cBAHtZCuG2YbtrkCwUkK90Ib1WayBPGRWZCKnTD7oIZCl8UJYBO4NJQgNa6lxE4WUefxZC7ikVJmYhJFoaTeRZBv0Tc2QXDiPKRKvwypxpDGH5wbggcb92K1TSxF7XDzSqhDfK59ehZC8TH7pPzbKU8nkQAJkYckTwZDZD")
    #print str(ad_infos)
    get_facebook_events("EAACEdEose0cBACBQ4WGSio6EhPw5nKG7YZCPoIUvDlphbgqmwa83UXAiZBI06aFnkL6ZA7BcYblyKFAzZCv0bB0xGUoriCDIxZBVB35HOZCH9ucuOfXO1iwgDvmTPy9ZAO2E1ZCubpKL0a6joheh3GWCW4VxGJEZBuwvuUZAnkjRGvVQZDZD",5)
