import random
import logging
import math
import time,sys,traceback
from datetime import date
from amazon.api import AmazonAPI, AmazonProduct
from lxml import objectify
from __builtin__ import str
#from serial.tools.list_ports_windows import NULL
logger = logging.getLogger("affiliateads.tasks")
import re
from affiliateads.createaffiliatecontent import create_affiliate_account, create_affiliate_playlists
from affiliateprefsprovider import get_affiliate_prefs

AMAZON_ACCESS_KEY = 'AKIAJT7JK7HIFFSEKUSQ'
AMAZON_SECRET_KEY = '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'
AMAZON_ASSOC_TAG = 'digiteyes91-21'

#################################################################################
# Converts the product information to DE product info format.
#################################################################################
def convert_item_deproduct(product):
    deproduct = {}
    deproduct['title'] = product.title
    deproduct['description'] = product.features
    deproduct['images'] = [product.large_image_url]
    deproduct['url'] = product.offer_url
    url = ''
    if product.medium_image_url is not None:
        url=product.medium_image_url
    else:
        url=product.large_image_url
    deproduct['imageUrls'] = [{"resolutionType":"mid",
        "url":url}]
    return deproduct
#################################################################################
# Looks up the product in Amazon with the given product id.
#################################################################################
def get_product(product_id):
    amazon = AmazonAPI('AKIAJT7JK7HIFFSEKUSQ', 'zxkLdkSWzY9SWLK6TezSmky2UJp6JDVPlg2Oxqeg', 'digiteyes1',region="IN")
    try:
        product = amazon.lookup(ItemId=product_id,ResponseGroup="Offers, Images,ItemAttributes")
        return convert_item_deproduct(product)
    except:
        logger.error ("ERROR"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("ERROR: "+str(tb))
        return None
    
    
#################################################################################
# Searches products with the given keywords
#################################################################################
def search_amazon_products(page,keywords,searchIndex,response):
    amazon = AmazonAPI('AKIAJT7JK7HIFFSEKUSQ', 'zxkLdkSWzY9SWLK6TezSmky2UJp6JDVPlg2Oxqeg', 'digiteyes1',region="IN")
    products=[]
    retries = 3
    while retries > 0:
        try :
            response = amazon.api.ItemSearch(Keywords=keywords, SearchIndex=searchIndex, 
                ResponseGroup=response, ItemPage=page,SearchIndex=searchIndex, 
                ResponseGroup=response, ItemPage=page)
            root = objectify.fromstring(response)
            if (hasattr(root.Items.Request, 'Errors') and
                not hasattr(root.Items, 'Item')):
                return products
            else :
                page = root
                for item in getattr(page.Items, 'Item', []):
                    products.append(AmazonProduct(item, AMAZON_ASSOC_TAG, amazon.api,
                        Keywords=keywords, SearchIndex=searchIndex, ResponseGroup=response,region='IN'))
                return products
        except :
                # Try after cooling for 10 secs.
                logger.info("Probable Throttling.. Cooling off..")
                time.sleep(10)
                retries -=1
    return products
    ##############################################################################
# Searches for offers in the given list of products.
#################################################################################
def get_Offers_list(KW,SI,RG,number):
    Offerlist = []
    page_list = []
    page=1
    while(len(Offerlist) < number and page <= 5):
        pageNo = random.randint(1, 10)
        while(pageNo in page_list):
            pageNo = random.randint(1, 20)
        page_list.append(pageNo)
        products = search_amazon_products(pageNo, KW, SI, RG)
        for product in products:
            SalePrice=str(product._safe_get_element_text(
                'Offers.Offer.OfferListing.SalePrice.FormattedPrice'))
            ListPrice=str(product._safe_get_element_text(
                'Offers.Offer.OfferListing.Price.FormattedPrice'))
            if SalePrice!="None" and ListPrice!="None" :
                SalePrice=SalePrice.strip( 'INR')
                SalePrice=SalePrice.replace(",", "")
                ListPrice=ListPrice.strip( 'INR')
                ListPrice=ListPrice.replace(",", "")
                Percentage=((float(ListPrice)-float(SalePrice))/float(ListPrice))*10
                SampleObject={}
                SampleObject['SalePrice']=str(product._safe_get_element_text(
                    'Offers.Offer.OfferListing.SalePrice.FormattedPrice'))
                SampleObject['ListPrice']=str(product._safe_get_element_text(
                    'Offers.Offer.OfferListing.Price.FormattedPrice'))
                SampleObject['Percentage']=Percentage
            
                imgobj=[]
                Himgobj={}
                Himgobj['resolutionType']="high"
                Himgobj['url']=product.large_image_url
                imgobj.append(Himgobj)
                Mimgobj={}
                Mimgobj['resolutionType']="mid"
                if product.medium_image_url is not None:
                    Mimgobj['url']=product.medium_image_url
                else:
                    Mimgobj['url']=product.large_image_url
                if product.large_image_url is None: # No image to show...do not add
                    continue
                
                imgobj.append(Mimgobj)
                SampleObject['imageUrls']=imgobj
                SampleObject['description']=product.features
                SampleObject['url']=str(product.offer_url)
                SampleObject['title']=product.title
                SampleObject['additional_info']={"Listed":ListPrice,"Sale":SalePrice,
                    "title":product.title}
                
                Offerlist.append(SampleObject)
                
        time.sleep(2)
        page +=1
        
    Offerlist=sorted(Offerlist,key=lambda x: x['Percentage'],reverse=True)
    picked=[]
    count=0
    while len(Offerlist) > count and count<5 :
        if Offerlist[count] is not None:
            picked.append(Offerlist[count])
            count=count+1
        else :
            break
    return picked
    
def create_offer_for_product_list(products,category):
    offer = {}
    offer["description"] = ""
    offer["images"] = []
    offer["additional_info"] = []
    offer["url"] = products[0]['url']
    minimum_sale = products[len(products)-1]['Percentage']
    offer["title"] = category + " " +str(math.floor(minimum_sale)*10) +"% Off"
    for product in products:
        offer["description"] += product['title'] +"  "
        offer["additional_info"].append(product["additional_info"])
        for urls in product["imageUrls"]:
            if urls["resolutionType"] == 'high':
                offer["images"].append(urls['url'])
            if urls["resolutionType"] == 'mid':
                offer['imageUrls'] = [urls]
    return offer

def get_amazon_offers(planned_date):
    prefs = get_affiliate_prefs("amazon",planned_date)
    items_list = []
    for pref in prefs:
        items_list.append({'keywords':pref.keywords,'category': pref.category,
            'response':'Offers, Images,ItemAttributes','number':pref.number_of_ads,
            'priority':pref.priority,'channels':pref.channels})
    create_affiliate_account('amazon')
    for item  in items_list:
        offerList=get_Offers_list(item['keywords'],item['category'],
            item['response'],item['number'])
        #create_affiliate_account('amazon')
        logger.info("AMAZON_AFFILIATE_CONTENT_PULL_STATS: Category : "+str(item['category'])+
                    " keyword : "+str(item['keywords'])+
                    " Number of Ads pulled : "+str(len(offerList))+
                    " Channels : "+str(len(item['channels'])))
        if(len(offerList) <= 0):
            continue
        time.sleep(2) #2 seconds 
        #final_offers_list.append(create_offer_for_product_list(offerList,item['category']))
        for each_item in offerList:
            temp_list = create_offer_for_product_list([each_item],item['category'])
            create_affiliate_playlists([temp_list],"amazon", False,item['channels'],
                item['priority'],planned_date)       
    #create_affiliate_playlists(final_offers_list,"amazon", False)
def get_amazon_offers_today():
    get_amazon_offers(date.today())
if __name__ == '__main__':
    print "I am in main()"
    #prod_info = 
    get_amazon_offers_today()
    #get_product("B00H38D74S")
    #print str(prod_info)
