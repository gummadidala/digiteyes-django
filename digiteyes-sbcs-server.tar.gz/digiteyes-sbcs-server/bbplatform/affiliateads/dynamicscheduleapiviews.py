'''
Created on 06-Oct-2016

@author: saba
'''


from rest_framework import generics, serializers
from boardcontentmgmt.models import DynamicSchedule, ConsumerCuratedPlaylists,\
    Account
from boardcontentmgmt.contentmgmt.adcontentserializers import ContentQueueSerializer
from rest_framework import filters
from rest_framework.views import APIView
from createaffiliatecontent import create_consumer_affiliate_playlist
from amazonaffiliate import get_product
from rest_framework.response import Response
from rest_framework.authentication import TokenAuthentication

class DynamicScheduleSerializer(serializers.ModelSerializer):
    play_list = ContentQueueSerializer()
    class Meta:
        model = DynamicSchedule
        fields = ('play_list','key')
class ConsumerCuratedPlaySerializer(serializers.ModelSerializer):
    class Meta:
        model = ConsumerCuratedPlaylists
        fields = ('play_list','consumer_account','priority','key')

class DynamicScheduleAPIView(generics.ListAPIView):
    authentication_classes = (TokenAuthentication,)
    serializer_class = DynamicScheduleSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('board__key','valid')
    queryset = DynamicSchedule.objects.all()

def create_play_list_for_consumer(deproduct,company, consumer):
    playlist = create_consumer_affiliate_playlist(deproduct, company)
    ccp = ConsumerCuratedPlaylists()
    ccp.consumer_account = consumer
    ccp.play_list = playlist
    ccp.priority = 1
    ccp.save()
    return ccp

class CreateCuratedPlaylists(APIView):
    def post(self,request,format = None):
        if 'affiliate' in request.data:
            affiliate_company = request.data['affiliate']
        if 'consumer' in request.data:
            consumer = request.data['consumer']
        if 'product' in request.data:
            product = request.data['product']
            
        if affiliate_company == 'amazon':
            deproduct = get_product(product)
            account = Account.objects.get(key=consumer)
            ccp = create_play_list_for_consumer(deproduct,affiliate_company,account)
            serializer = ConsumerCuratedPlaySerializer(ccp)
            return Response(serializer.data)
            
             
    
        
    
    
