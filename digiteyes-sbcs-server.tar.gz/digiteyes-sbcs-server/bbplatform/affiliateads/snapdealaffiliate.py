'''
Created on 19-Jan-2017

@author: saba
'''
import requests
import time
from datetime import date
import logging
import sys,traceback
from createaffiliatecontent import create_affiliate_account, create_affiliate_playlists
from affiliateprefsprovider import get_affiliate_prefs

logger = logging.getLogger("affiliateads.tasks")

SNAPDEAL_AFFILIATE_ID="113348"
SNAPDEAL_AFFILIATE_TOKEN="024c8016d8282092d336e8f3c98377"
SNAP_DEAL_CATEGORY_MAP = {11: u'Beauty', 2060: u'Non Electronic Accessories', 
    526: u'Boys Clothing (2-8 Yrs)', 16: u'Handbags & Clutches', 856: u'Tools & Hardware', 
    20: u'Personal Care & Grooming', 541: u'Girls Clothing (2-8 Yrs)', 
    34: u'Personal Care & Grooming', 38: u'Bags & Luggage', 42: u'Precious Jewellery', 
    52: u'Computers & Peripherals', 56: u'Computers & Peripherals', 
    58: u'Computers & Peripherals', 63: u'TVs, Audio & Video', 64: u'TVs, Audio & Video', 
    577: u'Gaming', 523: u'Movies & Music', 595: u'Health, Wellness & Medicine', 
    89: u'Kitchenware', 93: u'Tools & Hardware', 95: u'Home Improvement', 619: u'Furniture', 
    625: u'Stationery', 630: u'TVs, Audio & Video', 631: u'TVs, Audio & Video', 
    144: u'Personal Care & Grooming', 1169: u'World Food / Indian Food', 
    1172: u'Home Decoratives', 151: u'Computers & Peripherals', 153: u'TVs, Audio & Video', 
    2206: u'World Food / Indian Food', 161: u'Sports & Fitness', 675: u'Electronic Accessories', 
    167: u'Sports & Fitness', 171: u'Sports & Fitness', 176: u"Women's Ethnic Wear", 
    178: u"Women's Ethnic Wear", 179: u"Women's Ethnic Wear", 1208: u'Cameras & Accessories', 
    185: u"Women's Clothing", 191: u"Men's Clothing", 192: u"Men's Clothing", 
    193: u"Men's Clothing", 194: u"Men's Clothing", 204: u'Kitchenware', 205: u'Kitchenware', 
    211: u'Home Furnishing', 724: u"Women's Clothing", 213: u'Home Decoratives', 
    728: u'Mens Fragrances', 222: u'Home Decoratives', 228: u'Computers & Peripherals', 
    229: u'Appliances', 232: u'Kitchen Appliances', 745: u"Women's Clothing", 
    239: u'Kitchen Appliances', 2289: u'Mobiles & Tablets', 242: u'Appliances', 
    243: u'Kitchen Appliances', 244: u'Appliances', 1269: u'Household Essentials', 
    1274: u'TVs, Audio & Video', 252: u'Kitchen Appliances', 254: u"Men's Footwear", 
    767: u'General Wellness', 267: u'Appliances', 790: u'Tools & Hardware', 
    791: u'Health, Wellness & Medicine', 286: u'Computers & Peripherals', 
    288: u'TVs, Audio & Video', 300: u'Fashion Accessories', 477: u'Watches', 313: u'Automotive', 
    317: u'Automotive', 344: u'Fashion Jewellery', 345: u'Fashion Jewellery', 
    865: u'Home Improvement', 868: u'Non Electronic Accessories', 358: u"Men's Clothing", 
    359: u"Men's Clothing", 365: u'Books', 366: u'Books', 372: u'Books', 375: u'Books', 
    917: u'Online Education', 418: u'Furniture', 422: u"Women's Clothing", 
    433: u'Nutrition & Supplements', 434: u'Bags & Luggage', 436: u'Stationery', 245: u'Appliances',
    455: u'Fashion Accessories', 250: u'Appliances', 479: u'Watches', 
    679: u'Electronic Accessories', 503: u'Musical Instruments'}

def filter_based_on_category(products,categoryName,max_number):
    filtered_products = []
    count=0
    for product in products:
        prod_category = SNAP_DEAL_CATEGORY_MAP[product['subCategoryId']]
        prod_info={}
        if prod_category == categoryName:
            #print unicode(product)
            prod_info['title'] = product['title']
            prod_info['description'] = product['description']
            prod_info['url'] = product['link']
            prod_info['additional_info'] = [{"Listed":product['mrp'],"Sale":product['offerPrice'],
                    "title":prod_info['title']}]
            prod_info["images"]=[product['imageLink']]
            prod_info['imageUrls']=[{'resolutionType':'mid','url':product['imageLink']}]
            filtered_products.append(prod_info)
            count +=1
            if count >= max_number :
                break
    return filtered_products
            
def get_snapdeal_deals(planned_date):
    try:
        url='https://affiliate-feeds.snapdeal.com/feed/api/dod/offer'
        headers= {"Snapdeal-Affiliate-Id": SNAPDEAL_AFFILIATE_ID,
            "Snapdeal-Token-Id":SNAPDEAL_AFFILIATE_TOKEN,"Accept":"application/json"}
        resp = requests.get(url,headers=headers)
        offers = resp.json()
        deal_products = offers['products']
        subCategoryMap = {}
        for product in deal_products:
            if product['subCategoryId'] not in SNAP_DEAL_CATEGORY_MAP:
                subCategoryMap[product['subCategoryId']]=product['id']
                logger.info("Category not available for"+ product['subCategoryId'])
        #print unicode(subCategoryMap)
        count=0
        detail_url='https://affiliate-feeds.snapdeal.com/feed/product'
        for key in subCategoryMap:
            time.sleep(2)
            #logger.info("Getting Category info for :"+ subCategoryMap[key])
            payload = {'id':subCategoryMap[key]}
            try :
                prod_details = requests.get(detail_url,headers=headers,params=payload)
                prod = prod_details.json()
            except:
                logger.error ("SNAPDEAL_AFFILIATE_CONTENT_PULL_EEEOR"+str(sys.exc_info()[0]))
                tb = traceback.format_exc()
                logger.error ("SNAPDEAL_AFFILIATE_CONTENT_PULL_EEEOR "+str(tb))
                #logger.warn("Error in getting product details for" +subCategoryMap[key])
                continue
            #print unicode(prod_details.json())
            #print prod['subCategoryName']
            SNAP_DEAL_CATEGORY_MAP[key]= prod['categoryName']
            #print prod['categoryName']
            count +=1
            if count % 15 == 0:
                time.sleep(2)
        #print count
        #print unicode(categoryNameMap)
        create_affiliate_account('snapdeal')
        prefs = get_affiliate_prefs("snapdeal",planned_date)
        for pref in prefs:
            #logger.debug("Loading ads for "+unicode(pref.category))
            deals = filter_based_on_category(deal_products, pref.category, 
            pref.number_of_ads)
            #print unicode(deals)
            logger.info("SNAPDEAL_AFFILIATE_CONTENT_PULL_STATS : Category : "+str(pref.category)+
                            " Number of Ads pulled :"+str(len(deals))+
                            " Channels : "+str(len(pref.channels)))
            for product in deals:
                #logger.debug(""+ unicode(product))
                create_affiliate_playlists([product],"snapdeal", False,pref.channels,
                    pref.priority,planned_date)
    except:
        logger.error ("SNAPDEAL_AFFILIATE_CONTENT_PULL_EEEOR"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("SNAPDEAL_AFFILIATE_CONTENT_PULL_EEEOR "+str(tb))
    
def get_snapdeal_deals_today():
    return get_snapdeal_deals(date.today())
if __name__ == '__main__':
    get_snapdeal_deals()
    
