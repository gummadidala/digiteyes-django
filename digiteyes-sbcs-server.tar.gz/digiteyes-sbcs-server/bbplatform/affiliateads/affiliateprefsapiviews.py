'''
Created on 26-Oct-2016

@author: saba
'''
from rest_framework import serializers, generics, filters
from boardcontentmgmt.models import AffiliatePromotionPrefs, Account,\
    AccountUser, DayPart, AttributeTagGroup
from boardcontentmgmt.accountmgmt.accountserializers import AccountSerializer
from boardcontentmgmt.adpackmgmt.masteradpackserializers import DayPartSerializer
from boardcontentmgmt.permissionsmgmt.profilebasedfiltering import ProfileCheck
from boardcontentmgmt.permissionsmgmt.expirytokenauthentication import ExpiringTokenAuthentication
from rest_framework.permissions import DjangoModelPermissions, IsAuthenticated
from boardcontentmgmt.permissionsmgmt.checkPermissions import DjangoObjectPermissions
from boardcontentmgmt.tagmgmt.tagserializers import AttributeTagGroupSerializer

class AffiliatePrefsSerializer(serializers.ModelSerializer):
    account = AccountSerializer()
    preferred_daypart = DayPartSerializer()
    channels_to_promote = AttributeTagGroupSerializer(many=True)
    class Meta:
        model = AffiliatePromotionPrefs
        fields = ('key','account','category','keywords','product_ids',
            'date_from','date_to','preferred_daypart','priority','number_of_ads',
            'channels_to_promote',)
        
class AffiliatePrefsWriteSerializer(serializers.ModelSerializer):
    account = serializers.SlugRelatedField(
        queryset=Account.objects.all(),
        slug_field='key',required=False)
    preferred_daypart = serializers.SlugRelatedField(
        queryset=DayPart.objects.all(),
        slug_field='name',required=False)
    category = serializers.CharField(default="")
    keywords = serializers.CharField(default="")
    product_ids = serializers.CharField(default="")
    channels_to_promote=serializers.SlugRelatedField(
        queryset=AttributeTagGroup.objects.all(),
        many=True ,slug_field='key',required=False)
    class Meta:
        model = AffiliatePromotionPrefs
        fields = ('key','account','category','keywords','product_ids',
            'date_from','date_to','preferred_daypart','priority','number_of_ads',
            'channels_to_promote',)
    def create(self,validated_data):
        usr = self.context['request'].user
        aUsr = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['account'] = aUsr[0].account
        return serializers.ModelSerializer.create(self,validated_data)

class AffiliatePrefsListView(generics.ListCreateAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    serializer_class = AffiliatePrefsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_fields = ('content_type__type_name', 'content_state__state_name')
    search_fields = ('keywords','category','product_ids','channels_to_promote')
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'affiliatepromotionprefs') == True):
            return AffiliatePromotionPrefs.objects.all()
        else:
            return AffiliatePromotionPrefs.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return AffiliatePrefsWriteSerializer
        return AffiliatePrefsSerializer

class AffiliatePrefsUpdateView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated, DjangoModelPermissions,DjangoObjectPermissions)
    lookup_field = 'key'
    serializer_class = AffiliatePrefsSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_fields = ('content_type__type_name', 'content_state__state_name')
    search_fields = ('keywords','category','product_ids','channels_to_promote')
    def get_queryset(self):
        username = self.request.user.username
        accounts = AccountUser.objects.filter(account_user__username=username)
        acct = accounts[0].account
        if(ProfileCheck().get_filter(self.request.user,'affiliatepromotionprefs') == True):
            return AffiliatePromotionPrefs.objects.all()
        else:
            return AffiliatePromotionPrefs.objects.filter(account__key = acct.key)
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH' :
            return AffiliatePrefsWriteSerializer
        return AffiliatePrefsSerializer
    