'''
Created on 26-Oct-2016

@author: saba
'''
from boardcontentmgmt.models import AffiliatePromotionPrefs,Account,AttributeTagGroup
from datetime import datetime

def default_prefs(affiliate):
    promotion_prefs = []
    channels = AttributeTagGroup.objects.all()
    if affiliate == 'amazon':
        p1 = AffiliatePromotionPrefs()
        p1.channels = channels
        p1.category = 'Apparel'
        p1.keywords = 'Kurtis'
        p1.priority = 1
        p1.number_of_ads = 5
        promotion_prefs.append(p1)
        p2 = AffiliatePromotionPrefs()
        p2.channels = channels
        p2.category = 'Apparel'
        p2.keywords = 'kids,girls'
        p2.priority = 1
        p2.number_of_ads = 5
        promotion_prefs.append(p2)
        p3 = AffiliatePromotionPrefs()
        p3.channels = channels
        p3.category = 'Apparel'
        p3.keywords = 'Western'
        p3.priority = 1
        p3.number_of_ads = 5
        promotion_prefs.append(p3)
        p4 = AffiliatePromotionPrefs()
        p4.channels = channels
        p4.category = 'Apparel'
        p4.keywords = 'Party'
        p4.priority = 1
        p4.number_of_ads = 5
        promotion_prefs.append(p4)
        p5 = AffiliatePromotionPrefs()
        p5.channels = channels
        p5.category = 'Apparel'
        p5.keywords = 'handbags'
        p5.priority = 1
        p5.number_of_ads = 5
        promotion_prefs.append(p5)
        p6 = AffiliatePromotionPrefs()
        p6.channels = channels
        p6.category = 'Apparel'
        p6.keywords = 'Mens formal'
        p6.priority = 1
        p6.number_of_ads = 5
        promotion_prefs.append(p6)
        return promotion_prefs
    if affiliate == 'flipkart':
        p1 = AffiliatePromotionPrefs()
        p1.channels = channels
        p1.category = 'clothing'
        p1.priority = 1
        p1.number_of_ads = 5
        promotion_prefs.append(p1)
        return promotion_prefs
    if affiliate == 'indianexpress':
        p1 = AffiliatePromotionPrefs()
        p1.channels = channels
        p1.category = 'news'
        p1.priority = 1
        p1.number_of_ads = 2
        promotion_prefs.append(p1)
        p2 = AffiliatePromotionPrefs()
        p2.channels = channels
        p2.category = 'sports'
        p2.priority = 1
        p2.number_of_ads = 2
        promotion_prefs.append(p2)
        p3 = AffiliatePromotionPrefs()
        p3.channels = channels
        p3.category = 'health'
        p3.priority = 1
        p3.number_of_ads = 1
        promotion_prefs.append(p3)
        p4 = AffiliatePromotionPrefs()
        p4.channels = channels
        p4.category = 'entertainment'
        p4.priority = 1
        p4.number_of_ads = 2
        promotion_prefs.append(p4)
        return promotion_prefs
    if affiliate == 'snapdeal':
        p1 = AffiliatePromotionPrefs()
        p1.channels = channels
        p1.category = "Women's Clothing"
        p1.priority = 1
        p1.number_of_ads = 5
        promotion_prefs.append(p1)
        return promotion_prefs
    p1 = AffiliatePromotionPrefs()
    p1.channels = channels
    p1.priority = 1
    p1.number_of_ads = 5
    promotion_prefs.append(p1)
    return promotion_prefs

def get_affiliate_prefs(affiliate,planned_date):
    aff_account = Account.objects.filter(account_name=affiliate+"_affiliate")
    if aff_account is None or len(aff_account) == 0 :
        #return []
        return default_prefs(affiliate)
    today = planned_date
    promotion_prefs = AffiliatePromotionPrefs.objects.filter(account__key = 
        aff_account[0].key,date_from__lte=today,date_to__gte=today)
    if len(promotion_prefs) == 0 :
        return default_prefs(affiliate)
    for prefs in promotion_prefs:
        #channels = prefs.channels_to_promote.split(',')
        channels = prefs.channels_to_promote.all()
        prefs.channels = channels
    return promotion_prefs
    #prefs = [ {"category":"Apparel","keywords":"Kurtis","product_ids":"","date_from":"",
    #    "date_to":"","priority":"1","number_of_ads":"3",'channels':['TEST_GROUP1']}
    #    ]
    #return prefs