import requests
import random
import string
from datetime import datetime
from boardcontentmgmt.models import Content,ContentQueue,ContentTarget,CTA,CTAType, AccountType,\
    ContentState, AccountUser, UserProfile, ContentQueueType,CTAParameters
from boardcontentmgmt.models import AttributeTagGroup,Layout,SubordinateContent,ContentLabel
from boardcontentmgmt.models import ContentType, Account, ContentSchedule, AffiliateContent
from datetime import date, timedelta
from django.contrib.auth.models import User, Group
from boardcontentmgmt.permissionsmgmt.Create_UserProfiles_for_users import Create_Profile
from boardcontentmgmt.tasks import calculate_hash
from bbplatform.settings import flipkart_logo_url,amazon_logo_url,jabong_logo_url,limeroad_logo_url,\
    nnnow_logo_url,ie_logo_url,fb_events
import logging
from affiliateads.scraper import scrap_provide_contents
from affiliateads.imagebunchcreator import create_image_bunch
from Tkconstants import OFF
import json
import traceback,sys
logger = logging.getLogger("affiliateads.tasks")

def provide_logo_urls(cmpny):
    #print "Logo for company",cmpny
    if cmpny == "jabong":
        return jabong_logo_url
    elif cmpny == "paytm":
        return "https://upload.wikimedia.org/wikipedia/en/4/42/Paytm_logo.png"
    elif cmpny == "limeroad":
        return limeroad_logo_url
    elif cmpny == "nnnow":
        return nnnow_logo_url
    elif cmpny == "flipkart":
        return flipkart_logo_url
    elif cmpny == "amazon":
        return amazon_logo_url
    elif cmpny == "tatacliq":
        return "https://upload.wikimedia.org/wikipedia/commons/f/fa/TATA_Cliq_Logo.jpg"
    elif cmpny == "pepperfry":
        return "https://upload.wikimedia.org/wikipedia/commons/e/ed/Pepperfry_New_Logo.png"
    elif cmpny == "faasos":
        return "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Faasos_Logo.jpg/220px-Faasos_Logo.jpg"
    elif cmpny == "voonik":
        return "http://st1.bgr.in/wp-content/uploads/2016/06/voonik-logo.jpg"
    elif cmpny == "lurap":
        return "https://brandturks.files.wordpress.com/2016/07/lurap.jpg?w=900&h=150&crop=1"
    elif cmpny == "indianexpress":
        return ie_logo_url
    elif cmpny == 'fbevents':
        return  fb_events
    elif cmpny == 'snapdeal':
        return 'http://logos-download.com/wp-content/uploads/2016/10/SnapDeal_logo_logotype.png'
def create_subordinate_content(cntnt,i,act,type):
    sub_cnt = SubordinateContent()
    sub_cnt.name = 'SubordinateContent'+str(i)
    sub_cnt.type = ContentType.objects.get(type_name=type)
    if type == 'TEXT':
        sub_cnt.text = unicode(cntnt)
    elif type=='IMAGE':
        sub_cnt.url = cntnt
    sub_cnt.account = act
    sub_cnt.content_label = ContentLabel.objects.filter(name = "SUB"+str(i))[0]
    sub_cnt.save()
    return sub_cnt
def process_additional_info(sub_content_list,additional_info,account,index): 
    for info in additional_info:
        info_text = json.dumps(info)
        sub_content_list.append(create_subordinate_content(info_text, index, account,"TEXT"))
        index +=1
    return sub_content_list
        
def create_content(offer, account,Company_name,offer_list,need_scraping):
    cont = Content()
    cont.content_name = offer['title']+''.join(
            random.choice(string.ascii_lowercase + string.ascii_uppercase + 
            string.digits) for i in range(5))
    product_info= {"title":"","images":[]}
    cont.enable_ar=False
    if need_scraping :
        product_info = scrap_provide_contents(offer['url'],Company_name)
        if product_info is not None and len(product_info["images"]) > 0:
            url = create_image_bunch(product_info["images"],cont.content_name,5)
            cont.content_source = url
            cont.content_type = ContentType.objects.get(type_name='IMAGE_BUNCH')
            cont.content_play_time = timedelta(seconds=30)
        else :
            cont.content_type = ContentType.objects.get(type_name='IMAGE')
            for img in offer['imageUrls']:
                if img['resolutionType'] == "high":
                    cont.content_source = img['url']
    else :
        if len(offer['images']) > 1 :
            url = create_image_bunch(offer["images"],cont.content_name,5)
            cont.content_source = url
            cont.content_type = ContentType.objects.get(type_name='IMAGE_BUNCH')
            cont.content_play_time = timedelta(seconds=30)
        else :
            cont.content_type = ContentType.objects.get(type_name='IMAGE')
            cont.content_source = offer['images'][0]
            cont.content_play_time = timedelta(seconds=10)
        
    cont.account = account 
    cont.content_owner = AccountUser.objects.get(account_user__username=Company_name+"_affiliate")
    cont.content_state = ContentState.objects.get(state_name='SUBMITTED')
    cont.save()
    #calculate_hash(cont.key)
    #cont.refresh_from_db()
    #cont.content_state = ContentState.objects.get(state_name='APPROVED')
    #cont.save()
    subordinate_content_list = []
    logo_url = provide_logo_urls(Company_name)
    if need_scraping and product_info is not None:
        subordinate_content_list.append(create_subordinate_content(
            logo_url,1,account,'IMAGE'))
        subordinate_content_list.append(create_subordinate_content(
            offer['title'],2,account,'TEXT'))
        subordinate_content_list.append(create_subordinate_content(
            product_info['title'],3,account,'TEXT'))
    else :
        subordinate_content_list.append(create_subordinate_content(
            logo_url,1,account,'IMAGE'))
        subordinate_content_list.append(create_subordinate_content(
            offer['description'],2,account,'TEXT'))
        subordinate_content_list.append(create_subordinate_content(
            offer['title'],3,account,'TEXT'))
    if 'additional_info' in offer:
        #print "Getting additional Info"
        subordinate_content_list = process_additional_info(subordinate_content_list,
            offer['additional_info'],account,4)
    cont.subordinate_content = subordinate_content_list
    cont.save()
    return cont

def create_cta(offer,account,Company_name):
    cta = CTA()
    cta.type = CTAType.objects.get(name='APP')
    '''
    cta.app_name = Company_name
    cta.app_link = offer['url']
    '''
    cta.account = account
    cta.save()
    cta_param = CTAParameters()
    cta_param.name = 'app_name'
    cta_param.value = Company_name
    cta_param.account = account
    cta.cta_parameters = []
    cta_param.save()
    cta.cta_parameters.add(cta_param)
    cta.save()
    cta_param = CTAParameters()
    cta_param.name = 'app_link'
    cta_param.value = offer['url']
    cta_param.account = account
    cta_param.save()
    cta.cta_parameters.add(cta_param) 
    cta.save()   
    return cta

def create_content_target(offer,account,Company_name):
    ct = ContentTarget()
    ct.account = account
    ct.target_title = offer['title']
    ct.target_description = offer['description']
    for img in offer['imageUrls']:
        if img['resolutionType'] == "mid":
            ct.target_image_url = img['url']
    ct.save()
    return ct

def create_play_list(cont, qname,account,Company_name):
    try:
        cq = ContentQueue()
        cq.content_queue_name = qname
        cs = ContentSchedule()
        cs.content = cont
        cs.repeat = 1
        cq.account = account
        cq.content_queue_owner = AccountUser.objects.get(account_user__username=Company_name+"_affiliate")
        cq.save()
        cs.save()
        cq.content_list = [cs]
        cq.queue_state = 'SEALED'
        cq.type = ContentQueueType.objects.filter(name='NORMAL')[0]
        cq.num_units = 1
        if cont.content_type.type_name == 'IMAGE':
            cq.unit_size = 10
        else:
            cq.unit_size = 30
        #layout=Layout.objects.filter(name = "LAYERED")
        layout=Layout.objects.filter(name = "AFFILIATE_ADVERTISEMENT")
        news_layout=Layout.objects.filter(name = "NEWS")
        layered_layout = Layout.objects.filter(name = "LAYERED")
        if layout is not None and len(layout) >0:   
            cq.layout = layout[0]
        if Company_name == "indianexpress":
            cq.layout = news_layout[0]
        if Company_name in ['jabong','paytm','lurap','limeroad','microsoft','voonik','tatacliq','faasos',
                            'makemytrip','oyo','pepperfry']:
            cq.layout = layered_layout[0]
        cq.save()
        return cq
    except:
        logger.error ("create_play_list_ERROR"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("create_play_list_ERROR: "+str(tb))
#################################################################################
# Create Affiliate playlist and returns.
#################################################################################
def create_consumer_affiliate_playlist(deproduct,Company_name):
    account = Account.objects.get(account_name=Company_name+'_affiliate')
    return create_affcontents_and_playlist(deproduct, account, Company_name, 
        False)
#################################################################################
# Convenient method to create affiliate contents and playlist.
#################################################################################    
def create_affcontents_and_playlist(offer,account,Company_name, need_scraping):
    cta = create_cta(offer, account,Company_name)
    ct = create_content_target(offer, account,Company_name)
    ct.target_cta = [cta]
    ct.save()
    cont = create_content(offer, account,Company_name,None,need_scraping)
    cont.content_target = ct
    cont.save()
    CN=Company_name.capitalize()
    qname = CN+ offer['title']+''.join(
        random.choice(string.ascii_lowercase + string.ascii_uppercase + 
        string.digits) for i in range(5))
    playlist = create_play_list(cont, qname, account,Company_name)
    return playlist
    
def create_affiliate_playlists(offer_list,Company_name,need_scraping,channels,priority,planned_date):
    try:
        #logger.debug("create_affiliate_playlists started for company: "+str(Company_name))
        account = Account.objects.get(account_name=Company_name+'_affiliate')
        for offer in offer_list:
            cta = create_cta(offer, account,Company_name)
            ct = create_content_target(offer, account,Company_name)
            ct.target_cta = [cta]
            ct.save()
            cont = create_content(offer, account,Company_name,offer_list,need_scraping)
            cont.content_target = ct
            cont.save()
            CN=Company_name.capitalize()
            qname = CN+ offer['title']+''.join(
                random.choice(string.ascii_lowercase + string.ascii_uppercase + 
                string.digits) for i in range(5))
            playlist = create_play_list(cont, qname, account,Company_name)
            order = 1
            affiliate_contents = AffiliateContent.objects.filter(planned_date=planned_date,
                                                                 submitted_account__key=account.key)
            if affiliate_contents is not None and len(affiliate_contents)>0:
                order = len(affiliate_contents)+1
            aff_cont = AffiliateContent()
            aff_cont.planned_date = planned_date
            aff_cont.play_list = playlist
            aff_cont.play_order = priority
            aff_cont.num_plays = 12
            aff_cont.submitted_account = account
            aff_cont.submitted_date = datetime.now()
            aff_cont.save()
            scr_grp = []
            for channel in channels:
                grps = AttributeTagGroup.objects.filter(key=channel.key)
                if grps is not None and len(grps) > 0:
                    scr_grp.append(grps[0])
            aff_cont.screen_group = scr_grp  
            aff_cont.save()
        #logger.debug("create_affiliate_playlists completed for company: "+str(Company_name))
    except:
        logger.error ("create_affiliate_playlists_ERROR"+str(sys.exc_info()[0]))
        tb = traceback.format_exc()
        logger.error ("create_affiliate_playlists_ERROR "+str(tb))
        
def create_affiliate_playlists_today(offer_list,Company_name,need_scraping,channels,priority):
    planned_date = date.today()
    create_affiliate_playlists(offer_list, Company_name, need_scraping, 
        channels, priority, planned_date)
        
def create_affiliate_account(Company_name):
    account = Account.objects.filter(account_name=Company_name+"_affiliate")
    
    if account:
        logger.debug( Company_name +" Account exists")
        acnt = account[0]
    else :
        acct = Account()
        acct.account_name = Company_name+'_affiliate'
        acct.account_type = AccountType.objects.get(type_name='AFFILIATE ADVERTISER')
        acct.save()
        Create_Profile().AffiliateAdvertiserProfile(acct)
        acnt = acct
    profile = UserProfile.objects.filter(profile_name='Affiliate Advertiser Profile', account = acnt)
    if not profile:
        Create_Profile().AffiliateAdvertiserProfile(acnt)
    act_usr = AccountUser.objects.filter(account_user__username=Company_name+"_affiliate")
    if act_usr:
        logger.debug( Company_name +" Account User exists")
    else: 
        usr = User()
        usr.username=Company_name+"_affiliate"
        usr.email = Company_name+".affiliate@digiteyes91.com"
        FN=Company_name.capitalize()
        usr.first_name = FN
        usr.last_name = "Affiliate"
        usr.set_password("Flip321")
        usr.save()
        act_user = AccountUser()
        act_user.account_user = usr
        act_user.account = acnt
        act_user.save()
        profile = UserProfile.objects.filter(profile_name='Affiliate Advertiser Profile', account = acnt)
        #profile = UserProfile.objects.filter(profile_name='Advertiser Profile', account = acnt)
        act_user.user_profiles = profile
        act_user.save()
        for each_group in profile[0].user_groups.all():
                    act_user.account_user.groups.add(Group.objects.get(name=each_group))
                    act_user.save()     
        act_user.save()
