
from . import campaigntestdataapiviews
from . import createTestData
from django.conf.urls import url

urlpatterns = [
    url(r'^api/campaignstatstestdata/',
        campaigntestdataapiviews.CampaignStatsTestdataView.as_view()),
    url(r'^api/testconsumers/',
        campaigntestdataapiviews.CreateTestConsumers.as_view()),
    url(r'^api/testdata/',
        createTestData.Test_DataAPIView.as_view()),
    ]