from rest_framework.views import APIView
from boardcontentmgmt.models import AccountUser
from createcampaignteststats import create_dummy_campaign_stats_for_running_campaigns
from createtestconsumers import create_dummy_consumers
from rest_framework.response import Response
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from .tasks import create_dummy_campaign_stats_for_running_campaigns_task
import logging
logger = logging.getLogger(__name__)
class CampaignStatsTestdataView(APIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    def post(self,request):
        reach = int(request.data['reach'])
        interest = int(request.data['interest'])
        action = int(request.data['action'])
        if 'user' in request.data :
            user = request.data['user']
        act_users = AccountUser.objects.filter(account_user__username=
            request.user.username)
        act_user = act_users[0]
        if user is not None:
            act_user = AccountUser.objects.filter(account_user__username=
                user) [0]
        create_dummy_campaign_stats_for_running_campaigns_task.delay(str(act_user.account.key),reach,
            interest,action)
        return Response ({'staus': 'Success'})
class CreateTestConsumers(APIView):
    def post(self,request):
        consumers = int(self.request.data['consumers'])
        create_dummy_consumers(consumers)
        return Response ({'staus': 'Success'})