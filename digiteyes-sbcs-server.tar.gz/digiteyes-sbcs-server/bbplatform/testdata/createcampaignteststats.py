
from boardcontentmgmt.models import AdvtCampaign, ConsumerContentTargets,Account
from boardcontentmgmt.models import AccountUser, UserInitiatedCTA,BookedAdPack
from boardcontentmgmt.models import CampaignInterests
from datetime import timedelta, datetime
import random
import logging
logger = logging.getLogger(__name__)

def create_consumer_target_record(show_spot,content_target,campaign,date,account):
    target = ConsumerContentTargets()
    target.show_spot_location_lat = show_spot.spot_location_lat
    target.show_spot_location_long = show_spot.spot_location_long
    target.show_spot_location_key = show_spot.key
    if len(show_spot.attached_beacons.all()) > 0 :
        target.show_spot_beacon_touched = show_spot.attached_beacons.all()[0].mac_address
    target.show_spot_location_image_url = show_spot.spot_location_image_url
    target.content_target = content_target
    timestamp = datetime.now()
    dtimestamp = timestamp.replace(date.year,date.month,date.day)
    target.time = dtimestamp
    target.campaign = campaign.key
    target.account = account
    target.save()

def create_interest_record(campaign,account,content_target,date):
    interest = CampaignInterests()
    users = AccountUser.objects.filter(account__key=account.key)
    interest.interested_user = users[0] 
    interest.interested_content = content_target
    interest.assoc_campaign = campaign
    timestamp = datetime.now()
    dtimestamp = timestamp.replace(date.year,date.month,date.day)
    interest.interest_time = dtimestamp
    interest.account = account    
    
def create_cta_acted(campaign,account,content_target,date):
    acted = UserInitiatedCTA()
    users = AccountUser.objects.filter(account__key=account.key)
    acted.interested_user = users[0] 
    ctas = content_target.target_cta.all()
    if len(ctas) > 0 :
        random_cta = random.randint(0, len(ctas)-1)
    else :
        logger.debug("No CTA found")
        return
    acted.initiated_cta = ctas[random_cta]
    acted.assoc_campaign = campaign
    timestamp = datetime.now()
    dtimestamp = timestamp.replace(date.year,date.month,date.day)
    acted.cta_time = dtimestamp
    acted.account = account
    
def create_stats_for_day(campaign,date,reach_number,interest_num,action_num):
    logger.debug("create stats"+str(date)+","+str(reach_number)+","+str(interest_num)
        +","+str(action_num))
    adpacks = BookedAdPack.objects.filter(applied_to__key = campaign.key)
    screens = []
    spots = []
    for bpack in adpacks:
        screens.append(bpack.booked_screen)
        spots.append(bpack.booked_screen.show_spot)
    play_list = campaign.play_list
    contents = []
    logger.debug("Play list:"+play_list.content_queue_name)
    logger.debug("Spots :"+str(spots))
    for schedule in play_list.content_list.all():
        contents.append(schedule.content)
    logger.debug("Contents :"+str(contents))
    accounts = Account.objects.filter(account_name__contains='TestDummy')
    while reach_number > 0:
        for account in accounts:
            random_spot = random.randint(0, len(spots)-1)
            random_content = random.randint(0, len(contents)-1)
            logger.debug("Random Spot :"+str(random_spot))
            logger.debug("Random Content :"+str(random_content))
            if contents[random_content].content_target is None:
                logger.warn("Non content target available")
                reach_number=0
                break
            create_consumer_target_record(spots[random_spot], 
                contents[random_content].content_target, campaign, date, account)
            reach_number -= 1
            if reach_number == 0 :
                break
    
    while interest_num > 0:
        logger.debug("Creating Interest records")
        for account in accounts:
            random_content = random.randint(0, len(contents)-1)
            if contents[random_content].content_target is None:
                logger.warn("Non content target available")
                interest_num=0
                break
            create_interest_record(campaign, 
                account,contents[random_content].content_target, date )
            interest_num -= 1
            if interest_num == 0 :
                break
    while action_num > 0:
        logger.debug("Creating Action records")
        for account in accounts:
            random_content = random.randint(0, len(contents)-1)
            if contents[random_content].content_target is None:
                logger.warn("Non content target available")
                action_num=0
                break
            create_cta_acted(campaign, 
                account,contents[random_content].content_target, date )
            action_num -= 1
            if action_num == 0 :
                break

    
def create_test_stats(campaign,reach_number,interest_number,action_number):
    start_date = campaign.planned_start_date;
    end_date = campaign.planned_end_date;
    curr_date = start_date
    reach_num = reach_number
    interest_num = interest_number
    action_num = action_number
    
    while curr_date <= end_date:
        if curr_date == end_date:
                reach_num = reach_number
                interest_num = interest_number
                action_num = action_number
        else:
            if reach_number > 1 :
                reach_num = random.randint(1, reach_number)
            else :
                reach_num = reach_number
            if interest_number > 0 :
                interest_num = random.randint(1,interest_number)
            else :
                interest_num = interest_number
            if action_number > 0: 
                action_num = random.randint(1,action_number)
            else :
                action_num = action_number
        create_stats_for_day(campaign,curr_date,reach_num,interest_num,action_num)
        reach_number -= reach_num
        interest_number -= interest_num
        action_number -= action_num
        curr_date = curr_date + timedelta(days=1)    

def create_dummy_campaign_stats_for_running_campaigns(account,reach,interest,action):
    campaigns = AdvtCampaign.objects.filter(account__key = account, 
        state__state_name = 'RUNNING')
    for campaign in campaigns:
        logger.debug("Inserting test campaign data for :"+str(campaign.key))
        create_test_stats(campaign,reach,interest,action)
    
    