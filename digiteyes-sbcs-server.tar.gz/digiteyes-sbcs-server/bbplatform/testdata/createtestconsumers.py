import random,string
from boardcontentmgmt.consumermgmt.consumerapiviews import create_consumer_account, create_user
from boardcontentmgmt.models import AccountUser,UserProfile
from boardcontentmgmt.permissionsmgmt.Create_UserProfiles_for_users import Create_Profile


import logging
logger = logging.getLogger(__name__)
#################################################################################
#
#################################################################################
def create_dummy_consumer(index):
    user_name = ''+str(index)+''.join(random.choice(string.ascii_lowercase + 
        string.ascii_uppercase + string.digits) for i in range(12))
    firstname = "First Name:"+user_name
    lastname = "Last Name:"+user_name
    email=user_name+"@test.com"
    usr = create_user(user_name,firstname,lastname,email)
    return usr
def create_dummy_account(account_name):
    return create_consumer_account("TestDummy:"+account_name)
def create_dummy_consumers(count):
    for i in range(count):
        usr = create_dummy_consumer(i)
        account = create_dummy_account(usr.username)
        act_user = AccountUser()
        act_user.account_user = usr
        act_user.account = account
        act_user.save()
        #assigning user profile
        Create_Profile().ConsumerProfile(account)
        act_user.user_profiles = UserProfile.objects.filter(profile_name=
            'Consumer Profile', account = act_user.account)
        act_user.save()

    
    
    