from __future__ import absolute_import
from celery import shared_task
from testdata.createcampaignteststats import create_dummy_campaign_stats_for_running_campaigns

import logging
logger = logging.getLogger(__name__)

@shared_task
def create_dummy_campaign_stats_for_running_campaigns_task(account_key,
        reach,interest,action):
    logger.info("Task create_dummy_campaign_stats_for_running_campaigns_task START")
    create_dummy_campaign_stats_for_running_campaigns(account_key,reach,interest,action)
    logger.info("Task create_dummy_campaign_stats_for_running_campaigns_task END")