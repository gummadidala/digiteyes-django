from boardcontentmgmt.models import Content , AccountUser , ContentQueue, CTA, ContentTarget
from boardcontentmgmt.models import ShowSpotAsset , Board, BoardPlayHistory, ContentState
from boardcontentmgmt.models import BookedAdPack,AdvtCampaign,BookingState,DayPart,CampaignState,Account
from boardcontentmgmt.models import SpotLocationType,AttributeTagGroup,PrimaryLocationTag,PrimaryAttributeTag
from boardcontentmgmt.models import ShowSpotAssetState,SignalQuality,ScreenOrientation,Beacon,ScreenSize,ScreenStatus
from datetime import datetime,timedelta
import string, random
from rest_framework.views import APIView
import math
from boardcontentmgmt.utilities.freeslotutilities import find_diff_in_secs
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED

import logging
logger = logging.getLogger(__name__)

BoarSerialNums = []

def generate_beacon_key():
    b_key = ''.join(random.choice(string.ascii_lowercase + string.ascii_uppercase + string.digits) 
        for i in range(4))
    spots = Board.objects.filter(beacon_key = b_key)
    if len(spots) > 0:
        generate_beacon_key()
    else:
        return b_key

def num_units_booked(date,brd,day_part):
    bps = BookedAdPack.objects.filter(date_booked_for = date, booked_screen__key = brd.key,day_part_booked_for = day_part)
    units = 0
    for b in bps:
        units += b.num_plays * b.units_per_play 
    return units
    
def generate_board_name():
    b_name = ''.join(random.choice(string.ascii_lowercase + string.ascii_uppercase + string.digits) for i in range(5))
    brds = Board.objects.filter(board_name = b_name)
    if len(brds) > 0:
        generate_board_name()
    else:
        return b_name

def generate_board_serial_num():
    serial_num = ''.join(random.choice(string.digits) for i in range(12))
    brds = Board.objects.filter(board_serial_number = serial_num)
    if len(brds) > 0:
        generate_board_serial_num()
    else:
        return serial_num
    
def create_test_campaign(num_plays,date,brd,day_part,cnt_q):
    acct = Account.objects.filter(account_name='ADVT-TEST')
    #content_queue = ContentQueue.objects.filter(account = acct[0]).all()
    logger.info( 'length of the content queue for day part:'+str(day_part.name)+' is:'+str(len(cnt_q)))
    for cntnt in cnt_q:
        units_booked = num_units_booked(date,brd,day_part)
        #print 'units_booked:',units_booked
        td_sec = find_diff_in_secs(day_part.from_time,day_part.to_time)
        total_units = math.floor(0.9*(td_sec/30))   # taking only 80% of available free units
        remaing_units = total_units - units_booked
        logger.info('Total units:'+str(total_units))
        logger.info( 'total units_booked already:'+str(units_booked))
        logger.info( 'remaining units available:'+str(remaing_units))
        if  remaing_units > 0:
            if(remaing_units < num_plays*cntnt.num_units):
                num_plays = remaing_units/cntnt.num_units
            logger.info( 'number of units going to book:'+ str(num_plays*cntnt.num_units))
            bap = BookedAdPack()
            bap.booked_screen = Board.objects.filter(key = brd.key)[0]
            bap.date_booked_for = date
            success = BookingState.objects.filter(name = 'SUCCESS')[0]
            bap.booking_state = success 
            bap.when_booked = datetime.now().date()
            bap.num_plays = num_plays
            bap.day_part_booked_for = DayPart.objects.filter(name = day_part.name)[0]
            bap.price = 0
            bap.account = acct[0]
            bap.booking_type = 'test_booking'
            
            campaign = AdvtCampaign()
            campaign.name ='camp-' + cntnt.content_queue_name +'-'+ day_part.name
            usr = AccountUser.objects.filter(account = acct[0])
            campaign.owner = usr[0]
            campaign.created_date = datetime.now().date()
            campaign.planned_start_date = datetime.now().date()
            #campaign.planned_end_date = datetime.now().date()+timedelta(days=3)
            campaign.planned_end_date = datetime.now().date()
            campaign.state = CampaignState.objects.filter(state_name = 'PLANNED')[0]
            campaign.selected_plays_per_day = num_plays
            campaign.screen_selection_tags = ""
            campaign.total_screens_selected = 1
            campaign.dayPart_selected = DayPart.objects.filter(name = day_part.name)[0] 
            campaign.account = acct[0]
            campaign.play_list = cntnt
            bap.units_per_play = cntnt.num_units
            bap.unit_size = cntnt.unit_size
            campaign.save()
            bap.applied_to = campaign
            bap.save()
            logger.info('campaign created for plays:'+str(num_plays)+' units per play:'+str(cntnt.num_units)+' brd:'+str(brd.board_name)+ ' day_part:'+str(day_part.name)+' date:'+str(date))

def create_board(show_spot,acct,actusr,cnt_q,beacon_mac_address):
    brd= Board()
    brd.account = acct
    brd.board_owner = actusr
    brd.board_name = generate_board_name()
    brd.board_location_lat = show_spot.spot_location_lat
    brd.board_location_long = show_spot.spot_location_long
    brd.board_address = 'hsr-layout'
    brd.board_city = 'bnglr'
    brd.board_size = ScreenSize.objects.filter(name = '48')[0]
    brd.board_serial_number = generate_board_serial_num()
    brd.beacon_key = generate_beacon_key()
    serialnum = {}
    serialnum['brd_serial_num'] = brd.board_serial_number
    serialnum['beacon'] = beacon_mac_address
    BoarSerialNums.append(serialnum)
    brd.show_spot = show_spot
    brd.board_state = ScreenStatus.objects.filter(name = 'CREATED')[0]
    brd.save()
    logger.info( 'board created. Name:'+str(brd.board_name) +'Serial num:'+str(brd.board_serial_number))
    #cerate test campaign accross all the day parts
    num_plays = 12 
    dt = datetime.now().date()
    day_parts = DayPart.objects.all()
    for dp in day_parts:
        create_test_campaign(num_plays,dt,brd,dp,cnt_q)


def create_test_showspots(beacon_mac_address,cnt_q,latitutde,longitude,image_url,z):
    acct = Account.objects.filter(account_name='DE Production')[0]
    actusr = AccountUser.objects.filter(account = acct)[0]
    b = Beacon.objects.filter(mac_address = beacon_mac_address)
    prev_show_spots_with_given_beacon = ShowSpotAsset.objects.filter(attached_beacons__in = b)
    if prev_show_spots_with_given_beacon is not None:
        for each_spot in prev_show_spots_with_given_beacon:
            each_spot.attached_beacons = []
            each_spot.save()
    show_spot = ShowSpotAsset()
    show_spot.account = acct
    show_spot.spot_location_lat  = latitutde
    show_spot.spot_location_long = longitude
    show_spot.name = 'test-show-spot'
    show_spot.spot_location_floor = '1'
    show_spot.spot_location_type = SpotLocationType.objects.filter(name = 'Indoor')[0]
    show_spot.asset_state = ShowSpotAssetState.objects.filter(name = 'APPROVED')[0]
    show_spot.spot_suggested_screen_size = ScreenSize.objects.filter(name = '40')[0]
    show_spot.spot_suggested_screen_orientation = ScreenOrientation.objects.filter(name = 'Landscape')[0]
    show_spot.signal_quality_3g = SignalQuality.objects.filter(name = 'Average')[0]
    show_spot.signal_quality_4g = SignalQuality.objects.filter(name = 'Average')[0]
    show_spot.save()
    loc_tag = PrimaryLocationTag.objects.filter(name = "TEST_LOCATION"+str(z))
    if loc_tag is not None and len(loc_tag) > 0:
        spots_with_loc_tag = ShowSpotAsset.objects.filter(attached_primary_location_tag__name = loc_tag[0].name)
        if spots_with_loc_tag is not None and len(spots_with_loc_tag) > 0:
            for spt in spots_with_loc_tag:
                spt.attached_primary_location_tag = None
                spt.save()
        show_spot.attached_primary_location_tag = loc_tag[0]
        show_spot.save()
    else:
        loc_tag = PrimaryLocationTag()
        loc_tag.name = "TEST_LOCATION"+str(z)
        loc_tag.tag_owner = actusr
        loc_tag.account = acct
        loc_tag.save()
        show_spot.attached_primary_location_tag = loc_tag
        show_spot.save()
    attrib_tag = PrimaryAttributeTag.objects.filter(name = "TEST_ATTRIBUTE"+str(z))
    if attrib_tag is not None and len(attrib_tag) > 0:
        spots_with_attrib_tag = ShowSpotAsset.objects.filter(attached_primary_attribute_tag__name = attrib_tag[0].name)
        if spots_with_attrib_tag is not None and len(spots_with_attrib_tag) > 0:
            for spt in spots_with_attrib_tag:
                spt.attached_primary_attribute_tag = None
                spt.save()
        show_spot.attached_primary_attribute_tag = attrib_tag[0]
        show_spot.save()
    else:
        attrib_tag = PrimaryAttributeTag()
        attrib_tag.name = "TEST_ATTRIBUTE"+str(z)
        attrib_tag.tag_owner = actusr
        attrib_tag.account = acct
        attrib_tag.save()
        show_spot.attached_primary_attribute_tag = attrib_tag
        show_spot.save()
    grp_tag = AttributeTagGroup.objects.filter(name = "TEST_GROUP"+str(z))
    if grp_tag is not None and len(grp_tag) > 0:
        spots_with_grp_tag = ShowSpotAsset.objects.filter(attached_attribute_tag__name = grp_tag[0].name)
        if spots_with_grp_tag is not None and len(spots_with_grp_tag) > 0:
            for spt in spots_with_grp_tag:
                spt.attached_attribute_tag = []
                spt.save()
        show_spot.attached_attribute_tag = [grp_tag[0],]
        show_spot.save()
    else:
        grp_tag = AttributeTagGroup()
        grp_tag.name = "TEST_GROUP"+str(z)
        grp_tag.tag_owner = actusr
        grp_tag.account = acct
        AttributeTagGroup.add_root(instance=grp_tag)
        show_spot.attached_attribute_tag = [grp_tag,]
        show_spot.save()
    show_spot.spot_location_image_url = image_url
    show_spot_location_type = SpotLocationType.objects.filter(name = 'Indoor')[0]
    show_spot.spot_location_type = show_spot_location_type
    show_spot.asset_state = ShowSpotAssetState.objects.filter(name = 'APPROVED')[0]
    show_spot.signal_quality_3g = SignalQuality.objects.filter(name  = 'Average')[0]
    show_spot.signal_quality_4g = SignalQuality.objects.filter(name  = 'Average')[0]
    show_spot.spot_suggested_screen_size = ScreenSize.objects.filter(name= '48')[0]
    show_spot.spot_suggested_screen_orientation = ScreenOrientation.objects.filter(name = 'Landscape')[0]
    show_spot.save()
    if(len(b) > 0):
        show_spot.attached_beacons = [b[0],]
        #raise ValueError("This beacon is already assigned to another screen!")
    else:
        bcn = Beacon()
        bcn.name = 'test-beacon'
        bcn.manufacturer = 'Google'
        bcn.namespace = 'test-namespace'
        bcn.bluetooth_name = 'ble'
        bcn.url = 'www.google.com'
        bcn.instance_id = 'test-id'
        bcn.mac_address = beacon_mac_address
        bcn.account = acct
        bcn.tx_power = '10.0'
        bcn.save()
        show_spot.attached_beacons = [bcn,]
    show_spot.save()
    logger.info( 'Show spot created')
    logger.info( 'start creating board')
    #create a screen and assign show spot
    create_board(show_spot,acct,actusr,cnt_q,beacon_mac_address)
    
class Test_DataAPIView(APIView):
    def post(self,request):
        num_screen = int(self.request.query_params.get('num_screen', None))
        beacon_mac_address = self.request.query_params.get('beacon_mac_address', None)
        contents_account = self.request.query_params.get('contents_account', None)
        logger.info( "num_screen:"+str(num_screen))
        logger.info( 'all beacon_mac_address'+str(beacon_mac_address))
        bcns = beacon_mac_address.split(',')
        acct = Account.objects.filter(account_name=contents_account)
        content_queue = ContentQueue.objects.filter(account = acct[0]).all()
        logger.info( 'length of full content queue:'+str(len(content_queue)))
        cnt_q = []
        i = 0
        k = 0
        while i <= num_screen-1:
            latitutde = ''
            longitude = ''
            image_url = ''
            #create test-show-spot
            logger.info( 'beacon-mac-address:'+str(bcns[i]))
            for k in range(len(content_queue)):
                #if(i == 0 and k <= 5):
                if(i == 0 and k <= (len(content_queue)/num_screen - 1)):
                    logger.info('content_Q_name:'+str(content_queue[k].content_queue_name))
                    cnt_q.append(content_queue[k])
                    latitutde = '12.906896'
                    image_url = 'https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/download.jpg'
                    longitude = '77.633223'
                #elif(i==1 and k >=6 and k <= 11):
                elif(i==1 and k >=len(content_queue)/num_screen and k <= 2*(len(content_queue)/num_screen)-1):
                    logger.info('content_Q_name:'+str(content_queue[k].content_queue_name))
                    cnt_q.append(content_queue[k])
                    latitutde = '12.993379'
                    longitude = '77.730280'
                    image_url = 'https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/images.jpg'
                #elif(i==2 and k >=12 and k <= 17):
                elif(i==2 and k >=2*(len(content_queue)/num_screen) and k <= 3*(len(content_queue)/num_screen)-1):
                    logger.info('content_Q_name:'+str(content_queue[k].content_queue_name))
                    cnt_q.append(content_queue[k])
                    latitutde = '12.979854'
                    longitude = '77.511534'
                    image_url = 'https://ruga-boardcontentmgmt-uploaded-media-content.s3-us-west-2.amazonaws.com/images%20%281%29.jpg'
            create_test_showspots(bcns[i],cnt_q,latitutde,longitude,image_url,i+1)
            cnt_q = []
            i = i+1
        return Response(BoarSerialNums)
        
