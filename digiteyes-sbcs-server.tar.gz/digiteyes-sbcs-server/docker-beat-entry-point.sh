#!/bin/sh
celery -A bbplatform beat --logfile=/var/log/beat.log
