#!/bin/sh
echo "Starting Celery" >> /var/log/celery_error.log
date >> /var/log/celery_error.log
celery -A bbplatform worker --logfile=/var/log/celery.log 2> /var/log/celery_error1.log
