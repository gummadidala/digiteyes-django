#!/bin/sh
echo "Stop Client App.."
sudo docker service rm clientapp
echo "Done"
echo "Stop Load Balancer..."
sudo docker service rm web
echo "Done"
echo "Stop Django app..."
sudo docker service rm app
echo "Done"
echo "Stop Celery..."
sudo docker service rm celery
echo "Done"
echo "Stop Beat.."
sudo docker service rm beat
echo "Done"
echo "Stop Mysql Proxy.."
sudo docker service rm mysqldb
echo "Done"
echo "Stop Redis..."
sudo docker service rm redis
echo "Done"
echo "Stop LogServer..."
sudo docker service rm logserver 
echo "Done"
echo "Stop Front..."
sudo docker service rm front 
echo "Done"
echo "All Service Stopped"
echo "Service Status"
sudo docker service ls
