####################################################################
# Commands for deploying various services across nodes
# in a docker swarm
#
####################################################################
#!/bin/sh
dbVersion=`./getCurrentVersion.sh mysqldb`
webVersion=`./getCurrentVersion.sh web`
appVersion=`./getCurrentVersion.sh app`
celeryVersion=`./getCurrentVersion.sh celery`
beatVersion=`./getCurrentVersion.sh beat`
frontVersion=`./getCurrentVersion.sh front`
# Deploy Redis
echo "Deploy redis..."
sudo docker service create \
	--name redis \
	--network adiotnw \
	--label redis redis
echo "Done"
sleep 5
#echo "Deploy mysql proxy"
#sudo docker service create \
#	--name mysqldb \
#	--network adiotnw \
#	--publish 3309:3309 \
#	--label mysqldb digiteyes91/haproxy:2.2
#echo "Done"
# Deploy Mysql
echo "Deploy mysql..."
sudo docker service create \
	--name mysqldb \
	--label mysqldb \
	--env MYSQL_ROOT_PASSWORD=Production321 \
	--publish 3306:3306 \
	--mount type=bind,source=/var/lib/mysql,destination=/var/lib/mysql \
	--mount type=bind,source=/var/log/mysql,destination=/var/log/mysql \
	--network adiotnw \
	--constraint 'node.role == manager' digiteyes91/db:$dbVersion
echo "Done"
sleep 5
# Deploy django app
echo "Deploy Web App..."
sudo docker service create \
	--name app \
	--label app \
	--env BIND_PORT=8001 \
	--network adiotnw \
	--mount type=bind,source=/var/log,destination=/var/log digiteyes91/adiotserver:$appVersion
echo "Done"
sleep 5
# Deploy Celery 
echo "Deploy Celery..."
sudo docker service create \
	--replicas 2 \
	--name celery \
	--label celery \
	--network adiotnw \
	--mount type=bind,source=/var/log,destination=/var/log digiteyes91/adiotcelery:$celeryVersion
echo "Done"
sleep 5
# Deploy Beat 
echo "Deploy Beat..."
sudo docker service create \
	--name beat \
	--label beat \
	--network adiotnw \
	--mount type=bind,source=/var/log,destination=/var/log digiteyes91/adiotbeat:$beatVersion
echo "Done"
sleep 5
# Deploy Load Balancer 
echo "Deploy Load Balancer..."
sudo docker service create \
	--name web \
	--label web \
	--mount type=bind,source=/var/log/nginx,destination=/var/log/nginx \
	--network adiotnw digiteyes91/adiotloadbalancer:$webVersion
echo "Done"
sleep 5
# Deploy Client App 
echo "Deploy client app..."
sudo docker service create \
	--name clientapp \
	--label clientapp \
	--network adiotnw \
	--mount type=bind,source=/var/log/nginx,destination=/var/log/nginx \
	 digiteyes91/adiotclientapp:2.0.13
echo "Done"
sleep 2
# Deploy Front Nginx
echo "Deploy Front Nginx..."
sudo docker service create \
	--name front \
	--label front \
	--network adiotnw \
	--publish 80:80 \
	--publish 443:443 \
	--mount type=bind,source=/var/log/nginx,destination=/var/log/nginx \
        --mount type=bind,source=/etc/ssl,destination=/etc/ssl \
        --constraint 'node.role == manager' digiteyes91/front:$frontVersion

	
echo "Deploy Log server..."
sudo docker service create \
	--name logserver \
	--label logserver \
	--network adiotnw \
	--publish 2222:22 \
	--mount type=bind,source=/var/devicelogs,destination=/home/deviceuser/share \
	--constraint 'node.role == manager' atmoz/sftp \
	deviceuser:AsDF13:1001
echo "Done"
	 
	 
echo "Deployment completed ... " 
sleep 5
echo "Service Status"
sudo docker service ls

