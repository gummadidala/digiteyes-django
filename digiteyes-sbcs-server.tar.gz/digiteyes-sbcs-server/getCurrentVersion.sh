#!/bin/bash
tag=$1
versionTag=`grep $tag image-versions.txt`
#echo $versionTag
currentVersion=`echo $versionTag | cut -f2 -d"="`
echo $currentVersion

