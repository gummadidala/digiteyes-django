#!/bin/bash
sudo docker build --file=HAProxyDockerFile  . -t digiteyes91/haproxy:2.4
